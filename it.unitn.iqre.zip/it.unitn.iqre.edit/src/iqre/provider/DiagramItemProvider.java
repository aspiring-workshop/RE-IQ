/**
 */
package iqre.provider;


import iqre.Diagram;
import iqre.IqreFactory;
import iqre.IqrePackage;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link iqre.Diagram} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class DiagramItemProvider 
	extends ItemProviderAdapter
	implements
		IEditingDomainItemProvider,
		IStructuredItemContentProvider,
		ITreeItemContentProvider,
		IItemLabelProvider,
		IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DiagramItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addRoleElementPropertyDescriptor(object);
			addGoalElementPropertyDescriptor(object);
			addGoalInstenceElementPropertyDescriptor(object);
			addAgentElementPropertyDescriptor(object);
			addTaskInstenceElementPropertyDescriptor(object);
			addTaskElementPropertyDescriptor(object);
			addInformationElementPropertyDescriptor(object);
			addReadsElementPropertyDescriptor(object);
			addProducesElementPropertyDescriptor(object);
			addSendsElementPropertyDescriptor(object);
			addDelegationElementPropertyDescriptor(object);
			addInformationProvisionElementPropertyDescriptor(object);
			addDelegationTrustElementPropertyDescriptor(object);
			addProvisionTrustElementPropertyDescriptor(object);
			addProduceTrustElemetPropertyDescriptor(object);
			addSoftgoalElementPropertyDescriptor(object);
			addQualityConstraintElementPropertyDescriptor(object);
			addScopeElelemtPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Role Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addRoleElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Diagram_roleElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Diagram_roleElement_feature", "_UI_Diagram_type"),
				 IqrePackage.Literals.DIAGRAM__ROLE_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Goal Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addGoalElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Diagram_goalElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Diagram_goalElement_feature", "_UI_Diagram_type"),
				 IqrePackage.Literals.DIAGRAM__GOAL_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Goal Instence Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addGoalInstenceElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Diagram_goalInstenceElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Diagram_goalInstenceElement_feature", "_UI_Diagram_type"),
				 IqrePackage.Literals.DIAGRAM__GOAL_INSTENCE_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Agent Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAgentElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Diagram_agentElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Diagram_agentElement_feature", "_UI_Diagram_type"),
				 IqrePackage.Literals.DIAGRAM__AGENT_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Task Instence Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTaskInstenceElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Diagram_taskInstenceElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Diagram_taskInstenceElement_feature", "_UI_Diagram_type"),
				 IqrePackage.Literals.DIAGRAM__TASK_INSTENCE_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Task Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTaskElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Diagram_taskElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Diagram_taskElement_feature", "_UI_Diagram_type"),
				 IqrePackage.Literals.DIAGRAM__TASK_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Information Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addInformationElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Diagram_informationElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Diagram_informationElement_feature", "_UI_Diagram_type"),
				 IqrePackage.Literals.DIAGRAM__INFORMATION_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Reads Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addReadsElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Diagram_readsElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Diagram_readsElement_feature", "_UI_Diagram_type"),
				 IqrePackage.Literals.DIAGRAM__READS_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Produces Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addProducesElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Diagram_producesElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Diagram_producesElement_feature", "_UI_Diagram_type"),
				 IqrePackage.Literals.DIAGRAM__PRODUCES_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Sends Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addSendsElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Diagram_sendsElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Diagram_sendsElement_feature", "_UI_Diagram_type"),
				 IqrePackage.Literals.DIAGRAM__SENDS_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Delegation Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDelegationElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Diagram_delegationElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Diagram_delegationElement_feature", "_UI_Diagram_type"),
				 IqrePackage.Literals.DIAGRAM__DELEGATION_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Information Provision Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addInformationProvisionElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Diagram_informationProvisionElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Diagram_informationProvisionElement_feature", "_UI_Diagram_type"),
				 IqrePackage.Literals.DIAGRAM__INFORMATION_PROVISION_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Delegation Trust Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDelegationTrustElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Diagram_delegationTrustElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Diagram_delegationTrustElement_feature", "_UI_Diagram_type"),
				 IqrePackage.Literals.DIAGRAM__DELEGATION_TRUST_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Provision Trust Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addProvisionTrustElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Diagram_provisionTrustElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Diagram_provisionTrustElement_feature", "_UI_Diagram_type"),
				 IqrePackage.Literals.DIAGRAM__PROVISION_TRUST_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Produce Trust Elemet feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addProduceTrustElemetPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Diagram_produceTrustElemet_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Diagram_produceTrustElemet_feature", "_UI_Diagram_type"),
				 IqrePackage.Literals.DIAGRAM__PRODUCE_TRUST_ELEMET,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Softgoal Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addSoftgoalElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Diagram_softgoalElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Diagram_softgoalElement_feature", "_UI_Diagram_type"),
				 IqrePackage.Literals.DIAGRAM__SOFTGOAL_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Quality Constraint Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addQualityConstraintElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Diagram_qualityConstraintElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Diagram_qualityConstraintElement_feature", "_UI_Diagram_type"),
				 IqrePackage.Literals.DIAGRAM__QUALITY_CONSTRAINT_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Scope Elelemt feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addScopeElelemtPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Diagram_scopeElelemt_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Diagram_scopeElelemt_feature", "_UI_Diagram_type"),
				 IqrePackage.Literals.DIAGRAM__SCOPE_ELELEMT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Collection getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(IqrePackage.Literals.DIAGRAM__ROLE_ELEMENT);
			childrenFeatures.add(IqrePackage.Literals.DIAGRAM__GOAL_ELEMENT);
			childrenFeatures.add(IqrePackage.Literals.DIAGRAM__GOAL_INSTENCE_ELEMENT);
			childrenFeatures.add(IqrePackage.Literals.DIAGRAM__AGENT_ELEMENT);
			childrenFeatures.add(IqrePackage.Literals.DIAGRAM__TASK_INSTENCE_ELEMENT);
			childrenFeatures.add(IqrePackage.Literals.DIAGRAM__TASK_ELEMENT);
			childrenFeatures.add(IqrePackage.Literals.DIAGRAM__INFORMATION_ELEMENT);
			childrenFeatures.add(IqrePackage.Literals.DIAGRAM__READS_ELEMENT);
			childrenFeatures.add(IqrePackage.Literals.DIAGRAM__PRODUCES_ELEMENT);
			childrenFeatures.add(IqrePackage.Literals.DIAGRAM__SENDS_ELEMENT);
			childrenFeatures.add(IqrePackage.Literals.DIAGRAM__DELEGATION_ELEMENT);
			childrenFeatures.add(IqrePackage.Literals.DIAGRAM__INFORMATION_PROVISION_ELEMENT);
			childrenFeatures.add(IqrePackage.Literals.DIAGRAM__DELEGATION_TRUST_ELEMENT);
			childrenFeatures.add(IqrePackage.Literals.DIAGRAM__PROVISION_TRUST_ELEMENT);
			childrenFeatures.add(IqrePackage.Literals.DIAGRAM__PRODUCE_TRUST_ELEMET);
			childrenFeatures.add(IqrePackage.Literals.DIAGRAM__SOFTGOAL_ELEMENT);
			childrenFeatures.add(IqrePackage.Literals.DIAGRAM__QUALITY_CONSTRAINT_ELEMENT);
			childrenFeatures.add(IqrePackage.Literals.DIAGRAM__SCOPE_ELELEMT);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns Diagram.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/Diagram"));
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getText(Object object) {
		return getString("_UI_Diagram_type");
	}
	

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(Diagram.class)) {
			case IqrePackage.DIAGRAM__ROLE_ELEMENT:
			case IqrePackage.DIAGRAM__GOAL_ELEMENT:
			case IqrePackage.DIAGRAM__GOAL_INSTENCE_ELEMENT:
			case IqrePackage.DIAGRAM__AGENT_ELEMENT:
			case IqrePackage.DIAGRAM__TASK_INSTENCE_ELEMENT:
			case IqrePackage.DIAGRAM__TASK_ELEMENT:
			case IqrePackage.DIAGRAM__INFORMATION_ELEMENT:
			case IqrePackage.DIAGRAM__READS_ELEMENT:
			case IqrePackage.DIAGRAM__PRODUCES_ELEMENT:
			case IqrePackage.DIAGRAM__SENDS_ELEMENT:
			case IqrePackage.DIAGRAM__DELEGATION_ELEMENT:
			case IqrePackage.DIAGRAM__INFORMATION_PROVISION_ELEMENT:
			case IqrePackage.DIAGRAM__DELEGATION_TRUST_ELEMENT:
			case IqrePackage.DIAGRAM__PROVISION_TRUST_ELEMENT:
			case IqrePackage.DIAGRAM__PRODUCE_TRUST_ELEMET:
			case IqrePackage.DIAGRAM__SOFTGOAL_ELEMENT:
			case IqrePackage.DIAGRAM__QUALITY_CONSTRAINT_ELEMENT:
			case IqrePackage.DIAGRAM__SCOPE_ELELEMT:
				fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
				return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void collectNewChildDescriptors(Collection newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add
			(createChildParameter
				(IqrePackage.Literals.DIAGRAM__ROLE_ELEMENT,
				 IqreFactory.eINSTANCE.createrole()));

		newChildDescriptors.add
			(createChildParameter
				(IqrePackage.Literals.DIAGRAM__GOAL_ELEMENT,
				 IqreFactory.eINSTANCE.creategoal()));

		newChildDescriptors.add
			(createChildParameter
				(IqrePackage.Literals.DIAGRAM__GOAL_INSTENCE_ELEMENT,
				 IqreFactory.eINSTANCE.creategoalInstence()));

		newChildDescriptors.add
			(createChildParameter
				(IqrePackage.Literals.DIAGRAM__AGENT_ELEMENT,
				 IqreFactory.eINSTANCE.createagent()));

		newChildDescriptors.add
			(createChildParameter
				(IqrePackage.Literals.DIAGRAM__TASK_INSTENCE_ELEMENT,
				 IqreFactory.eINSTANCE.createtaskInstence()));

		newChildDescriptors.add
			(createChildParameter
				(IqrePackage.Literals.DIAGRAM__TASK_ELEMENT,
				 IqreFactory.eINSTANCE.createtask()));

		newChildDescriptors.add
			(createChildParameter
				(IqrePackage.Literals.DIAGRAM__INFORMATION_ELEMENT,
				 IqreFactory.eINSTANCE.createinformation()));

		newChildDescriptors.add
			(createChildParameter
				(IqrePackage.Literals.DIAGRAM__READS_ELEMENT,
				 IqreFactory.eINSTANCE.createreads()));

		newChildDescriptors.add
			(createChildParameter
				(IqrePackage.Literals.DIAGRAM__PRODUCES_ELEMENT,
				 IqreFactory.eINSTANCE.createproduces()));

		newChildDescriptors.add
			(createChildParameter
				(IqrePackage.Literals.DIAGRAM__SENDS_ELEMENT,
				 IqreFactory.eINSTANCE.createsends()));

		newChildDescriptors.add
			(createChildParameter
				(IqrePackage.Literals.DIAGRAM__DELEGATION_ELEMENT,
				 IqreFactory.eINSTANCE.createdelegation()));

		newChildDescriptors.add
			(createChildParameter
				(IqrePackage.Literals.DIAGRAM__INFORMATION_PROVISION_ELEMENT,
				 IqreFactory.eINSTANCE.createinformationProvision()));

		newChildDescriptors.add
			(createChildParameter
				(IqrePackage.Literals.DIAGRAM__DELEGATION_TRUST_ELEMENT,
				 IqreFactory.eINSTANCE.createtrustOfDelegation()));

		newChildDescriptors.add
			(createChildParameter
				(IqrePackage.Literals.DIAGRAM__PROVISION_TRUST_ELEMENT,
				 IqreFactory.eINSTANCE.createprovisionTrust()));

		newChildDescriptors.add
			(createChildParameter
				(IqrePackage.Literals.DIAGRAM__PRODUCE_TRUST_ELEMET,
				 IqreFactory.eINSTANCE.createproduceTrust()));

		newChildDescriptors.add
			(createChildParameter
				(IqrePackage.Literals.DIAGRAM__SOFTGOAL_ELEMENT,
				 IqreFactory.eINSTANCE.createsoftgoal()));

		newChildDescriptors.add
			(createChildParameter
				(IqrePackage.Literals.DIAGRAM__QUALITY_CONSTRAINT_ELEMENT,
				 IqreFactory.eINSTANCE.createqualityConstraint()));

		newChildDescriptors.add
			(createChildParameter
				(IqrePackage.Literals.DIAGRAM__SCOPE_ELELEMT,
				 IqreFactory.eINSTANCE.createscope()));
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ResourceLocator getResourceLocator() {
		return IqreEditPlugin.INSTANCE;
	}

}
