/**
 */
package iqre.tests;

import iqre.IqreFactory;
import iqre.trustOfDelegation;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>trust Of Delegation</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class trustOfDelegationTest extends TestCase {

	/**
	 * The fixture for this trust Of Delegation test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected trustOfDelegation fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(trustOfDelegationTest.class);
	}

	/**
	 * Constructs a new trust Of Delegation test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public trustOfDelegationTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this trust Of Delegation test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(trustOfDelegation fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this trust Of Delegation test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private trustOfDelegation getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	protected void setUp() throws Exception {
		setFixture(IqreFactory.eINSTANCE.createtrustOfDelegation());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //trustOfDelegationTest
