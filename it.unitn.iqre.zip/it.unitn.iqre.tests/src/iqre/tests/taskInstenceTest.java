/**
 */
package iqre.tests;

import iqre.IqreFactory;
import iqre.taskInstence;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>task Instence</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class taskInstenceTest extends TestCase {

	/**
	 * The fixture for this task Instence test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected taskInstence fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(taskInstenceTest.class);
	}

	/**
	 * Constructs a new task Instence test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public taskInstenceTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this task Instence test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(taskInstence fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this task Instence test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private taskInstence getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	protected void setUp() throws Exception {
		setFixture(IqreFactory.eINSTANCE.createtaskInstence());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //taskInstenceTest
