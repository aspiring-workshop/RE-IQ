/**
 */
package iqre;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>trust Of Delegation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqre.trustOfDelegation#getDeleTrustor <em>Dele Trustor</em>}</li>
 *   <li>{@link iqre.trustOfDelegation#getDeleTrustee <em>Dele Trustee</em>}</li>
 *   <li>{@link iqre.trustOfDelegation#getGoalTrustum <em>Goal Trustum</em>}</li>
 *   <li>{@link iqre.trustOfDelegation#getTaskTrustum <em>Task Trustum</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqre.IqrePackage#gettrustOfDelegation()
 * @model
 * @generated
 */
public interface trustOfDelegation extends EObject {
	/**
	 * Returns the value of the '<em><b>Dele Trustor</b></em>' reference list.
	 * The list contents are of type {@link iqre.agent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Dele Trustor</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dele Trustor</em>' reference list.
	 * @see iqre.IqrePackage#gettrustOfDelegation_DeleTrustor()
	 * @model type="iqre.agent"
	 * @generated
	 */
	EList getDeleTrustor();

	/**
	 * Returns the value of the '<em><b>Dele Trustee</b></em>' reference list.
	 * The list contents are of type {@link iqre.agent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Dele Trustee</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dele Trustee</em>' reference list.
	 * @see iqre.IqrePackage#gettrustOfDelegation_DeleTrustee()
	 * @model type="iqre.agent"
	 * @generated
	 */
	EList getDeleTrustee();

	/**
	 * Returns the value of the '<em><b>Goal Trustum</b></em>' reference list.
	 * The list contents are of type {@link iqre.goalInstence}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Goal Trustum</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Goal Trustum</em>' reference list.
	 * @see iqre.IqrePackage#gettrustOfDelegation_GoalTrustum()
	 * @model type="iqre.goalInstence"
	 * @generated
	 */
	EList getGoalTrustum();

	/**
	 * Returns the value of the '<em><b>Task Trustum</b></em>' reference list.
	 * The list contents are of type {@link iqre.taskInstence}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Task Trustum</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Task Trustum</em>' reference list.
	 * @see iqre.IqrePackage#gettrustOfDelegation_TaskTrustum()
	 * @model type="iqre.taskInstence"
	 * @generated
	 */
	EList getTaskTrustum();

} // trustOfDelegation
