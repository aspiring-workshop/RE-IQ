/**
 */
package iqre;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>provision Trust</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqre.provisionTrust#getPrvTrustee <em>Prv Trustee</em>}</li>
 *   <li>{@link iqre.provisionTrust#getPrvTrustor <em>Prv Trustor</em>}</li>
 *   <li>{@link iqre.provisionTrust#getTrustOfProvision <em>Trust Of Provision</em>}</li>
 *   <li>{@link iqre.provisionTrust#getType <em>Type</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqre.IqrePackage#getprovisionTrust()
 * @model
 * @generated
 */
public interface provisionTrust extends EObject {
	/**
	 * Returns the value of the '<em><b>Prv Trustee</b></em>' reference list.
	 * The list contents are of type {@link iqre.agent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Prv Trustee</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Prv Trustee</em>' reference list.
	 * @see iqre.IqrePackage#getprovisionTrust_PrvTrustee()
	 * @model type="iqre.agent"
	 * @generated
	 */
	EList getPrvTrustee();

	/**
	 * Returns the value of the '<em><b>Prv Trustor</b></em>' reference list.
	 * The list contents are of type {@link iqre.agent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Prv Trustor</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Prv Trustor</em>' reference list.
	 * @see iqre.IqrePackage#getprovisionTrust_PrvTrustor()
	 * @model type="iqre.agent"
	 * @generated
	 */
	EList getPrvTrustor();

	/**
	 * Returns the value of the '<em><b>Trust Of Provision</b></em>' reference list.
	 * The list contents are of type {@link iqre.information}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trust Of Provision</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trust Of Provision</em>' reference list.
	 * @see iqre.IqrePackage#getprovisionTrust_TrustOfProvision()
	 * @model type="iqre.information"
	 * @generated
	 */
	EList getTrustOfProvision();

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see iqre.IqrePackage#getprovisionTrust_Type()
	 * @model
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link iqre.provisionTrust#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

} // provisionTrust
