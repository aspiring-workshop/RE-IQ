/**
 */
package iqre;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>reads</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqre.reads#getPurposeOfUse <em>Purpose Of Use</em>}</li>
 *   <li>{@link iqre.reads#getType <em>Type</em>}</li>
 *   <li>{@link iqre.reads#getReadsBy <em>Reads By</em>}</li>
 *   <li>{@link iqre.reads#getReadsOf <em>Reads Of</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqre.IqrePackage#getreads()
 * @model
 * @generated
 */
public interface reads extends EObject {
	/**
	 * Returns the value of the '<em><b>Purpose Of Use</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Purpose Of Use</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Purpose Of Use</em>' attribute.
	 * @see #setPurposeOfUse(String)
	 * @see iqre.IqrePackage#getreads_PurposeOfUse()
	 * @model
	 * @generated
	 */
	String getPurposeOfUse();

	/**
	 * Sets the value of the '{@link iqre.reads#getPurposeOfUse <em>Purpose Of Use</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Purpose Of Use</em>' attribute.
	 * @see #getPurposeOfUse()
	 * @generated
	 */
	void setPurposeOfUse(String value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see iqre.IqrePackage#getreads_Type()
	 * @model
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link iqre.reads#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

	/**
	 * Returns the value of the '<em><b>Reads By</b></em>' reference list.
	 * The list contents are of type {@link iqre.taskInstence}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Reads By</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Reads By</em>' reference list.
	 * @see iqre.IqrePackage#getreads_ReadsBy()
	 * @model type="iqre.taskInstence"
	 * @generated
	 */
	EList getReadsBy();

	/**
	 * Returns the value of the '<em><b>Reads Of</b></em>' reference list.
	 * The list contents are of type {@link iqre.information}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Reads Of</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Reads Of</em>' reference list.
	 * @see iqre.IqrePackage#getreads_ReadsOf()
	 * @model type="iqre.information"
	 * @generated
	 */
	EList getReadsOf();

} // reads
