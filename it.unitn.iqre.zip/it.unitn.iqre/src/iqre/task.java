/**
 */
package iqre;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>task</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqre.task#getName <em>Name</em>}</li>
 *   <li>{@link iqre.task#getMeansEndGoal <em>Means End Goal</em>}</li>
 *   <li>{@link iqre.task#getAndDecomposition <em>And Decomposition</em>}</li>
 *   <li>{@link iqre.task#getOrDecomposition <em>Or Decomposition</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqre.IqrePackage#gettask()
 * @model
 * @generated
 */
public interface task extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see iqre.IqrePackage#gettask_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link iqre.task#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Means End Goal</b></em>' reference list.
	 * The list contents are of type {@link iqre.goal}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Means End Goal</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Means End Goal</em>' reference list.
	 * @see iqre.IqrePackage#gettask_MeansEndGoal()
	 * @model type="iqre.goal"
	 * @generated
	 */
	EList getMeansEndGoal();

	/**
	 * Returns the value of the '<em><b>And Decomposition</b></em>' reference list.
	 * The list contents are of type {@link iqre.task}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>And Decomposition</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>And Decomposition</em>' reference list.
	 * @see iqre.IqrePackage#gettask_AndDecomposition()
	 * @model type="iqre.task"
	 * @generated
	 */
	EList getAndDecomposition();

	/**
	 * Returns the value of the '<em><b>Or Decomposition</b></em>' reference list.
	 * The list contents are of type {@link iqre.task}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Or Decomposition</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Or Decomposition</em>' reference list.
	 * @see iqre.IqrePackage#gettask_OrDecomposition()
	 * @model type="iqre.task"
	 * @generated
	 */
	EList getOrDecomposition();

} // task
