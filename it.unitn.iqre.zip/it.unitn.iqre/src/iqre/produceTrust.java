/**
 */
package iqre;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>produce Trust</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqre.produceTrust#getProduceTrustor <em>Produce Trustor</em>}</li>
 *   <li>{@link iqre.produceTrust#getProduceTrustee <em>Produce Trustee</em>}</li>
 *   <li>{@link iqre.produceTrust#getTrustOfProvducing <em>Trust Of Provducing</em>}</li>
 *   <li>{@link iqre.produceTrust#getType <em>Type</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqre.IqrePackage#getproduceTrust()
 * @model
 * @generated
 */
public interface produceTrust extends EObject {
	/**
	 * Returns the value of the '<em><b>Produce Trustor</b></em>' reference list.
	 * The list contents are of type {@link iqre.agent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Produce Trustor</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Produce Trustor</em>' reference list.
	 * @see iqre.IqrePackage#getproduceTrust_ProduceTrustor()
	 * @model type="iqre.agent"
	 * @generated
	 */
	EList getProduceTrustor();

	/**
	 * Returns the value of the '<em><b>Produce Trustee</b></em>' reference list.
	 * The list contents are of type {@link iqre.agent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Produce Trustee</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Produce Trustee</em>' reference list.
	 * @see iqre.IqrePackage#getproduceTrust_ProduceTrustee()
	 * @model type="iqre.agent"
	 * @generated
	 */
	EList getProduceTrustee();

	/**
	 * Returns the value of the '<em><b>Trust Of Provducing</b></em>' reference list.
	 * The list contents are of type {@link iqre.information}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trust Of Provducing</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trust Of Provducing</em>' reference list.
	 * @see iqre.IqrePackage#getproduceTrust_TrustOfProvducing()
	 * @model type="iqre.information"
	 * @generated
	 */
	EList getTrustOfProvducing();

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see iqre.IqrePackage#getproduceTrust_Type()
	 * @model
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link iqre.produceTrust#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

} // produceTrust
