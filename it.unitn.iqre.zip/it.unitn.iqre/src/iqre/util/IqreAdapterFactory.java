/**
 */
package iqre.util;

import iqre.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see iqre.IqrePackage
 * @generated
 */
public class IqreAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static IqrePackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IqreAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = IqrePackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IqreSwitch modelSwitch =
		new IqreSwitch() {
			public Object caseDiagram(Diagram object) {
				return createDiagramAdapter();
			}
			public Object caserole(role object) {
				return createroleAdapter();
			}
			public Object casegoal(goal object) {
				return creategoalAdapter();
			}
			public Object caseagent(agent object) {
				return createagentAdapter();
			}
			public Object casegoalInstence(goalInstence object) {
				return creategoalInstenceAdapter();
			}
			public Object casetask(task object) {
				return createtaskAdapter();
			}
			public Object casetaskInstence(taskInstence object) {
				return createtaskInstenceAdapter();
			}
			public Object caseinformation(information object) {
				return createinformationAdapter();
			}
			public Object casereads(reads object) {
				return createreadsAdapter();
			}
			public Object caseproduces(produces object) {
				return createproducesAdapter();
			}
			public Object casesends(sends object) {
				return createsendsAdapter();
			}
			public Object casedelegation(delegation object) {
				return createdelegationAdapter();
			}
			public Object caseinformationProvision(informationProvision object) {
				return createinformationProvisionAdapter();
			}
			public Object casetrustOfDelegation(trustOfDelegation object) {
				return createtrustOfDelegationAdapter();
			}
			public Object caseprovisionTrust(provisionTrust object) {
				return createprovisionTrustAdapter();
			}
			public Object caseproduceTrust(produceTrust object) {
				return createproduceTrustAdapter();
			}
			public Object casesoftgoal(softgoal object) {
				return createsoftgoalAdapter();
			}
			public Object casequalityConstraint(qualityConstraint object) {
				return createqualityConstraintAdapter();
			}
			public Object casescope(scope object) {
				return createscopeAdapter();
			}
			public Object defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	public Adapter createAdapter(Notifier target) {
		return (Adapter)modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link iqre.Diagram <em>Diagram</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.Diagram
	 * @generated
	 */
	public Adapter createDiagramAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqre.role <em>role</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.role
	 * @generated
	 */
	public Adapter createroleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqre.goal <em>goal</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.goal
	 * @generated
	 */
	public Adapter creategoalAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqre.agent <em>agent</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.agent
	 * @generated
	 */
	public Adapter createagentAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqre.goalInstence <em>goal Instence</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.goalInstence
	 * @generated
	 */
	public Adapter creategoalInstenceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqre.task <em>task</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.task
	 * @generated
	 */
	public Adapter createtaskAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqre.taskInstence <em>task Instence</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.taskInstence
	 * @generated
	 */
	public Adapter createtaskInstenceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqre.information <em>information</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.information
	 * @generated
	 */
	public Adapter createinformationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqre.reads <em>reads</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.reads
	 * @generated
	 */
	public Adapter createreadsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqre.produces <em>produces</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.produces
	 * @generated
	 */
	public Adapter createproducesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqre.sends <em>sends</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.sends
	 * @generated
	 */
	public Adapter createsendsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqre.delegation <em>delegation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.delegation
	 * @generated
	 */
	public Adapter createdelegationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqre.informationProvision <em>information Provision</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.informationProvision
	 * @generated
	 */
	public Adapter createinformationProvisionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqre.trustOfDelegation <em>trust Of Delegation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.trustOfDelegation
	 * @generated
	 */
	public Adapter createtrustOfDelegationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqre.provisionTrust <em>provision Trust</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.provisionTrust
	 * @generated
	 */
	public Adapter createprovisionTrustAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqre.produceTrust <em>produce Trust</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.produceTrust
	 * @generated
	 */
	public Adapter createproduceTrustAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqre.softgoal <em>softgoal</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.softgoal
	 * @generated
	 */
	public Adapter createsoftgoalAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqre.qualityConstraint <em>quality Constraint</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.qualityConstraint
	 * @generated
	 */
	public Adapter createqualityConstraintAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqre.scope <em>scope</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqre.scope
	 * @generated
	 */
	public Adapter createscopeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //IqreAdapterFactory
