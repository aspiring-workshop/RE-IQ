/**
 */
package iqre;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>goal Instence</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqre.goalInstence#getName <em>Name</em>}</li>
 *   <li>{@link iqre.goalInstence#getInstence <em>Instence</em>}</li>
 *   <li>{@link iqre.goalInstence#getAndDecomposition <em>And Decomposition</em>}</li>
 *   <li>{@link iqre.goalInstence#getOrDecomposition <em>Or Decomposition</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqre.IqrePackage#getgoalInstence()
 * @model
 * @generated
 */
public interface goalInstence extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see iqre.IqrePackage#getgoalInstence_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link iqre.goalInstence#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Instence</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Instence</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Instence</em>' reference.
	 * @see #setInstence(goal)
	 * @see iqre.IqrePackage#getgoalInstence_Instence()
	 * @model required="true"
	 * @generated
	 */
	goal getInstence();

	/**
	 * Sets the value of the '{@link iqre.goalInstence#getInstence <em>Instence</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Instence</em>' reference.
	 * @see #getInstence()
	 * @generated
	 */
	void setInstence(goal value);

	/**
	 * Returns the value of the '<em><b>And Decomposition</b></em>' reference list.
	 * The list contents are of type {@link iqre.goalInstence}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>And Decomposition</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>And Decomposition</em>' reference list.
	 * @see iqre.IqrePackage#getgoalInstence_AndDecomposition()
	 * @model type="iqre.goalInstence"
	 * @generated
	 */
	EList getAndDecomposition();

	/**
	 * Returns the value of the '<em><b>Or Decomposition</b></em>' reference list.
	 * The list contents are of type {@link iqre.goalInstence}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Or Decomposition</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Or Decomposition</em>' reference list.
	 * @see iqre.IqrePackage#getgoalInstence_OrDecomposition()
	 * @model type="iqre.goalInstence"
	 * @generated
	 */
	EList getOrDecomposition();

} // goalInstence
