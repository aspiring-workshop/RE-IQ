/**
 */
package iqre;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>sends</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqre.sends#getType <em>Type</em>}</li>
 *   <li>{@link iqre.sends#getTime <em>Time</em>}</li>
 *   <li>{@link iqre.sends#getSendsBy <em>Sends By</em>}</li>
 *   <li>{@link iqre.sends#getSendsOf <em>Sends Of</em>}</li>
 *   <li>{@link iqre.sends#getSendsTo <em>Sends To</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqre.IqrePackage#getsends()
 * @model
 * @generated
 */
public interface sends extends EObject {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see iqre.IqrePackage#getsends_Type()
	 * @model
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link iqre.sends#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

	/**
	 * Returns the value of the '<em><b>Time</b></em>' attribute.
	 * The default value is <code>"100"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Time</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Time</em>' attribute.
	 * @see #setTime(int)
	 * @see iqre.IqrePackage#getsends_Time()
	 * @model default="100"
	 * @generated
	 */
	int getTime();

	/**
	 * Sets the value of the '{@link iqre.sends#getTime <em>Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Time</em>' attribute.
	 * @see #getTime()
	 * @generated
	 */
	void setTime(int value);

	/**
	 * Returns the value of the '<em><b>Sends By</b></em>' reference list.
	 * The list contents are of type {@link iqre.taskInstence}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sends By</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sends By</em>' reference list.
	 * @see iqre.IqrePackage#getsends_SendsBy()
	 * @model type="iqre.taskInstence"
	 * @generated
	 */
	EList getSendsBy();

	/**
	 * Returns the value of the '<em><b>Sends Of</b></em>' reference list.
	 * The list contents are of type {@link iqre.information}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sends Of</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sends Of</em>' reference list.
	 * @see iqre.IqrePackage#getsends_SendsOf()
	 * @model type="iqre.information"
	 * @generated
	 */
	EList getSendsOf();

	/**
	 * Returns the value of the '<em><b>Sends To</b></em>' reference list.
	 * The list contents are of type {@link iqre.agent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sends To</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sends To</em>' reference list.
	 * @see iqre.IqrePackage#getsends_SendsTo()
	 * @model type="iqre.agent"
	 * @generated
	 */
	EList getSendsTo();

} // sends
