/**
 */
package iqre;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>delegation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqre.delegation#getDelegationFrom <em>Delegation From</em>}</li>
 *   <li>{@link iqre.delegation#getDelegationTo <em>Delegation To</em>}</li>
 *   <li>{@link iqre.delegation#getDelegationOfGoal <em>Delegation Of Goal</em>}</li>
 *   <li>{@link iqre.delegation#getDelegationOfTask <em>Delegation Of Task</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqre.IqrePackage#getdelegation()
 * @model
 * @generated
 */
public interface delegation extends EObject {
	/**
	 * Returns the value of the '<em><b>Delegation From</b></em>' reference list.
	 * The list contents are of type {@link iqre.agent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Delegation From</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Delegation From</em>' reference list.
	 * @see iqre.IqrePackage#getdelegation_DelegationFrom()
	 * @model type="iqre.agent"
	 * @generated
	 */
	EList getDelegationFrom();

	/**
	 * Returns the value of the '<em><b>Delegation To</b></em>' reference list.
	 * The list contents are of type {@link iqre.agent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Delegation To</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Delegation To</em>' reference list.
	 * @see iqre.IqrePackage#getdelegation_DelegationTo()
	 * @model type="iqre.agent"
	 * @generated
	 */
	EList getDelegationTo();

	/**
	 * Returns the value of the '<em><b>Delegation Of Goal</b></em>' reference list.
	 * The list contents are of type {@link iqre.goalInstence}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Delegation Of Goal</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Delegation Of Goal</em>' reference list.
	 * @see iqre.IqrePackage#getdelegation_DelegationOfGoal()
	 * @model type="iqre.goalInstence"
	 * @generated
	 */
	EList getDelegationOfGoal();

	/**
	 * Returns the value of the '<em><b>Delegation Of Task</b></em>' reference list.
	 * The list contents are of type {@link iqre.taskInstence}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Delegation Of Task</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Delegation Of Task</em>' reference list.
	 * @see iqre.IqrePackage#getdelegation_DelegationOfTask()
	 * @model type="iqre.taskInstence"
	 * @generated
	 */
	EList getDelegationOfTask();

} // delegation
