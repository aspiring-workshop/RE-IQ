/**
 */
package iqre;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see iqre.IqrePackage
 * @generated
 */
public interface IqreFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	IqreFactory eINSTANCE = iqre.impl.IqreFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Diagram</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Diagram</em>'.
	 * @generated
	 */
	Diagram createDiagram();

	/**
	 * Returns a new object of class '<em>role</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>role</em>'.
	 * @generated
	 */
	role createrole();

	/**
	 * Returns a new object of class '<em>goal</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>goal</em>'.
	 * @generated
	 */
	goal creategoal();

	/**
	 * Returns a new object of class '<em>agent</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>agent</em>'.
	 * @generated
	 */
	agent createagent();

	/**
	 * Returns a new object of class '<em>goal Instence</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>goal Instence</em>'.
	 * @generated
	 */
	goalInstence creategoalInstence();

	/**
	 * Returns a new object of class '<em>task</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>task</em>'.
	 * @generated
	 */
	task createtask();

	/**
	 * Returns a new object of class '<em>task Instence</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>task Instence</em>'.
	 * @generated
	 */
	taskInstence createtaskInstence();

	/**
	 * Returns a new object of class '<em>information</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>information</em>'.
	 * @generated
	 */
	information createinformation();

	/**
	 * Returns a new object of class '<em>reads</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>reads</em>'.
	 * @generated
	 */
	reads createreads();

	/**
	 * Returns a new object of class '<em>produces</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>produces</em>'.
	 * @generated
	 */
	produces createproduces();

	/**
	 * Returns a new object of class '<em>sends</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>sends</em>'.
	 * @generated
	 */
	sends createsends();

	/**
	 * Returns a new object of class '<em>delegation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>delegation</em>'.
	 * @generated
	 */
	delegation createdelegation();

	/**
	 * Returns a new object of class '<em>information Provision</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>information Provision</em>'.
	 * @generated
	 */
	informationProvision createinformationProvision();

	/**
	 * Returns a new object of class '<em>trust Of Delegation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>trust Of Delegation</em>'.
	 * @generated
	 */
	trustOfDelegation createtrustOfDelegation();

	/**
	 * Returns a new object of class '<em>provision Trust</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>provision Trust</em>'.
	 * @generated
	 */
	provisionTrust createprovisionTrust();

	/**
	 * Returns a new object of class '<em>produce Trust</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>produce Trust</em>'.
	 * @generated
	 */
	produceTrust createproduceTrust();

	/**
	 * Returns a new object of class '<em>softgoal</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>softgoal</em>'.
	 * @generated
	 */
	softgoal createsoftgoal();

	/**
	 * Returns a new object of class '<em>quality Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>quality Constraint</em>'.
	 * @generated
	 */
	qualityConstraint createqualityConstraint();

	/**
	 * Returns a new object of class '<em>scope</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>scope</em>'.
	 * @generated
	 */
	scope createscope();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	IqrePackage getIqrePackage();

} //IqreFactory
