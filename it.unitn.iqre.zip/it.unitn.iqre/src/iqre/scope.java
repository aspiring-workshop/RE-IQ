/**
 */
package iqre;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>scope</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see iqre.IqrePackage#getscope()
 * @model
 * @generated
 */
public interface scope extends EObject {
} // scope
