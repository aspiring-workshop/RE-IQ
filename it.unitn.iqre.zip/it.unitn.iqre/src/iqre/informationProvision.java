/**
 */
package iqre;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>information Provision</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqre.informationProvision#getTime <em>Time</em>}</li>
 *   <li>{@link iqre.informationProvision#getType <em>Type</em>}</li>
 *   <li>{@link iqre.informationProvision#getProvisionTo <em>Provision To</em>}</li>
 *   <li>{@link iqre.informationProvision#getProvisionFrom <em>Provision From</em>}</li>
 *   <li>{@link iqre.informationProvision#getProvisionOf <em>Provision Of</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqre.IqrePackage#getinformationProvision()
 * @model
 * @generated
 */
public interface informationProvision extends EObject {
	/**
	 * Returns the value of the '<em><b>Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Time</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Time</em>' attribute.
	 * @see #setTime(int)
	 * @see iqre.IqrePackage#getinformationProvision_Time()
	 * @model
	 * @generated
	 */
	int getTime();

	/**
	 * Sets the value of the '{@link iqre.informationProvision#getTime <em>Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Time</em>' attribute.
	 * @see #getTime()
	 * @generated
	 */
	void setTime(int value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see iqre.IqrePackage#getinformationProvision_Type()
	 * @model
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link iqre.informationProvision#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

	/**
	 * Returns the value of the '<em><b>Provision To</b></em>' reference list.
	 * The list contents are of type {@link iqre.agent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Provision To</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Provision To</em>' reference list.
	 * @see iqre.IqrePackage#getinformationProvision_ProvisionTo()
	 * @model type="iqre.agent"
	 * @generated
	 */
	EList getProvisionTo();

	/**
	 * Returns the value of the '<em><b>Provision From</b></em>' reference list.
	 * The list contents are of type {@link iqre.agent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Provision From</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Provision From</em>' reference list.
	 * @see iqre.IqrePackage#getinformationProvision_ProvisionFrom()
	 * @model type="iqre.agent"
	 * @generated
	 */
	EList getProvisionFrom();

	/**
	 * Returns the value of the '<em><b>Provision Of</b></em>' reference list.
	 * The list contents are of type {@link iqre.information}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Provision Of</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Provision Of</em>' reference list.
	 * @see iqre.IqrePackage#getinformationProvision_ProvisionOf()
	 * @model type="iqre.information"
	 * @generated
	 */
	EList getProvisionOf();

} // informationProvision
