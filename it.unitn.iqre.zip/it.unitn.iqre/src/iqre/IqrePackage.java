/**
 */
package iqre;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see iqre.IqreFactory
 * @model kind="package"
 * @generated
 */
public interface IqrePackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "iqre";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.unitn.iqre/iqre";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "iqre";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	IqrePackage eINSTANCE = iqre.impl.IqrePackageImpl.init();

	/**
	 * The meta object id for the '{@link iqre.impl.DiagramImpl <em>Diagram</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.DiagramImpl
	 * @see iqre.impl.IqrePackageImpl#getDiagram()
	 * @generated
	 */
	int DIAGRAM = 0;

	/**
	 * The feature id for the '<em><b>Role Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__ROLE_ELEMENT = 0;

	/**
	 * The feature id for the '<em><b>Goal Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__GOAL_ELEMENT = 1;

	/**
	 * The feature id for the '<em><b>Goal Instence Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__GOAL_INSTENCE_ELEMENT = 2;

	/**
	 * The feature id for the '<em><b>Agent Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__AGENT_ELEMENT = 3;

	/**
	 * The feature id for the '<em><b>Task Instence Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__TASK_INSTENCE_ELEMENT = 4;

	/**
	 * The feature id for the '<em><b>Task Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__TASK_ELEMENT = 5;

	/**
	 * The feature id for the '<em><b>Information Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__INFORMATION_ELEMENT = 6;

	/**
	 * The feature id for the '<em><b>Reads Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__READS_ELEMENT = 7;

	/**
	 * The feature id for the '<em><b>Produces Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__PRODUCES_ELEMENT = 8;

	/**
	 * The feature id for the '<em><b>Sends Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__SENDS_ELEMENT = 9;

	/**
	 * The feature id for the '<em><b>Delegation Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__DELEGATION_ELEMENT = 10;

	/**
	 * The feature id for the '<em><b>Information Provision Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__INFORMATION_PROVISION_ELEMENT = 11;

	/**
	 * The feature id for the '<em><b>Delegation Trust Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__DELEGATION_TRUST_ELEMENT = 12;

	/**
	 * The feature id for the '<em><b>Provision Trust Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__PROVISION_TRUST_ELEMENT = 13;

	/**
	 * The feature id for the '<em><b>Produce Trust Elemet</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__PRODUCE_TRUST_ELEMET = 14;

	/**
	 * The feature id for the '<em><b>Softgoal Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__SOFTGOAL_ELEMENT = 15;

	/**
	 * The feature id for the '<em><b>Quality Constraint Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__QUALITY_CONSTRAINT_ELEMENT = 16;

	/**
	 * The feature id for the '<em><b>Scope Elelemt</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__SCOPE_ELELEMT = 17;

	/**
	 * The number of structural features of the '<em>Diagram</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM_FEATURE_COUNT = 18;

	/**
	 * The meta object id for the '{@link iqre.impl.roleImpl <em>role</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.roleImpl
	 * @see iqre.impl.IqrePackageImpl#getrole()
	 * @generated
	 */
	int ROLE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Aims</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__AIMS = 1;

	/**
	 * The feature id for the '<em><b>Capable Goal</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__CAPABLE_GOAL = 2;

	/**
	 * The feature id for the '<em><b>Capable Task</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__CAPABLE_TASK = 3;

	/**
	 * The number of structural features of the '<em>role</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link iqre.impl.goalImpl <em>goal</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.goalImpl
	 * @see iqre.impl.IqrePackageImpl#getgoal()
	 * @generated
	 */
	int GOAL = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__NAME = 0;

	/**
	 * The feature id for the '<em><b>And Decomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__AND_DECOMPOSITION = 1;

	/**
	 * The feature id for the '<em><b>Or Decomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__OR_DECOMPOSITION = 2;

	/**
	 * The number of structural features of the '<em>goal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link iqre.impl.agentImpl <em>agent</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.agentImpl
	 * @see iqre.impl.IqrePackageImpl#getagent()
	 * @generated
	 */
	int AGENT = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Plays</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT__PLAYS = 1;

	/**
	 * The feature id for the '<em><b>Aims</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT__AIMS = 2;

	/**
	 * The number of structural features of the '<em>agent</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT_FEATURE_COUNT = 3;


	/**
	 * The meta object id for the '{@link iqre.impl.goalInstenceImpl <em>goal Instence</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.goalInstenceImpl
	 * @see iqre.impl.IqrePackageImpl#getgoalInstence()
	 * @generated
	 */
	int GOAL_INSTENCE = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_INSTENCE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Instence</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_INSTENCE__INSTENCE = 1;

	/**
	 * The feature id for the '<em><b>And Decomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_INSTENCE__AND_DECOMPOSITION = 2;

	/**
	 * The feature id for the '<em><b>Or Decomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_INSTENCE__OR_DECOMPOSITION = 3;

	/**
	 * The number of structural features of the '<em>goal Instence</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_INSTENCE_FEATURE_COUNT = 4;


	/**
	 * The meta object id for the '{@link iqre.impl.taskImpl <em>task</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.taskImpl
	 * @see iqre.impl.IqrePackageImpl#gettask()
	 * @generated
	 */
	int TASK = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK__NAME = 0;

	/**
	 * The feature id for the '<em><b>Means End Goal</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK__MEANS_END_GOAL = 1;

	/**
	 * The feature id for the '<em><b>And Decomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK__AND_DECOMPOSITION = 2;

	/**
	 * The feature id for the '<em><b>Or Decomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK__OR_DECOMPOSITION = 3;

	/**
	 * The number of structural features of the '<em>task</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link iqre.impl.taskInstenceImpl <em>task Instence</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.taskInstenceImpl
	 * @see iqre.impl.IqrePackageImpl#gettaskInstence()
	 * @generated
	 */
	int TASK_INSTENCE = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_INSTENCE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Means End Ins Goal</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_INSTENCE__MEANS_END_INS_GOAL = 1;

	/**
	 * The feature id for the '<em><b>Instence</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_INSTENCE__INSTENCE = 2;

	/**
	 * The feature id for the '<em><b>And Decomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_INSTENCE__AND_DECOMPOSITION = 3;

	/**
	 * The feature id for the '<em><b>Or Decomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_INSTENCE__OR_DECOMPOSITION = 4;

	/**
	 * The feature id for the '<em><b>Dependent</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_INSTENCE__DEPENDENT = 5;

	/**
	 * The number of structural features of the '<em>task Instence</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_INSTENCE_FEATURE_COUNT = 6;

	/**
	 * The meta object id for the '{@link iqre.impl.informationImpl <em>information</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.informationImpl
	 * @see iqre.impl.IqrePackageImpl#getinformation()
	 * @generated
	 */
	int INFORMATION = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Volatility</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION__VOLATILITY = 1;

	/**
	 * The feature id for the '<em><b>Sub Item</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION__SUB_ITEM = 2;

	/**
	 * The number of structural features of the '<em>information</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link iqre.impl.readsImpl <em>reads</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.readsImpl
	 * @see iqre.impl.IqrePackageImpl#getreads()
	 * @generated
	 */
	int READS = 8;

	/**
	 * The feature id for the '<em><b>Purpose Of Use</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READS__PURPOSE_OF_USE = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READS__TYPE = 1;

	/**
	 * The feature id for the '<em><b>Reads By</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READS__READS_BY = 2;

	/**
	 * The feature id for the '<em><b>Reads Of</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READS__READS_OF = 3;

	/**
	 * The number of structural features of the '<em>reads</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READS_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link iqre.impl.producesImpl <em>produces</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.producesImpl
	 * @see iqre.impl.IqrePackageImpl#getproduces()
	 * @generated
	 */
	int PRODUCES = 9;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCES__TYPE = 0;

	/**
	 * The feature id for the '<em><b>Produces By</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCES__PRODUCES_BY = 1;

	/**
	 * The feature id for the '<em><b>Produces Of</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCES__PRODUCES_OF = 2;

	/**
	 * The number of structural features of the '<em>produces</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCES_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link iqre.impl.sendsImpl <em>sends</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.sendsImpl
	 * @see iqre.impl.IqrePackageImpl#getsends()
	 * @generated
	 */
	int SENDS = 10;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENDS__TYPE = 0;

	/**
	 * The feature id for the '<em><b>Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENDS__TIME = 1;

	/**
	 * The feature id for the '<em><b>Sends By</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENDS__SENDS_BY = 2;

	/**
	 * The feature id for the '<em><b>Sends Of</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENDS__SENDS_OF = 3;

	/**
	 * The feature id for the '<em><b>Sends To</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENDS__SENDS_TO = 4;

	/**
	 * The number of structural features of the '<em>sends</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENDS_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link iqre.impl.delegationImpl <em>delegation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.delegationImpl
	 * @see iqre.impl.IqrePackageImpl#getdelegation()
	 * @generated
	 */
	int DELEGATION = 11;

	/**
	 * The feature id for the '<em><b>Delegation From</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELEGATION__DELEGATION_FROM = 0;

	/**
	 * The feature id for the '<em><b>Delegation To</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELEGATION__DELEGATION_TO = 1;

	/**
	 * The feature id for the '<em><b>Delegation Of Goal</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELEGATION__DELEGATION_OF_GOAL = 2;

	/**
	 * The feature id for the '<em><b>Delegation Of Task</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELEGATION__DELEGATION_OF_TASK = 3;

	/**
	 * The number of structural features of the '<em>delegation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELEGATION_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link iqre.impl.informationProvisionImpl <em>information Provision</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.informationProvisionImpl
	 * @see iqre.impl.IqrePackageImpl#getinformationProvision()
	 * @generated
	 */
	int INFORMATION_PROVISION = 12;

	/**
	 * The feature id for the '<em><b>Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_PROVISION__TIME = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_PROVISION__TYPE = 1;

	/**
	 * The feature id for the '<em><b>Provision To</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_PROVISION__PROVISION_TO = 2;

	/**
	 * The feature id for the '<em><b>Provision From</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_PROVISION__PROVISION_FROM = 3;

	/**
	 * The feature id for the '<em><b>Provision Of</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_PROVISION__PROVISION_OF = 4;

	/**
	 * The number of structural features of the '<em>information Provision</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_PROVISION_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link iqre.impl.trustOfDelegationImpl <em>trust Of Delegation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.trustOfDelegationImpl
	 * @see iqre.impl.IqrePackageImpl#gettrustOfDelegation()
	 * @generated
	 */
	int TRUST_OF_DELEGATION = 13;

	/**
	 * The feature id for the '<em><b>Dele Trustor</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_OF_DELEGATION__DELE_TRUSTOR = 0;

	/**
	 * The feature id for the '<em><b>Dele Trustee</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_OF_DELEGATION__DELE_TRUSTEE = 1;

	/**
	 * The feature id for the '<em><b>Goal Trustum</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_OF_DELEGATION__GOAL_TRUSTUM = 2;

	/**
	 * The feature id for the '<em><b>Task Trustum</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_OF_DELEGATION__TASK_TRUSTUM = 3;

	/**
	 * The number of structural features of the '<em>trust Of Delegation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_OF_DELEGATION_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link iqre.impl.provisionTrustImpl <em>provision Trust</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.provisionTrustImpl
	 * @see iqre.impl.IqrePackageImpl#getprovisionTrust()
	 * @generated
	 */
	int PROVISION_TRUST = 14;

	/**
	 * The feature id for the '<em><b>Prv Trustee</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROVISION_TRUST__PRV_TRUSTEE = 0;

	/**
	 * The feature id for the '<em><b>Prv Trustor</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROVISION_TRUST__PRV_TRUSTOR = 1;

	/**
	 * The feature id for the '<em><b>Trust Of Provision</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROVISION_TRUST__TRUST_OF_PROVISION = 2;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROVISION_TRUST__TYPE = 3;

	/**
	 * The number of structural features of the '<em>provision Trust</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROVISION_TRUST_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link iqre.impl.produceTrustImpl <em>produce Trust</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.produceTrustImpl
	 * @see iqre.impl.IqrePackageImpl#getproduceTrust()
	 * @generated
	 */
	int PRODUCE_TRUST = 15;

	/**
	 * The feature id for the '<em><b>Produce Trustor</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE_TRUST__PRODUCE_TRUSTOR = 0;

	/**
	 * The feature id for the '<em><b>Produce Trustee</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE_TRUST__PRODUCE_TRUSTEE = 1;

	/**
	 * The feature id for the '<em><b>Trust Of Provducing</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE_TRUST__TRUST_OF_PROVDUCING = 2;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE_TRUST__TYPE = 3;

	/**
	 * The number of structural features of the '<em>produce Trust</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE_TRUST_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link iqre.impl.softgoalImpl <em>softgoal</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.softgoalImpl
	 * @see iqre.impl.IqrePackageImpl#getsoftgoal()
	 * @generated
	 */
	int SOFTGOAL = 16;

	/**
	 * The feature id for the '<em><b>And Decomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTGOAL__AND_DECOMPOSITION = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTGOAL__TYPE = 1;

	/**
	 * The feature id for the '<em><b>Quality Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTGOAL__QUALITY_TARGET = 2;

	/**
	 * The number of structural features of the '<em>softgoal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTGOAL_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link iqre.impl.qualityConstraintImpl <em>quality Constraint</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.qualityConstraintImpl
	 * @see iqre.impl.IqrePackageImpl#getqualityConstraint()
	 * @generated
	 */
	int QUALITY_CONSTRAINT = 17;

	/**
	 * The feature id for the '<em><b>Approximate Relation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUALITY_CONSTRAINT__APPROXIMATE_RELATION = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUALITY_CONSTRAINT__TYPE = 1;

	/**
	 * The feature id for the '<em><b>Quality Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUALITY_CONSTRAINT__QUALITY_TARGET = 2;

	/**
	 * The number of structural features of the '<em>quality Constraint</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUALITY_CONSTRAINT_FEATURE_COUNT = 3;


	/**
	 * The meta object id for the '{@link iqre.impl.scopeImpl <em>scope</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqre.impl.scopeImpl
	 * @see iqre.impl.IqrePackageImpl#getscope()
	 * @generated
	 */
	int SCOPE = 18;

	/**
	 * The number of structural features of the '<em>scope</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCOPE_FEATURE_COUNT = 0;


	/**
	 * Returns the meta object for class '{@link iqre.Diagram <em>Diagram</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Diagram</em>'.
	 * @see iqre.Diagram
	 * @generated
	 */
	EClass getDiagram();

	/**
	 * Returns the meta object for the containment reference list '{@link iqre.Diagram#getRoleElement <em>Role Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Role Element</em>'.
	 * @see iqre.Diagram#getRoleElement()
	 * @see #getDiagram()
	 * @generated
	 */
	EReference getDiagram_RoleElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqre.Diagram#getGoalElement <em>Goal Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Goal Element</em>'.
	 * @see iqre.Diagram#getGoalElement()
	 * @see #getDiagram()
	 * @generated
	 */
	EReference getDiagram_GoalElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqre.Diagram#getGoalInstenceElement <em>Goal Instence Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Goal Instence Element</em>'.
	 * @see iqre.Diagram#getGoalInstenceElement()
	 * @see #getDiagram()
	 * @generated
	 */
	EReference getDiagram_GoalInstenceElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqre.Diagram#getAgentElement <em>Agent Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Agent Element</em>'.
	 * @see iqre.Diagram#getAgentElement()
	 * @see #getDiagram()
	 * @generated
	 */
	EReference getDiagram_AgentElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqre.Diagram#getTaskInstenceElement <em>Task Instence Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Task Instence Element</em>'.
	 * @see iqre.Diagram#getTaskInstenceElement()
	 * @see #getDiagram()
	 * @generated
	 */
	EReference getDiagram_TaskInstenceElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqre.Diagram#getTaskElement <em>Task Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Task Element</em>'.
	 * @see iqre.Diagram#getTaskElement()
	 * @see #getDiagram()
	 * @generated
	 */
	EReference getDiagram_TaskElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqre.Diagram#getInformationElement <em>Information Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Information Element</em>'.
	 * @see iqre.Diagram#getInformationElement()
	 * @see #getDiagram()
	 * @generated
	 */
	EReference getDiagram_InformationElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqre.Diagram#getReadsElement <em>Reads Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Reads Element</em>'.
	 * @see iqre.Diagram#getReadsElement()
	 * @see #getDiagram()
	 * @generated
	 */
	EReference getDiagram_ReadsElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqre.Diagram#getProducesElement <em>Produces Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Produces Element</em>'.
	 * @see iqre.Diagram#getProducesElement()
	 * @see #getDiagram()
	 * @generated
	 */
	EReference getDiagram_ProducesElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqre.Diagram#getSendsElement <em>Sends Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sends Element</em>'.
	 * @see iqre.Diagram#getSendsElement()
	 * @see #getDiagram()
	 * @generated
	 */
	EReference getDiagram_SendsElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqre.Diagram#getDelegationElement <em>Delegation Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Delegation Element</em>'.
	 * @see iqre.Diagram#getDelegationElement()
	 * @see #getDiagram()
	 * @generated
	 */
	EReference getDiagram_DelegationElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqre.Diagram#getInformationProvisionElement <em>Information Provision Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Information Provision Element</em>'.
	 * @see iqre.Diagram#getInformationProvisionElement()
	 * @see #getDiagram()
	 * @generated
	 */
	EReference getDiagram_InformationProvisionElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqre.Diagram#getDelegationTrustElement <em>Delegation Trust Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Delegation Trust Element</em>'.
	 * @see iqre.Diagram#getDelegationTrustElement()
	 * @see #getDiagram()
	 * @generated
	 */
	EReference getDiagram_DelegationTrustElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqre.Diagram#getProvisionTrustElement <em>Provision Trust Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Provision Trust Element</em>'.
	 * @see iqre.Diagram#getProvisionTrustElement()
	 * @see #getDiagram()
	 * @generated
	 */
	EReference getDiagram_ProvisionTrustElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqre.Diagram#getProduceTrustElemet <em>Produce Trust Elemet</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Produce Trust Elemet</em>'.
	 * @see iqre.Diagram#getProduceTrustElemet()
	 * @see #getDiagram()
	 * @generated
	 */
	EReference getDiagram_ProduceTrustElemet();

	/**
	 * Returns the meta object for the containment reference list '{@link iqre.Diagram#getSoftgoalElement <em>Softgoal Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Softgoal Element</em>'.
	 * @see iqre.Diagram#getSoftgoalElement()
	 * @see #getDiagram()
	 * @generated
	 */
	EReference getDiagram_SoftgoalElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqre.Diagram#getQualityConstraintElement <em>Quality Constraint Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Quality Constraint Element</em>'.
	 * @see iqre.Diagram#getQualityConstraintElement()
	 * @see #getDiagram()
	 * @generated
	 */
	EReference getDiagram_QualityConstraintElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqre.Diagram#getScopeElelemt <em>Scope Elelemt</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Scope Elelemt</em>'.
	 * @see iqre.Diagram#getScopeElelemt()
	 * @see #getDiagram()
	 * @generated
	 */
	EReference getDiagram_ScopeElelemt();

	/**
	 * Returns the meta object for class '{@link iqre.role <em>role</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>role</em>'.
	 * @see iqre.role
	 * @generated
	 */
	EClass getrole();

	/**
	 * Returns the meta object for the attribute '{@link iqre.role#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see iqre.role#getName()
	 * @see #getrole()
	 * @generated
	 */
	EAttribute getrole_Name();

	/**
	 * Returns the meta object for the reference list '{@link iqre.role#getAims <em>Aims</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Aims</em>'.
	 * @see iqre.role#getAims()
	 * @see #getrole()
	 * @generated
	 */
	EReference getrole_Aims();

	/**
	 * Returns the meta object for the reference list '{@link iqre.role#getCapableGoal <em>Capable Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Capable Goal</em>'.
	 * @see iqre.role#getCapableGoal()
	 * @see #getrole()
	 * @generated
	 */
	EReference getrole_CapableGoal();

	/**
	 * Returns the meta object for the reference list '{@link iqre.role#getCapableTask <em>Capable Task</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Capable Task</em>'.
	 * @see iqre.role#getCapableTask()
	 * @see #getrole()
	 * @generated
	 */
	EReference getrole_CapableTask();

	/**
	 * Returns the meta object for class '{@link iqre.goal <em>goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>goal</em>'.
	 * @see iqre.goal
	 * @generated
	 */
	EClass getgoal();

	/**
	 * Returns the meta object for the attribute '{@link iqre.goal#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see iqre.goal#getName()
	 * @see #getgoal()
	 * @generated
	 */
	EAttribute getgoal_Name();

	/**
	 * Returns the meta object for the reference list '{@link iqre.goal#getAndDecomposition <em>And Decomposition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>And Decomposition</em>'.
	 * @see iqre.goal#getAndDecomposition()
	 * @see #getgoal()
	 * @generated
	 */
	EReference getgoal_AndDecomposition();

	/**
	 * Returns the meta object for the reference list '{@link iqre.goal#getOrDecomposition <em>Or Decomposition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Or Decomposition</em>'.
	 * @see iqre.goal#getOrDecomposition()
	 * @see #getgoal()
	 * @generated
	 */
	EReference getgoal_OrDecomposition();

	/**
	 * Returns the meta object for class '{@link iqre.agent <em>agent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>agent</em>'.
	 * @see iqre.agent
	 * @generated
	 */
	EClass getagent();

	/**
	 * Returns the meta object for the attribute '{@link iqre.agent#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see iqre.agent#getName()
	 * @see #getagent()
	 * @generated
	 */
	EAttribute getagent_Name();

	/**
	 * Returns the meta object for the reference list '{@link iqre.agent#getPlays <em>Plays</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Plays</em>'.
	 * @see iqre.agent#getPlays()
	 * @see #getagent()
	 * @generated
	 */
	EReference getagent_Plays();

	/**
	 * Returns the meta object for the reference list '{@link iqre.agent#getAims <em>Aims</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Aims</em>'.
	 * @see iqre.agent#getAims()
	 * @see #getagent()
	 * @generated
	 */
	EReference getagent_Aims();

	/**
	 * Returns the meta object for class '{@link iqre.goalInstence <em>goal Instence</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>goal Instence</em>'.
	 * @see iqre.goalInstence
	 * @generated
	 */
	EClass getgoalInstence();

	/**
	 * Returns the meta object for the attribute '{@link iqre.goalInstence#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see iqre.goalInstence#getName()
	 * @see #getgoalInstence()
	 * @generated
	 */
	EAttribute getgoalInstence_Name();

	/**
	 * Returns the meta object for the reference '{@link iqre.goalInstence#getInstence <em>Instence</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Instence</em>'.
	 * @see iqre.goalInstence#getInstence()
	 * @see #getgoalInstence()
	 * @generated
	 */
	EReference getgoalInstence_Instence();

	/**
	 * Returns the meta object for the reference list '{@link iqre.goalInstence#getAndDecomposition <em>And Decomposition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>And Decomposition</em>'.
	 * @see iqre.goalInstence#getAndDecomposition()
	 * @see #getgoalInstence()
	 * @generated
	 */
	EReference getgoalInstence_AndDecomposition();

	/**
	 * Returns the meta object for the reference list '{@link iqre.goalInstence#getOrDecomposition <em>Or Decomposition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Or Decomposition</em>'.
	 * @see iqre.goalInstence#getOrDecomposition()
	 * @see #getgoalInstence()
	 * @generated
	 */
	EReference getgoalInstence_OrDecomposition();

	/**
	 * Returns the meta object for class '{@link iqre.task <em>task</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>task</em>'.
	 * @see iqre.task
	 * @generated
	 */
	EClass gettask();

	/**
	 * Returns the meta object for the attribute '{@link iqre.task#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see iqre.task#getName()
	 * @see #gettask()
	 * @generated
	 */
	EAttribute gettask_Name();

	/**
	 * Returns the meta object for the reference list '{@link iqre.task#getMeansEndGoal <em>Means End Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Means End Goal</em>'.
	 * @see iqre.task#getMeansEndGoal()
	 * @see #gettask()
	 * @generated
	 */
	EReference gettask_MeansEndGoal();

	/**
	 * Returns the meta object for the reference list '{@link iqre.task#getAndDecomposition <em>And Decomposition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>And Decomposition</em>'.
	 * @see iqre.task#getAndDecomposition()
	 * @see #gettask()
	 * @generated
	 */
	EReference gettask_AndDecomposition();

	/**
	 * Returns the meta object for the reference list '{@link iqre.task#getOrDecomposition <em>Or Decomposition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Or Decomposition</em>'.
	 * @see iqre.task#getOrDecomposition()
	 * @see #gettask()
	 * @generated
	 */
	EReference gettask_OrDecomposition();

	/**
	 * Returns the meta object for class '{@link iqre.taskInstence <em>task Instence</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>task Instence</em>'.
	 * @see iqre.taskInstence
	 * @generated
	 */
	EClass gettaskInstence();

	/**
	 * Returns the meta object for the attribute '{@link iqre.taskInstence#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see iqre.taskInstence#getName()
	 * @see #gettaskInstence()
	 * @generated
	 */
	EAttribute gettaskInstence_Name();

	/**
	 * Returns the meta object for the reference list '{@link iqre.taskInstence#getMeansEndInsGoal <em>Means End Ins Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Means End Ins Goal</em>'.
	 * @see iqre.taskInstence#getMeansEndInsGoal()
	 * @see #gettaskInstence()
	 * @generated
	 */
	EReference gettaskInstence_MeansEndInsGoal();

	/**
	 * Returns the meta object for the reference '{@link iqre.taskInstence#getInstence <em>Instence</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Instence</em>'.
	 * @see iqre.taskInstence#getInstence()
	 * @see #gettaskInstence()
	 * @generated
	 */
	EReference gettaskInstence_Instence();

	/**
	 * Returns the meta object for the reference list '{@link iqre.taskInstence#getAndDecomposition <em>And Decomposition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>And Decomposition</em>'.
	 * @see iqre.taskInstence#getAndDecomposition()
	 * @see #gettaskInstence()
	 * @generated
	 */
	EReference gettaskInstence_AndDecomposition();

	/**
	 * Returns the meta object for the reference list '{@link iqre.taskInstence#getOrDecomposition <em>Or Decomposition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Or Decomposition</em>'.
	 * @see iqre.taskInstence#getOrDecomposition()
	 * @see #gettaskInstence()
	 * @generated
	 */
	EReference gettaskInstence_OrDecomposition();

	/**
	 * Returns the meta object for the reference list '{@link iqre.taskInstence#getDependent <em>Dependent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Dependent</em>'.
	 * @see iqre.taskInstence#getDependent()
	 * @see #gettaskInstence()
	 * @generated
	 */
	EReference gettaskInstence_Dependent();

	/**
	 * Returns the meta object for class '{@link iqre.information <em>information</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>information</em>'.
	 * @see iqre.information
	 * @generated
	 */
	EClass getinformation();

	/**
	 * Returns the meta object for the attribute '{@link iqre.information#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see iqre.information#getName()
	 * @see #getinformation()
	 * @generated
	 */
	EAttribute getinformation_Name();

	/**
	 * Returns the meta object for the attribute '{@link iqre.information#getVolatility <em>Volatility</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Volatility</em>'.
	 * @see iqre.information#getVolatility()
	 * @see #getinformation()
	 * @generated
	 */
	EAttribute getinformation_Volatility();

	/**
	 * Returns the meta object for the reference list '{@link iqre.information#getSubItem <em>Sub Item</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Sub Item</em>'.
	 * @see iqre.information#getSubItem()
	 * @see #getinformation()
	 * @generated
	 */
	EReference getinformation_SubItem();

	/**
	 * Returns the meta object for class '{@link iqre.reads <em>reads</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>reads</em>'.
	 * @see iqre.reads
	 * @generated
	 */
	EClass getreads();

	/**
	 * Returns the meta object for the attribute '{@link iqre.reads#getPurposeOfUse <em>Purpose Of Use</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Purpose Of Use</em>'.
	 * @see iqre.reads#getPurposeOfUse()
	 * @see #getreads()
	 * @generated
	 */
	EAttribute getreads_PurposeOfUse();

	/**
	 * Returns the meta object for the attribute '{@link iqre.reads#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see iqre.reads#getType()
	 * @see #getreads()
	 * @generated
	 */
	EAttribute getreads_Type();

	/**
	 * Returns the meta object for the reference list '{@link iqre.reads#getReadsBy <em>Reads By</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Reads By</em>'.
	 * @see iqre.reads#getReadsBy()
	 * @see #getreads()
	 * @generated
	 */
	EReference getreads_ReadsBy();

	/**
	 * Returns the meta object for the reference list '{@link iqre.reads#getReadsOf <em>Reads Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Reads Of</em>'.
	 * @see iqre.reads#getReadsOf()
	 * @see #getreads()
	 * @generated
	 */
	EReference getreads_ReadsOf();

	/**
	 * Returns the meta object for class '{@link iqre.produces <em>produces</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>produces</em>'.
	 * @see iqre.produces
	 * @generated
	 */
	EClass getproduces();

	/**
	 * Returns the meta object for the attribute '{@link iqre.produces#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see iqre.produces#getType()
	 * @see #getproduces()
	 * @generated
	 */
	EAttribute getproduces_Type();

	/**
	 * Returns the meta object for the reference list '{@link iqre.produces#getProducesBy <em>Produces By</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Produces By</em>'.
	 * @see iqre.produces#getProducesBy()
	 * @see #getproduces()
	 * @generated
	 */
	EReference getproduces_ProducesBy();

	/**
	 * Returns the meta object for the reference list '{@link iqre.produces#getProducesOf <em>Produces Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Produces Of</em>'.
	 * @see iqre.produces#getProducesOf()
	 * @see #getproduces()
	 * @generated
	 */
	EReference getproduces_ProducesOf();

	/**
	 * Returns the meta object for class '{@link iqre.sends <em>sends</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>sends</em>'.
	 * @see iqre.sends
	 * @generated
	 */
	EClass getsends();

	/**
	 * Returns the meta object for the attribute '{@link iqre.sends#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see iqre.sends#getType()
	 * @see #getsends()
	 * @generated
	 */
	EAttribute getsends_Type();

	/**
	 * Returns the meta object for the attribute '{@link iqre.sends#getTime <em>Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Time</em>'.
	 * @see iqre.sends#getTime()
	 * @see #getsends()
	 * @generated
	 */
	EAttribute getsends_Time();

	/**
	 * Returns the meta object for the reference list '{@link iqre.sends#getSendsBy <em>Sends By</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Sends By</em>'.
	 * @see iqre.sends#getSendsBy()
	 * @see #getsends()
	 * @generated
	 */
	EReference getsends_SendsBy();

	/**
	 * Returns the meta object for the reference list '{@link iqre.sends#getSendsOf <em>Sends Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Sends Of</em>'.
	 * @see iqre.sends#getSendsOf()
	 * @see #getsends()
	 * @generated
	 */
	EReference getsends_SendsOf();

	/**
	 * Returns the meta object for the reference list '{@link iqre.sends#getSendsTo <em>Sends To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Sends To</em>'.
	 * @see iqre.sends#getSendsTo()
	 * @see #getsends()
	 * @generated
	 */
	EReference getsends_SendsTo();

	/**
	 * Returns the meta object for class '{@link iqre.delegation <em>delegation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>delegation</em>'.
	 * @see iqre.delegation
	 * @generated
	 */
	EClass getdelegation();

	/**
	 * Returns the meta object for the reference list '{@link iqre.delegation#getDelegationFrom <em>Delegation From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Delegation From</em>'.
	 * @see iqre.delegation#getDelegationFrom()
	 * @see #getdelegation()
	 * @generated
	 */
	EReference getdelegation_DelegationFrom();

	/**
	 * Returns the meta object for the reference list '{@link iqre.delegation#getDelegationTo <em>Delegation To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Delegation To</em>'.
	 * @see iqre.delegation#getDelegationTo()
	 * @see #getdelegation()
	 * @generated
	 */
	EReference getdelegation_DelegationTo();

	/**
	 * Returns the meta object for the reference list '{@link iqre.delegation#getDelegationOfGoal <em>Delegation Of Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Delegation Of Goal</em>'.
	 * @see iqre.delegation#getDelegationOfGoal()
	 * @see #getdelegation()
	 * @generated
	 */
	EReference getdelegation_DelegationOfGoal();

	/**
	 * Returns the meta object for the reference list '{@link iqre.delegation#getDelegationOfTask <em>Delegation Of Task</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Delegation Of Task</em>'.
	 * @see iqre.delegation#getDelegationOfTask()
	 * @see #getdelegation()
	 * @generated
	 */
	EReference getdelegation_DelegationOfTask();

	/**
	 * Returns the meta object for class '{@link iqre.informationProvision <em>information Provision</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>information Provision</em>'.
	 * @see iqre.informationProvision
	 * @generated
	 */
	EClass getinformationProvision();

	/**
	 * Returns the meta object for the attribute '{@link iqre.informationProvision#getTime <em>Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Time</em>'.
	 * @see iqre.informationProvision#getTime()
	 * @see #getinformationProvision()
	 * @generated
	 */
	EAttribute getinformationProvision_Time();

	/**
	 * Returns the meta object for the attribute '{@link iqre.informationProvision#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see iqre.informationProvision#getType()
	 * @see #getinformationProvision()
	 * @generated
	 */
	EAttribute getinformationProvision_Type();

	/**
	 * Returns the meta object for the reference list '{@link iqre.informationProvision#getProvisionTo <em>Provision To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Provision To</em>'.
	 * @see iqre.informationProvision#getProvisionTo()
	 * @see #getinformationProvision()
	 * @generated
	 */
	EReference getinformationProvision_ProvisionTo();

	/**
	 * Returns the meta object for the reference list '{@link iqre.informationProvision#getProvisionFrom <em>Provision From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Provision From</em>'.
	 * @see iqre.informationProvision#getProvisionFrom()
	 * @see #getinformationProvision()
	 * @generated
	 */
	EReference getinformationProvision_ProvisionFrom();

	/**
	 * Returns the meta object for the reference list '{@link iqre.informationProvision#getProvisionOf <em>Provision Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Provision Of</em>'.
	 * @see iqre.informationProvision#getProvisionOf()
	 * @see #getinformationProvision()
	 * @generated
	 */
	EReference getinformationProvision_ProvisionOf();

	/**
	 * Returns the meta object for class '{@link iqre.trustOfDelegation <em>trust Of Delegation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>trust Of Delegation</em>'.
	 * @see iqre.trustOfDelegation
	 * @generated
	 */
	EClass gettrustOfDelegation();

	/**
	 * Returns the meta object for the reference list '{@link iqre.trustOfDelegation#getDeleTrustor <em>Dele Trustor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Dele Trustor</em>'.
	 * @see iqre.trustOfDelegation#getDeleTrustor()
	 * @see #gettrustOfDelegation()
	 * @generated
	 */
	EReference gettrustOfDelegation_DeleTrustor();

	/**
	 * Returns the meta object for the reference list '{@link iqre.trustOfDelegation#getDeleTrustee <em>Dele Trustee</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Dele Trustee</em>'.
	 * @see iqre.trustOfDelegation#getDeleTrustee()
	 * @see #gettrustOfDelegation()
	 * @generated
	 */
	EReference gettrustOfDelegation_DeleTrustee();

	/**
	 * Returns the meta object for the reference list '{@link iqre.trustOfDelegation#getGoalTrustum <em>Goal Trustum</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Goal Trustum</em>'.
	 * @see iqre.trustOfDelegation#getGoalTrustum()
	 * @see #gettrustOfDelegation()
	 * @generated
	 */
	EReference gettrustOfDelegation_GoalTrustum();

	/**
	 * Returns the meta object for the reference list '{@link iqre.trustOfDelegation#getTaskTrustum <em>Task Trustum</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Task Trustum</em>'.
	 * @see iqre.trustOfDelegation#getTaskTrustum()
	 * @see #gettrustOfDelegation()
	 * @generated
	 */
	EReference gettrustOfDelegation_TaskTrustum();

	/**
	 * Returns the meta object for class '{@link iqre.provisionTrust <em>provision Trust</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>provision Trust</em>'.
	 * @see iqre.provisionTrust
	 * @generated
	 */
	EClass getprovisionTrust();

	/**
	 * Returns the meta object for the reference list '{@link iqre.provisionTrust#getPrvTrustee <em>Prv Trustee</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Prv Trustee</em>'.
	 * @see iqre.provisionTrust#getPrvTrustee()
	 * @see #getprovisionTrust()
	 * @generated
	 */
	EReference getprovisionTrust_PrvTrustee();

	/**
	 * Returns the meta object for the reference list '{@link iqre.provisionTrust#getPrvTrustor <em>Prv Trustor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Prv Trustor</em>'.
	 * @see iqre.provisionTrust#getPrvTrustor()
	 * @see #getprovisionTrust()
	 * @generated
	 */
	EReference getprovisionTrust_PrvTrustor();

	/**
	 * Returns the meta object for the reference list '{@link iqre.provisionTrust#getTrustOfProvision <em>Trust Of Provision</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Trust Of Provision</em>'.
	 * @see iqre.provisionTrust#getTrustOfProvision()
	 * @see #getprovisionTrust()
	 * @generated
	 */
	EReference getprovisionTrust_TrustOfProvision();

	/**
	 * Returns the meta object for the attribute '{@link iqre.provisionTrust#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see iqre.provisionTrust#getType()
	 * @see #getprovisionTrust()
	 * @generated
	 */
	EAttribute getprovisionTrust_Type();

	/**
	 * Returns the meta object for class '{@link iqre.produceTrust <em>produce Trust</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>produce Trust</em>'.
	 * @see iqre.produceTrust
	 * @generated
	 */
	EClass getproduceTrust();

	/**
	 * Returns the meta object for the reference list '{@link iqre.produceTrust#getProduceTrustor <em>Produce Trustor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Produce Trustor</em>'.
	 * @see iqre.produceTrust#getProduceTrustor()
	 * @see #getproduceTrust()
	 * @generated
	 */
	EReference getproduceTrust_ProduceTrustor();

	/**
	 * Returns the meta object for the reference list '{@link iqre.produceTrust#getProduceTrustee <em>Produce Trustee</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Produce Trustee</em>'.
	 * @see iqre.produceTrust#getProduceTrustee()
	 * @see #getproduceTrust()
	 * @generated
	 */
	EReference getproduceTrust_ProduceTrustee();

	/**
	 * Returns the meta object for the reference list '{@link iqre.produceTrust#getTrustOfProvducing <em>Trust Of Provducing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Trust Of Provducing</em>'.
	 * @see iqre.produceTrust#getTrustOfProvducing()
	 * @see #getproduceTrust()
	 * @generated
	 */
	EReference getproduceTrust_TrustOfProvducing();

	/**
	 * Returns the meta object for the attribute '{@link iqre.produceTrust#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see iqre.produceTrust#getType()
	 * @see #getproduceTrust()
	 * @generated
	 */
	EAttribute getproduceTrust_Type();

	/**
	 * Returns the meta object for class '{@link iqre.softgoal <em>softgoal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>softgoal</em>'.
	 * @see iqre.softgoal
	 * @generated
	 */
	EClass getsoftgoal();

	/**
	 * Returns the meta object for the reference list '{@link iqre.softgoal#getAndDecomposition <em>And Decomposition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>And Decomposition</em>'.
	 * @see iqre.softgoal#getAndDecomposition()
	 * @see #getsoftgoal()
	 * @generated
	 */
	EReference getsoftgoal_AndDecomposition();

	/**
	 * Returns the meta object for the attribute '{@link iqre.softgoal#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see iqre.softgoal#getType()
	 * @see #getsoftgoal()
	 * @generated
	 */
	EAttribute getsoftgoal_Type();

	/**
	 * Returns the meta object for the reference '{@link iqre.softgoal#getQualityTarget <em>Quality Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Quality Target</em>'.
	 * @see iqre.softgoal#getQualityTarget()
	 * @see #getsoftgoal()
	 * @generated
	 */
	EReference getsoftgoal_QualityTarget();

	/**
	 * Returns the meta object for class '{@link iqre.qualityConstraint <em>quality Constraint</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>quality Constraint</em>'.
	 * @see iqre.qualityConstraint
	 * @generated
	 */
	EClass getqualityConstraint();

	/**
	 * Returns the meta object for the reference '{@link iqre.qualityConstraint#getApproximateRelation <em>Approximate Relation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Approximate Relation</em>'.
	 * @see iqre.qualityConstraint#getApproximateRelation()
	 * @see #getqualityConstraint()
	 * @generated
	 */
	EReference getqualityConstraint_ApproximateRelation();

	/**
	 * Returns the meta object for the attribute '{@link iqre.qualityConstraint#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see iqre.qualityConstraint#getType()
	 * @see #getqualityConstraint()
	 * @generated
	 */
	EAttribute getqualityConstraint_Type();

	/**
	 * Returns the meta object for the reference '{@link iqre.qualityConstraint#getQualityTarget <em>Quality Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Quality Target</em>'.
	 * @see iqre.qualityConstraint#getQualityTarget()
	 * @see #getqualityConstraint()
	 * @generated
	 */
	EReference getqualityConstraint_QualityTarget();

	/**
	 * Returns the meta object for class '{@link iqre.scope <em>scope</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>scope</em>'.
	 * @see iqre.scope
	 * @generated
	 */
	EClass getscope();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	IqreFactory getIqreFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link iqre.impl.DiagramImpl <em>Diagram</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.DiagramImpl
		 * @see iqre.impl.IqrePackageImpl#getDiagram()
		 * @generated
		 */
		EClass DIAGRAM = eINSTANCE.getDiagram();

		/**
		 * The meta object literal for the '<em><b>Role Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__ROLE_ELEMENT = eINSTANCE.getDiagram_RoleElement();

		/**
		 * The meta object literal for the '<em><b>Goal Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__GOAL_ELEMENT = eINSTANCE.getDiagram_GoalElement();

		/**
		 * The meta object literal for the '<em><b>Goal Instence Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__GOAL_INSTENCE_ELEMENT = eINSTANCE.getDiagram_GoalInstenceElement();

		/**
		 * The meta object literal for the '<em><b>Agent Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__AGENT_ELEMENT = eINSTANCE.getDiagram_AgentElement();

		/**
		 * The meta object literal for the '<em><b>Task Instence Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__TASK_INSTENCE_ELEMENT = eINSTANCE.getDiagram_TaskInstenceElement();

		/**
		 * The meta object literal for the '<em><b>Task Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__TASK_ELEMENT = eINSTANCE.getDiagram_TaskElement();

		/**
		 * The meta object literal for the '<em><b>Information Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__INFORMATION_ELEMENT = eINSTANCE.getDiagram_InformationElement();

		/**
		 * The meta object literal for the '<em><b>Reads Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__READS_ELEMENT = eINSTANCE.getDiagram_ReadsElement();

		/**
		 * The meta object literal for the '<em><b>Produces Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__PRODUCES_ELEMENT = eINSTANCE.getDiagram_ProducesElement();

		/**
		 * The meta object literal for the '<em><b>Sends Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__SENDS_ELEMENT = eINSTANCE.getDiagram_SendsElement();

		/**
		 * The meta object literal for the '<em><b>Delegation Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__DELEGATION_ELEMENT = eINSTANCE.getDiagram_DelegationElement();

		/**
		 * The meta object literal for the '<em><b>Information Provision Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__INFORMATION_PROVISION_ELEMENT = eINSTANCE.getDiagram_InformationProvisionElement();

		/**
		 * The meta object literal for the '<em><b>Delegation Trust Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__DELEGATION_TRUST_ELEMENT = eINSTANCE.getDiagram_DelegationTrustElement();

		/**
		 * The meta object literal for the '<em><b>Provision Trust Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__PROVISION_TRUST_ELEMENT = eINSTANCE.getDiagram_ProvisionTrustElement();

		/**
		 * The meta object literal for the '<em><b>Produce Trust Elemet</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__PRODUCE_TRUST_ELEMET = eINSTANCE.getDiagram_ProduceTrustElemet();

		/**
		 * The meta object literal for the '<em><b>Softgoal Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__SOFTGOAL_ELEMENT = eINSTANCE.getDiagram_SoftgoalElement();

		/**
		 * The meta object literal for the '<em><b>Quality Constraint Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__QUALITY_CONSTRAINT_ELEMENT = eINSTANCE.getDiagram_QualityConstraintElement();

		/**
		 * The meta object literal for the '<em><b>Scope Elelemt</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__SCOPE_ELELEMT = eINSTANCE.getDiagram_ScopeElelemt();

		/**
		 * The meta object literal for the '{@link iqre.impl.roleImpl <em>role</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.roleImpl
		 * @see iqre.impl.IqrePackageImpl#getrole()
		 * @generated
		 */
		EClass ROLE = eINSTANCE.getrole();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROLE__NAME = eINSTANCE.getrole_Name();

		/**
		 * The meta object literal for the '<em><b>Aims</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__AIMS = eINSTANCE.getrole_Aims();

		/**
		 * The meta object literal for the '<em><b>Capable Goal</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__CAPABLE_GOAL = eINSTANCE.getrole_CapableGoal();

		/**
		 * The meta object literal for the '<em><b>Capable Task</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__CAPABLE_TASK = eINSTANCE.getrole_CapableTask();

		/**
		 * The meta object literal for the '{@link iqre.impl.goalImpl <em>goal</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.goalImpl
		 * @see iqre.impl.IqrePackageImpl#getgoal()
		 * @generated
		 */
		EClass GOAL = eINSTANCE.getgoal();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GOAL__NAME = eINSTANCE.getgoal_Name();

		/**
		 * The meta object literal for the '<em><b>And Decomposition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL__AND_DECOMPOSITION = eINSTANCE.getgoal_AndDecomposition();

		/**
		 * The meta object literal for the '<em><b>Or Decomposition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL__OR_DECOMPOSITION = eINSTANCE.getgoal_OrDecomposition();

		/**
		 * The meta object literal for the '{@link iqre.impl.agentImpl <em>agent</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.agentImpl
		 * @see iqre.impl.IqrePackageImpl#getagent()
		 * @generated
		 */
		EClass AGENT = eINSTANCE.getagent();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGENT__NAME = eINSTANCE.getagent_Name();

		/**
		 * The meta object literal for the '<em><b>Plays</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AGENT__PLAYS = eINSTANCE.getagent_Plays();

		/**
		 * The meta object literal for the '<em><b>Aims</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AGENT__AIMS = eINSTANCE.getagent_Aims();

		/**
		 * The meta object literal for the '{@link iqre.impl.goalInstenceImpl <em>goal Instence</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.goalInstenceImpl
		 * @see iqre.impl.IqrePackageImpl#getgoalInstence()
		 * @generated
		 */
		EClass GOAL_INSTENCE = eINSTANCE.getgoalInstence();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GOAL_INSTENCE__NAME = eINSTANCE.getgoalInstence_Name();

		/**
		 * The meta object literal for the '<em><b>Instence</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL_INSTENCE__INSTENCE = eINSTANCE.getgoalInstence_Instence();

		/**
		 * The meta object literal for the '<em><b>And Decomposition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL_INSTENCE__AND_DECOMPOSITION = eINSTANCE.getgoalInstence_AndDecomposition();

		/**
		 * The meta object literal for the '<em><b>Or Decomposition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL_INSTENCE__OR_DECOMPOSITION = eINSTANCE.getgoalInstence_OrDecomposition();

		/**
		 * The meta object literal for the '{@link iqre.impl.taskImpl <em>task</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.taskImpl
		 * @see iqre.impl.IqrePackageImpl#gettask()
		 * @generated
		 */
		EClass TASK = eINSTANCE.gettask();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TASK__NAME = eINSTANCE.gettask_Name();

		/**
		 * The meta object literal for the '<em><b>Means End Goal</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TASK__MEANS_END_GOAL = eINSTANCE.gettask_MeansEndGoal();

		/**
		 * The meta object literal for the '<em><b>And Decomposition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TASK__AND_DECOMPOSITION = eINSTANCE.gettask_AndDecomposition();

		/**
		 * The meta object literal for the '<em><b>Or Decomposition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TASK__OR_DECOMPOSITION = eINSTANCE.gettask_OrDecomposition();

		/**
		 * The meta object literal for the '{@link iqre.impl.taskInstenceImpl <em>task Instence</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.taskInstenceImpl
		 * @see iqre.impl.IqrePackageImpl#gettaskInstence()
		 * @generated
		 */
		EClass TASK_INSTENCE = eINSTANCE.gettaskInstence();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TASK_INSTENCE__NAME = eINSTANCE.gettaskInstence_Name();

		/**
		 * The meta object literal for the '<em><b>Means End Ins Goal</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TASK_INSTENCE__MEANS_END_INS_GOAL = eINSTANCE.gettaskInstence_MeansEndInsGoal();

		/**
		 * The meta object literal for the '<em><b>Instence</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TASK_INSTENCE__INSTENCE = eINSTANCE.gettaskInstence_Instence();

		/**
		 * The meta object literal for the '<em><b>And Decomposition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TASK_INSTENCE__AND_DECOMPOSITION = eINSTANCE.gettaskInstence_AndDecomposition();

		/**
		 * The meta object literal for the '<em><b>Or Decomposition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TASK_INSTENCE__OR_DECOMPOSITION = eINSTANCE.gettaskInstence_OrDecomposition();

		/**
		 * The meta object literal for the '<em><b>Dependent</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TASK_INSTENCE__DEPENDENT = eINSTANCE.gettaskInstence_Dependent();

		/**
		 * The meta object literal for the '{@link iqre.impl.informationImpl <em>information</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.informationImpl
		 * @see iqre.impl.IqrePackageImpl#getinformation()
		 * @generated
		 */
		EClass INFORMATION = eINSTANCE.getinformation();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INFORMATION__NAME = eINSTANCE.getinformation_Name();

		/**
		 * The meta object literal for the '<em><b>Volatility</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INFORMATION__VOLATILITY = eINSTANCE.getinformation_Volatility();

		/**
		 * The meta object literal for the '<em><b>Sub Item</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INFORMATION__SUB_ITEM = eINSTANCE.getinformation_SubItem();

		/**
		 * The meta object literal for the '{@link iqre.impl.readsImpl <em>reads</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.readsImpl
		 * @see iqre.impl.IqrePackageImpl#getreads()
		 * @generated
		 */
		EClass READS = eINSTANCE.getreads();

		/**
		 * The meta object literal for the '<em><b>Purpose Of Use</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute READS__PURPOSE_OF_USE = eINSTANCE.getreads_PurposeOfUse();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute READS__TYPE = eINSTANCE.getreads_Type();

		/**
		 * The meta object literal for the '<em><b>Reads By</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference READS__READS_BY = eINSTANCE.getreads_ReadsBy();

		/**
		 * The meta object literal for the '<em><b>Reads Of</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference READS__READS_OF = eINSTANCE.getreads_ReadsOf();

		/**
		 * The meta object literal for the '{@link iqre.impl.producesImpl <em>produces</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.producesImpl
		 * @see iqre.impl.IqrePackageImpl#getproduces()
		 * @generated
		 */
		EClass PRODUCES = eINSTANCE.getproduces();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRODUCES__TYPE = eINSTANCE.getproduces_Type();

		/**
		 * The meta object literal for the '<em><b>Produces By</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCES__PRODUCES_BY = eINSTANCE.getproduces_ProducesBy();

		/**
		 * The meta object literal for the '<em><b>Produces Of</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCES__PRODUCES_OF = eINSTANCE.getproduces_ProducesOf();

		/**
		 * The meta object literal for the '{@link iqre.impl.sendsImpl <em>sends</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.sendsImpl
		 * @see iqre.impl.IqrePackageImpl#getsends()
		 * @generated
		 */
		EClass SENDS = eINSTANCE.getsends();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SENDS__TYPE = eINSTANCE.getsends_Type();

		/**
		 * The meta object literal for the '<em><b>Time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SENDS__TIME = eINSTANCE.getsends_Time();

		/**
		 * The meta object literal for the '<em><b>Sends By</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SENDS__SENDS_BY = eINSTANCE.getsends_SendsBy();

		/**
		 * The meta object literal for the '<em><b>Sends Of</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SENDS__SENDS_OF = eINSTANCE.getsends_SendsOf();

		/**
		 * The meta object literal for the '<em><b>Sends To</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SENDS__SENDS_TO = eINSTANCE.getsends_SendsTo();

		/**
		 * The meta object literal for the '{@link iqre.impl.delegationImpl <em>delegation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.delegationImpl
		 * @see iqre.impl.IqrePackageImpl#getdelegation()
		 * @generated
		 */
		EClass DELEGATION = eINSTANCE.getdelegation();

		/**
		 * The meta object literal for the '<em><b>Delegation From</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DELEGATION__DELEGATION_FROM = eINSTANCE.getdelegation_DelegationFrom();

		/**
		 * The meta object literal for the '<em><b>Delegation To</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DELEGATION__DELEGATION_TO = eINSTANCE.getdelegation_DelegationTo();

		/**
		 * The meta object literal for the '<em><b>Delegation Of Goal</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DELEGATION__DELEGATION_OF_GOAL = eINSTANCE.getdelegation_DelegationOfGoal();

		/**
		 * The meta object literal for the '<em><b>Delegation Of Task</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DELEGATION__DELEGATION_OF_TASK = eINSTANCE.getdelegation_DelegationOfTask();

		/**
		 * The meta object literal for the '{@link iqre.impl.informationProvisionImpl <em>information Provision</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.informationProvisionImpl
		 * @see iqre.impl.IqrePackageImpl#getinformationProvision()
		 * @generated
		 */
		EClass INFORMATION_PROVISION = eINSTANCE.getinformationProvision();

		/**
		 * The meta object literal for the '<em><b>Time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INFORMATION_PROVISION__TIME = eINSTANCE.getinformationProvision_Time();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INFORMATION_PROVISION__TYPE = eINSTANCE.getinformationProvision_Type();

		/**
		 * The meta object literal for the '<em><b>Provision To</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INFORMATION_PROVISION__PROVISION_TO = eINSTANCE.getinformationProvision_ProvisionTo();

		/**
		 * The meta object literal for the '<em><b>Provision From</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INFORMATION_PROVISION__PROVISION_FROM = eINSTANCE.getinformationProvision_ProvisionFrom();

		/**
		 * The meta object literal for the '<em><b>Provision Of</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INFORMATION_PROVISION__PROVISION_OF = eINSTANCE.getinformationProvision_ProvisionOf();

		/**
		 * The meta object literal for the '{@link iqre.impl.trustOfDelegationImpl <em>trust Of Delegation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.trustOfDelegationImpl
		 * @see iqre.impl.IqrePackageImpl#gettrustOfDelegation()
		 * @generated
		 */
		EClass TRUST_OF_DELEGATION = eINSTANCE.gettrustOfDelegation();

		/**
		 * The meta object literal for the '<em><b>Dele Trustor</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRUST_OF_DELEGATION__DELE_TRUSTOR = eINSTANCE.gettrustOfDelegation_DeleTrustor();

		/**
		 * The meta object literal for the '<em><b>Dele Trustee</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRUST_OF_DELEGATION__DELE_TRUSTEE = eINSTANCE.gettrustOfDelegation_DeleTrustee();

		/**
		 * The meta object literal for the '<em><b>Goal Trustum</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRUST_OF_DELEGATION__GOAL_TRUSTUM = eINSTANCE.gettrustOfDelegation_GoalTrustum();

		/**
		 * The meta object literal for the '<em><b>Task Trustum</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRUST_OF_DELEGATION__TASK_TRUSTUM = eINSTANCE.gettrustOfDelegation_TaskTrustum();

		/**
		 * The meta object literal for the '{@link iqre.impl.provisionTrustImpl <em>provision Trust</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.provisionTrustImpl
		 * @see iqre.impl.IqrePackageImpl#getprovisionTrust()
		 * @generated
		 */
		EClass PROVISION_TRUST = eINSTANCE.getprovisionTrust();

		/**
		 * The meta object literal for the '<em><b>Prv Trustee</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROVISION_TRUST__PRV_TRUSTEE = eINSTANCE.getprovisionTrust_PrvTrustee();

		/**
		 * The meta object literal for the '<em><b>Prv Trustor</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROVISION_TRUST__PRV_TRUSTOR = eINSTANCE.getprovisionTrust_PrvTrustor();

		/**
		 * The meta object literal for the '<em><b>Trust Of Provision</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROVISION_TRUST__TRUST_OF_PROVISION = eINSTANCE.getprovisionTrust_TrustOfProvision();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROVISION_TRUST__TYPE = eINSTANCE.getprovisionTrust_Type();

		/**
		 * The meta object literal for the '{@link iqre.impl.produceTrustImpl <em>produce Trust</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.produceTrustImpl
		 * @see iqre.impl.IqrePackageImpl#getproduceTrust()
		 * @generated
		 */
		EClass PRODUCE_TRUST = eINSTANCE.getproduceTrust();

		/**
		 * The meta object literal for the '<em><b>Produce Trustor</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCE_TRUST__PRODUCE_TRUSTOR = eINSTANCE.getproduceTrust_ProduceTrustor();

		/**
		 * The meta object literal for the '<em><b>Produce Trustee</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCE_TRUST__PRODUCE_TRUSTEE = eINSTANCE.getproduceTrust_ProduceTrustee();

		/**
		 * The meta object literal for the '<em><b>Trust Of Provducing</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCE_TRUST__TRUST_OF_PROVDUCING = eINSTANCE.getproduceTrust_TrustOfProvducing();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRODUCE_TRUST__TYPE = eINSTANCE.getproduceTrust_Type();

		/**
		 * The meta object literal for the '{@link iqre.impl.softgoalImpl <em>softgoal</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.softgoalImpl
		 * @see iqre.impl.IqrePackageImpl#getsoftgoal()
		 * @generated
		 */
		EClass SOFTGOAL = eINSTANCE.getsoftgoal();

		/**
		 * The meta object literal for the '<em><b>And Decomposition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SOFTGOAL__AND_DECOMPOSITION = eINSTANCE.getsoftgoal_AndDecomposition();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SOFTGOAL__TYPE = eINSTANCE.getsoftgoal_Type();

		/**
		 * The meta object literal for the '<em><b>Quality Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SOFTGOAL__QUALITY_TARGET = eINSTANCE.getsoftgoal_QualityTarget();

		/**
		 * The meta object literal for the '{@link iqre.impl.qualityConstraintImpl <em>quality Constraint</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.qualityConstraintImpl
		 * @see iqre.impl.IqrePackageImpl#getqualityConstraint()
		 * @generated
		 */
		EClass QUALITY_CONSTRAINT = eINSTANCE.getqualityConstraint();

		/**
		 * The meta object literal for the '<em><b>Approximate Relation</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference QUALITY_CONSTRAINT__APPROXIMATE_RELATION = eINSTANCE.getqualityConstraint_ApproximateRelation();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute QUALITY_CONSTRAINT__TYPE = eINSTANCE.getqualityConstraint_Type();

		/**
		 * The meta object literal for the '<em><b>Quality Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference QUALITY_CONSTRAINT__QUALITY_TARGET = eINSTANCE.getqualityConstraint_QualityTarget();

		/**
		 * The meta object literal for the '{@link iqre.impl.scopeImpl <em>scope</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqre.impl.scopeImpl
		 * @see iqre.impl.IqrePackageImpl#getscope()
		 * @generated
		 */
		EClass SCOPE = eINSTANCE.getscope();

	}

} //IqrePackage
