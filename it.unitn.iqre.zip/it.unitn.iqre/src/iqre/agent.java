/**
 */
package iqre;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>agent</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqre.agent#getName <em>Name</em>}</li>
 *   <li>{@link iqre.agent#getPlays <em>Plays</em>}</li>
 *   <li>{@link iqre.agent#getAims <em>Aims</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqre.IqrePackage#getagent()
 * @model
 * @generated
 */
public interface agent extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see iqre.IqrePackage#getagent_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link iqre.agent#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Plays</b></em>' reference list.
	 * The list contents are of type {@link iqre.role}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Plays</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Plays</em>' reference list.
	 * @see iqre.IqrePackage#getagent_Plays()
	 * @model type="iqre.role"
	 * @generated
	 */
	EList getPlays();

	/**
	 * Returns the value of the '<em><b>Aims</b></em>' reference list.
	 * The list contents are of type {@link iqre.goalInstence}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Aims</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Aims</em>' reference list.
	 * @see iqre.IqrePackage#getagent_Aims()
	 * @model type="iqre.goalInstence"
	 * @generated
	 */
	EList getAims();

} // agent
