/**
 */
package iqre;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Diagram</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqre.Diagram#getRoleElement <em>Role Element</em>}</li>
 *   <li>{@link iqre.Diagram#getGoalElement <em>Goal Element</em>}</li>
 *   <li>{@link iqre.Diagram#getGoalInstenceElement <em>Goal Instence Element</em>}</li>
 *   <li>{@link iqre.Diagram#getAgentElement <em>Agent Element</em>}</li>
 *   <li>{@link iqre.Diagram#getTaskInstenceElement <em>Task Instence Element</em>}</li>
 *   <li>{@link iqre.Diagram#getTaskElement <em>Task Element</em>}</li>
 *   <li>{@link iqre.Diagram#getInformationElement <em>Information Element</em>}</li>
 *   <li>{@link iqre.Diagram#getReadsElement <em>Reads Element</em>}</li>
 *   <li>{@link iqre.Diagram#getProducesElement <em>Produces Element</em>}</li>
 *   <li>{@link iqre.Diagram#getSendsElement <em>Sends Element</em>}</li>
 *   <li>{@link iqre.Diagram#getDelegationElement <em>Delegation Element</em>}</li>
 *   <li>{@link iqre.Diagram#getInformationProvisionElement <em>Information Provision Element</em>}</li>
 *   <li>{@link iqre.Diagram#getDelegationTrustElement <em>Delegation Trust Element</em>}</li>
 *   <li>{@link iqre.Diagram#getProvisionTrustElement <em>Provision Trust Element</em>}</li>
 *   <li>{@link iqre.Diagram#getProduceTrustElemet <em>Produce Trust Elemet</em>}</li>
 *   <li>{@link iqre.Diagram#getSoftgoalElement <em>Softgoal Element</em>}</li>
 *   <li>{@link iqre.Diagram#getQualityConstraintElement <em>Quality Constraint Element</em>}</li>
 *   <li>{@link iqre.Diagram#getScopeElelemt <em>Scope Elelemt</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqre.IqrePackage#getDiagram()
 * @model
 * @generated
 */
public interface Diagram extends EObject {

	/**
	 * Returns the value of the '<em><b>Role Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqre.role}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Role Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Role Element</em>' containment reference list.
	 * @see iqre.IqrePackage#getDiagram_RoleElement()
	 * @model type="iqre.role" containment="true"
	 * @generated
	 */
	EList getRoleElement();

	/**
	 * Returns the value of the '<em><b>Goal Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqre.goal}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Goal Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Goal Element</em>' containment reference list.
	 * @see iqre.IqrePackage#getDiagram_GoalElement()
	 * @model type="iqre.goal" containment="true"
	 * @generated
	 */
	EList getGoalElement();

	/**
	 * Returns the value of the '<em><b>Goal Instence Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqre.goalInstence}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Goal Instence Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Goal Instence Element</em>' containment reference list.
	 * @see iqre.IqrePackage#getDiagram_GoalInstenceElement()
	 * @model type="iqre.goalInstence" containment="true"
	 * @generated
	 */
	EList getGoalInstenceElement();

	/**
	 * Returns the value of the '<em><b>Agent Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqre.agent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Agent Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Agent Element</em>' containment reference list.
	 * @see iqre.IqrePackage#getDiagram_AgentElement()
	 * @model type="iqre.agent" containment="true"
	 * @generated
	 */
	EList getAgentElement();

	/**
	 * Returns the value of the '<em><b>Task Instence Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqre.taskInstence}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Task Instence Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Task Instence Element</em>' containment reference list.
	 * @see iqre.IqrePackage#getDiagram_TaskInstenceElement()
	 * @model type="iqre.taskInstence" containment="true"
	 * @generated
	 */
	EList getTaskInstenceElement();

	/**
	 * Returns the value of the '<em><b>Task Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqre.task}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Task Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Task Element</em>' containment reference list.
	 * @see iqre.IqrePackage#getDiagram_TaskElement()
	 * @model type="iqre.task" containment="true"
	 * @generated
	 */
	EList getTaskElement();

	/**
	 * Returns the value of the '<em><b>Information Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqre.information}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Information Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Information Element</em>' containment reference list.
	 * @see iqre.IqrePackage#getDiagram_InformationElement()
	 * @model type="iqre.information" containment="true"
	 * @generated
	 */
	EList getInformationElement();

	/**
	 * Returns the value of the '<em><b>Reads Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqre.reads}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Reads Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Reads Element</em>' containment reference list.
	 * @see iqre.IqrePackage#getDiagram_ReadsElement()
	 * @model type="iqre.reads" containment="true"
	 * @generated
	 */
	EList getReadsElement();

	/**
	 * Returns the value of the '<em><b>Produces Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqre.produces}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Produces Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Produces Element</em>' containment reference list.
	 * @see iqre.IqrePackage#getDiagram_ProducesElement()
	 * @model type="iqre.produces" containment="true"
	 * @generated
	 */
	EList getProducesElement();

	/**
	 * Returns the value of the '<em><b>Sends Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqre.sends}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sends Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sends Element</em>' containment reference list.
	 * @see iqre.IqrePackage#getDiagram_SendsElement()
	 * @model type="iqre.sends" containment="true"
	 * @generated
	 */
	EList getSendsElement();

	/**
	 * Returns the value of the '<em><b>Delegation Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqre.delegation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Delegation Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Delegation Element</em>' containment reference list.
	 * @see iqre.IqrePackage#getDiagram_DelegationElement()
	 * @model type="iqre.delegation" containment="true"
	 * @generated
	 */
	EList getDelegationElement();

	/**
	 * Returns the value of the '<em><b>Information Provision Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqre.informationProvision}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Information Provision Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Information Provision Element</em>' containment reference list.
	 * @see iqre.IqrePackage#getDiagram_InformationProvisionElement()
	 * @model type="iqre.informationProvision" containment="true"
	 * @generated
	 */
	EList getInformationProvisionElement();

	/**
	 * Returns the value of the '<em><b>Delegation Trust Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqre.trustOfDelegation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Delegation Trust Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Delegation Trust Element</em>' containment reference list.
	 * @see iqre.IqrePackage#getDiagram_DelegationTrustElement()
	 * @model type="iqre.trustOfDelegation" containment="true"
	 * @generated
	 */
	EList getDelegationTrustElement();

	/**
	 * Returns the value of the '<em><b>Provision Trust Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqre.provisionTrust}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Provision Trust Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Provision Trust Element</em>' containment reference list.
	 * @see iqre.IqrePackage#getDiagram_ProvisionTrustElement()
	 * @model type="iqre.provisionTrust" containment="true"
	 * @generated
	 */
	EList getProvisionTrustElement();

	/**
	 * Returns the value of the '<em><b>Produce Trust Elemet</b></em>' containment reference list.
	 * The list contents are of type {@link iqre.produceTrust}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Produce Trust Elemet</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Produce Trust Elemet</em>' containment reference list.
	 * @see iqre.IqrePackage#getDiagram_ProduceTrustElemet()
	 * @model type="iqre.produceTrust" containment="true"
	 * @generated
	 */
	EList getProduceTrustElemet();

	/**
	 * Returns the value of the '<em><b>Softgoal Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqre.softgoal}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Softgoal Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Softgoal Element</em>' containment reference list.
	 * @see iqre.IqrePackage#getDiagram_SoftgoalElement()
	 * @model type="iqre.softgoal" containment="true"
	 * @generated
	 */
	EList getSoftgoalElement();

	/**
	 * Returns the value of the '<em><b>Quality Constraint Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqre.qualityConstraint}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Quality Constraint Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Quality Constraint Element</em>' containment reference list.
	 * @see iqre.IqrePackage#getDiagram_QualityConstraintElement()
	 * @model type="iqre.qualityConstraint" containment="true"
	 * @generated
	 */
	EList getQualityConstraintElement();

	/**
	 * Returns the value of the '<em><b>Scope Elelemt</b></em>' containment reference list.
	 * The list contents are of type {@link iqre.scope}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Scope Elelemt</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Scope Elelemt</em>' containment reference list.
	 * @see iqre.IqrePackage#getDiagram_ScopeElelemt()
	 * @model type="iqre.scope" containment="true"
	 * @generated
	 */
	EList getScopeElelemt();
} // Diagram
