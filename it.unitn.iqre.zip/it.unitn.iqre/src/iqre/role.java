/**
 */
package iqre;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>role</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqre.role#getName <em>Name</em>}</li>
 *   <li>{@link iqre.role#getAims <em>Aims</em>}</li>
 *   <li>{@link iqre.role#getCapableGoal <em>Capable Goal</em>}</li>
 *   <li>{@link iqre.role#getCapableTask <em>Capable Task</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqre.IqrePackage#getrole()
 * @model
 * @generated
 */
public interface role extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see iqre.IqrePackage#getrole_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link iqre.role#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Aims</b></em>' reference list.
	 * The list contents are of type {@link iqre.goal}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Aims</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Aims</em>' reference list.
	 * @see iqre.IqrePackage#getrole_Aims()
	 * @model type="iqre.goal"
	 * @generated
	 */
	EList getAims();

	/**
	 * Returns the value of the '<em><b>Capable Goal</b></em>' reference list.
	 * The list contents are of type {@link iqre.goal}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Capable Goal</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Capable Goal</em>' reference list.
	 * @see iqre.IqrePackage#getrole_CapableGoal()
	 * @model type="iqre.goal"
	 * @generated
	 */
	EList getCapableGoal();

	/**
	 * Returns the value of the '<em><b>Capable Task</b></em>' reference list.
	 * The list contents are of type {@link iqre.task}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Capable Task</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Capable Task</em>' reference list.
	 * @see iqre.IqrePackage#getrole_CapableTask()
	 * @model type="iqre.task"
	 * @generated
	 */
	EList getCapableTask();

} // role
