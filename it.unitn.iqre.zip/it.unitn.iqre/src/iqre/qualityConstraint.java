/**
 */
package iqre;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>quality Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqre.qualityConstraint#getApproximateRelation <em>Approximate Relation</em>}</li>
 *   <li>{@link iqre.qualityConstraint#getType <em>Type</em>}</li>
 *   <li>{@link iqre.qualityConstraint#getQualityTarget <em>Quality Target</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqre.IqrePackage#getqualityConstraint()
 * @model
 * @generated
 */
public interface qualityConstraint extends EObject {
	/**
	 * Returns the value of the '<em><b>Approximate Relation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Approximate Relation</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Approximate Relation</em>' reference.
	 * @see #setApproximateRelation(softgoal)
	 * @see iqre.IqrePackage#getqualityConstraint_ApproximateRelation()
	 * @model
	 * @generated
	 */
	softgoal getApproximateRelation();

	/**
	 * Sets the value of the '{@link iqre.qualityConstraint#getApproximateRelation <em>Approximate Relation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Approximate Relation</em>' reference.
	 * @see #getApproximateRelation()
	 * @generated
	 */
	void setApproximateRelation(softgoal value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see iqre.IqrePackage#getqualityConstraint_Type()
	 * @model
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link iqre.qualityConstraint#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

	/**
	 * Returns the value of the '<em><b>Quality Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Quality Target</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Quality Target</em>' reference.
	 * @see #setQualityTarget(information)
	 * @see iqre.IqrePackage#getqualityConstraint_QualityTarget()
	 * @model required="true"
	 * @generated
	 */
	information getQualityTarget();

	/**
	 * Sets the value of the '{@link iqre.qualityConstraint#getQualityTarget <em>Quality Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Quality Target</em>' reference.
	 * @see #getQualityTarget()
	 * @generated
	 */
	void setQualityTarget(information value);

} // qualityConstraint
