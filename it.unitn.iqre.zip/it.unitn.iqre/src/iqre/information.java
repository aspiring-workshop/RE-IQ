/**
 */
package iqre;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>information</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqre.information#getName <em>Name</em>}</li>
 *   <li>{@link iqre.information#getVolatility <em>Volatility</em>}</li>
 *   <li>{@link iqre.information#getSubItem <em>Sub Item</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqre.IqrePackage#getinformation()
 * @model
 * @generated
 */
public interface information extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see iqre.IqrePackage#getinformation_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link iqre.information#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Volatility</b></em>' attribute.
	 * The default value is <code>"100"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Volatility</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Volatility</em>' attribute.
	 * @see #setVolatility(int)
	 * @see iqre.IqrePackage#getinformation_Volatility()
	 * @model default="100"
	 * @generated
	 */
	int getVolatility();

	/**
	 * Sets the value of the '{@link iqre.information#getVolatility <em>Volatility</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Volatility</em>' attribute.
	 * @see #getVolatility()
	 * @generated
	 */
	void setVolatility(int value);

	/**
	 * Returns the value of the '<em><b>Sub Item</b></em>' reference list.
	 * The list contents are of type {@link iqre.information}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sub Item</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sub Item</em>' reference list.
	 * @see iqre.IqrePackage#getinformation_SubItem()
	 * @model type="iqre.information" upper="2"
	 * @generated
	 */
	EList getSubItem();

} // information
