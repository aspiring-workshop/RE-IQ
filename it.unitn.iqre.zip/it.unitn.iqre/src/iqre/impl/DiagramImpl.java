/**
 */
package iqre.impl;

import iqre.Diagram;
import iqre.IqrePackage;

import iqre.agent;
import iqre.delegation;
import iqre.goal;
import iqre.goalInstence;
import iqre.information;
import iqre.informationProvision;
import iqre.produceTrust;
import iqre.produces;
import iqre.provisionTrust;
import iqre.qualityConstraint;
import iqre.reads;
import iqre.role;
import iqre.scope;
import iqre.sends;
import iqre.softgoal;
import iqre.task;
import iqre.taskInstence;
import iqre.trustOfDelegation;
import java.util.Collection;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Diagram</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqre.impl.DiagramImpl#getRoleElement <em>Role Element</em>}</li>
 *   <li>{@link iqre.impl.DiagramImpl#getGoalElement <em>Goal Element</em>}</li>
 *   <li>{@link iqre.impl.DiagramImpl#getGoalInstenceElement <em>Goal Instence Element</em>}</li>
 *   <li>{@link iqre.impl.DiagramImpl#getAgentElement <em>Agent Element</em>}</li>
 *   <li>{@link iqre.impl.DiagramImpl#getTaskInstenceElement <em>Task Instence Element</em>}</li>
 *   <li>{@link iqre.impl.DiagramImpl#getTaskElement <em>Task Element</em>}</li>
 *   <li>{@link iqre.impl.DiagramImpl#getInformationElement <em>Information Element</em>}</li>
 *   <li>{@link iqre.impl.DiagramImpl#getReadsElement <em>Reads Element</em>}</li>
 *   <li>{@link iqre.impl.DiagramImpl#getProducesElement <em>Produces Element</em>}</li>
 *   <li>{@link iqre.impl.DiagramImpl#getSendsElement <em>Sends Element</em>}</li>
 *   <li>{@link iqre.impl.DiagramImpl#getDelegationElement <em>Delegation Element</em>}</li>
 *   <li>{@link iqre.impl.DiagramImpl#getInformationProvisionElement <em>Information Provision Element</em>}</li>
 *   <li>{@link iqre.impl.DiagramImpl#getDelegationTrustElement <em>Delegation Trust Element</em>}</li>
 *   <li>{@link iqre.impl.DiagramImpl#getProvisionTrustElement <em>Provision Trust Element</em>}</li>
 *   <li>{@link iqre.impl.DiagramImpl#getProduceTrustElemet <em>Produce Trust Elemet</em>}</li>
 *   <li>{@link iqre.impl.DiagramImpl#getSoftgoalElement <em>Softgoal Element</em>}</li>
 *   <li>{@link iqre.impl.DiagramImpl#getQualityConstraintElement <em>Quality Constraint Element</em>}</li>
 *   <li>{@link iqre.impl.DiagramImpl#getScopeElelemt <em>Scope Elelemt</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class DiagramImpl extends MinimalEObjectImpl.Container implements Diagram {
	/**
	 * The cached value of the '{@link #getRoleElement() <em>Role Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoleElement()
	 * @generated
	 * @ordered
	 */
	protected EList roleElement;
	/**
	 * The cached value of the '{@link #getGoalElement() <em>Goal Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGoalElement()
	 * @generated
	 * @ordered
	 */
	protected EList goalElement;
	/**
	 * The cached value of the '{@link #getGoalInstenceElement() <em>Goal Instence Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGoalInstenceElement()
	 * @generated
	 * @ordered
	 */
	protected EList goalInstenceElement;
	/**
	 * The cached value of the '{@link #getAgentElement() <em>Agent Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAgentElement()
	 * @generated
	 * @ordered
	 */
	protected EList agentElement;

	/**
	 * The cached value of the '{@link #getTaskInstenceElement() <em>Task Instence Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTaskInstenceElement()
	 * @generated
	 * @ordered
	 */
	protected EList taskInstenceElement;
	/**
	 * The cached value of the '{@link #getTaskElement() <em>Task Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTaskElement()
	 * @generated
	 * @ordered
	 */
	protected EList taskElement;
	/**
	 * The cached value of the '{@link #getInformationElement() <em>Information Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInformationElement()
	 * @generated
	 * @ordered
	 */
	protected EList informationElement;
	/**
	 * The cached value of the '{@link #getReadsElement() <em>Reads Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReadsElement()
	 * @generated
	 * @ordered
	 */
	protected EList readsElement;
	/**
	 * The cached value of the '{@link #getProducesElement() <em>Produces Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProducesElement()
	 * @generated
	 * @ordered
	 */
	protected EList producesElement;
	/**
	 * The cached value of the '{@link #getSendsElement() <em>Sends Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSendsElement()
	 * @generated
	 * @ordered
	 */
	protected EList sendsElement;
	/**
	 * The cached value of the '{@link #getDelegationElement() <em>Delegation Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDelegationElement()
	 * @generated
	 * @ordered
	 */
	protected EList delegationElement;
	/**
	 * The cached value of the '{@link #getInformationProvisionElement() <em>Information Provision Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInformationProvisionElement()
	 * @generated
	 * @ordered
	 */
	protected EList informationProvisionElement;
	/**
	 * The cached value of the '{@link #getDelegationTrustElement() <em>Delegation Trust Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDelegationTrustElement()
	 * @generated
	 * @ordered
	 */
	protected EList delegationTrustElement;
	/**
	 * The cached value of the '{@link #getProvisionTrustElement() <em>Provision Trust Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProvisionTrustElement()
	 * @generated
	 * @ordered
	 */
	protected EList provisionTrustElement;
	/**
	 * The cached value of the '{@link #getProduceTrustElemet() <em>Produce Trust Elemet</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProduceTrustElemet()
	 * @generated
	 * @ordered
	 */
	protected EList produceTrustElemet;
	/**
	 * The cached value of the '{@link #getSoftgoalElement() <em>Softgoal Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSoftgoalElement()
	 * @generated
	 * @ordered
	 */
	protected EList softgoalElement;
	/**
	 * The cached value of the '{@link #getQualityConstraintElement() <em>Quality Constraint Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQualityConstraintElement()
	 * @generated
	 * @ordered
	 */
	protected EList qualityConstraintElement;

	/**
	 * The cached value of the '{@link #getScopeElelemt() <em>Scope Elelemt</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScopeElelemt()
	 * @generated
	 * @ordered
	 */
	protected EList scopeElelemt;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DiagramImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqrePackage.Literals.DIAGRAM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getRoleElement() {
		if (roleElement == null) {
			roleElement = new EObjectContainmentEList(role.class, this, IqrePackage.DIAGRAM__ROLE_ELEMENT);
		}
		return roleElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getGoalElement() {
		if (goalElement == null) {
			goalElement = new EObjectContainmentEList(goal.class, this, IqrePackage.DIAGRAM__GOAL_ELEMENT);
		}
		return goalElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getGoalInstenceElement() {
		if (goalInstenceElement == null) {
			goalInstenceElement = new EObjectContainmentEList(goalInstence.class, this, IqrePackage.DIAGRAM__GOAL_INSTENCE_ELEMENT);
		}
		return goalInstenceElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getAgentElement() {
		if (agentElement == null) {
			agentElement = new EObjectContainmentEList(agent.class, this, IqrePackage.DIAGRAM__AGENT_ELEMENT);
		}
		return agentElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getTaskInstenceElement() {
		if (taskInstenceElement == null) {
			taskInstenceElement = new EObjectContainmentEList(taskInstence.class, this, IqrePackage.DIAGRAM__TASK_INSTENCE_ELEMENT);
		}
		return taskInstenceElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getTaskElement() {
		if (taskElement == null) {
			taskElement = new EObjectContainmentEList(task.class, this, IqrePackage.DIAGRAM__TASK_ELEMENT);
		}
		return taskElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getInformationElement() {
		if (informationElement == null) {
			informationElement = new EObjectContainmentEList(information.class, this, IqrePackage.DIAGRAM__INFORMATION_ELEMENT);
		}
		return informationElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getReadsElement() {
		if (readsElement == null) {
			readsElement = new EObjectContainmentEList(reads.class, this, IqrePackage.DIAGRAM__READS_ELEMENT);
		}
		return readsElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getProducesElement() {
		if (producesElement == null) {
			producesElement = new EObjectContainmentEList(produces.class, this, IqrePackage.DIAGRAM__PRODUCES_ELEMENT);
		}
		return producesElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getSendsElement() {
		if (sendsElement == null) {
			sendsElement = new EObjectContainmentEList(sends.class, this, IqrePackage.DIAGRAM__SENDS_ELEMENT);
		}
		return sendsElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getDelegationElement() {
		if (delegationElement == null) {
			delegationElement = new EObjectContainmentEList(delegation.class, this, IqrePackage.DIAGRAM__DELEGATION_ELEMENT);
		}
		return delegationElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getInformationProvisionElement() {
		if (informationProvisionElement == null) {
			informationProvisionElement = new EObjectContainmentEList(informationProvision.class, this, IqrePackage.DIAGRAM__INFORMATION_PROVISION_ELEMENT);
		}
		return informationProvisionElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getDelegationTrustElement() {
		if (delegationTrustElement == null) {
			delegationTrustElement = new EObjectContainmentEList(trustOfDelegation.class, this, IqrePackage.DIAGRAM__DELEGATION_TRUST_ELEMENT);
		}
		return delegationTrustElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getProvisionTrustElement() {
		if (provisionTrustElement == null) {
			provisionTrustElement = new EObjectContainmentEList(provisionTrust.class, this, IqrePackage.DIAGRAM__PROVISION_TRUST_ELEMENT);
		}
		return provisionTrustElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getProduceTrustElemet() {
		if (produceTrustElemet == null) {
			produceTrustElemet = new EObjectContainmentEList(produceTrust.class, this, IqrePackage.DIAGRAM__PRODUCE_TRUST_ELEMET);
		}
		return produceTrustElemet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getSoftgoalElement() {
		if (softgoalElement == null) {
			softgoalElement = new EObjectContainmentEList(softgoal.class, this, IqrePackage.DIAGRAM__SOFTGOAL_ELEMENT);
		}
		return softgoalElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getQualityConstraintElement() {
		if (qualityConstraintElement == null) {
			qualityConstraintElement = new EObjectContainmentEList(qualityConstraint.class, this, IqrePackage.DIAGRAM__QUALITY_CONSTRAINT_ELEMENT);
		}
		return qualityConstraintElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getScopeElelemt() {
		if (scopeElelemt == null) {
			scopeElelemt = new EObjectContainmentEList(scope.class, this, IqrePackage.DIAGRAM__SCOPE_ELELEMT);
		}
		return scopeElelemt;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case IqrePackage.DIAGRAM__ROLE_ELEMENT:
				return ((InternalEList)getRoleElement()).basicRemove(otherEnd, msgs);
			case IqrePackage.DIAGRAM__GOAL_ELEMENT:
				return ((InternalEList)getGoalElement()).basicRemove(otherEnd, msgs);
			case IqrePackage.DIAGRAM__GOAL_INSTENCE_ELEMENT:
				return ((InternalEList)getGoalInstenceElement()).basicRemove(otherEnd, msgs);
			case IqrePackage.DIAGRAM__AGENT_ELEMENT:
				return ((InternalEList)getAgentElement()).basicRemove(otherEnd, msgs);
			case IqrePackage.DIAGRAM__TASK_INSTENCE_ELEMENT:
				return ((InternalEList)getTaskInstenceElement()).basicRemove(otherEnd, msgs);
			case IqrePackage.DIAGRAM__TASK_ELEMENT:
				return ((InternalEList)getTaskElement()).basicRemove(otherEnd, msgs);
			case IqrePackage.DIAGRAM__INFORMATION_ELEMENT:
				return ((InternalEList)getInformationElement()).basicRemove(otherEnd, msgs);
			case IqrePackage.DIAGRAM__READS_ELEMENT:
				return ((InternalEList)getReadsElement()).basicRemove(otherEnd, msgs);
			case IqrePackage.DIAGRAM__PRODUCES_ELEMENT:
				return ((InternalEList)getProducesElement()).basicRemove(otherEnd, msgs);
			case IqrePackage.DIAGRAM__SENDS_ELEMENT:
				return ((InternalEList)getSendsElement()).basicRemove(otherEnd, msgs);
			case IqrePackage.DIAGRAM__DELEGATION_ELEMENT:
				return ((InternalEList)getDelegationElement()).basicRemove(otherEnd, msgs);
			case IqrePackage.DIAGRAM__INFORMATION_PROVISION_ELEMENT:
				return ((InternalEList)getInformationProvisionElement()).basicRemove(otherEnd, msgs);
			case IqrePackage.DIAGRAM__DELEGATION_TRUST_ELEMENT:
				return ((InternalEList)getDelegationTrustElement()).basicRemove(otherEnd, msgs);
			case IqrePackage.DIAGRAM__PROVISION_TRUST_ELEMENT:
				return ((InternalEList)getProvisionTrustElement()).basicRemove(otherEnd, msgs);
			case IqrePackage.DIAGRAM__PRODUCE_TRUST_ELEMET:
				return ((InternalEList)getProduceTrustElemet()).basicRemove(otherEnd, msgs);
			case IqrePackage.DIAGRAM__SOFTGOAL_ELEMENT:
				return ((InternalEList)getSoftgoalElement()).basicRemove(otherEnd, msgs);
			case IqrePackage.DIAGRAM__QUALITY_CONSTRAINT_ELEMENT:
				return ((InternalEList)getQualityConstraintElement()).basicRemove(otherEnd, msgs);
			case IqrePackage.DIAGRAM__SCOPE_ELELEMT:
				return ((InternalEList)getScopeElelemt()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqrePackage.DIAGRAM__ROLE_ELEMENT:
				return getRoleElement();
			case IqrePackage.DIAGRAM__GOAL_ELEMENT:
				return getGoalElement();
			case IqrePackage.DIAGRAM__GOAL_INSTENCE_ELEMENT:
				return getGoalInstenceElement();
			case IqrePackage.DIAGRAM__AGENT_ELEMENT:
				return getAgentElement();
			case IqrePackage.DIAGRAM__TASK_INSTENCE_ELEMENT:
				return getTaskInstenceElement();
			case IqrePackage.DIAGRAM__TASK_ELEMENT:
				return getTaskElement();
			case IqrePackage.DIAGRAM__INFORMATION_ELEMENT:
				return getInformationElement();
			case IqrePackage.DIAGRAM__READS_ELEMENT:
				return getReadsElement();
			case IqrePackage.DIAGRAM__PRODUCES_ELEMENT:
				return getProducesElement();
			case IqrePackage.DIAGRAM__SENDS_ELEMENT:
				return getSendsElement();
			case IqrePackage.DIAGRAM__DELEGATION_ELEMENT:
				return getDelegationElement();
			case IqrePackage.DIAGRAM__INFORMATION_PROVISION_ELEMENT:
				return getInformationProvisionElement();
			case IqrePackage.DIAGRAM__DELEGATION_TRUST_ELEMENT:
				return getDelegationTrustElement();
			case IqrePackage.DIAGRAM__PROVISION_TRUST_ELEMENT:
				return getProvisionTrustElement();
			case IqrePackage.DIAGRAM__PRODUCE_TRUST_ELEMET:
				return getProduceTrustElemet();
			case IqrePackage.DIAGRAM__SOFTGOAL_ELEMENT:
				return getSoftgoalElement();
			case IqrePackage.DIAGRAM__QUALITY_CONSTRAINT_ELEMENT:
				return getQualityConstraintElement();
			case IqrePackage.DIAGRAM__SCOPE_ELELEMT:
				return getScopeElelemt();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqrePackage.DIAGRAM__ROLE_ELEMENT:
				getRoleElement().clear();
				getRoleElement().addAll((Collection)newValue);
				return;
			case IqrePackage.DIAGRAM__GOAL_ELEMENT:
				getGoalElement().clear();
				getGoalElement().addAll((Collection)newValue);
				return;
			case IqrePackage.DIAGRAM__GOAL_INSTENCE_ELEMENT:
				getGoalInstenceElement().clear();
				getGoalInstenceElement().addAll((Collection)newValue);
				return;
			case IqrePackage.DIAGRAM__AGENT_ELEMENT:
				getAgentElement().clear();
				getAgentElement().addAll((Collection)newValue);
				return;
			case IqrePackage.DIAGRAM__TASK_INSTENCE_ELEMENT:
				getTaskInstenceElement().clear();
				getTaskInstenceElement().addAll((Collection)newValue);
				return;
			case IqrePackage.DIAGRAM__TASK_ELEMENT:
				getTaskElement().clear();
				getTaskElement().addAll((Collection)newValue);
				return;
			case IqrePackage.DIAGRAM__INFORMATION_ELEMENT:
				getInformationElement().clear();
				getInformationElement().addAll((Collection)newValue);
				return;
			case IqrePackage.DIAGRAM__READS_ELEMENT:
				getReadsElement().clear();
				getReadsElement().addAll((Collection)newValue);
				return;
			case IqrePackage.DIAGRAM__PRODUCES_ELEMENT:
				getProducesElement().clear();
				getProducesElement().addAll((Collection)newValue);
				return;
			case IqrePackage.DIAGRAM__SENDS_ELEMENT:
				getSendsElement().clear();
				getSendsElement().addAll((Collection)newValue);
				return;
			case IqrePackage.DIAGRAM__DELEGATION_ELEMENT:
				getDelegationElement().clear();
				getDelegationElement().addAll((Collection)newValue);
				return;
			case IqrePackage.DIAGRAM__INFORMATION_PROVISION_ELEMENT:
				getInformationProvisionElement().clear();
				getInformationProvisionElement().addAll((Collection)newValue);
				return;
			case IqrePackage.DIAGRAM__DELEGATION_TRUST_ELEMENT:
				getDelegationTrustElement().clear();
				getDelegationTrustElement().addAll((Collection)newValue);
				return;
			case IqrePackage.DIAGRAM__PROVISION_TRUST_ELEMENT:
				getProvisionTrustElement().clear();
				getProvisionTrustElement().addAll((Collection)newValue);
				return;
			case IqrePackage.DIAGRAM__PRODUCE_TRUST_ELEMET:
				getProduceTrustElemet().clear();
				getProduceTrustElemet().addAll((Collection)newValue);
				return;
			case IqrePackage.DIAGRAM__SOFTGOAL_ELEMENT:
				getSoftgoalElement().clear();
				getSoftgoalElement().addAll((Collection)newValue);
				return;
			case IqrePackage.DIAGRAM__QUALITY_CONSTRAINT_ELEMENT:
				getQualityConstraintElement().clear();
				getQualityConstraintElement().addAll((Collection)newValue);
				return;
			case IqrePackage.DIAGRAM__SCOPE_ELELEMT:
				getScopeElelemt().clear();
				getScopeElelemt().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqrePackage.DIAGRAM__ROLE_ELEMENT:
				getRoleElement().clear();
				return;
			case IqrePackage.DIAGRAM__GOAL_ELEMENT:
				getGoalElement().clear();
				return;
			case IqrePackage.DIAGRAM__GOAL_INSTENCE_ELEMENT:
				getGoalInstenceElement().clear();
				return;
			case IqrePackage.DIAGRAM__AGENT_ELEMENT:
				getAgentElement().clear();
				return;
			case IqrePackage.DIAGRAM__TASK_INSTENCE_ELEMENT:
				getTaskInstenceElement().clear();
				return;
			case IqrePackage.DIAGRAM__TASK_ELEMENT:
				getTaskElement().clear();
				return;
			case IqrePackage.DIAGRAM__INFORMATION_ELEMENT:
				getInformationElement().clear();
				return;
			case IqrePackage.DIAGRAM__READS_ELEMENT:
				getReadsElement().clear();
				return;
			case IqrePackage.DIAGRAM__PRODUCES_ELEMENT:
				getProducesElement().clear();
				return;
			case IqrePackage.DIAGRAM__SENDS_ELEMENT:
				getSendsElement().clear();
				return;
			case IqrePackage.DIAGRAM__DELEGATION_ELEMENT:
				getDelegationElement().clear();
				return;
			case IqrePackage.DIAGRAM__INFORMATION_PROVISION_ELEMENT:
				getInformationProvisionElement().clear();
				return;
			case IqrePackage.DIAGRAM__DELEGATION_TRUST_ELEMENT:
				getDelegationTrustElement().clear();
				return;
			case IqrePackage.DIAGRAM__PROVISION_TRUST_ELEMENT:
				getProvisionTrustElement().clear();
				return;
			case IqrePackage.DIAGRAM__PRODUCE_TRUST_ELEMET:
				getProduceTrustElemet().clear();
				return;
			case IqrePackage.DIAGRAM__SOFTGOAL_ELEMENT:
				getSoftgoalElement().clear();
				return;
			case IqrePackage.DIAGRAM__QUALITY_CONSTRAINT_ELEMENT:
				getQualityConstraintElement().clear();
				return;
			case IqrePackage.DIAGRAM__SCOPE_ELELEMT:
				getScopeElelemt().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqrePackage.DIAGRAM__ROLE_ELEMENT:
				return roleElement != null && !roleElement.isEmpty();
			case IqrePackage.DIAGRAM__GOAL_ELEMENT:
				return goalElement != null && !goalElement.isEmpty();
			case IqrePackage.DIAGRAM__GOAL_INSTENCE_ELEMENT:
				return goalInstenceElement != null && !goalInstenceElement.isEmpty();
			case IqrePackage.DIAGRAM__AGENT_ELEMENT:
				return agentElement != null && !agentElement.isEmpty();
			case IqrePackage.DIAGRAM__TASK_INSTENCE_ELEMENT:
				return taskInstenceElement != null && !taskInstenceElement.isEmpty();
			case IqrePackage.DIAGRAM__TASK_ELEMENT:
				return taskElement != null && !taskElement.isEmpty();
			case IqrePackage.DIAGRAM__INFORMATION_ELEMENT:
				return informationElement != null && !informationElement.isEmpty();
			case IqrePackage.DIAGRAM__READS_ELEMENT:
				return readsElement != null && !readsElement.isEmpty();
			case IqrePackage.DIAGRAM__PRODUCES_ELEMENT:
				return producesElement != null && !producesElement.isEmpty();
			case IqrePackage.DIAGRAM__SENDS_ELEMENT:
				return sendsElement != null && !sendsElement.isEmpty();
			case IqrePackage.DIAGRAM__DELEGATION_ELEMENT:
				return delegationElement != null && !delegationElement.isEmpty();
			case IqrePackage.DIAGRAM__INFORMATION_PROVISION_ELEMENT:
				return informationProvisionElement != null && !informationProvisionElement.isEmpty();
			case IqrePackage.DIAGRAM__DELEGATION_TRUST_ELEMENT:
				return delegationTrustElement != null && !delegationTrustElement.isEmpty();
			case IqrePackage.DIAGRAM__PROVISION_TRUST_ELEMENT:
				return provisionTrustElement != null && !provisionTrustElement.isEmpty();
			case IqrePackage.DIAGRAM__PRODUCE_TRUST_ELEMET:
				return produceTrustElemet != null && !produceTrustElemet.isEmpty();
			case IqrePackage.DIAGRAM__SOFTGOAL_ELEMENT:
				return softgoalElement != null && !softgoalElement.isEmpty();
			case IqrePackage.DIAGRAM__QUALITY_CONSTRAINT_ELEMENT:
				return qualityConstraintElement != null && !qualityConstraintElement.isEmpty();
			case IqrePackage.DIAGRAM__SCOPE_ELELEMT:
				return scopeElelemt != null && !scopeElelemt.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //DiagramImpl
