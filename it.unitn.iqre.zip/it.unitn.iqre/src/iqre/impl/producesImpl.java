/**
 */
package iqre.impl;

import iqre.IqrePackage;
import iqre.information;
import iqre.produces;
import iqre.taskInstence;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>produces</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqre.impl.producesImpl#getType <em>Type</em>}</li>
 *   <li>{@link iqre.impl.producesImpl#getProducesBy <em>Produces By</em>}</li>
 *   <li>{@link iqre.impl.producesImpl#getProducesOf <em>Produces Of</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class producesImpl extends MinimalEObjectImpl.Container implements produces {
	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getProducesBy() <em>Produces By</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProducesBy()
	 * @generated
	 * @ordered
	 */
	protected EList producesBy;

	/**
	 * The cached value of the '{@link #getProducesOf() <em>Produces Of</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProducesOf()
	 * @generated
	 * @ordered
	 */
	protected EList producesOf;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected producesImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqrePackage.Literals.PRODUCES;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqrePackage.PRODUCES__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getProducesBy() {
		if (producesBy == null) {
			producesBy = new EObjectResolvingEList(taskInstence.class, this, IqrePackage.PRODUCES__PRODUCES_BY);
		}
		return producesBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getProducesOf() {
		if (producesOf == null) {
			producesOf = new EObjectResolvingEList(information.class, this, IqrePackage.PRODUCES__PRODUCES_OF);
		}
		return producesOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqrePackage.PRODUCES__TYPE:
				return getType();
			case IqrePackage.PRODUCES__PRODUCES_BY:
				return getProducesBy();
			case IqrePackage.PRODUCES__PRODUCES_OF:
				return getProducesOf();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqrePackage.PRODUCES__TYPE:
				setType((String)newValue);
				return;
			case IqrePackage.PRODUCES__PRODUCES_BY:
				getProducesBy().clear();
				getProducesBy().addAll((Collection)newValue);
				return;
			case IqrePackage.PRODUCES__PRODUCES_OF:
				getProducesOf().clear();
				getProducesOf().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqrePackage.PRODUCES__TYPE:
				setType(TYPE_EDEFAULT);
				return;
			case IqrePackage.PRODUCES__PRODUCES_BY:
				getProducesBy().clear();
				return;
			case IqrePackage.PRODUCES__PRODUCES_OF:
				getProducesOf().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqrePackage.PRODUCES__TYPE:
				return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
			case IqrePackage.PRODUCES__PRODUCES_BY:
				return producesBy != null && !producesBy.isEmpty();
			case IqrePackage.PRODUCES__PRODUCES_OF:
				return producesOf != null && !producesOf.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (type: ");
		result.append(type);
		result.append(')');
		return result.toString();
	}

} //producesImpl
