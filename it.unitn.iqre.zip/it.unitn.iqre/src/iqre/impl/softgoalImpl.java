/**
 */
package iqre.impl;

import iqre.IqrePackage;
import iqre.information;
import iqre.softgoal;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>softgoal</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqre.impl.softgoalImpl#getAndDecomposition <em>And Decomposition</em>}</li>
 *   <li>{@link iqre.impl.softgoalImpl#getType <em>Type</em>}</li>
 *   <li>{@link iqre.impl.softgoalImpl#getQualityTarget <em>Quality Target</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class softgoalImpl extends MinimalEObjectImpl.Container implements softgoal {
	/**
	 * The cached value of the '{@link #getAndDecomposition() <em>And Decomposition</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAndDecomposition()
	 * @generated
	 * @ordered
	 */
	protected EList andDecomposition;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getQualityTarget() <em>Quality Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQualityTarget()
	 * @generated
	 * @ordered
	 */
	protected information qualityTarget;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected softgoalImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqrePackage.Literals.SOFTGOAL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getAndDecomposition() {
		if (andDecomposition == null) {
			andDecomposition = new EObjectResolvingEList(softgoal.class, this, IqrePackage.SOFTGOAL__AND_DECOMPOSITION);
		}
		return andDecomposition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqrePackage.SOFTGOAL__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information getQualityTarget() {
		if (qualityTarget != null && qualityTarget.eIsProxy()) {
			InternalEObject oldQualityTarget = (InternalEObject)qualityTarget;
			qualityTarget = (information)eResolveProxy(oldQualityTarget);
			if (qualityTarget != oldQualityTarget) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqrePackage.SOFTGOAL__QUALITY_TARGET, oldQualityTarget, qualityTarget));
			}
		}
		return qualityTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information basicGetQualityTarget() {
		return qualityTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setQualityTarget(information newQualityTarget) {
		information oldQualityTarget = qualityTarget;
		qualityTarget = newQualityTarget;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqrePackage.SOFTGOAL__QUALITY_TARGET, oldQualityTarget, qualityTarget));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqrePackage.SOFTGOAL__AND_DECOMPOSITION:
				return getAndDecomposition();
			case IqrePackage.SOFTGOAL__TYPE:
				return getType();
			case IqrePackage.SOFTGOAL__QUALITY_TARGET:
				if (resolve) return getQualityTarget();
				return basicGetQualityTarget();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqrePackage.SOFTGOAL__AND_DECOMPOSITION:
				getAndDecomposition().clear();
				getAndDecomposition().addAll((Collection)newValue);
				return;
			case IqrePackage.SOFTGOAL__TYPE:
				setType((String)newValue);
				return;
			case IqrePackage.SOFTGOAL__QUALITY_TARGET:
				setQualityTarget((information)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqrePackage.SOFTGOAL__AND_DECOMPOSITION:
				getAndDecomposition().clear();
				return;
			case IqrePackage.SOFTGOAL__TYPE:
				setType(TYPE_EDEFAULT);
				return;
			case IqrePackage.SOFTGOAL__QUALITY_TARGET:
				setQualityTarget((information)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqrePackage.SOFTGOAL__AND_DECOMPOSITION:
				return andDecomposition != null && !andDecomposition.isEmpty();
			case IqrePackage.SOFTGOAL__TYPE:
				return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
			case IqrePackage.SOFTGOAL__QUALITY_TARGET:
				return qualityTarget != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (type: ");
		result.append(type);
		result.append(')');
		return result.toString();
	}

} //softgoalImpl
