/**
 */
package iqre.impl;

import iqre.IqrePackage;
import iqre.agent;
import iqre.goalInstence;
import iqre.role;
import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>agent</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqre.impl.agentImpl#getName <em>Name</em>}</li>
 *   <li>{@link iqre.impl.agentImpl#getPlays <em>Plays</em>}</li>
 *   <li>{@link iqre.impl.agentImpl#getAims <em>Aims</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class agentImpl extends MinimalEObjectImpl.Container implements agent {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPlays() <em>Plays</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlays()
	 * @generated
	 * @ordered
	 */
	protected EList plays;

	/**
	 * The cached value of the '{@link #getAims() <em>Aims</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAims()
	 * @generated
	 * @ordered
	 */
	protected EList aims;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected agentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqrePackage.Literals.AGENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqrePackage.AGENT__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getPlays() {
		if (plays == null) {
			plays = new EObjectResolvingEList(role.class, this, IqrePackage.AGENT__PLAYS);
		}
		return plays;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getAims() {
		if (aims == null) {
			aims = new EObjectResolvingEList(goalInstence.class, this, IqrePackage.AGENT__AIMS);
		}
		return aims;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqrePackage.AGENT__NAME:
				return getName();
			case IqrePackage.AGENT__PLAYS:
				return getPlays();
			case IqrePackage.AGENT__AIMS:
				return getAims();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqrePackage.AGENT__NAME:
				setName((String)newValue);
				return;
			case IqrePackage.AGENT__PLAYS:
				getPlays().clear();
				getPlays().addAll((Collection)newValue);
				return;
			case IqrePackage.AGENT__AIMS:
				getAims().clear();
				getAims().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqrePackage.AGENT__NAME:
				setName(NAME_EDEFAULT);
				return;
			case IqrePackage.AGENT__PLAYS:
				getPlays().clear();
				return;
			case IqrePackage.AGENT__AIMS:
				getAims().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqrePackage.AGENT__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case IqrePackage.AGENT__PLAYS:
				return plays != null && !plays.isEmpty();
			case IqrePackage.AGENT__AIMS:
				return aims != null && !aims.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //agentImpl
