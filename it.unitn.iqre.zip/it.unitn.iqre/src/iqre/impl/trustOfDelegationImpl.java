/**
 */
package iqre.impl;

import iqre.IqrePackage;
import iqre.agent;
import iqre.goalInstence;
import iqre.taskInstence;
import iqre.trustOfDelegation;

import java.util.Collection;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>trust Of Delegation</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqre.impl.trustOfDelegationImpl#getDeleTrustor <em>Dele Trustor</em>}</li>
 *   <li>{@link iqre.impl.trustOfDelegationImpl#getDeleTrustee <em>Dele Trustee</em>}</li>
 *   <li>{@link iqre.impl.trustOfDelegationImpl#getGoalTrustum <em>Goal Trustum</em>}</li>
 *   <li>{@link iqre.impl.trustOfDelegationImpl#getTaskTrustum <em>Task Trustum</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class trustOfDelegationImpl extends MinimalEObjectImpl.Container implements trustOfDelegation {
	/**
	 * The cached value of the '{@link #getDeleTrustor() <em>Dele Trustor</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDeleTrustor()
	 * @generated
	 * @ordered
	 */
	protected EList deleTrustor;

	/**
	 * The cached value of the '{@link #getDeleTrustee() <em>Dele Trustee</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDeleTrustee()
	 * @generated
	 * @ordered
	 */
	protected EList deleTrustee;

	/**
	 * The cached value of the '{@link #getGoalTrustum() <em>Goal Trustum</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGoalTrustum()
	 * @generated
	 * @ordered
	 */
	protected EList goalTrustum;

	/**
	 * The cached value of the '{@link #getTaskTrustum() <em>Task Trustum</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTaskTrustum()
	 * @generated
	 * @ordered
	 */
	protected EList taskTrustum;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected trustOfDelegationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqrePackage.Literals.TRUST_OF_DELEGATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getDeleTrustor() {
		if (deleTrustor == null) {
			deleTrustor = new EObjectResolvingEList(agent.class, this, IqrePackage.TRUST_OF_DELEGATION__DELE_TRUSTOR);
		}
		return deleTrustor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getDeleTrustee() {
		if (deleTrustee == null) {
			deleTrustee = new EObjectResolvingEList(agent.class, this, IqrePackage.TRUST_OF_DELEGATION__DELE_TRUSTEE);
		}
		return deleTrustee;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getGoalTrustum() {
		if (goalTrustum == null) {
			goalTrustum = new EObjectResolvingEList(goalInstence.class, this, IqrePackage.TRUST_OF_DELEGATION__GOAL_TRUSTUM);
		}
		return goalTrustum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getTaskTrustum() {
		if (taskTrustum == null) {
			taskTrustum = new EObjectResolvingEList(taskInstence.class, this, IqrePackage.TRUST_OF_DELEGATION__TASK_TRUSTUM);
		}
		return taskTrustum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqrePackage.TRUST_OF_DELEGATION__DELE_TRUSTOR:
				return getDeleTrustor();
			case IqrePackage.TRUST_OF_DELEGATION__DELE_TRUSTEE:
				return getDeleTrustee();
			case IqrePackage.TRUST_OF_DELEGATION__GOAL_TRUSTUM:
				return getGoalTrustum();
			case IqrePackage.TRUST_OF_DELEGATION__TASK_TRUSTUM:
				return getTaskTrustum();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqrePackage.TRUST_OF_DELEGATION__DELE_TRUSTOR:
				getDeleTrustor().clear();
				getDeleTrustor().addAll((Collection)newValue);
				return;
			case IqrePackage.TRUST_OF_DELEGATION__DELE_TRUSTEE:
				getDeleTrustee().clear();
				getDeleTrustee().addAll((Collection)newValue);
				return;
			case IqrePackage.TRUST_OF_DELEGATION__GOAL_TRUSTUM:
				getGoalTrustum().clear();
				getGoalTrustum().addAll((Collection)newValue);
				return;
			case IqrePackage.TRUST_OF_DELEGATION__TASK_TRUSTUM:
				getTaskTrustum().clear();
				getTaskTrustum().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqrePackage.TRUST_OF_DELEGATION__DELE_TRUSTOR:
				getDeleTrustor().clear();
				return;
			case IqrePackage.TRUST_OF_DELEGATION__DELE_TRUSTEE:
				getDeleTrustee().clear();
				return;
			case IqrePackage.TRUST_OF_DELEGATION__GOAL_TRUSTUM:
				getGoalTrustum().clear();
				return;
			case IqrePackage.TRUST_OF_DELEGATION__TASK_TRUSTUM:
				getTaskTrustum().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqrePackage.TRUST_OF_DELEGATION__DELE_TRUSTOR:
				return deleTrustor != null && !deleTrustor.isEmpty();
			case IqrePackage.TRUST_OF_DELEGATION__DELE_TRUSTEE:
				return deleTrustee != null && !deleTrustee.isEmpty();
			case IqrePackage.TRUST_OF_DELEGATION__GOAL_TRUSTUM:
				return goalTrustum != null && !goalTrustum.isEmpty();
			case IqrePackage.TRUST_OF_DELEGATION__TASK_TRUSTUM:
				return taskTrustum != null && !taskTrustum.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //trustOfDelegationImpl
