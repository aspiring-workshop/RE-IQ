/**
 */
package iqre.impl;

import iqre.IqrePackage;
import iqre.information;
import iqre.reads;
import iqre.taskInstence;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>reads</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqre.impl.readsImpl#getPurposeOfUse <em>Purpose Of Use</em>}</li>
 *   <li>{@link iqre.impl.readsImpl#getType <em>Type</em>}</li>
 *   <li>{@link iqre.impl.readsImpl#getReadsBy <em>Reads By</em>}</li>
 *   <li>{@link iqre.impl.readsImpl#getReadsOf <em>Reads Of</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class readsImpl extends MinimalEObjectImpl.Container implements reads {
	/**
	 * The default value of the '{@link #getPurposeOfUse() <em>Purpose Of Use</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPurposeOfUse()
	 * @generated
	 * @ordered
	 */
	protected static final String PURPOSE_OF_USE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPurposeOfUse() <em>Purpose Of Use</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPurposeOfUse()
	 * @generated
	 * @ordered
	 */
	protected String purposeOfUse = PURPOSE_OF_USE_EDEFAULT;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getReadsBy() <em>Reads By</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReadsBy()
	 * @generated
	 * @ordered
	 */
	protected EList readsBy;

	/**
	 * The cached value of the '{@link #getReadsOf() <em>Reads Of</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReadsOf()
	 * @generated
	 * @ordered
	 */
	protected EList readsOf;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected readsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqrePackage.Literals.READS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPurposeOfUse() {
		return purposeOfUse;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPurposeOfUse(String newPurposeOfUse) {
		String oldPurposeOfUse = purposeOfUse;
		purposeOfUse = newPurposeOfUse;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqrePackage.READS__PURPOSE_OF_USE, oldPurposeOfUse, purposeOfUse));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqrePackage.READS__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getReadsBy() {
		if (readsBy == null) {
			readsBy = new EObjectResolvingEList(taskInstence.class, this, IqrePackage.READS__READS_BY);
		}
		return readsBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getReadsOf() {
		if (readsOf == null) {
			readsOf = new EObjectResolvingEList(information.class, this, IqrePackage.READS__READS_OF);
		}
		return readsOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqrePackage.READS__PURPOSE_OF_USE:
				return getPurposeOfUse();
			case IqrePackage.READS__TYPE:
				return getType();
			case IqrePackage.READS__READS_BY:
				return getReadsBy();
			case IqrePackage.READS__READS_OF:
				return getReadsOf();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqrePackage.READS__PURPOSE_OF_USE:
				setPurposeOfUse((String)newValue);
				return;
			case IqrePackage.READS__TYPE:
				setType((String)newValue);
				return;
			case IqrePackage.READS__READS_BY:
				getReadsBy().clear();
				getReadsBy().addAll((Collection)newValue);
				return;
			case IqrePackage.READS__READS_OF:
				getReadsOf().clear();
				getReadsOf().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqrePackage.READS__PURPOSE_OF_USE:
				setPurposeOfUse(PURPOSE_OF_USE_EDEFAULT);
				return;
			case IqrePackage.READS__TYPE:
				setType(TYPE_EDEFAULT);
				return;
			case IqrePackage.READS__READS_BY:
				getReadsBy().clear();
				return;
			case IqrePackage.READS__READS_OF:
				getReadsOf().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqrePackage.READS__PURPOSE_OF_USE:
				return PURPOSE_OF_USE_EDEFAULT == null ? purposeOfUse != null : !PURPOSE_OF_USE_EDEFAULT.equals(purposeOfUse);
			case IqrePackage.READS__TYPE:
				return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
			case IqrePackage.READS__READS_BY:
				return readsBy != null && !readsBy.isEmpty();
			case IqrePackage.READS__READS_OF:
				return readsOf != null && !readsOf.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (purposeOfUse: ");
		result.append(purposeOfUse);
		result.append(", type: ");
		result.append(type);
		result.append(')');
		return result.toString();
	}

} //readsImpl
