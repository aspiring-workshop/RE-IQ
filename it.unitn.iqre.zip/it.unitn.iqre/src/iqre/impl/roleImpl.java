/**
 */
package iqre.impl;

import iqre.IqrePackage;
import iqre.goal;
import iqre.role;
import iqre.task;
import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>role</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqre.impl.roleImpl#getName <em>Name</em>}</li>
 *   <li>{@link iqre.impl.roleImpl#getAims <em>Aims</em>}</li>
 *   <li>{@link iqre.impl.roleImpl#getCapableGoal <em>Capable Goal</em>}</li>
 *   <li>{@link iqre.impl.roleImpl#getCapableTask <em>Capable Task</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class roleImpl extends MinimalEObjectImpl.Container implements role {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAims() <em>Aims</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAims()
	 * @generated
	 * @ordered
	 */
	protected EList aims;

	/**
	 * The cached value of the '{@link #getCapableGoal() <em>Capable Goal</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapableGoal()
	 * @generated
	 * @ordered
	 */
	protected EList capableGoal;

	/**
	 * The cached value of the '{@link #getCapableTask() <em>Capable Task</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapableTask()
	 * @generated
	 * @ordered
	 */
	protected EList capableTask;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected roleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqrePackage.Literals.ROLE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqrePackage.ROLE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getAims() {
		if (aims == null) {
			aims = new EObjectResolvingEList(goal.class, this, IqrePackage.ROLE__AIMS);
		}
		return aims;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getCapableGoal() {
		if (capableGoal == null) {
			capableGoal = new EObjectResolvingEList(goal.class, this, IqrePackage.ROLE__CAPABLE_GOAL);
		}
		return capableGoal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getCapableTask() {
		if (capableTask == null) {
			capableTask = new EObjectResolvingEList(task.class, this, IqrePackage.ROLE__CAPABLE_TASK);
		}
		return capableTask;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqrePackage.ROLE__NAME:
				return getName();
			case IqrePackage.ROLE__AIMS:
				return getAims();
			case IqrePackage.ROLE__CAPABLE_GOAL:
				return getCapableGoal();
			case IqrePackage.ROLE__CAPABLE_TASK:
				return getCapableTask();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqrePackage.ROLE__NAME:
				setName((String)newValue);
				return;
			case IqrePackage.ROLE__AIMS:
				getAims().clear();
				getAims().addAll((Collection)newValue);
				return;
			case IqrePackage.ROLE__CAPABLE_GOAL:
				getCapableGoal().clear();
				getCapableGoal().addAll((Collection)newValue);
				return;
			case IqrePackage.ROLE__CAPABLE_TASK:
				getCapableTask().clear();
				getCapableTask().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqrePackage.ROLE__NAME:
				setName(NAME_EDEFAULT);
				return;
			case IqrePackage.ROLE__AIMS:
				getAims().clear();
				return;
			case IqrePackage.ROLE__CAPABLE_GOAL:
				getCapableGoal().clear();
				return;
			case IqrePackage.ROLE__CAPABLE_TASK:
				getCapableTask().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqrePackage.ROLE__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case IqrePackage.ROLE__AIMS:
				return aims != null && !aims.isEmpty();
			case IqrePackage.ROLE__CAPABLE_GOAL:
				return capableGoal != null && !capableGoal.isEmpty();
			case IqrePackage.ROLE__CAPABLE_TASK:
				return capableTask != null && !capableTask.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //roleImpl
