/**
 */
package iqre.impl;

import iqre.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class IqreFactoryImpl extends EFactoryImpl implements IqreFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static IqreFactory init() {
		try {
			IqreFactory theIqreFactory = (IqreFactory)EPackage.Registry.INSTANCE.getEFactory(IqrePackage.eNS_URI);
			if (theIqreFactory != null) {
				return theIqreFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new IqreFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IqreFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case IqrePackage.DIAGRAM: return createDiagram();
			case IqrePackage.ROLE: return createrole();
			case IqrePackage.GOAL: return creategoal();
			case IqrePackage.AGENT: return createagent();
			case IqrePackage.GOAL_INSTENCE: return creategoalInstence();
			case IqrePackage.TASK: return createtask();
			case IqrePackage.TASK_INSTENCE: return createtaskInstence();
			case IqrePackage.INFORMATION: return createinformation();
			case IqrePackage.READS: return createreads();
			case IqrePackage.PRODUCES: return createproduces();
			case IqrePackage.SENDS: return createsends();
			case IqrePackage.DELEGATION: return createdelegation();
			case IqrePackage.INFORMATION_PROVISION: return createinformationProvision();
			case IqrePackage.TRUST_OF_DELEGATION: return createtrustOfDelegation();
			case IqrePackage.PROVISION_TRUST: return createprovisionTrust();
			case IqrePackage.PRODUCE_TRUST: return createproduceTrust();
			case IqrePackage.SOFTGOAL: return createsoftgoal();
			case IqrePackage.QUALITY_CONSTRAINT: return createqualityConstraint();
			case IqrePackage.SCOPE: return createscope();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Diagram createDiagram() {
		DiagramImpl diagram = new DiagramImpl();
		return diagram;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public role createrole() {
		roleImpl role = new roleImpl();
		return role;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goal creategoal() {
		goalImpl goal = new goalImpl();
		return goal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public agent createagent() {
		agentImpl agent = new agentImpl();
		return agent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goalInstence creategoalInstence() {
		goalInstenceImpl goalInstence = new goalInstenceImpl();
		return goalInstence;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public task createtask() {
		taskImpl task = new taskImpl();
		return task;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public taskInstence createtaskInstence() {
		taskInstenceImpl taskInstence = new taskInstenceImpl();
		return taskInstence;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information createinformation() {
		informationImpl information = new informationImpl();
		return information;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public reads createreads() {
		readsImpl reads = new readsImpl();
		return reads;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public produces createproduces() {
		producesImpl produces = new producesImpl();
		return produces;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public sends createsends() {
		sendsImpl sends = new sendsImpl();
		return sends;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public delegation createdelegation() {
		delegationImpl delegation = new delegationImpl();
		return delegation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public informationProvision createinformationProvision() {
		informationProvisionImpl informationProvision = new informationProvisionImpl();
		return informationProvision;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public trustOfDelegation createtrustOfDelegation() {
		trustOfDelegationImpl trustOfDelegation = new trustOfDelegationImpl();
		return trustOfDelegation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public provisionTrust createprovisionTrust() {
		provisionTrustImpl provisionTrust = new provisionTrustImpl();
		return provisionTrust;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public produceTrust createproduceTrust() {
		produceTrustImpl produceTrust = new produceTrustImpl();
		return produceTrust;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public softgoal createsoftgoal() {
		softgoalImpl softgoal = new softgoalImpl();
		return softgoal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public qualityConstraint createqualityConstraint() {
		qualityConstraintImpl qualityConstraint = new qualityConstraintImpl();
		return qualityConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public scope createscope() {
		scopeImpl scope = new scopeImpl();
		return scope;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IqrePackage getIqrePackage() {
		return (IqrePackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	public static IqrePackage getPackage() {
		return IqrePackage.eINSTANCE;
	}

} //IqreFactoryImpl
