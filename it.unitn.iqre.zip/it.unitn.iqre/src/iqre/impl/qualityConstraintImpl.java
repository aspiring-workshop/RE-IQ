/**
 */
package iqre.impl;

import iqre.IqrePackage;
import iqre.information;
import iqre.qualityConstraint;
import iqre.softgoal;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>quality Constraint</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqre.impl.qualityConstraintImpl#getApproximateRelation <em>Approximate Relation</em>}</li>
 *   <li>{@link iqre.impl.qualityConstraintImpl#getType <em>Type</em>}</li>
 *   <li>{@link iqre.impl.qualityConstraintImpl#getQualityTarget <em>Quality Target</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class qualityConstraintImpl extends MinimalEObjectImpl.Container implements qualityConstraint {
	/**
	 * The cached value of the '{@link #getApproximateRelation() <em>Approximate Relation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getApproximateRelation()
	 * @generated
	 * @ordered
	 */
	protected softgoal approximateRelation;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getQualityTarget() <em>Quality Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQualityTarget()
	 * @generated
	 * @ordered
	 */
	protected information qualityTarget;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected qualityConstraintImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqrePackage.Literals.QUALITY_CONSTRAINT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public softgoal getApproximateRelation() {
		if (approximateRelation != null && approximateRelation.eIsProxy()) {
			InternalEObject oldApproximateRelation = (InternalEObject)approximateRelation;
			approximateRelation = (softgoal)eResolveProxy(oldApproximateRelation);
			if (approximateRelation != oldApproximateRelation) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqrePackage.QUALITY_CONSTRAINT__APPROXIMATE_RELATION, oldApproximateRelation, approximateRelation));
			}
		}
		return approximateRelation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public softgoal basicGetApproximateRelation() {
		return approximateRelation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setApproximateRelation(softgoal newApproximateRelation) {
		softgoal oldApproximateRelation = approximateRelation;
		approximateRelation = newApproximateRelation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqrePackage.QUALITY_CONSTRAINT__APPROXIMATE_RELATION, oldApproximateRelation, approximateRelation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqrePackage.QUALITY_CONSTRAINT__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information getQualityTarget() {
		if (qualityTarget != null && qualityTarget.eIsProxy()) {
			InternalEObject oldQualityTarget = (InternalEObject)qualityTarget;
			qualityTarget = (information)eResolveProxy(oldQualityTarget);
			if (qualityTarget != oldQualityTarget) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqrePackage.QUALITY_CONSTRAINT__QUALITY_TARGET, oldQualityTarget, qualityTarget));
			}
		}
		return qualityTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information basicGetQualityTarget() {
		return qualityTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setQualityTarget(information newQualityTarget) {
		information oldQualityTarget = qualityTarget;
		qualityTarget = newQualityTarget;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqrePackage.QUALITY_CONSTRAINT__QUALITY_TARGET, oldQualityTarget, qualityTarget));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqrePackage.QUALITY_CONSTRAINT__APPROXIMATE_RELATION:
				if (resolve) return getApproximateRelation();
				return basicGetApproximateRelation();
			case IqrePackage.QUALITY_CONSTRAINT__TYPE:
				return getType();
			case IqrePackage.QUALITY_CONSTRAINT__QUALITY_TARGET:
				if (resolve) return getQualityTarget();
				return basicGetQualityTarget();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqrePackage.QUALITY_CONSTRAINT__APPROXIMATE_RELATION:
				setApproximateRelation((softgoal)newValue);
				return;
			case IqrePackage.QUALITY_CONSTRAINT__TYPE:
				setType((String)newValue);
				return;
			case IqrePackage.QUALITY_CONSTRAINT__QUALITY_TARGET:
				setQualityTarget((information)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqrePackage.QUALITY_CONSTRAINT__APPROXIMATE_RELATION:
				setApproximateRelation((softgoal)null);
				return;
			case IqrePackage.QUALITY_CONSTRAINT__TYPE:
				setType(TYPE_EDEFAULT);
				return;
			case IqrePackage.QUALITY_CONSTRAINT__QUALITY_TARGET:
				setQualityTarget((information)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqrePackage.QUALITY_CONSTRAINT__APPROXIMATE_RELATION:
				return approximateRelation != null;
			case IqrePackage.QUALITY_CONSTRAINT__TYPE:
				return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
			case IqrePackage.QUALITY_CONSTRAINT__QUALITY_TARGET:
				return qualityTarget != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (type: ");
		result.append(type);
		result.append(')');
		return result.toString();
	}

} //qualityConstraintImpl
