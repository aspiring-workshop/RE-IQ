/**
 */
package iqre.impl;

import iqre.IqrePackage;
import iqre.agent;
import iqre.information;
import iqre.informationProvision;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>information Provision</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqre.impl.informationProvisionImpl#getTime <em>Time</em>}</li>
 *   <li>{@link iqre.impl.informationProvisionImpl#getType <em>Type</em>}</li>
 *   <li>{@link iqre.impl.informationProvisionImpl#getProvisionTo <em>Provision To</em>}</li>
 *   <li>{@link iqre.impl.informationProvisionImpl#getProvisionFrom <em>Provision From</em>}</li>
 *   <li>{@link iqre.impl.informationProvisionImpl#getProvisionOf <em>Provision Of</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class informationProvisionImpl extends MinimalEObjectImpl.Container implements informationProvision {
	/**
	 * The default value of the '{@link #getTime() <em>Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTime()
	 * @generated
	 * @ordered
	 */
	protected static final int TIME_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getTime() <em>Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTime()
	 * @generated
	 * @ordered
	 */
	protected int time = TIME_EDEFAULT;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getProvisionTo() <em>Provision To</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProvisionTo()
	 * @generated
	 * @ordered
	 */
	protected EList provisionTo;

	/**
	 * The cached value of the '{@link #getProvisionFrom() <em>Provision From</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProvisionFrom()
	 * @generated
	 * @ordered
	 */
	protected EList provisionFrom;

	/**
	 * The cached value of the '{@link #getProvisionOf() <em>Provision Of</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProvisionOf()
	 * @generated
	 * @ordered
	 */
	protected EList provisionOf;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected informationProvisionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqrePackage.Literals.INFORMATION_PROVISION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTime() {
		return time;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTime(int newTime) {
		int oldTime = time;
		time = newTime;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqrePackage.INFORMATION_PROVISION__TIME, oldTime, time));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqrePackage.INFORMATION_PROVISION__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getProvisionTo() {
		if (provisionTo == null) {
			provisionTo = new EObjectResolvingEList(agent.class, this, IqrePackage.INFORMATION_PROVISION__PROVISION_TO);
		}
		return provisionTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getProvisionFrom() {
		if (provisionFrom == null) {
			provisionFrom = new EObjectResolvingEList(agent.class, this, IqrePackage.INFORMATION_PROVISION__PROVISION_FROM);
		}
		return provisionFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getProvisionOf() {
		if (provisionOf == null) {
			provisionOf = new EObjectResolvingEList(information.class, this, IqrePackage.INFORMATION_PROVISION__PROVISION_OF);
		}
		return provisionOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqrePackage.INFORMATION_PROVISION__TIME:
				return new Integer(getTime());
			case IqrePackage.INFORMATION_PROVISION__TYPE:
				return getType();
			case IqrePackage.INFORMATION_PROVISION__PROVISION_TO:
				return getProvisionTo();
			case IqrePackage.INFORMATION_PROVISION__PROVISION_FROM:
				return getProvisionFrom();
			case IqrePackage.INFORMATION_PROVISION__PROVISION_OF:
				return getProvisionOf();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqrePackage.INFORMATION_PROVISION__TIME:
				setTime(((Integer)newValue).intValue());
				return;
			case IqrePackage.INFORMATION_PROVISION__TYPE:
				setType((String)newValue);
				return;
			case IqrePackage.INFORMATION_PROVISION__PROVISION_TO:
				getProvisionTo().clear();
				getProvisionTo().addAll((Collection)newValue);
				return;
			case IqrePackage.INFORMATION_PROVISION__PROVISION_FROM:
				getProvisionFrom().clear();
				getProvisionFrom().addAll((Collection)newValue);
				return;
			case IqrePackage.INFORMATION_PROVISION__PROVISION_OF:
				getProvisionOf().clear();
				getProvisionOf().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqrePackage.INFORMATION_PROVISION__TIME:
				setTime(TIME_EDEFAULT);
				return;
			case IqrePackage.INFORMATION_PROVISION__TYPE:
				setType(TYPE_EDEFAULT);
				return;
			case IqrePackage.INFORMATION_PROVISION__PROVISION_TO:
				getProvisionTo().clear();
				return;
			case IqrePackage.INFORMATION_PROVISION__PROVISION_FROM:
				getProvisionFrom().clear();
				return;
			case IqrePackage.INFORMATION_PROVISION__PROVISION_OF:
				getProvisionOf().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqrePackage.INFORMATION_PROVISION__TIME:
				return time != TIME_EDEFAULT;
			case IqrePackage.INFORMATION_PROVISION__TYPE:
				return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
			case IqrePackage.INFORMATION_PROVISION__PROVISION_TO:
				return provisionTo != null && !provisionTo.isEmpty();
			case IqrePackage.INFORMATION_PROVISION__PROVISION_FROM:
				return provisionFrom != null && !provisionFrom.isEmpty();
			case IqrePackage.INFORMATION_PROVISION__PROVISION_OF:
				return provisionOf != null && !provisionOf.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (time: ");
		result.append(time);
		result.append(", type: ");
		result.append(type);
		result.append(')');
		return result.toString();
	}

} //informationProvisionImpl
