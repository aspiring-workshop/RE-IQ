/**
 */
package iqre.impl;

import iqre.IqrePackage;
import iqre.agent;
import iqre.information;
import iqre.provisionTrust;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>provision Trust</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqre.impl.provisionTrustImpl#getPrvTrustee <em>Prv Trustee</em>}</li>
 *   <li>{@link iqre.impl.provisionTrustImpl#getPrvTrustor <em>Prv Trustor</em>}</li>
 *   <li>{@link iqre.impl.provisionTrustImpl#getTrustOfProvision <em>Trust Of Provision</em>}</li>
 *   <li>{@link iqre.impl.provisionTrustImpl#getType <em>Type</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class provisionTrustImpl extends MinimalEObjectImpl.Container implements provisionTrust {
	/**
	 * The cached value of the '{@link #getPrvTrustee() <em>Prv Trustee</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrvTrustee()
	 * @generated
	 * @ordered
	 */
	protected EList prvTrustee;

	/**
	 * The cached value of the '{@link #getPrvTrustor() <em>Prv Trustor</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrvTrustor()
	 * @generated
	 * @ordered
	 */
	protected EList prvTrustor;

	/**
	 * The cached value of the '{@link #getTrustOfProvision() <em>Trust Of Provision</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustOfProvision()
	 * @generated
	 * @ordered
	 */
	protected EList trustOfProvision;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected provisionTrustImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqrePackage.Literals.PROVISION_TRUST;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getPrvTrustee() {
		if (prvTrustee == null) {
			prvTrustee = new EObjectResolvingEList(agent.class, this, IqrePackage.PROVISION_TRUST__PRV_TRUSTEE);
		}
		return prvTrustee;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getPrvTrustor() {
		if (prvTrustor == null) {
			prvTrustor = new EObjectResolvingEList(agent.class, this, IqrePackage.PROVISION_TRUST__PRV_TRUSTOR);
		}
		return prvTrustor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getTrustOfProvision() {
		if (trustOfProvision == null) {
			trustOfProvision = new EObjectResolvingEList(information.class, this, IqrePackage.PROVISION_TRUST__TRUST_OF_PROVISION);
		}
		return trustOfProvision;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqrePackage.PROVISION_TRUST__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqrePackage.PROVISION_TRUST__PRV_TRUSTEE:
				return getPrvTrustee();
			case IqrePackage.PROVISION_TRUST__PRV_TRUSTOR:
				return getPrvTrustor();
			case IqrePackage.PROVISION_TRUST__TRUST_OF_PROVISION:
				return getTrustOfProvision();
			case IqrePackage.PROVISION_TRUST__TYPE:
				return getType();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqrePackage.PROVISION_TRUST__PRV_TRUSTEE:
				getPrvTrustee().clear();
				getPrvTrustee().addAll((Collection)newValue);
				return;
			case IqrePackage.PROVISION_TRUST__PRV_TRUSTOR:
				getPrvTrustor().clear();
				getPrvTrustor().addAll((Collection)newValue);
				return;
			case IqrePackage.PROVISION_TRUST__TRUST_OF_PROVISION:
				getTrustOfProvision().clear();
				getTrustOfProvision().addAll((Collection)newValue);
				return;
			case IqrePackage.PROVISION_TRUST__TYPE:
				setType((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqrePackage.PROVISION_TRUST__PRV_TRUSTEE:
				getPrvTrustee().clear();
				return;
			case IqrePackage.PROVISION_TRUST__PRV_TRUSTOR:
				getPrvTrustor().clear();
				return;
			case IqrePackage.PROVISION_TRUST__TRUST_OF_PROVISION:
				getTrustOfProvision().clear();
				return;
			case IqrePackage.PROVISION_TRUST__TYPE:
				setType(TYPE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqrePackage.PROVISION_TRUST__PRV_TRUSTEE:
				return prvTrustee != null && !prvTrustee.isEmpty();
			case IqrePackage.PROVISION_TRUST__PRV_TRUSTOR:
				return prvTrustor != null && !prvTrustor.isEmpty();
			case IqrePackage.PROVISION_TRUST__TRUST_OF_PROVISION:
				return trustOfProvision != null && !trustOfProvision.isEmpty();
			case IqrePackage.PROVISION_TRUST__TYPE:
				return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (type: ");
		result.append(type);
		result.append(')');
		return result.toString();
	}

} //provisionTrustImpl
