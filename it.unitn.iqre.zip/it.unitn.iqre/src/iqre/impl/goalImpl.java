/**
 */
package iqre.impl;

import iqre.IqrePackage;
import iqre.goal;
import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>goal</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqre.impl.goalImpl#getName <em>Name</em>}</li>
 *   <li>{@link iqre.impl.goalImpl#getAndDecomposition <em>And Decomposition</em>}</li>
 *   <li>{@link iqre.impl.goalImpl#getOrDecomposition <em>Or Decomposition</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class goalImpl extends MinimalEObjectImpl.Container implements goal {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAndDecomposition() <em>And Decomposition</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAndDecomposition()
	 * @generated
	 * @ordered
	 */
	protected EList andDecomposition;

	/**
	 * The cached value of the '{@link #getOrDecomposition() <em>Or Decomposition</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOrDecomposition()
	 * @generated
	 * @ordered
	 */
	protected EList orDecomposition;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected goalImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqrePackage.Literals.GOAL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqrePackage.GOAL__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getAndDecomposition() {
		if (andDecomposition == null) {
			andDecomposition = new EObjectResolvingEList(goal.class, this, IqrePackage.GOAL__AND_DECOMPOSITION);
		}
		return andDecomposition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getOrDecomposition() {
		if (orDecomposition == null) {
			orDecomposition = new EObjectResolvingEList(goal.class, this, IqrePackage.GOAL__OR_DECOMPOSITION);
		}
		return orDecomposition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqrePackage.GOAL__NAME:
				return getName();
			case IqrePackage.GOAL__AND_DECOMPOSITION:
				return getAndDecomposition();
			case IqrePackage.GOAL__OR_DECOMPOSITION:
				return getOrDecomposition();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqrePackage.GOAL__NAME:
				setName((String)newValue);
				return;
			case IqrePackage.GOAL__AND_DECOMPOSITION:
				getAndDecomposition().clear();
				getAndDecomposition().addAll((Collection)newValue);
				return;
			case IqrePackage.GOAL__OR_DECOMPOSITION:
				getOrDecomposition().clear();
				getOrDecomposition().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqrePackage.GOAL__NAME:
				setName(NAME_EDEFAULT);
				return;
			case IqrePackage.GOAL__AND_DECOMPOSITION:
				getAndDecomposition().clear();
				return;
			case IqrePackage.GOAL__OR_DECOMPOSITION:
				getOrDecomposition().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqrePackage.GOAL__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case IqrePackage.GOAL__AND_DECOMPOSITION:
				return andDecomposition != null && !andDecomposition.isEmpty();
			case IqrePackage.GOAL__OR_DECOMPOSITION:
				return orDecomposition != null && !orDecomposition.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //goalImpl
