/**
 */
package iqre.impl;

import iqre.IqrePackage;
import iqre.information;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>information</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqre.impl.informationImpl#getName <em>Name</em>}</li>
 *   <li>{@link iqre.impl.informationImpl#getVolatility <em>Volatility</em>}</li>
 *   <li>{@link iqre.impl.informationImpl#getSubItem <em>Sub Item</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class informationImpl extends MinimalEObjectImpl.Container implements information {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getVolatility() <em>Volatility</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVolatility()
	 * @generated
	 * @ordered
	 */
	protected static final int VOLATILITY_EDEFAULT = 100;

	/**
	 * The cached value of the '{@link #getVolatility() <em>Volatility</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVolatility()
	 * @generated
	 * @ordered
	 */
	protected int volatility = VOLATILITY_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSubItem() <em>Sub Item</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubItem()
	 * @generated
	 * @ordered
	 */
	protected EList subItem;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected informationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqrePackage.Literals.INFORMATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqrePackage.INFORMATION__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getVolatility() {
		return volatility;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVolatility(int newVolatility) {
		int oldVolatility = volatility;
		volatility = newVolatility;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqrePackage.INFORMATION__VOLATILITY, oldVolatility, volatility));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getSubItem() {
		if (subItem == null) {
			subItem = new EObjectResolvingEList(information.class, this, IqrePackage.INFORMATION__SUB_ITEM);
		}
		return subItem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqrePackage.INFORMATION__NAME:
				return getName();
			case IqrePackage.INFORMATION__VOLATILITY:
				return new Integer(getVolatility());
			case IqrePackage.INFORMATION__SUB_ITEM:
				return getSubItem();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqrePackage.INFORMATION__NAME:
				setName((String)newValue);
				return;
			case IqrePackage.INFORMATION__VOLATILITY:
				setVolatility(((Integer)newValue).intValue());
				return;
			case IqrePackage.INFORMATION__SUB_ITEM:
				getSubItem().clear();
				getSubItem().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqrePackage.INFORMATION__NAME:
				setName(NAME_EDEFAULT);
				return;
			case IqrePackage.INFORMATION__VOLATILITY:
				setVolatility(VOLATILITY_EDEFAULT);
				return;
			case IqrePackage.INFORMATION__SUB_ITEM:
				getSubItem().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqrePackage.INFORMATION__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case IqrePackage.INFORMATION__VOLATILITY:
				return volatility != VOLATILITY_EDEFAULT;
			case IqrePackage.INFORMATION__SUB_ITEM:
				return subItem != null && !subItem.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", volatility: ");
		result.append(volatility);
		result.append(')');
		return result.toString();
	}

} //informationImpl
