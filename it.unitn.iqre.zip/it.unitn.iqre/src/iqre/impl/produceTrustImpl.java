/**
 */
package iqre.impl;

import iqre.IqrePackage;
import iqre.agent;
import iqre.information;
import iqre.produceTrust;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>produce Trust</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqre.impl.produceTrustImpl#getProduceTrustor <em>Produce Trustor</em>}</li>
 *   <li>{@link iqre.impl.produceTrustImpl#getProduceTrustee <em>Produce Trustee</em>}</li>
 *   <li>{@link iqre.impl.produceTrustImpl#getTrustOfProvducing <em>Trust Of Provducing</em>}</li>
 *   <li>{@link iqre.impl.produceTrustImpl#getType <em>Type</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class produceTrustImpl extends MinimalEObjectImpl.Container implements produceTrust {
	/**
	 * The cached value of the '{@link #getProduceTrustor() <em>Produce Trustor</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProduceTrustor()
	 * @generated
	 * @ordered
	 */
	protected EList produceTrustor;

	/**
	 * The cached value of the '{@link #getProduceTrustee() <em>Produce Trustee</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProduceTrustee()
	 * @generated
	 * @ordered
	 */
	protected EList produceTrustee;

	/**
	 * The cached value of the '{@link #getTrustOfProvducing() <em>Trust Of Provducing</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustOfProvducing()
	 * @generated
	 * @ordered
	 */
	protected EList trustOfProvducing;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected produceTrustImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqrePackage.Literals.PRODUCE_TRUST;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getProduceTrustor() {
		if (produceTrustor == null) {
			produceTrustor = new EObjectResolvingEList(agent.class, this, IqrePackage.PRODUCE_TRUST__PRODUCE_TRUSTOR);
		}
		return produceTrustor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getProduceTrustee() {
		if (produceTrustee == null) {
			produceTrustee = new EObjectResolvingEList(agent.class, this, IqrePackage.PRODUCE_TRUST__PRODUCE_TRUSTEE);
		}
		return produceTrustee;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getTrustOfProvducing() {
		if (trustOfProvducing == null) {
			trustOfProvducing = new EObjectResolvingEList(information.class, this, IqrePackage.PRODUCE_TRUST__TRUST_OF_PROVDUCING);
		}
		return trustOfProvducing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqrePackage.PRODUCE_TRUST__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqrePackage.PRODUCE_TRUST__PRODUCE_TRUSTOR:
				return getProduceTrustor();
			case IqrePackage.PRODUCE_TRUST__PRODUCE_TRUSTEE:
				return getProduceTrustee();
			case IqrePackage.PRODUCE_TRUST__TRUST_OF_PROVDUCING:
				return getTrustOfProvducing();
			case IqrePackage.PRODUCE_TRUST__TYPE:
				return getType();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqrePackage.PRODUCE_TRUST__PRODUCE_TRUSTOR:
				getProduceTrustor().clear();
				getProduceTrustor().addAll((Collection)newValue);
				return;
			case IqrePackage.PRODUCE_TRUST__PRODUCE_TRUSTEE:
				getProduceTrustee().clear();
				getProduceTrustee().addAll((Collection)newValue);
				return;
			case IqrePackage.PRODUCE_TRUST__TRUST_OF_PROVDUCING:
				getTrustOfProvducing().clear();
				getTrustOfProvducing().addAll((Collection)newValue);
				return;
			case IqrePackage.PRODUCE_TRUST__TYPE:
				setType((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqrePackage.PRODUCE_TRUST__PRODUCE_TRUSTOR:
				getProduceTrustor().clear();
				return;
			case IqrePackage.PRODUCE_TRUST__PRODUCE_TRUSTEE:
				getProduceTrustee().clear();
				return;
			case IqrePackage.PRODUCE_TRUST__TRUST_OF_PROVDUCING:
				getTrustOfProvducing().clear();
				return;
			case IqrePackage.PRODUCE_TRUST__TYPE:
				setType(TYPE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqrePackage.PRODUCE_TRUST__PRODUCE_TRUSTOR:
				return produceTrustor != null && !produceTrustor.isEmpty();
			case IqrePackage.PRODUCE_TRUST__PRODUCE_TRUSTEE:
				return produceTrustee != null && !produceTrustee.isEmpty();
			case IqrePackage.PRODUCE_TRUST__TRUST_OF_PROVDUCING:
				return trustOfProvducing != null && !trustOfProvducing.isEmpty();
			case IqrePackage.PRODUCE_TRUST__TYPE:
				return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (type: ");
		result.append(type);
		result.append(')');
		return result.toString();
	}

} //produceTrustImpl
