/**
 */
package iqre.impl;

import iqre.IqrePackage;
import iqre.agent;
import iqre.delegation;
import iqre.goalInstence;
import iqre.taskInstence;

import java.util.Collection;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>delegation</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqre.impl.delegationImpl#getDelegationFrom <em>Delegation From</em>}</li>
 *   <li>{@link iqre.impl.delegationImpl#getDelegationTo <em>Delegation To</em>}</li>
 *   <li>{@link iqre.impl.delegationImpl#getDelegationOfGoal <em>Delegation Of Goal</em>}</li>
 *   <li>{@link iqre.impl.delegationImpl#getDelegationOfTask <em>Delegation Of Task</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class delegationImpl extends MinimalEObjectImpl.Container implements delegation {
	/**
	 * The cached value of the '{@link #getDelegationFrom() <em>Delegation From</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDelegationFrom()
	 * @generated
	 * @ordered
	 */
	protected EList delegationFrom;

	/**
	 * The cached value of the '{@link #getDelegationTo() <em>Delegation To</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDelegationTo()
	 * @generated
	 * @ordered
	 */
	protected EList delegationTo;

	/**
	 * The cached value of the '{@link #getDelegationOfGoal() <em>Delegation Of Goal</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDelegationOfGoal()
	 * @generated
	 * @ordered
	 */
	protected EList delegationOfGoal;

	/**
	 * The cached value of the '{@link #getDelegationOfTask() <em>Delegation Of Task</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDelegationOfTask()
	 * @generated
	 * @ordered
	 */
	protected EList delegationOfTask;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected delegationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqrePackage.Literals.DELEGATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getDelegationFrom() {
		if (delegationFrom == null) {
			delegationFrom = new EObjectResolvingEList(agent.class, this, IqrePackage.DELEGATION__DELEGATION_FROM);
		}
		return delegationFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getDelegationTo() {
		if (delegationTo == null) {
			delegationTo = new EObjectResolvingEList(agent.class, this, IqrePackage.DELEGATION__DELEGATION_TO);
		}
		return delegationTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getDelegationOfGoal() {
		if (delegationOfGoal == null) {
			delegationOfGoal = new EObjectResolvingEList(goalInstence.class, this, IqrePackage.DELEGATION__DELEGATION_OF_GOAL);
		}
		return delegationOfGoal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getDelegationOfTask() {
		if (delegationOfTask == null) {
			delegationOfTask = new EObjectResolvingEList(taskInstence.class, this, IqrePackage.DELEGATION__DELEGATION_OF_TASK);
		}
		return delegationOfTask;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqrePackage.DELEGATION__DELEGATION_FROM:
				return getDelegationFrom();
			case IqrePackage.DELEGATION__DELEGATION_TO:
				return getDelegationTo();
			case IqrePackage.DELEGATION__DELEGATION_OF_GOAL:
				return getDelegationOfGoal();
			case IqrePackage.DELEGATION__DELEGATION_OF_TASK:
				return getDelegationOfTask();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqrePackage.DELEGATION__DELEGATION_FROM:
				getDelegationFrom().clear();
				getDelegationFrom().addAll((Collection)newValue);
				return;
			case IqrePackage.DELEGATION__DELEGATION_TO:
				getDelegationTo().clear();
				getDelegationTo().addAll((Collection)newValue);
				return;
			case IqrePackage.DELEGATION__DELEGATION_OF_GOAL:
				getDelegationOfGoal().clear();
				getDelegationOfGoal().addAll((Collection)newValue);
				return;
			case IqrePackage.DELEGATION__DELEGATION_OF_TASK:
				getDelegationOfTask().clear();
				getDelegationOfTask().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqrePackage.DELEGATION__DELEGATION_FROM:
				getDelegationFrom().clear();
				return;
			case IqrePackage.DELEGATION__DELEGATION_TO:
				getDelegationTo().clear();
				return;
			case IqrePackage.DELEGATION__DELEGATION_OF_GOAL:
				getDelegationOfGoal().clear();
				return;
			case IqrePackage.DELEGATION__DELEGATION_OF_TASK:
				getDelegationOfTask().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqrePackage.DELEGATION__DELEGATION_FROM:
				return delegationFrom != null && !delegationFrom.isEmpty();
			case IqrePackage.DELEGATION__DELEGATION_TO:
				return delegationTo != null && !delegationTo.isEmpty();
			case IqrePackage.DELEGATION__DELEGATION_OF_GOAL:
				return delegationOfGoal != null && !delegationOfGoal.isEmpty();
			case IqrePackage.DELEGATION__DELEGATION_OF_TASK:
				return delegationOfTask != null && !delegationOfTask.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //delegationImpl
