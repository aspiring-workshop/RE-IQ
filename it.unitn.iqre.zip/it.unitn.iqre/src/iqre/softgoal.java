/**
 */
package iqre;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>softgoal</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqre.softgoal#getAndDecomposition <em>And Decomposition</em>}</li>
 *   <li>{@link iqre.softgoal#getType <em>Type</em>}</li>
 *   <li>{@link iqre.softgoal#getQualityTarget <em>Quality Target</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqre.IqrePackage#getsoftgoal()
 * @model
 * @generated
 */
public interface softgoal extends EObject {
	/**
	 * Returns the value of the '<em><b>And Decomposition</b></em>' reference list.
	 * The list contents are of type {@link iqre.softgoal}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>And Decomposition</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>And Decomposition</em>' reference list.
	 * @see iqre.IqrePackage#getsoftgoal_AndDecomposition()
	 * @model type="iqre.softgoal"
	 * @generated
	 */
	EList getAndDecomposition();

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see iqre.IqrePackage#getsoftgoal_Type()
	 * @model
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link iqre.softgoal#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

	/**
	 * Returns the value of the '<em><b>Quality Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Quality Target</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Quality Target</em>' reference.
	 * @see #setQualityTarget(information)
	 * @see iqre.IqrePackage#getsoftgoal_QualityTarget()
	 * @model required="true"
	 * @generated
	 */
	information getQualityTarget();

	/**
	 * Sets the value of the '{@link iqre.softgoal#getQualityTarget <em>Quality Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Quality Target</em>' reference.
	 * @see #getQualityTarget()
	 * @generated
	 */
	void setQualityTarget(information value);

} // softgoal
