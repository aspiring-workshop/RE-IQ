/**
 */
package iqre;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>task Instence</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqre.taskInstence#getName <em>Name</em>}</li>
 *   <li>{@link iqre.taskInstence#getMeansEndInsGoal <em>Means End Ins Goal</em>}</li>
 *   <li>{@link iqre.taskInstence#getInstence <em>Instence</em>}</li>
 *   <li>{@link iqre.taskInstence#getAndDecomposition <em>And Decomposition</em>}</li>
 *   <li>{@link iqre.taskInstence#getOrDecomposition <em>Or Decomposition</em>}</li>
 *   <li>{@link iqre.taskInstence#getDependent <em>Dependent</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqre.IqrePackage#gettaskInstence()
 * @model
 * @generated
 */
public interface taskInstence extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see iqre.IqrePackage#gettaskInstence_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link iqre.taskInstence#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Means End Ins Goal</b></em>' reference list.
	 * The list contents are of type {@link iqre.goalInstence}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Means End Ins Goal</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Means End Ins Goal</em>' reference list.
	 * @see iqre.IqrePackage#gettaskInstence_MeansEndInsGoal()
	 * @model type="iqre.goalInstence"
	 * @generated
	 */
	EList getMeansEndInsGoal();

	/**
	 * Returns the value of the '<em><b>Instence</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Instence</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Instence</em>' reference.
	 * @see #setInstence(task)
	 * @see iqre.IqrePackage#gettaskInstence_Instence()
	 * @model required="true"
	 * @generated
	 */
	task getInstence();

	/**
	 * Sets the value of the '{@link iqre.taskInstence#getInstence <em>Instence</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Instence</em>' reference.
	 * @see #getInstence()
	 * @generated
	 */
	void setInstence(task value);

	/**
	 * Returns the value of the '<em><b>And Decomposition</b></em>' reference list.
	 * The list contents are of type {@link iqre.taskInstence}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>And Decomposition</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>And Decomposition</em>' reference list.
	 * @see iqre.IqrePackage#gettaskInstence_AndDecomposition()
	 * @model type="iqre.taskInstence"
	 * @generated
	 */
	EList getAndDecomposition();

	/**
	 * Returns the value of the '<em><b>Or Decomposition</b></em>' reference list.
	 * The list contents are of type {@link iqre.taskInstence}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Or Decomposition</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Or Decomposition</em>' reference list.
	 * @see iqre.IqrePackage#gettaskInstence_OrDecomposition()
	 * @model type="iqre.taskInstence"
	 * @generated
	 */
	EList getOrDecomposition();

	/**
	 * Returns the value of the '<em><b>Dependent</b></em>' reference list.
	 * The list contents are of type {@link iqre.softgoal}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Dependent</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dependent</em>' reference list.
	 * @see iqre.IqrePackage#gettaskInstence_Dependent()
	 * @model type="iqre.softgoal"
	 * @generated
	 */
	EList getDependent();

} // taskInstence
