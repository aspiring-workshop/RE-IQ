/**
 */
package iqtool;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>provision Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see iqtool.IqtoolPackage#getprovisionType()
 * @model
 * @generated
 */
public final class provisionType extends AbstractEnumerator {
	/**
	 * The '<em><b>Provision</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Provision</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #PROVISION_LITERAL
	 * @model name="provision"
	 * @generated
	 * @ordered
	 */
	public static final int PROVISION = 0;

	/**
	 * The '<em><b>Iprovision</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Iprovision</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #IPROVISION_LITERAL
	 * @model name="iprovision"
	 * @generated
	 * @ordered
	 */
	public static final int IPROVISION = 1;

	/**
	 * The '<em><b>Provision</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PROVISION
	 * @generated
	 * @ordered
	 */
	public static final provisionType PROVISION_LITERAL = new provisionType(PROVISION, "provision", "provision");

	/**
	 * The '<em><b>Iprovision</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #IPROVISION
	 * @generated
	 * @ordered
	 */
	public static final provisionType IPROVISION_LITERAL = new provisionType(IPROVISION, "iprovision", "iprovision");

	/**
	 * An array of all the '<em><b>provision Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final provisionType[] VALUES_ARRAY =
		new provisionType[] {
			PROVISION_LITERAL,
			IPROVISION_LITERAL,
		};

	/**
	 * A public read-only list of all the '<em><b>provision Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>provision Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static provisionType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			provisionType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>provision Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static provisionType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			provisionType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>provision Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static provisionType get(int value) {
		switch (value) {
			case PROVISION: return PROVISION_LITERAL;
			case IPROVISION: return IPROVISION_LITERAL;
		}
		return null;
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private provisionType(int value, String name, String literal) {
		super(value, name, literal);
	}

} //provisionType
