/**
 */
package iqtool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>produce</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.produce#getProduceBy <em>Produce By</em>}</li>
 *   <li>{@link iqtool.produce#getProduceOf <em>Produce Of</em>}</li>
 *   <li>{@link iqtool.produce#getPrd_blv_type <em>Prd blv type</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getproduce()
 * @model
 * @generated
 */
public interface produce extends EObject {
	/**
	 * Returns the value of the '<em><b>Produce By</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Produce By</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Produce By</em>' reference.
	 * @see #setProduceBy(goal)
	 * @see iqtool.IqtoolPackage#getproduce_ProduceBy()
	 * @model
	 * @generated
	 */
	goal getProduceBy();

	/**
	 * Sets the value of the '{@link iqtool.produce#getProduceBy <em>Produce By</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Produce By</em>' reference.
	 * @see #getProduceBy()
	 * @generated
	 */
	void setProduceBy(goal value);

	/**
	 * Returns the value of the '<em><b>Produce Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Produce Of</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Produce Of</em>' reference.
	 * @see #setProduceOf(information)
	 * @see iqtool.IqtoolPackage#getproduce_ProduceOf()
	 * @model
	 * @generated
	 */
	information getProduceOf();

	/**
	 * Sets the value of the '{@link iqtool.produce#getProduceOf <em>Produce Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Produce Of</em>' reference.
	 * @see #getProduceOf()
	 * @generated
	 */
	void setProduceOf(information value);

	/**
	 * Returns the value of the '<em><b>Prd blv type</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.blv_type}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Prd blv type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Prd blv type</em>' attribute.
	 * @see iqtool.blv_type
	 * @see #setPrd_blv_type(blv_type)
	 * @see iqtool.IqtoolPackage#getproduce_Prd_blv_type()
	 * @model
	 * @generated
	 */
	blv_type getPrd_blv_type();

	/**
	 * Sets the value of the '{@link iqtool.produce#getPrd_blv_type <em>Prd blv type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Prd blv type</em>' attribute.
	 * @see iqtool.blv_type
	 * @see #getPrd_blv_type()
	 * @generated
	 */
	void setPrd_blv_type(blv_type value);

} // produce
