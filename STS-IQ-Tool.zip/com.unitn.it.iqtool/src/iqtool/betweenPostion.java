/**
 */
package iqtool;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>between Postion</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.betweenPostion#getOutarc <em>Outarc</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getbetweenPostion()
 * @model
 * @generated
 */
public interface betweenPostion extends position {
	/**
	 * Returns the value of the '<em><b>Outarc</b></em>' reference list.
	 * The list contents are of type {@link iqtool.goal}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Outarc</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Outarc</em>' reference list.
	 * @see iqtool.IqtoolPackage#getbetweenPostion_Outarc()
	 * @model type="iqtool.goal"
	 * @generated
	 */
	EList getOutarc();

} // betweenPostion
