/**
 */
package iqtool;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>goal</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.goal#getName <em>Name</em>}</li>
 *   <li>{@link iqtool.goal#getOrdecomposition <em>Ordecomposition</em>}</li>
 *   <li>{@link iqtool.goal#getAnddecomposition <em>Anddecomposition</em>}</li>
 *   <li>{@link iqtool.goal#getModify <em>Modify</em>}</li>
 *   <li>{@link iqtool.goal#getPosContributes <em>Pos Contributes</em>}</li>
 *   <li>{@link iqtool.goal#getNegContributes <em>Neg Contributes</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getgoal()
 * @model
 * @generated
 */
public interface goal extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see iqtool.IqtoolPackage#getgoal_Name()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link iqtool.goal#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Ordecomposition</b></em>' reference list.
	 * The list contents are of type {@link iqtool.goal}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ordecomposition</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ordecomposition</em>' reference list.
	 * @see iqtool.IqtoolPackage#getgoal_Ordecomposition()
	 * @model type="iqtool.goal"
	 * @generated
	 */
	EList getOrdecomposition();

	/**
	 * Returns the value of the '<em><b>Anddecomposition</b></em>' reference list.
	 * The list contents are of type {@link iqtool.goal}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Anddecomposition</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Anddecomposition</em>' reference list.
	 * @see iqtool.IqtoolPackage#getgoal_Anddecomposition()
	 * @model type="iqtool.goal"
	 * @generated
	 */
	EList getAnddecomposition();

	/**
	 * Returns the value of the '<em><b>Modify</b></em>' reference list.
	 * The list contents are of type {@link iqtool.information}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Modify</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Modify</em>' reference list.
	 * @see iqtool.IqtoolPackage#getgoal_Modify()
	 * @model type="iqtool.information"
	 * @generated
	 */
	EList getModify();

	/**
	 * Returns the value of the '<em><b>Pos Contributes</b></em>' reference list.
	 * The list contents are of type {@link iqtool.goal}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pos Contributes</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pos Contributes</em>' reference list.
	 * @see iqtool.IqtoolPackage#getgoal_PosContributes()
	 * @model type="iqtool.goal"
	 * @generated
	 */
	EList getPosContributes();

	/**
	 * Returns the value of the '<em><b>Neg Contributes</b></em>' reference list.
	 * The list contents are of type {@link iqtool.goal}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Neg Contributes</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Neg Contributes</em>' reference list.
	 * @see iqtool.IqtoolPackage#getgoal_NegContributes()
	 * @model type="iqtool.goal"
	 * @generated
	 */
	EList getNegContributes();

} // goal
