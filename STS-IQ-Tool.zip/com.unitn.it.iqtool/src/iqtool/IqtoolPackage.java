/**
 */
package iqtool;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see iqtool.IqtoolFactory
 * @model kind="package"
 * @generated
 */
public interface IqtoolPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "iqtool";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/iqtool";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "iqtool";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	IqtoolPackage eINSTANCE = iqtool.impl.IqtoolPackageImpl.init();

	/**
	 * The meta object id for the '{@link iqtool.impl.actorImpl <em>actor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.actorImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getactor()
	 * @generated
	 */
	int ACTOR = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR__NAME = 0;

	/**
	 * The feature id for the '<em><b>Aims</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR__AIMS = 1;

	/**
	 * The feature id for the '<em><b>Own</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR__OWN = 2;

	/**
	 * The feature id for the '<em><b>Capable Of Threat</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR__CAPABLE_OF_THREAT = 3;

	/**
	 * The feature id for the '<em><b>Incapable Of Threat</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR__INCAPABLE_OF_THREAT = 4;

	/**
	 * The number of structural features of the '<em>actor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link iqtool.impl.diagramImpl <em>diagram</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.diagramImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getdiagram()
	 * @generated
	 */
	int DIAGRAM = 1;

	/**
	 * The feature id for the '<em><b>Scope Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__SCOPE_ELEMENT = 0;

	/**
	 * The feature id for the '<em><b>Delegation Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__DELEGATION_ELEMENT = 1;

	/**
	 * The feature id for the '<em><b>Provision Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__PROVISION_ELEMENT = 2;

	/**
	 * The feature id for the '<em><b>Delegation Trust Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__DELEGATION_TRUST_ELEMENT = 3;

	/**
	 * The feature id for the '<em><b>Agent Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__AGENT_ELEMENT = 4;

	/**
	 * The feature id for the '<em><b>Role Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__ROLE_ELEMENT = 5;

	/**
	 * The feature id for the '<em><b>Perm Dele Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__PERM_DELE_ELEMENT = 6;

	/**
	 * The feature id for the '<em><b>Trust Perm Dele Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__TRUST_PERM_DELE_ELEMENT = 7;

	/**
	 * The feature id for the '<em><b>Read Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__READ_ELEMENT = 8;

	/**
	 * The feature id for the '<em><b>Send Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__SEND_ELEMENT = 9;

	/**
	 * The feature id for the '<em><b>Produce Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__PRODUCE_ELEMENT = 10;

	/**
	 * The feature id for the '<em><b>Produce Trust Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__PRODUCE_TRUST_ELEMENT = 11;

	/**
	 * The feature id for the '<em><b>Instance Goal Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__INSTANCE_GOAL_ELEMENT = 12;

	/**
	 * The feature id for the '<em><b>General Goal Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__GENERAL_GOAL_ELEMENT = 13;

	/**
	 * The feature id for the '<em><b>Instance Information Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__INSTANCE_INFORMATION_ELEMENT = 14;

	/**
	 * The feature id for the '<em><b>General Information Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__GENERAL_INFORMATION_ELEMENT = 15;

	/**
	 * The feature id for the '<em><b>Goal Threat Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__GOAL_THREAT_ELEMENT = 16;

	/**
	 * The feature id for the '<em><b>Information Threat Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__INFORMATION_THREAT_ELEMENT = 17;

	/**
	 * The feature id for the '<em><b>Goal Monitoring Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__GOAL_MONITORING_ELEMENT = 18;

	/**
	 * The feature id for the '<em><b>Info Monitoring Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__INFO_MONITORING_ELEMENT = 19;

	/**
	 * The feature id for the '<em><b>Perm Monitor Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__PERM_MONITOR_ELEMENT = 20;

	/**
	 * The number of structural features of the '<em>diagram</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM_FEATURE_COUNT = 21;

	/**
	 * The meta object id for the '{@link iqtool.impl.roleImpl <em>role</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.roleImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getrole()
	 * @generated
	 */
	int ROLE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__NAME = ACTOR__NAME;

	/**
	 * The feature id for the '<em><b>Aims</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__AIMS = ACTOR__AIMS;

	/**
	 * The feature id for the '<em><b>Own</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__OWN = ACTOR__OWN;

	/**
	 * The feature id for the '<em><b>Capable Of Threat</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__CAPABLE_OF_THREAT = ACTOR__CAPABLE_OF_THREAT;

	/**
	 * The feature id for the '<em><b>Incapable Of Threat</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__INCAPABLE_OF_THREAT = ACTOR__INCAPABLE_OF_THREAT;

	/**
	 * The feature id for the '<em><b>Isa</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__ISA = ACTOR_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Is capable</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__IS_CAPABLE = ACTOR_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>role</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_FEATURE_COUNT = ACTOR_FEATURE_COUNT + 2;

	/**
	 * The meta object id for the '{@link iqtool.impl.agentImpl <em>agent</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.agentImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getagent()
	 * @generated
	 */
	int AGENT = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT__NAME = ACTOR__NAME;

	/**
	 * The feature id for the '<em><b>Aims</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT__AIMS = ACTOR__AIMS;

	/**
	 * The feature id for the '<em><b>Own</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT__OWN = ACTOR__OWN;

	/**
	 * The feature id for the '<em><b>Capable Of Threat</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT__CAPABLE_OF_THREAT = ACTOR__CAPABLE_OF_THREAT;

	/**
	 * The feature id for the '<em><b>Incapable Of Threat</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT__INCAPABLE_OF_THREAT = ACTOR__INCAPABLE_OF_THREAT;

	/**
	 * The feature id for the '<em><b>Play</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT__PLAY = ACTOR_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>agent</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT_FEATURE_COUNT = ACTOR_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.permDelegationImpl <em>perm Delegation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.permDelegationImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getpermDelegation()
	 * @generated
	 */
	int PERM_DELEGATION = 4;

	/**
	 * The feature id for the '<em><b>Perm Over</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_DELEGATION__PERM_OVER = 0;

	/**
	 * The feature id for the '<em><b>Perm Dele From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_DELEGATION__PERM_DELE_FROM = 1;

	/**
	 * The feature id for the '<em><b>Perm Dele To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_DELEGATION__PERM_DELE_TO = 2;

	/**
	 * The feature id for the '<em><b>Read Perm</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_DELEGATION__READ_PERM = 3;

	/**
	 * The feature id for the '<em><b>Produce Perm</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_DELEGATION__PRODUCE_PERM = 4;

	/**
	 * The feature id for the '<em><b>Modify Perm</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_DELEGATION__MODIFY_PERM = 5;

	/**
	 * The feature id for the '<em><b>Send Perm</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_DELEGATION__SEND_PERM = 6;

	/**
	 * The number of structural features of the '<em>perm Delegation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_DELEGATION_FEATURE_COUNT = 7;

	/**
	 * The meta object id for the '{@link iqtool.impl.readImpl <em>read</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.readImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getread()
	 * @generated
	 */
	int READ = 5;

	/**
	 * The feature id for the '<em><b>Pou</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READ__POU = 0;

	/**
	 * The feature id for the '<em><b>Read Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READ__READ_OF = 1;

	/**
	 * The feature id for the '<em><b>Read By</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READ__READ_BY = 2;

	/**
	 * The feature id for the '<em><b>Read Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READ__READ_TYPE = 3;

	/**
	 * The feature id for the '<em><b>Prd blv type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READ__PRD_BLV_TYPE = 4;

	/**
	 * The number of structural features of the '<em>read</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READ_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link iqtool.impl.sendImpl <em>send</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.sendImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getsend()
	 * @generated
	 */
	int SEND = 6;

	/**
	 * The feature id for the '<em><b>Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEND__TIME = 0;

	/**
	 * The feature id for the '<em><b>Send Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEND__SEND_OF = 1;

	/**
	 * The feature id for the '<em><b>Send By</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEND__SEND_BY = 2;

	/**
	 * The feature id for the '<em><b>Send To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEND__SEND_TO = 3;

	/**
	 * The number of structural features of the '<em>send</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEND_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link iqtool.impl.goalDelegationImpl <em>goal Delegation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.goalDelegationImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getgoalDelegation()
	 * @generated
	 */
	int GOAL_DELEGATION = 7;

	/**
	 * The feature id for the '<em><b>Delegation Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_DELEGATION__DELEGATION_OF = 0;

	/**
	 * The feature id for the '<em><b>Delegation From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_DELEGATION__DELEGATION_FROM = 1;

	/**
	 * The feature id for the '<em><b>Delegation To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_DELEGATION__DELEGATION_TO = 2;

	/**
	 * The number of structural features of the '<em>goal Delegation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_DELEGATION_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link iqtool.impl.delegationTrustImpl <em>delegation Trust</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.delegationTrustImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getdelegationTrust()
	 * @generated
	 */
	int DELEGATION_TRUST = 8;

	/**
	 * The feature id for the '<em><b>Trustlevel</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELEGATION_TRUST__TRUSTLEVEL = 0;

	/**
	 * The feature id for the '<em><b>Trustum Goal</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELEGATION_TRUST__TRUSTUM_GOAL = 1;

	/**
	 * The feature id for the '<em><b>Trustor Goal</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELEGATION_TRUST__TRUSTOR_GOAL = 2;

	/**
	 * The feature id for the '<em><b>Trustee Goal</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELEGATION_TRUST__TRUSTEE_GOAL = 3;

	/**
	 * The number of structural features of the '<em>delegation Trust</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELEGATION_TRUST_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link iqtool.impl.infoProvisionImpl <em>info Provision</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.infoProvisionImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getinfoProvision()
	 * @generated
	 */
	int INFO_PROVISION = 9;

	/**
	 * The feature id for the '<em><b>Provision Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_PROVISION__PROVISION_OF = 0;

	/**
	 * The feature id for the '<em><b>Provision From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_PROVISION__PROVISION_FROM = 1;

	/**
	 * The feature id for the '<em><b>Provision To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_PROVISION__PROVISION_TO = 2;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_PROVISION__TYPE = 3;

	/**
	 * The feature id for the '<em><b>Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_PROVISION__TIME = 4;

	/**
	 * The number of structural features of the '<em>info Provision</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_PROVISION_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link iqtool.impl.trustPermDelegationImpl <em>trust Perm Delegation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.trustPermDelegationImpl
	 * @see iqtool.impl.IqtoolPackageImpl#gettrustPermDelegation()
	 * @generated
	 */
	int TRUST_PERM_DELEGATION = 10;

	/**
	 * The feature id for the '<em><b>Trust Perm Dele To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_PERM_DELEGATION__TRUST_PERM_DELE_TO = 0;

	/**
	 * The feature id for the '<em><b>Trust Perm Dele From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_PERM_DELEGATION__TRUST_PERM_DELE_FROM = 1;

	/**
	 * The feature id for the '<em><b>Trust Perm Dele Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_PERM_DELEGATION__TRUST_PERM_DELE_OF = 2;

	/**
	 * The feature id for the '<em><b>Trustprodue</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_PERM_DELEGATION__TRUSTPRODUE = 3;

	/**
	 * The feature id for the '<em><b>Trustread</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_PERM_DELEGATION__TRUSTREAD = 4;

	/**
	 * The feature id for the '<em><b>Trustsend</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_PERM_DELEGATION__TRUSTSEND = 5;

	/**
	 * The feature id for the '<em><b>Trustmodify</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_PERM_DELEGATION__TRUSTMODIFY = 6;

	/**
	 * The number of structural features of the '<em>trust Perm Delegation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_PERM_DELEGATION_FEATURE_COUNT = 7;

	/**
	 * The meta object id for the '{@link iqtool.impl.informationImpl <em>information</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.informationImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getinformation()
	 * @generated
	 */
	int INFORMATION = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Volatility</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION__VOLATILITY = 1;

	/**
	 * The feature id for the '<em><b>Sub Item</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION__SUB_ITEM = 2;

	/**
	 * The number of structural features of the '<em>information</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link iqtool.impl.scopeImpl <em>scope</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.scopeImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getscope()
	 * @generated
	 */
	int SCOPE = 12;

	/**
	 * The feature id for the '<em><b>Contains</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCOPE__CONTAINS = 0;

	/**
	 * The number of structural features of the '<em>scope</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCOPE_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.goalImpl <em>goal</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.goalImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getgoal()
	 * @generated
	 */
	int GOAL = 13;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__NAME = 0;

	/**
	 * The feature id for the '<em><b>Ordecomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__ORDECOMPOSITION = 1;

	/**
	 * The feature id for the '<em><b>Anddecomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__ANDDECOMPOSITION = 2;

	/**
	 * The feature id for the '<em><b>Modify</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__MODIFY = 3;

	/**
	 * The feature id for the '<em><b>Pos Contributes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__POS_CONTRIBUTES = 4;

	/**
	 * The feature id for the '<em><b>Neg Contributes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__NEG_CONTRIBUTES = 5;

	/**
	 * The number of structural features of the '<em>goal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_FEATURE_COUNT = 6;

	/**
	 * The meta object id for the '{@link iqtool.impl.produceImpl <em>produce</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.produceImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getproduce()
	 * @generated
	 */
	int PRODUCE = 14;

	/**
	 * The feature id for the '<em><b>Produce By</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE__PRODUCE_BY = 0;

	/**
	 * The feature id for the '<em><b>Produce Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE__PRODUCE_OF = 1;

	/**
	 * The feature id for the '<em><b>Prd blv type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE__PRD_BLV_TYPE = 2;

	/**
	 * The number of structural features of the '<em>produce</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link iqtool.impl.produceTrustImpl <em>produce Trust</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.produceTrustImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getproduceTrust()
	 * @generated
	 */
	int PRODUCE_TRUST = 15;

	/**
	 * The feature id for the '<em><b>Trustlevel</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE_TRUST__TRUSTLEVEL = 0;

	/**
	 * The feature id for the '<em><b>Produce Trustor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE_TRUST__PRODUCE_TRUSTOR = 1;

	/**
	 * The feature id for the '<em><b>Produce Trustee</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE_TRUST__PRODUCE_TRUSTEE = 2;

	/**
	 * The feature id for the '<em><b>Produce Trust Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE_TRUST__PRODUCE_TRUST_OF = 3;

	/**
	 * The number of structural features of the '<em>produce Trust</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE_TRUST_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link iqtool.impl.instanceGoalImpl <em>instance Goal</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.instanceGoalImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getinstanceGoal()
	 * @generated
	 */
	int INSTANCE_GOAL = 16;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_GOAL__NAME = GOAL__NAME;

	/**
	 * The feature id for the '<em><b>Ordecomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_GOAL__ORDECOMPOSITION = GOAL__ORDECOMPOSITION;

	/**
	 * The feature id for the '<em><b>Anddecomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_GOAL__ANDDECOMPOSITION = GOAL__ANDDECOMPOSITION;

	/**
	 * The feature id for the '<em><b>Modify</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_GOAL__MODIFY = GOAL__MODIFY;

	/**
	 * The feature id for the '<em><b>Pos Contributes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_GOAL__POS_CONTRIBUTES = GOAL__POS_CONTRIBUTES;

	/**
	 * The feature id for the '<em><b>Neg Contributes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_GOAL__NEG_CONTRIBUTES = GOAL__NEG_CONTRIBUTES;

	/**
	 * The feature id for the '<em><b>Instance</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_GOAL__INSTANCE = GOAL_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>instance Goal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_GOAL_FEATURE_COUNT = GOAL_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.generalGoalImpl <em>general Goal</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.generalGoalImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getgeneralGoal()
	 * @generated
	 */
	int GENERAL_GOAL = 17;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_GOAL__NAME = GOAL__NAME;

	/**
	 * The feature id for the '<em><b>Ordecomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_GOAL__ORDECOMPOSITION = GOAL__ORDECOMPOSITION;

	/**
	 * The feature id for the '<em><b>Anddecomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_GOAL__ANDDECOMPOSITION = GOAL__ANDDECOMPOSITION;

	/**
	 * The feature id for the '<em><b>Modify</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_GOAL__MODIFY = GOAL__MODIFY;

	/**
	 * The feature id for the '<em><b>Pos Contributes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_GOAL__POS_CONTRIBUTES = GOAL__POS_CONTRIBUTES;

	/**
	 * The feature id for the '<em><b>Neg Contributes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_GOAL__NEG_CONTRIBUTES = GOAL__NEG_CONTRIBUTES;

	/**
	 * The number of structural features of the '<em>general Goal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_GOAL_FEATURE_COUNT = GOAL_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link iqtool.impl.instanceInformationImpl <em>instance Information</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.instanceInformationImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getinstanceInformation()
	 * @generated
	 */
	int INSTANCE_INFORMATION = 18;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_INFORMATION__NAME = INFORMATION__NAME;

	/**
	 * The feature id for the '<em><b>Volatility</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_INFORMATION__VOLATILITY = INFORMATION__VOLATILITY;

	/**
	 * The feature id for the '<em><b>Sub Item</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_INFORMATION__SUB_ITEM = INFORMATION__SUB_ITEM;

	/**
	 * The feature id for the '<em><b>Instance</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_INFORMATION__INSTANCE = INFORMATION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>instance Information</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_INFORMATION_FEATURE_COUNT = INFORMATION_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.general_informationImpl <em>general information</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.general_informationImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getgeneral_information()
	 * @generated
	 */
	int GENERAL_INFORMATION = 19;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_INFORMATION__NAME = INFORMATION__NAME;

	/**
	 * The feature id for the '<em><b>Volatility</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_INFORMATION__VOLATILITY = INFORMATION__VOLATILITY;

	/**
	 * The feature id for the '<em><b>Sub Item</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_INFORMATION__SUB_ITEM = INFORMATION__SUB_ITEM;

	/**
	 * The number of structural features of the '<em>general information</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_INFORMATION_FEATURE_COUNT = INFORMATION_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link iqtool.impl.threatImpl <em>threat</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.threatImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getthreat()
	 * @generated
	 */
	int THREAT = 20;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREAT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Pos Contribute</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREAT__POS_CONTRIBUTE = 1;

	/**
	 * The feature id for the '<em><b>Neg Contribute</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREAT__NEG_CONTRIBUTE = 2;

	/**
	 * The number of structural features of the '<em>threat</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREAT_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link iqtool.impl.informationThreatImpl <em>information Threat</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.informationThreatImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getinformationThreat()
	 * @generated
	 */
	int INFORMATION_THREAT = 21;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_THREAT__NAME = THREAT__NAME;

	/**
	 * The feature id for the '<em><b>Pos Contribute</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_THREAT__POS_CONTRIBUTE = THREAT__POS_CONTRIBUTE;

	/**
	 * The feature id for the '<em><b>Neg Contribute</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_THREAT__NEG_CONTRIBUTE = THREAT__NEG_CONTRIBUTE;

	/**
	 * The feature id for the '<em><b>Threat Information</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_THREAT__THREAT_INFORMATION = THREAT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>information Threat</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_THREAT_FEATURE_COUNT = THREAT_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.goalThreatImpl <em>goal Threat</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.goalThreatImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getgoalThreat()
	 * @generated
	 */
	int GOAL_THREAT = 22;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_THREAT__NAME = THREAT__NAME;

	/**
	 * The feature id for the '<em><b>Pos Contribute</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_THREAT__POS_CONTRIBUTE = THREAT__POS_CONTRIBUTE;

	/**
	 * The feature id for the '<em><b>Neg Contribute</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_THREAT__NEG_CONTRIBUTE = THREAT__NEG_CONTRIBUTE;

	/**
	 * The feature id for the '<em><b>Goal Threat</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_THREAT__GOAL_THREAT = THREAT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>goal Threat</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_THREAT_FEATURE_COUNT = THREAT_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.monitoringImpl <em>monitoring</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.monitoringImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getmonitoring()
	 * @generated
	 */
	int MONITORING = 23;

	/**
	 * The feature id for the '<em><b>Monitor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITORING__MONITOR = 0;

	/**
	 * The feature id for the '<em><b>Monitored</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITORING__MONITORED = 1;

	/**
	 * The number of structural features of the '<em>monitoring</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITORING_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link iqtool.impl.goalMonitoringImpl <em>goal Monitoring</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.goalMonitoringImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getgoalMonitoring()
	 * @generated
	 */
	int GOAL_MONITORING = 24;

	/**
	 * The feature id for the '<em><b>Monitor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_MONITORING__MONITOR = MONITORING__MONITOR;

	/**
	 * The feature id for the '<em><b>Monitored</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_MONITORING__MONITORED = MONITORING__MONITORED;

	/**
	 * The feature id for the '<em><b>Monitoring Of Goal</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_MONITORING__MONITORING_OF_GOAL = MONITORING_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>goal Monitoring</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_MONITORING_FEATURE_COUNT = MONITORING_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.permMonitoringImpl <em>perm Monitoring</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.permMonitoringImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getpermMonitoring()
	 * @generated
	 */
	int PERM_MONITORING = 25;

	/**
	 * The feature id for the '<em><b>Monitor Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_MONITORING__MONITOR_OF = 0;

	/**
	 * The number of structural features of the '<em>perm Monitoring</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_MONITORING_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.infoMonitoringImpl <em>info Monitoring</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.infoMonitoringImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getinfoMonitoring()
	 * @generated
	 */
	int INFO_MONITORING = 26;

	/**
	 * The feature id for the '<em><b>Monitor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_MONITORING__MONITOR = MONITORING__MONITOR;

	/**
	 * The feature id for the '<em><b>Monitored</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_MONITORING__MONITORED = MONITORING__MONITORED;

	/**
	 * The feature id for the '<em><b>Monitoring Of Info</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_MONITORING__MONITORING_OF_INFO = MONITORING_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>info Monitoring</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_MONITORING_FEATURE_COUNT = MONITORING_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.permMonitorImpl <em>perm Monitor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.permMonitorImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getpermMonitor()
	 * @generated
	 */
	int PERM_MONITOR = 27;

	/**
	 * The feature id for the '<em><b>Over</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_MONITOR__OVER = 0;

	/**
	 * The feature id for the '<em><b>R</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_MONITOR__R = 1;

	/**
	 * The feature id for the '<em><b>P</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_MONITOR__P = 2;

	/**
	 * The feature id for the '<em><b>S</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_MONITOR__S = 3;

	/**
	 * The feature id for the '<em><b>M</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_MONITOR__M = 4;

	/**
	 * The feature id for the '<em><b>Monitored</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_MONITOR__MONITORED = 5;

	/**
	 * The feature id for the '<em><b>Monitor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_MONITOR__MONITOR = 6;

	/**
	 * The number of structural features of the '<em>perm Monitor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_MONITOR_FEATURE_COUNT = 7;

	/**
	 * The meta object id for the '{@link iqtool.purposeOfUseTypes <em>purpose Of Use Types</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.purposeOfUseTypes
	 * @see iqtool.impl.IqtoolPackageImpl#getpurposeOfUseTypes()
	 * @generated
	 */
	int PURPOSE_OF_USE_TYPES = 28;

	/**
	 * The meta object id for the '{@link iqtool.sendPermType <em>send Perm Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.sendPermType
	 * @see iqtool.impl.IqtoolPackageImpl#getsendPermType()
	 * @generated
	 */
	int SEND_PERM_TYPE = 29;

	/**
	 * The meta object id for the '{@link iqtool.modifyPermType <em>modify Perm Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.modifyPermType
	 * @see iqtool.impl.IqtoolPackageImpl#getmodifyPermType()
	 * @generated
	 */
	int MODIFY_PERM_TYPE = 30;

	/**
	 * The meta object id for the '{@link iqtool.trustLevel <em>trust Level</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.trustLevel
	 * @see iqtool.impl.IqtoolPackageImpl#gettrustLevel()
	 * @generated
	 */
	int TRUST_LEVEL = 31;

	/**
	 * The meta object id for the '{@link iqtool.producePermType <em>produce Perm Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.producePermType
	 * @see iqtool.impl.IqtoolPackageImpl#getproducePermType()
	 * @generated
	 */
	int PRODUCE_PERM_TYPE = 32;

	/**
	 * The meta object id for the '{@link iqtool.provisionType <em>provision Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.provisionType
	 * @see iqtool.impl.IqtoolPackageImpl#getprovisionType()
	 * @generated
	 */
	int PROVISION_TYPE = 33;

	/**
	 * The meta object id for the '{@link iqtool.readPermType <em>read Perm Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.readPermType
	 * @see iqtool.impl.IqtoolPackageImpl#getreadPermType()
	 * @generated
	 */
	int READ_PERM_TYPE = 34;

	/**
	 * The meta object id for the '{@link iqtool.blv_type <em>blv type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.blv_type
	 * @see iqtool.impl.IqtoolPackageImpl#getblv_type()
	 * @generated
	 */
	int BLV_TYPE = 35;

	/**
	 * The meta object id for the '{@link iqtool.rtype <em>rtype</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.rtype
	 * @see iqtool.impl.IqtoolPackageImpl#getrtype()
	 * @generated
	 */
	int RTYPE = 36;

	/**
	 * The meta object id for the '{@link iqtool.permMonitorType <em>perm Monitor Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.permMonitorType
	 * @see iqtool.impl.IqtoolPackageImpl#getpermMonitorType()
	 * @generated
	 */
	int PERM_MONITOR_TYPE = 37;

	/**
	 * Returns the meta object for class '{@link iqtool.actor <em>actor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>actor</em>'.
	 * @see iqtool.actor
	 * @generated
	 */
	EClass getactor();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.actor#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see iqtool.actor#getName()
	 * @see #getactor()
	 * @generated
	 */
	EAttribute getactor_Name();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.actor#getAims <em>Aims</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Aims</em>'.
	 * @see iqtool.actor#getAims()
	 * @see #getactor()
	 * @generated
	 */
	EReference getactor_Aims();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.actor#getOwn <em>Own</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Own</em>'.
	 * @see iqtool.actor#getOwn()
	 * @see #getactor()
	 * @generated
	 */
	EReference getactor_Own();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.actor#getCapableOfThreat <em>Capable Of Threat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Capable Of Threat</em>'.
	 * @see iqtool.actor#getCapableOfThreat()
	 * @see #getactor()
	 * @generated
	 */
	EReference getactor_CapableOfThreat();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.actor#getIncapableOfThreat <em>Incapable Of Threat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Incapable Of Threat</em>'.
	 * @see iqtool.actor#getIncapableOfThreat()
	 * @see #getactor()
	 * @generated
	 */
	EReference getactor_IncapableOfThreat();

	/**
	 * Returns the meta object for class '{@link iqtool.diagram <em>diagram</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>diagram</em>'.
	 * @see iqtool.diagram
	 * @generated
	 */
	EClass getdiagram();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getScopeElement <em>Scope Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Scope Element</em>'.
	 * @see iqtool.diagram#getScopeElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_ScopeElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getDelegationElement <em>Delegation Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Delegation Element</em>'.
	 * @see iqtool.diagram#getDelegationElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_DelegationElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getProvisionElement <em>Provision Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Provision Element</em>'.
	 * @see iqtool.diagram#getProvisionElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_ProvisionElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getDelegationTrustElement <em>Delegation Trust Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Delegation Trust Element</em>'.
	 * @see iqtool.diagram#getDelegationTrustElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_DelegationTrustElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getAgentElement <em>Agent Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Agent Element</em>'.
	 * @see iqtool.diagram#getAgentElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_AgentElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getRoleElement <em>Role Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Role Element</em>'.
	 * @see iqtool.diagram#getRoleElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_RoleElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getPermDeleElement <em>Perm Dele Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Perm Dele Element</em>'.
	 * @see iqtool.diagram#getPermDeleElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_PermDeleElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getTrustPermDeleElement <em>Trust Perm Dele Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Trust Perm Dele Element</em>'.
	 * @see iqtool.diagram#getTrustPermDeleElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_TrustPermDeleElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getReadElement <em>Read Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Read Element</em>'.
	 * @see iqtool.diagram#getReadElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_ReadElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getSendElement <em>Send Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Send Element</em>'.
	 * @see iqtool.diagram#getSendElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_SendElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getProduceElement <em>Produce Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Produce Element</em>'.
	 * @see iqtool.diagram#getProduceElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_ProduceElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getProduceTrustElement <em>Produce Trust Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Produce Trust Element</em>'.
	 * @see iqtool.diagram#getProduceTrustElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_ProduceTrustElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getInstanceGoalElement <em>Instance Goal Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Instance Goal Element</em>'.
	 * @see iqtool.diagram#getInstanceGoalElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_InstanceGoalElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getGeneralGoalElement <em>General Goal Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>General Goal Element</em>'.
	 * @see iqtool.diagram#getGeneralGoalElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_GeneralGoalElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getInstanceInformationElement <em>Instance Information Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Instance Information Element</em>'.
	 * @see iqtool.diagram#getInstanceInformationElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_InstanceInformationElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getGeneralInformationElement <em>General Information Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>General Information Element</em>'.
	 * @see iqtool.diagram#getGeneralInformationElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_GeneralInformationElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getGoalThreatElement <em>Goal Threat Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Goal Threat Element</em>'.
	 * @see iqtool.diagram#getGoalThreatElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_GoalThreatElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getInformationThreatElement <em>Information Threat Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Information Threat Element</em>'.
	 * @see iqtool.diagram#getInformationThreatElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_InformationThreatElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getGoalMonitoringElement <em>Goal Monitoring Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Goal Monitoring Element</em>'.
	 * @see iqtool.diagram#getGoalMonitoringElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_GoalMonitoringElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getInfoMonitoringElement <em>Info Monitoring Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Info Monitoring Element</em>'.
	 * @see iqtool.diagram#getInfoMonitoringElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_InfoMonitoringElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getPermMonitorElement <em>Perm Monitor Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Perm Monitor Element</em>'.
	 * @see iqtool.diagram#getPermMonitorElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_PermMonitorElement();

	/**
	 * Returns the meta object for class '{@link iqtool.role <em>role</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>role</em>'.
	 * @see iqtool.role
	 * @generated
	 */
	EClass getrole();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.role#getIsa <em>Isa</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Isa</em>'.
	 * @see iqtool.role#getIsa()
	 * @see #getrole()
	 * @generated
	 */
	EReference getrole_Isa();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.role#getIs_capable <em>Is capable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Is capable</em>'.
	 * @see iqtool.role#getIs_capable()
	 * @see #getrole()
	 * @generated
	 */
	EReference getrole_Is_capable();

	/**
	 * Returns the meta object for class '{@link iqtool.agent <em>agent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>agent</em>'.
	 * @see iqtool.agent
	 * @generated
	 */
	EClass getagent();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.agent#getPlay <em>Play</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Play</em>'.
	 * @see iqtool.agent#getPlay()
	 * @see #getagent()
	 * @generated
	 */
	EReference getagent_Play();

	/**
	 * Returns the meta object for class '{@link iqtool.permDelegation <em>perm Delegation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>perm Delegation</em>'.
	 * @see iqtool.permDelegation
	 * @generated
	 */
	EClass getpermDelegation();

	/**
	 * Returns the meta object for the reference '{@link iqtool.permDelegation#getPermOver <em>Perm Over</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Perm Over</em>'.
	 * @see iqtool.permDelegation#getPermOver()
	 * @see #getpermDelegation()
	 * @generated
	 */
	EReference getpermDelegation_PermOver();

	/**
	 * Returns the meta object for the reference '{@link iqtool.permDelegation#getPermDeleFrom <em>Perm Dele From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Perm Dele From</em>'.
	 * @see iqtool.permDelegation#getPermDeleFrom()
	 * @see #getpermDelegation()
	 * @generated
	 */
	EReference getpermDelegation_PermDeleFrom();

	/**
	 * Returns the meta object for the reference '{@link iqtool.permDelegation#getPermDeleTo <em>Perm Dele To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Perm Dele To</em>'.
	 * @see iqtool.permDelegation#getPermDeleTo()
	 * @see #getpermDelegation()
	 * @generated
	 */
	EReference getpermDelegation_PermDeleTo();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.permDelegation#getReadPerm <em>Read Perm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Read Perm</em>'.
	 * @see iqtool.permDelegation#getReadPerm()
	 * @see #getpermDelegation()
	 * @generated
	 */
	EAttribute getpermDelegation_ReadPerm();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.permDelegation#getProducePerm <em>Produce Perm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Produce Perm</em>'.
	 * @see iqtool.permDelegation#getProducePerm()
	 * @see #getpermDelegation()
	 * @generated
	 */
	EAttribute getpermDelegation_ProducePerm();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.permDelegation#getModifyPerm <em>Modify Perm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Modify Perm</em>'.
	 * @see iqtool.permDelegation#getModifyPerm()
	 * @see #getpermDelegation()
	 * @generated
	 */
	EAttribute getpermDelegation_ModifyPerm();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.permDelegation#getSendPerm <em>Send Perm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Send Perm</em>'.
	 * @see iqtool.permDelegation#getSendPerm()
	 * @see #getpermDelegation()
	 * @generated
	 */
	EAttribute getpermDelegation_SendPerm();

	/**
	 * Returns the meta object for class '{@link iqtool.read <em>read</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>read</em>'.
	 * @see iqtool.read
	 * @generated
	 */
	EClass getread();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.read#getPou <em>Pou</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Pou</em>'.
	 * @see iqtool.read#getPou()
	 * @see #getread()
	 * @generated
	 */
	EAttribute getread_Pou();

	/**
	 * Returns the meta object for the reference '{@link iqtool.read#getReadOf <em>Read Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Read Of</em>'.
	 * @see iqtool.read#getReadOf()
	 * @see #getread()
	 * @generated
	 */
	EReference getread_ReadOf();

	/**
	 * Returns the meta object for the reference '{@link iqtool.read#getReadBy <em>Read By</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Read By</em>'.
	 * @see iqtool.read#getReadBy()
	 * @see #getread()
	 * @generated
	 */
	EReference getread_ReadBy();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.read#getReadType <em>Read Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Read Type</em>'.
	 * @see iqtool.read#getReadType()
	 * @see #getread()
	 * @generated
	 */
	EAttribute getread_ReadType();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.read#getPrd_blv_type <em>Prd blv type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Prd blv type</em>'.
	 * @see iqtool.read#getPrd_blv_type()
	 * @see #getread()
	 * @generated
	 */
	EAttribute getread_Prd_blv_type();

	/**
	 * Returns the meta object for class '{@link iqtool.send <em>send</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>send</em>'.
	 * @see iqtool.send
	 * @generated
	 */
	EClass getsend();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.send#getTime <em>Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Time</em>'.
	 * @see iqtool.send#getTime()
	 * @see #getsend()
	 * @generated
	 */
	EAttribute getsend_Time();

	/**
	 * Returns the meta object for the reference '{@link iqtool.send#getSendOf <em>Send Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Send Of</em>'.
	 * @see iqtool.send#getSendOf()
	 * @see #getsend()
	 * @generated
	 */
	EReference getsend_SendOf();

	/**
	 * Returns the meta object for the reference '{@link iqtool.send#getSendBy <em>Send By</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Send By</em>'.
	 * @see iqtool.send#getSendBy()
	 * @see #getsend()
	 * @generated
	 */
	EReference getsend_SendBy();

	/**
	 * Returns the meta object for the reference '{@link iqtool.send#getSendTo <em>Send To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Send To</em>'.
	 * @see iqtool.send#getSendTo()
	 * @see #getsend()
	 * @generated
	 */
	EReference getsend_SendTo();

	/**
	 * Returns the meta object for class '{@link iqtool.goalDelegation <em>goal Delegation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>goal Delegation</em>'.
	 * @see iqtool.goalDelegation
	 * @generated
	 */
	EClass getgoalDelegation();

	/**
	 * Returns the meta object for the reference '{@link iqtool.goalDelegation#getDelegationOf <em>Delegation Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Delegation Of</em>'.
	 * @see iqtool.goalDelegation#getDelegationOf()
	 * @see #getgoalDelegation()
	 * @generated
	 */
	EReference getgoalDelegation_DelegationOf();

	/**
	 * Returns the meta object for the reference '{@link iqtool.goalDelegation#getDelegationFrom <em>Delegation From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Delegation From</em>'.
	 * @see iqtool.goalDelegation#getDelegationFrom()
	 * @see #getgoalDelegation()
	 * @generated
	 */
	EReference getgoalDelegation_DelegationFrom();

	/**
	 * Returns the meta object for the reference '{@link iqtool.goalDelegation#getDelegationTo <em>Delegation To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Delegation To</em>'.
	 * @see iqtool.goalDelegation#getDelegationTo()
	 * @see #getgoalDelegation()
	 * @generated
	 */
	EReference getgoalDelegation_DelegationTo();

	/**
	 * Returns the meta object for class '{@link iqtool.delegationTrust <em>delegation Trust</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>delegation Trust</em>'.
	 * @see iqtool.delegationTrust
	 * @generated
	 */
	EClass getdelegationTrust();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.delegationTrust#getTrustlevel <em>Trustlevel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Trustlevel</em>'.
	 * @see iqtool.delegationTrust#getTrustlevel()
	 * @see #getdelegationTrust()
	 * @generated
	 */
	EAttribute getdelegationTrust_Trustlevel();

	/**
	 * Returns the meta object for the reference '{@link iqtool.delegationTrust#getTrustumGoal <em>Trustum Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Trustum Goal</em>'.
	 * @see iqtool.delegationTrust#getTrustumGoal()
	 * @see #getdelegationTrust()
	 * @generated
	 */
	EReference getdelegationTrust_TrustumGoal();

	/**
	 * Returns the meta object for the reference '{@link iqtool.delegationTrust#getTrustorGoal <em>Trustor Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Trustor Goal</em>'.
	 * @see iqtool.delegationTrust#getTrustorGoal()
	 * @see #getdelegationTrust()
	 * @generated
	 */
	EReference getdelegationTrust_TrustorGoal();

	/**
	 * Returns the meta object for the reference '{@link iqtool.delegationTrust#getTrusteeGoal <em>Trustee Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Trustee Goal</em>'.
	 * @see iqtool.delegationTrust#getTrusteeGoal()
	 * @see #getdelegationTrust()
	 * @generated
	 */
	EReference getdelegationTrust_TrusteeGoal();

	/**
	 * Returns the meta object for class '{@link iqtool.infoProvision <em>info Provision</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>info Provision</em>'.
	 * @see iqtool.infoProvision
	 * @generated
	 */
	EClass getinfoProvision();

	/**
	 * Returns the meta object for the reference '{@link iqtool.infoProvision#getProvisionOf <em>Provision Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Provision Of</em>'.
	 * @see iqtool.infoProvision#getProvisionOf()
	 * @see #getinfoProvision()
	 * @generated
	 */
	EReference getinfoProvision_ProvisionOf();

	/**
	 * Returns the meta object for the reference '{@link iqtool.infoProvision#getProvisionFrom <em>Provision From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Provision From</em>'.
	 * @see iqtool.infoProvision#getProvisionFrom()
	 * @see #getinfoProvision()
	 * @generated
	 */
	EReference getinfoProvision_ProvisionFrom();

	/**
	 * Returns the meta object for the reference '{@link iqtool.infoProvision#getProvisionTo <em>Provision To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Provision To</em>'.
	 * @see iqtool.infoProvision#getProvisionTo()
	 * @see #getinfoProvision()
	 * @generated
	 */
	EReference getinfoProvision_ProvisionTo();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.infoProvision#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see iqtool.infoProvision#getType()
	 * @see #getinfoProvision()
	 * @generated
	 */
	EAttribute getinfoProvision_Type();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.infoProvision#getTime <em>Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Time</em>'.
	 * @see iqtool.infoProvision#getTime()
	 * @see #getinfoProvision()
	 * @generated
	 */
	EAttribute getinfoProvision_Time();

	/**
	 * Returns the meta object for class '{@link iqtool.trustPermDelegation <em>trust Perm Delegation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>trust Perm Delegation</em>'.
	 * @see iqtool.trustPermDelegation
	 * @generated
	 */
	EClass gettrustPermDelegation();

	/**
	 * Returns the meta object for the reference '{@link iqtool.trustPermDelegation#getTrustPermDeleTo <em>Trust Perm Dele To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Trust Perm Dele To</em>'.
	 * @see iqtool.trustPermDelegation#getTrustPermDeleTo()
	 * @see #gettrustPermDelegation()
	 * @generated
	 */
	EReference gettrustPermDelegation_TrustPermDeleTo();

	/**
	 * Returns the meta object for the reference '{@link iqtool.trustPermDelegation#getTrustPermDeleFrom <em>Trust Perm Dele From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Trust Perm Dele From</em>'.
	 * @see iqtool.trustPermDelegation#getTrustPermDeleFrom()
	 * @see #gettrustPermDelegation()
	 * @generated
	 */
	EReference gettrustPermDelegation_TrustPermDeleFrom();

	/**
	 * Returns the meta object for the reference '{@link iqtool.trustPermDelegation#getTrustPermDeleOf <em>Trust Perm Dele Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Trust Perm Dele Of</em>'.
	 * @see iqtool.trustPermDelegation#getTrustPermDeleOf()
	 * @see #gettrustPermDelegation()
	 * @generated
	 */
	EReference gettrustPermDelegation_TrustPermDeleOf();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.trustPermDelegation#getTrustprodue <em>Trustprodue</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Trustprodue</em>'.
	 * @see iqtool.trustPermDelegation#getTrustprodue()
	 * @see #gettrustPermDelegation()
	 * @generated
	 */
	EAttribute gettrustPermDelegation_Trustprodue();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.trustPermDelegation#getTrustread <em>Trustread</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Trustread</em>'.
	 * @see iqtool.trustPermDelegation#getTrustread()
	 * @see #gettrustPermDelegation()
	 * @generated
	 */
	EAttribute gettrustPermDelegation_Trustread();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.trustPermDelegation#getTrustsend <em>Trustsend</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Trustsend</em>'.
	 * @see iqtool.trustPermDelegation#getTrustsend()
	 * @see #gettrustPermDelegation()
	 * @generated
	 */
	EAttribute gettrustPermDelegation_Trustsend();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.trustPermDelegation#getTrustmodify <em>Trustmodify</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Trustmodify</em>'.
	 * @see iqtool.trustPermDelegation#getTrustmodify()
	 * @see #gettrustPermDelegation()
	 * @generated
	 */
	EAttribute gettrustPermDelegation_Trustmodify();

	/**
	 * Returns the meta object for class '{@link iqtool.information <em>information</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>information</em>'.
	 * @see iqtool.information
	 * @generated
	 */
	EClass getinformation();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.information#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see iqtool.information#getName()
	 * @see #getinformation()
	 * @generated
	 */
	EAttribute getinformation_Name();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.information#getVolatility <em>Volatility</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Volatility</em>'.
	 * @see iqtool.information#getVolatility()
	 * @see #getinformation()
	 * @generated
	 */
	EAttribute getinformation_Volatility();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.information#getSubItem <em>Sub Item</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Sub Item</em>'.
	 * @see iqtool.information#getSubItem()
	 * @see #getinformation()
	 * @generated
	 */
	EReference getinformation_SubItem();

	/**
	 * Returns the meta object for class '{@link iqtool.scope <em>scope</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>scope</em>'.
	 * @see iqtool.scope
	 * @generated
	 */
	EClass getscope();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.scope#getContains <em>Contains</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Contains</em>'.
	 * @see iqtool.scope#getContains()
	 * @see #getscope()
	 * @generated
	 */
	EReference getscope_Contains();

	/**
	 * Returns the meta object for class '{@link iqtool.goal <em>goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>goal</em>'.
	 * @see iqtool.goal
	 * @generated
	 */
	EClass getgoal();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.goal#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see iqtool.goal#getName()
	 * @see #getgoal()
	 * @generated
	 */
	EAttribute getgoal_Name();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.goal#getOrdecomposition <em>Ordecomposition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Ordecomposition</em>'.
	 * @see iqtool.goal#getOrdecomposition()
	 * @see #getgoal()
	 * @generated
	 */
	EReference getgoal_Ordecomposition();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.goal#getAnddecomposition <em>Anddecomposition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Anddecomposition</em>'.
	 * @see iqtool.goal#getAnddecomposition()
	 * @see #getgoal()
	 * @generated
	 */
	EReference getgoal_Anddecomposition();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.goal#getModify <em>Modify</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Modify</em>'.
	 * @see iqtool.goal#getModify()
	 * @see #getgoal()
	 * @generated
	 */
	EReference getgoal_Modify();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.goal#getPosContributes <em>Pos Contributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Pos Contributes</em>'.
	 * @see iqtool.goal#getPosContributes()
	 * @see #getgoal()
	 * @generated
	 */
	EReference getgoal_PosContributes();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.goal#getNegContributes <em>Neg Contributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Neg Contributes</em>'.
	 * @see iqtool.goal#getNegContributes()
	 * @see #getgoal()
	 * @generated
	 */
	EReference getgoal_NegContributes();

	/**
	 * Returns the meta object for class '{@link iqtool.produce <em>produce</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>produce</em>'.
	 * @see iqtool.produce
	 * @generated
	 */
	EClass getproduce();

	/**
	 * Returns the meta object for the reference '{@link iqtool.produce#getProduceBy <em>Produce By</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Produce By</em>'.
	 * @see iqtool.produce#getProduceBy()
	 * @see #getproduce()
	 * @generated
	 */
	EReference getproduce_ProduceBy();

	/**
	 * Returns the meta object for the reference '{@link iqtool.produce#getProduceOf <em>Produce Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Produce Of</em>'.
	 * @see iqtool.produce#getProduceOf()
	 * @see #getproduce()
	 * @generated
	 */
	EReference getproduce_ProduceOf();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.produce#getPrd_blv_type <em>Prd blv type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Prd blv type</em>'.
	 * @see iqtool.produce#getPrd_blv_type()
	 * @see #getproduce()
	 * @generated
	 */
	EAttribute getproduce_Prd_blv_type();

	/**
	 * Returns the meta object for class '{@link iqtool.produceTrust <em>produce Trust</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>produce Trust</em>'.
	 * @see iqtool.produceTrust
	 * @generated
	 */
	EClass getproduceTrust();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.produceTrust#getTrustlevel <em>Trustlevel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Trustlevel</em>'.
	 * @see iqtool.produceTrust#getTrustlevel()
	 * @see #getproduceTrust()
	 * @generated
	 */
	EAttribute getproduceTrust_Trustlevel();

	/**
	 * Returns the meta object for the reference '{@link iqtool.produceTrust#getProduceTrustor <em>Produce Trustor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Produce Trustor</em>'.
	 * @see iqtool.produceTrust#getProduceTrustor()
	 * @see #getproduceTrust()
	 * @generated
	 */
	EReference getproduceTrust_ProduceTrustor();

	/**
	 * Returns the meta object for the reference '{@link iqtool.produceTrust#getProduceTrustee <em>Produce Trustee</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Produce Trustee</em>'.
	 * @see iqtool.produceTrust#getProduceTrustee()
	 * @see #getproduceTrust()
	 * @generated
	 */
	EReference getproduceTrust_ProduceTrustee();

	/**
	 * Returns the meta object for the reference '{@link iqtool.produceTrust#getProduceTrustOf <em>Produce Trust Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Produce Trust Of</em>'.
	 * @see iqtool.produceTrust#getProduceTrustOf()
	 * @see #getproduceTrust()
	 * @generated
	 */
	EReference getproduceTrust_ProduceTrustOf();

	/**
	 * Returns the meta object for class '{@link iqtool.instanceGoal <em>instance Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>instance Goal</em>'.
	 * @see iqtool.instanceGoal
	 * @generated
	 */
	EClass getinstanceGoal();

	/**
	 * Returns the meta object for the reference '{@link iqtool.instanceGoal#getInstance <em>Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Instance</em>'.
	 * @see iqtool.instanceGoal#getInstance()
	 * @see #getinstanceGoal()
	 * @generated
	 */
	EReference getinstanceGoal_Instance();

	/**
	 * Returns the meta object for class '{@link iqtool.generalGoal <em>general Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>general Goal</em>'.
	 * @see iqtool.generalGoal
	 * @generated
	 */
	EClass getgeneralGoal();

	/**
	 * Returns the meta object for class '{@link iqtool.instanceInformation <em>instance Information</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>instance Information</em>'.
	 * @see iqtool.instanceInformation
	 * @generated
	 */
	EClass getinstanceInformation();

	/**
	 * Returns the meta object for the reference '{@link iqtool.instanceInformation#getInstance <em>Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Instance</em>'.
	 * @see iqtool.instanceInformation#getInstance()
	 * @see #getinstanceInformation()
	 * @generated
	 */
	EReference getinstanceInformation_Instance();

	/**
	 * Returns the meta object for class '{@link iqtool.general_information <em>general information</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>general information</em>'.
	 * @see iqtool.general_information
	 * @generated
	 */
	EClass getgeneral_information();

	/**
	 * Returns the meta object for class '{@link iqtool.threat <em>threat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>threat</em>'.
	 * @see iqtool.threat
	 * @generated
	 */
	EClass getthreat();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.threat#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see iqtool.threat#getName()
	 * @see #getthreat()
	 * @generated
	 */
	EAttribute getthreat_Name();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.threat#getPosContribute <em>Pos Contribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Pos Contribute</em>'.
	 * @see iqtool.threat#getPosContribute()
	 * @see #getthreat()
	 * @generated
	 */
	EReference getthreat_PosContribute();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.threat#getNegContribute <em>Neg Contribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Neg Contribute</em>'.
	 * @see iqtool.threat#getNegContribute()
	 * @see #getthreat()
	 * @generated
	 */
	EReference getthreat_NegContribute();

	/**
	 * Returns the meta object for class '{@link iqtool.informationThreat <em>information Threat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>information Threat</em>'.
	 * @see iqtool.informationThreat
	 * @generated
	 */
	EClass getinformationThreat();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.informationThreat#getThreatInformation <em>Threat Information</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Threat Information</em>'.
	 * @see iqtool.informationThreat#getThreatInformation()
	 * @see #getinformationThreat()
	 * @generated
	 */
	EReference getinformationThreat_ThreatInformation();

	/**
	 * Returns the meta object for class '{@link iqtool.goalThreat <em>goal Threat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>goal Threat</em>'.
	 * @see iqtool.goalThreat
	 * @generated
	 */
	EClass getgoalThreat();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.goalThreat#getGoalThreat <em>Goal Threat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Goal Threat</em>'.
	 * @see iqtool.goalThreat#getGoalThreat()
	 * @see #getgoalThreat()
	 * @generated
	 */
	EReference getgoalThreat_GoalThreat();

	/**
	 * Returns the meta object for class '{@link iqtool.monitoring <em>monitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>monitoring</em>'.
	 * @see iqtool.monitoring
	 * @generated
	 */
	EClass getmonitoring();

	/**
	 * Returns the meta object for the reference '{@link iqtool.monitoring#getMonitor <em>Monitor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Monitor</em>'.
	 * @see iqtool.monitoring#getMonitor()
	 * @see #getmonitoring()
	 * @generated
	 */
	EReference getmonitoring_Monitor();

	/**
	 * Returns the meta object for the reference '{@link iqtool.monitoring#getMonitored <em>Monitored</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Monitored</em>'.
	 * @see iqtool.monitoring#getMonitored()
	 * @see #getmonitoring()
	 * @generated
	 */
	EReference getmonitoring_Monitored();

	/**
	 * Returns the meta object for class '{@link iqtool.goalMonitoring <em>goal Monitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>goal Monitoring</em>'.
	 * @see iqtool.goalMonitoring
	 * @generated
	 */
	EClass getgoalMonitoring();

	/**
	 * Returns the meta object for the reference '{@link iqtool.goalMonitoring#getMonitoringOfGoal <em>Monitoring Of Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Monitoring Of Goal</em>'.
	 * @see iqtool.goalMonitoring#getMonitoringOfGoal()
	 * @see #getgoalMonitoring()
	 * @generated
	 */
	EReference getgoalMonitoring_MonitoringOfGoal();

	/**
	 * Returns the meta object for class '{@link iqtool.permMonitoring <em>perm Monitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>perm Monitoring</em>'.
	 * @see iqtool.permMonitoring
	 * @generated
	 */
	EClass getpermMonitoring();

	/**
	 * Returns the meta object for the reference '{@link iqtool.permMonitoring#getMonitorOf <em>Monitor Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Monitor Of</em>'.
	 * @see iqtool.permMonitoring#getMonitorOf()
	 * @see #getpermMonitoring()
	 * @generated
	 */
	EReference getpermMonitoring_MonitorOf();

	/**
	 * Returns the meta object for class '{@link iqtool.infoMonitoring <em>info Monitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>info Monitoring</em>'.
	 * @see iqtool.infoMonitoring
	 * @generated
	 */
	EClass getinfoMonitoring();

	/**
	 * Returns the meta object for the reference '{@link iqtool.infoMonitoring#getMonitoringOfInfo <em>Monitoring Of Info</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Monitoring Of Info</em>'.
	 * @see iqtool.infoMonitoring#getMonitoringOfInfo()
	 * @see #getinfoMonitoring()
	 * @generated
	 */
	EReference getinfoMonitoring_MonitoringOfInfo();

	/**
	 * Returns the meta object for class '{@link iqtool.permMonitor <em>perm Monitor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>perm Monitor</em>'.
	 * @see iqtool.permMonitor
	 * @generated
	 */
	EClass getpermMonitor();

	/**
	 * Returns the meta object for the reference '{@link iqtool.permMonitor#getOver <em>Over</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Over</em>'.
	 * @see iqtool.permMonitor#getOver()
	 * @see #getpermMonitor()
	 * @generated
	 */
	EReference getpermMonitor_Over();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.permMonitor#getR <em>R</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>R</em>'.
	 * @see iqtool.permMonitor#getR()
	 * @see #getpermMonitor()
	 * @generated
	 */
	EAttribute getpermMonitor_R();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.permMonitor#getP <em>P</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>P</em>'.
	 * @see iqtool.permMonitor#getP()
	 * @see #getpermMonitor()
	 * @generated
	 */
	EAttribute getpermMonitor_P();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.permMonitor#getS <em>S</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>S</em>'.
	 * @see iqtool.permMonitor#getS()
	 * @see #getpermMonitor()
	 * @generated
	 */
	EAttribute getpermMonitor_S();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.permMonitor#getM <em>M</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>M</em>'.
	 * @see iqtool.permMonitor#getM()
	 * @see #getpermMonitor()
	 * @generated
	 */
	EAttribute getpermMonitor_M();

	/**
	 * Returns the meta object for the reference '{@link iqtool.permMonitor#getMonitored <em>Monitored</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Monitored</em>'.
	 * @see iqtool.permMonitor#getMonitored()
	 * @see #getpermMonitor()
	 * @generated
	 */
	EReference getpermMonitor_Monitored();

	/**
	 * Returns the meta object for the reference '{@link iqtool.permMonitor#getMonitor <em>Monitor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Monitor</em>'.
	 * @see iqtool.permMonitor#getMonitor()
	 * @see #getpermMonitor()
	 * @generated
	 */
	EReference getpermMonitor_Monitor();

	/**
	 * Returns the meta object for enum '{@link iqtool.purposeOfUseTypes <em>purpose Of Use Types</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>purpose Of Use Types</em>'.
	 * @see iqtool.purposeOfUseTypes
	 * @generated
	 */
	EEnum getpurposeOfUseTypes();

	/**
	 * Returns the meta object for enum '{@link iqtool.sendPermType <em>send Perm Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>send Perm Type</em>'.
	 * @see iqtool.sendPermType
	 * @generated
	 */
	EEnum getsendPermType();

	/**
	 * Returns the meta object for enum '{@link iqtool.modifyPermType <em>modify Perm Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>modify Perm Type</em>'.
	 * @see iqtool.modifyPermType
	 * @generated
	 */
	EEnum getmodifyPermType();

	/**
	 * Returns the meta object for enum '{@link iqtool.trustLevel <em>trust Level</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>trust Level</em>'.
	 * @see iqtool.trustLevel
	 * @generated
	 */
	EEnum gettrustLevel();

	/**
	 * Returns the meta object for enum '{@link iqtool.producePermType <em>produce Perm Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>produce Perm Type</em>'.
	 * @see iqtool.producePermType
	 * @generated
	 */
	EEnum getproducePermType();

	/**
	 * Returns the meta object for enum '{@link iqtool.provisionType <em>provision Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>provision Type</em>'.
	 * @see iqtool.provisionType
	 * @generated
	 */
	EEnum getprovisionType();

	/**
	 * Returns the meta object for enum '{@link iqtool.readPermType <em>read Perm Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>read Perm Type</em>'.
	 * @see iqtool.readPermType
	 * @generated
	 */
	EEnum getreadPermType();

	/**
	 * Returns the meta object for enum '{@link iqtool.blv_type <em>blv type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>blv type</em>'.
	 * @see iqtool.blv_type
	 * @generated
	 */
	EEnum getblv_type();

	/**
	 * Returns the meta object for enum '{@link iqtool.rtype <em>rtype</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>rtype</em>'.
	 * @see iqtool.rtype
	 * @generated
	 */
	EEnum getrtype();

	/**
	 * Returns the meta object for enum '{@link iqtool.permMonitorType <em>perm Monitor Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>perm Monitor Type</em>'.
	 * @see iqtool.permMonitorType
	 * @generated
	 */
	EEnum getpermMonitorType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	IqtoolFactory getIqtoolFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link iqtool.impl.actorImpl <em>actor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.actorImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getactor()
		 * @generated
		 */
		EClass ACTOR = eINSTANCE.getactor();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTOR__NAME = eINSTANCE.getactor_Name();

		/**
		 * The meta object literal for the '<em><b>Aims</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTOR__AIMS = eINSTANCE.getactor_Aims();

		/**
		 * The meta object literal for the '<em><b>Own</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTOR__OWN = eINSTANCE.getactor_Own();

		/**
		 * The meta object literal for the '<em><b>Capable Of Threat</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTOR__CAPABLE_OF_THREAT = eINSTANCE.getactor_CapableOfThreat();

		/**
		 * The meta object literal for the '<em><b>Incapable Of Threat</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTOR__INCAPABLE_OF_THREAT = eINSTANCE.getactor_IncapableOfThreat();

		/**
		 * The meta object literal for the '{@link iqtool.impl.diagramImpl <em>diagram</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.diagramImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getdiagram()
		 * @generated
		 */
		EClass DIAGRAM = eINSTANCE.getdiagram();

		/**
		 * The meta object literal for the '<em><b>Scope Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__SCOPE_ELEMENT = eINSTANCE.getdiagram_ScopeElement();

		/**
		 * The meta object literal for the '<em><b>Delegation Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__DELEGATION_ELEMENT = eINSTANCE.getdiagram_DelegationElement();

		/**
		 * The meta object literal for the '<em><b>Provision Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__PROVISION_ELEMENT = eINSTANCE.getdiagram_ProvisionElement();

		/**
		 * The meta object literal for the '<em><b>Delegation Trust Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__DELEGATION_TRUST_ELEMENT = eINSTANCE.getdiagram_DelegationTrustElement();

		/**
		 * The meta object literal for the '<em><b>Agent Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__AGENT_ELEMENT = eINSTANCE.getdiagram_AgentElement();

		/**
		 * The meta object literal for the '<em><b>Role Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__ROLE_ELEMENT = eINSTANCE.getdiagram_RoleElement();

		/**
		 * The meta object literal for the '<em><b>Perm Dele Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__PERM_DELE_ELEMENT = eINSTANCE.getdiagram_PermDeleElement();

		/**
		 * The meta object literal for the '<em><b>Trust Perm Dele Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__TRUST_PERM_DELE_ELEMENT = eINSTANCE.getdiagram_TrustPermDeleElement();

		/**
		 * The meta object literal for the '<em><b>Read Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__READ_ELEMENT = eINSTANCE.getdiagram_ReadElement();

		/**
		 * The meta object literal for the '<em><b>Send Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__SEND_ELEMENT = eINSTANCE.getdiagram_SendElement();

		/**
		 * The meta object literal for the '<em><b>Produce Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__PRODUCE_ELEMENT = eINSTANCE.getdiagram_ProduceElement();

		/**
		 * The meta object literal for the '<em><b>Produce Trust Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__PRODUCE_TRUST_ELEMENT = eINSTANCE.getdiagram_ProduceTrustElement();

		/**
		 * The meta object literal for the '<em><b>Instance Goal Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__INSTANCE_GOAL_ELEMENT = eINSTANCE.getdiagram_InstanceGoalElement();

		/**
		 * The meta object literal for the '<em><b>General Goal Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__GENERAL_GOAL_ELEMENT = eINSTANCE.getdiagram_GeneralGoalElement();

		/**
		 * The meta object literal for the '<em><b>Instance Information Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__INSTANCE_INFORMATION_ELEMENT = eINSTANCE.getdiagram_InstanceInformationElement();

		/**
		 * The meta object literal for the '<em><b>General Information Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__GENERAL_INFORMATION_ELEMENT = eINSTANCE.getdiagram_GeneralInformationElement();

		/**
		 * The meta object literal for the '<em><b>Goal Threat Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__GOAL_THREAT_ELEMENT = eINSTANCE.getdiagram_GoalThreatElement();

		/**
		 * The meta object literal for the '<em><b>Information Threat Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__INFORMATION_THREAT_ELEMENT = eINSTANCE.getdiagram_InformationThreatElement();

		/**
		 * The meta object literal for the '<em><b>Goal Monitoring Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__GOAL_MONITORING_ELEMENT = eINSTANCE.getdiagram_GoalMonitoringElement();

		/**
		 * The meta object literal for the '<em><b>Info Monitoring Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__INFO_MONITORING_ELEMENT = eINSTANCE.getdiagram_InfoMonitoringElement();

		/**
		 * The meta object literal for the '<em><b>Perm Monitor Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__PERM_MONITOR_ELEMENT = eINSTANCE.getdiagram_PermMonitorElement();

		/**
		 * The meta object literal for the '{@link iqtool.impl.roleImpl <em>role</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.roleImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getrole()
		 * @generated
		 */
		EClass ROLE = eINSTANCE.getrole();

		/**
		 * The meta object literal for the '<em><b>Isa</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__ISA = eINSTANCE.getrole_Isa();

		/**
		 * The meta object literal for the '<em><b>Is capable</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__IS_CAPABLE = eINSTANCE.getrole_Is_capable();

		/**
		 * The meta object literal for the '{@link iqtool.impl.agentImpl <em>agent</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.agentImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getagent()
		 * @generated
		 */
		EClass AGENT = eINSTANCE.getagent();

		/**
		 * The meta object literal for the '<em><b>Play</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AGENT__PLAY = eINSTANCE.getagent_Play();

		/**
		 * The meta object literal for the '{@link iqtool.impl.permDelegationImpl <em>perm Delegation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.permDelegationImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getpermDelegation()
		 * @generated
		 */
		EClass PERM_DELEGATION = eINSTANCE.getpermDelegation();

		/**
		 * The meta object literal for the '<em><b>Perm Over</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PERM_DELEGATION__PERM_OVER = eINSTANCE.getpermDelegation_PermOver();

		/**
		 * The meta object literal for the '<em><b>Perm Dele From</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PERM_DELEGATION__PERM_DELE_FROM = eINSTANCE.getpermDelegation_PermDeleFrom();

		/**
		 * The meta object literal for the '<em><b>Perm Dele To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PERM_DELEGATION__PERM_DELE_TO = eINSTANCE.getpermDelegation_PermDeleTo();

		/**
		 * The meta object literal for the '<em><b>Read Perm</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERM_DELEGATION__READ_PERM = eINSTANCE.getpermDelegation_ReadPerm();

		/**
		 * The meta object literal for the '<em><b>Produce Perm</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERM_DELEGATION__PRODUCE_PERM = eINSTANCE.getpermDelegation_ProducePerm();

		/**
		 * The meta object literal for the '<em><b>Modify Perm</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERM_DELEGATION__MODIFY_PERM = eINSTANCE.getpermDelegation_ModifyPerm();

		/**
		 * The meta object literal for the '<em><b>Send Perm</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERM_DELEGATION__SEND_PERM = eINSTANCE.getpermDelegation_SendPerm();

		/**
		 * The meta object literal for the '{@link iqtool.impl.readImpl <em>read</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.readImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getread()
		 * @generated
		 */
		EClass READ = eINSTANCE.getread();

		/**
		 * The meta object literal for the '<em><b>Pou</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute READ__POU = eINSTANCE.getread_Pou();

		/**
		 * The meta object literal for the '<em><b>Read Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference READ__READ_OF = eINSTANCE.getread_ReadOf();

		/**
		 * The meta object literal for the '<em><b>Read By</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference READ__READ_BY = eINSTANCE.getread_ReadBy();

		/**
		 * The meta object literal for the '<em><b>Read Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute READ__READ_TYPE = eINSTANCE.getread_ReadType();

		/**
		 * The meta object literal for the '<em><b>Prd blv type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute READ__PRD_BLV_TYPE = eINSTANCE.getread_Prd_blv_type();

		/**
		 * The meta object literal for the '{@link iqtool.impl.sendImpl <em>send</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.sendImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getsend()
		 * @generated
		 */
		EClass SEND = eINSTANCE.getsend();

		/**
		 * The meta object literal for the '<em><b>Time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEND__TIME = eINSTANCE.getsend_Time();

		/**
		 * The meta object literal for the '<em><b>Send Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEND__SEND_OF = eINSTANCE.getsend_SendOf();

		/**
		 * The meta object literal for the '<em><b>Send By</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEND__SEND_BY = eINSTANCE.getsend_SendBy();

		/**
		 * The meta object literal for the '<em><b>Send To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEND__SEND_TO = eINSTANCE.getsend_SendTo();

		/**
		 * The meta object literal for the '{@link iqtool.impl.goalDelegationImpl <em>goal Delegation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.goalDelegationImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getgoalDelegation()
		 * @generated
		 */
		EClass GOAL_DELEGATION = eINSTANCE.getgoalDelegation();

		/**
		 * The meta object literal for the '<em><b>Delegation Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL_DELEGATION__DELEGATION_OF = eINSTANCE.getgoalDelegation_DelegationOf();

		/**
		 * The meta object literal for the '<em><b>Delegation From</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL_DELEGATION__DELEGATION_FROM = eINSTANCE.getgoalDelegation_DelegationFrom();

		/**
		 * The meta object literal for the '<em><b>Delegation To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL_DELEGATION__DELEGATION_TO = eINSTANCE.getgoalDelegation_DelegationTo();

		/**
		 * The meta object literal for the '{@link iqtool.impl.delegationTrustImpl <em>delegation Trust</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.delegationTrustImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getdelegationTrust()
		 * @generated
		 */
		EClass DELEGATION_TRUST = eINSTANCE.getdelegationTrust();

		/**
		 * The meta object literal for the '<em><b>Trustlevel</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DELEGATION_TRUST__TRUSTLEVEL = eINSTANCE.getdelegationTrust_Trustlevel();

		/**
		 * The meta object literal for the '<em><b>Trustum Goal</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DELEGATION_TRUST__TRUSTUM_GOAL = eINSTANCE.getdelegationTrust_TrustumGoal();

		/**
		 * The meta object literal for the '<em><b>Trustor Goal</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DELEGATION_TRUST__TRUSTOR_GOAL = eINSTANCE.getdelegationTrust_TrustorGoal();

		/**
		 * The meta object literal for the '<em><b>Trustee Goal</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DELEGATION_TRUST__TRUSTEE_GOAL = eINSTANCE.getdelegationTrust_TrusteeGoal();

		/**
		 * The meta object literal for the '{@link iqtool.impl.infoProvisionImpl <em>info Provision</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.infoProvisionImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getinfoProvision()
		 * @generated
		 */
		EClass INFO_PROVISION = eINSTANCE.getinfoProvision();

		/**
		 * The meta object literal for the '<em><b>Provision Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INFO_PROVISION__PROVISION_OF = eINSTANCE.getinfoProvision_ProvisionOf();

		/**
		 * The meta object literal for the '<em><b>Provision From</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INFO_PROVISION__PROVISION_FROM = eINSTANCE.getinfoProvision_ProvisionFrom();

		/**
		 * The meta object literal for the '<em><b>Provision To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INFO_PROVISION__PROVISION_TO = eINSTANCE.getinfoProvision_ProvisionTo();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INFO_PROVISION__TYPE = eINSTANCE.getinfoProvision_Type();

		/**
		 * The meta object literal for the '<em><b>Time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INFO_PROVISION__TIME = eINSTANCE.getinfoProvision_Time();

		/**
		 * The meta object literal for the '{@link iqtool.impl.trustPermDelegationImpl <em>trust Perm Delegation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.trustPermDelegationImpl
		 * @see iqtool.impl.IqtoolPackageImpl#gettrustPermDelegation()
		 * @generated
		 */
		EClass TRUST_PERM_DELEGATION = eINSTANCE.gettrustPermDelegation();

		/**
		 * The meta object literal for the '<em><b>Trust Perm Dele To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRUST_PERM_DELEGATION__TRUST_PERM_DELE_TO = eINSTANCE.gettrustPermDelegation_TrustPermDeleTo();

		/**
		 * The meta object literal for the '<em><b>Trust Perm Dele From</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRUST_PERM_DELEGATION__TRUST_PERM_DELE_FROM = eINSTANCE.gettrustPermDelegation_TrustPermDeleFrom();

		/**
		 * The meta object literal for the '<em><b>Trust Perm Dele Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRUST_PERM_DELEGATION__TRUST_PERM_DELE_OF = eINSTANCE.gettrustPermDelegation_TrustPermDeleOf();

		/**
		 * The meta object literal for the '<em><b>Trustprodue</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRUST_PERM_DELEGATION__TRUSTPRODUE = eINSTANCE.gettrustPermDelegation_Trustprodue();

		/**
		 * The meta object literal for the '<em><b>Trustread</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRUST_PERM_DELEGATION__TRUSTREAD = eINSTANCE.gettrustPermDelegation_Trustread();

		/**
		 * The meta object literal for the '<em><b>Trustsend</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRUST_PERM_DELEGATION__TRUSTSEND = eINSTANCE.gettrustPermDelegation_Trustsend();

		/**
		 * The meta object literal for the '<em><b>Trustmodify</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRUST_PERM_DELEGATION__TRUSTMODIFY = eINSTANCE.gettrustPermDelegation_Trustmodify();

		/**
		 * The meta object literal for the '{@link iqtool.impl.informationImpl <em>information</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.informationImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getinformation()
		 * @generated
		 */
		EClass INFORMATION = eINSTANCE.getinformation();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INFORMATION__NAME = eINSTANCE.getinformation_Name();

		/**
		 * The meta object literal for the '<em><b>Volatility</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INFORMATION__VOLATILITY = eINSTANCE.getinformation_Volatility();

		/**
		 * The meta object literal for the '<em><b>Sub Item</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INFORMATION__SUB_ITEM = eINSTANCE.getinformation_SubItem();

		/**
		 * The meta object literal for the '{@link iqtool.impl.scopeImpl <em>scope</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.scopeImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getscope()
		 * @generated
		 */
		EClass SCOPE = eINSTANCE.getscope();

		/**
		 * The meta object literal for the '<em><b>Contains</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCOPE__CONTAINS = eINSTANCE.getscope_Contains();

		/**
		 * The meta object literal for the '{@link iqtool.impl.goalImpl <em>goal</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.goalImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getgoal()
		 * @generated
		 */
		EClass GOAL = eINSTANCE.getgoal();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GOAL__NAME = eINSTANCE.getgoal_Name();

		/**
		 * The meta object literal for the '<em><b>Ordecomposition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL__ORDECOMPOSITION = eINSTANCE.getgoal_Ordecomposition();

		/**
		 * The meta object literal for the '<em><b>Anddecomposition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL__ANDDECOMPOSITION = eINSTANCE.getgoal_Anddecomposition();

		/**
		 * The meta object literal for the '<em><b>Modify</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL__MODIFY = eINSTANCE.getgoal_Modify();

		/**
		 * The meta object literal for the '<em><b>Pos Contributes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL__POS_CONTRIBUTES = eINSTANCE.getgoal_PosContributes();

		/**
		 * The meta object literal for the '<em><b>Neg Contributes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL__NEG_CONTRIBUTES = eINSTANCE.getgoal_NegContributes();

		/**
		 * The meta object literal for the '{@link iqtool.impl.produceImpl <em>produce</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.produceImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getproduce()
		 * @generated
		 */
		EClass PRODUCE = eINSTANCE.getproduce();

		/**
		 * The meta object literal for the '<em><b>Produce By</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCE__PRODUCE_BY = eINSTANCE.getproduce_ProduceBy();

		/**
		 * The meta object literal for the '<em><b>Produce Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCE__PRODUCE_OF = eINSTANCE.getproduce_ProduceOf();

		/**
		 * The meta object literal for the '<em><b>Prd blv type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRODUCE__PRD_BLV_TYPE = eINSTANCE.getproduce_Prd_blv_type();

		/**
		 * The meta object literal for the '{@link iqtool.impl.produceTrustImpl <em>produce Trust</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.produceTrustImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getproduceTrust()
		 * @generated
		 */
		EClass PRODUCE_TRUST = eINSTANCE.getproduceTrust();

		/**
		 * The meta object literal for the '<em><b>Trustlevel</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRODUCE_TRUST__TRUSTLEVEL = eINSTANCE.getproduceTrust_Trustlevel();

		/**
		 * The meta object literal for the '<em><b>Produce Trustor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCE_TRUST__PRODUCE_TRUSTOR = eINSTANCE.getproduceTrust_ProduceTrustor();

		/**
		 * The meta object literal for the '<em><b>Produce Trustee</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCE_TRUST__PRODUCE_TRUSTEE = eINSTANCE.getproduceTrust_ProduceTrustee();

		/**
		 * The meta object literal for the '<em><b>Produce Trust Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCE_TRUST__PRODUCE_TRUST_OF = eINSTANCE.getproduceTrust_ProduceTrustOf();

		/**
		 * The meta object literal for the '{@link iqtool.impl.instanceGoalImpl <em>instance Goal</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.instanceGoalImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getinstanceGoal()
		 * @generated
		 */
		EClass INSTANCE_GOAL = eINSTANCE.getinstanceGoal();

		/**
		 * The meta object literal for the '<em><b>Instance</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INSTANCE_GOAL__INSTANCE = eINSTANCE.getinstanceGoal_Instance();

		/**
		 * The meta object literal for the '{@link iqtool.impl.generalGoalImpl <em>general Goal</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.generalGoalImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getgeneralGoal()
		 * @generated
		 */
		EClass GENERAL_GOAL = eINSTANCE.getgeneralGoal();

		/**
		 * The meta object literal for the '{@link iqtool.impl.instanceInformationImpl <em>instance Information</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.instanceInformationImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getinstanceInformation()
		 * @generated
		 */
		EClass INSTANCE_INFORMATION = eINSTANCE.getinstanceInformation();

		/**
		 * The meta object literal for the '<em><b>Instance</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INSTANCE_INFORMATION__INSTANCE = eINSTANCE.getinstanceInformation_Instance();

		/**
		 * The meta object literal for the '{@link iqtool.impl.general_informationImpl <em>general information</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.general_informationImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getgeneral_information()
		 * @generated
		 */
		EClass GENERAL_INFORMATION = eINSTANCE.getgeneral_information();

		/**
		 * The meta object literal for the '{@link iqtool.impl.threatImpl <em>threat</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.threatImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getthreat()
		 * @generated
		 */
		EClass THREAT = eINSTANCE.getthreat();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute THREAT__NAME = eINSTANCE.getthreat_Name();

		/**
		 * The meta object literal for the '<em><b>Pos Contribute</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THREAT__POS_CONTRIBUTE = eINSTANCE.getthreat_PosContribute();

		/**
		 * The meta object literal for the '<em><b>Neg Contribute</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THREAT__NEG_CONTRIBUTE = eINSTANCE.getthreat_NegContribute();

		/**
		 * The meta object literal for the '{@link iqtool.impl.informationThreatImpl <em>information Threat</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.informationThreatImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getinformationThreat()
		 * @generated
		 */
		EClass INFORMATION_THREAT = eINSTANCE.getinformationThreat();

		/**
		 * The meta object literal for the '<em><b>Threat Information</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INFORMATION_THREAT__THREAT_INFORMATION = eINSTANCE.getinformationThreat_ThreatInformation();

		/**
		 * The meta object literal for the '{@link iqtool.impl.goalThreatImpl <em>goal Threat</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.goalThreatImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getgoalThreat()
		 * @generated
		 */
		EClass GOAL_THREAT = eINSTANCE.getgoalThreat();

		/**
		 * The meta object literal for the '<em><b>Goal Threat</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL_THREAT__GOAL_THREAT = eINSTANCE.getgoalThreat_GoalThreat();

		/**
		 * The meta object literal for the '{@link iqtool.impl.monitoringImpl <em>monitoring</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.monitoringImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getmonitoring()
		 * @generated
		 */
		EClass MONITORING = eINSTANCE.getmonitoring();

		/**
		 * The meta object literal for the '<em><b>Monitor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MONITORING__MONITOR = eINSTANCE.getmonitoring_Monitor();

		/**
		 * The meta object literal for the '<em><b>Monitored</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MONITORING__MONITORED = eINSTANCE.getmonitoring_Monitored();

		/**
		 * The meta object literal for the '{@link iqtool.impl.goalMonitoringImpl <em>goal Monitoring</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.goalMonitoringImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getgoalMonitoring()
		 * @generated
		 */
		EClass GOAL_MONITORING = eINSTANCE.getgoalMonitoring();

		/**
		 * The meta object literal for the '<em><b>Monitoring Of Goal</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL_MONITORING__MONITORING_OF_GOAL = eINSTANCE.getgoalMonitoring_MonitoringOfGoal();

		/**
		 * The meta object literal for the '{@link iqtool.impl.permMonitoringImpl <em>perm Monitoring</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.permMonitoringImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getpermMonitoring()
		 * @generated
		 */
		EClass PERM_MONITORING = eINSTANCE.getpermMonitoring();

		/**
		 * The meta object literal for the '<em><b>Monitor Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PERM_MONITORING__MONITOR_OF = eINSTANCE.getpermMonitoring_MonitorOf();

		/**
		 * The meta object literal for the '{@link iqtool.impl.infoMonitoringImpl <em>info Monitoring</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.infoMonitoringImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getinfoMonitoring()
		 * @generated
		 */
		EClass INFO_MONITORING = eINSTANCE.getinfoMonitoring();

		/**
		 * The meta object literal for the '<em><b>Monitoring Of Info</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INFO_MONITORING__MONITORING_OF_INFO = eINSTANCE.getinfoMonitoring_MonitoringOfInfo();

		/**
		 * The meta object literal for the '{@link iqtool.impl.permMonitorImpl <em>perm Monitor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.permMonitorImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getpermMonitor()
		 * @generated
		 */
		EClass PERM_MONITOR = eINSTANCE.getpermMonitor();

		/**
		 * The meta object literal for the '<em><b>Over</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PERM_MONITOR__OVER = eINSTANCE.getpermMonitor_Over();

		/**
		 * The meta object literal for the '<em><b>R</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERM_MONITOR__R = eINSTANCE.getpermMonitor_R();

		/**
		 * The meta object literal for the '<em><b>P</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERM_MONITOR__P = eINSTANCE.getpermMonitor_P();

		/**
		 * The meta object literal for the '<em><b>S</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERM_MONITOR__S = eINSTANCE.getpermMonitor_S();

		/**
		 * The meta object literal for the '<em><b>M</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERM_MONITOR__M = eINSTANCE.getpermMonitor_M();

		/**
		 * The meta object literal for the '<em><b>Monitored</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PERM_MONITOR__MONITORED = eINSTANCE.getpermMonitor_Monitored();

		/**
		 * The meta object literal for the '<em><b>Monitor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PERM_MONITOR__MONITOR = eINSTANCE.getpermMonitor_Monitor();

		/**
		 * The meta object literal for the '{@link iqtool.purposeOfUseTypes <em>purpose Of Use Types</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.purposeOfUseTypes
		 * @see iqtool.impl.IqtoolPackageImpl#getpurposeOfUseTypes()
		 * @generated
		 */
		EEnum PURPOSE_OF_USE_TYPES = eINSTANCE.getpurposeOfUseTypes();

		/**
		 * The meta object literal for the '{@link iqtool.sendPermType <em>send Perm Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.sendPermType
		 * @see iqtool.impl.IqtoolPackageImpl#getsendPermType()
		 * @generated
		 */
		EEnum SEND_PERM_TYPE = eINSTANCE.getsendPermType();

		/**
		 * The meta object literal for the '{@link iqtool.modifyPermType <em>modify Perm Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.modifyPermType
		 * @see iqtool.impl.IqtoolPackageImpl#getmodifyPermType()
		 * @generated
		 */
		EEnum MODIFY_PERM_TYPE = eINSTANCE.getmodifyPermType();

		/**
		 * The meta object literal for the '{@link iqtool.trustLevel <em>trust Level</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.trustLevel
		 * @see iqtool.impl.IqtoolPackageImpl#gettrustLevel()
		 * @generated
		 */
		EEnum TRUST_LEVEL = eINSTANCE.gettrustLevel();

		/**
		 * The meta object literal for the '{@link iqtool.producePermType <em>produce Perm Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.producePermType
		 * @see iqtool.impl.IqtoolPackageImpl#getproducePermType()
		 * @generated
		 */
		EEnum PRODUCE_PERM_TYPE = eINSTANCE.getproducePermType();

		/**
		 * The meta object literal for the '{@link iqtool.provisionType <em>provision Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.provisionType
		 * @see iqtool.impl.IqtoolPackageImpl#getprovisionType()
		 * @generated
		 */
		EEnum PROVISION_TYPE = eINSTANCE.getprovisionType();

		/**
		 * The meta object literal for the '{@link iqtool.readPermType <em>read Perm Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.readPermType
		 * @see iqtool.impl.IqtoolPackageImpl#getreadPermType()
		 * @generated
		 */
		EEnum READ_PERM_TYPE = eINSTANCE.getreadPermType();

		/**
		 * The meta object literal for the '{@link iqtool.blv_type <em>blv type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.blv_type
		 * @see iqtool.impl.IqtoolPackageImpl#getblv_type()
		 * @generated
		 */
		EEnum BLV_TYPE = eINSTANCE.getblv_type();

		/**
		 * The meta object literal for the '{@link iqtool.rtype <em>rtype</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.rtype
		 * @see iqtool.impl.IqtoolPackageImpl#getrtype()
		 * @generated
		 */
		EEnum RTYPE = eINSTANCE.getrtype();

		/**
		 * The meta object literal for the '{@link iqtool.permMonitorType <em>perm Monitor Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.permMonitorType
		 * @see iqtool.impl.IqtoolPackageImpl#getpermMonitorType()
		 * @generated
		 */
		EEnum PERM_MONITOR_TYPE = eINSTANCE.getpermMonitorType();

	}

} //IqtoolPackage
