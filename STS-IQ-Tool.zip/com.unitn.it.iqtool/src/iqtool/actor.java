/**
 */
package iqtool;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>actor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.actor#getName <em>Name</em>}</li>
 *   <li>{@link iqtool.actor#getAims <em>Aims</em>}</li>
 *   <li>{@link iqtool.actor#getOwn <em>Own</em>}</li>
 *   <li>{@link iqtool.actor#getCapableOfThreat <em>Capable Of Threat</em>}</li>
 *   <li>{@link iqtool.actor#getIncapableOfThreat <em>Incapable Of Threat</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getactor()
 * @model abstract="true"
 * @generated
 */
public interface actor extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see iqtool.IqtoolPackage#getactor_Name()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link iqtool.actor#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Aims</b></em>' reference list.
	 * The list contents are of type {@link iqtool.goal}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Aims</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Aims</em>' reference list.
	 * @see iqtool.IqtoolPackage#getactor_Aims()
	 * @model type="iqtool.goal"
	 * @generated
	 */
	EList getAims();

	/**
	 * Returns the value of the '<em><b>Own</b></em>' reference list.
	 * The list contents are of type {@link iqtool.information}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Own</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Own</em>' reference list.
	 * @see iqtool.IqtoolPackage#getactor_Own()
	 * @model type="iqtool.information"
	 * @generated
	 */
	EList getOwn();

	/**
	 * Returns the value of the '<em><b>Capable Of Threat</b></em>' reference list.
	 * The list contents are of type {@link iqtool.threat}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Capable Of Threat</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Capable Of Threat</em>' reference list.
	 * @see iqtool.IqtoolPackage#getactor_CapableOfThreat()
	 * @model type="iqtool.threat"
	 * @generated
	 */
	EList getCapableOfThreat();

	/**
	 * Returns the value of the '<em><b>Incapable Of Threat</b></em>' reference list.
	 * The list contents are of type {@link iqtool.threat}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Incapable Of Threat</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Incapable Of Threat</em>' reference list.
	 * @see iqtool.IqtoolPackage#getactor_IncapableOfThreat()
	 * @model type="iqtool.threat"
	 * @generated
	 */
	EList getIncapableOfThreat();

} // actor
