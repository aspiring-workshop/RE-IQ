/**
 */
package iqtool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>adoption</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.adoption#getAdoptionTo <em>Adoption To</em>}</li>
 *   <li>{@link iqtool.adoption#getAdoptionFrom <em>Adoption From</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getadoption()
 * @model
 * @generated
 */
public interface adoption extends EObject {
	/**
	 * Returns the value of the '<em><b>Adoption To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Adoption To</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Adoption To</em>' reference.
	 * @see #setAdoptionTo(actor)
	 * @see iqtool.IqtoolPackage#getadoption_AdoptionTo()
	 * @model
	 * @generated
	 */
	actor getAdoptionTo();

	/**
	 * Sets the value of the '{@link iqtool.adoption#getAdoptionTo <em>Adoption To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Adoption To</em>' reference.
	 * @see #getAdoptionTo()
	 * @generated
	 */
	void setAdoptionTo(actor value);

	/**
	 * Returns the value of the '<em><b>Adoption From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Adoption From</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Adoption From</em>' reference.
	 * @see #setAdoptionFrom(actor)
	 * @see iqtool.IqtoolPackage#getadoption_AdoptionFrom()
	 * @model
	 * @generated
	 */
	actor getAdoptionFrom();

	/**
	 * Sets the value of the '{@link iqtool.adoption#getAdoptionFrom <em>Adoption From</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Adoption From</em>' reference.
	 * @see #getAdoptionFrom()
	 * @generated
	 */
	void setAdoptionFrom(actor value);

} // adoption
