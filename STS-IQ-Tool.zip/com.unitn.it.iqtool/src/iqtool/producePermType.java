/**
 */
package iqtool;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>produce Perm Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see iqtool.IqtoolPackage#getproducePermType()
 * @model
 * @generated
 */
public final class producePermType extends AbstractEnumerator {
	/**
	 * The '<em><b>P</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>P</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #P_LITERAL
	 * @model name="p"
	 * @generated
	 * @ordered
	 */
	public static final int P = 0;

	/**
	 * The '<em><b>X</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>X</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #X_LITERAL
	 * @model name="x"
	 * @generated
	 * @ordered
	 */
	public static final int X = 1;

	/**
	 * The '<em><b>P</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #P
	 * @generated
	 * @ordered
	 */
	public static final producePermType P_LITERAL = new producePermType(P, "p", "p");

	/**
	 * The '<em><b>X</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #X
	 * @generated
	 * @ordered
	 */
	public static final producePermType X_LITERAL = new producePermType(X, "x", "x");

	/**
	 * An array of all the '<em><b>produce Perm Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final producePermType[] VALUES_ARRAY =
		new producePermType[] {
			P_LITERAL,
			X_LITERAL,
		};

	/**
	 * A public read-only list of all the '<em><b>produce Perm Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>produce Perm Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static producePermType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			producePermType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>produce Perm Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static producePermType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			producePermType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>produce Perm Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static producePermType get(int value) {
		switch (value) {
			case P: return P_LITERAL;
			case X: return X_LITERAL;
		}
		return null;
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private producePermType(int value, String name, String literal) {
		super(value, name, literal);
	}

} //producePermType
