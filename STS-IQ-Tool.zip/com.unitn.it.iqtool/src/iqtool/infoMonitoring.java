/**
 */
package iqtool;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>info Monitoring</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.infoMonitoring#getMonitoringOfInfo <em>Monitoring Of Info</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getinfoMonitoring()
 * @model
 * @generated
 */
public interface infoMonitoring extends monitoring {
	/**
	 * Returns the value of the '<em><b>Monitoring Of Info</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Monitoring Of Info</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Monitoring Of Info</em>' reference.
	 * @see #setMonitoringOfInfo(information)
	 * @see iqtool.IqtoolPackage#getinfoMonitoring_MonitoringOfInfo()
	 * @model
	 * @generated
	 */
	information getMonitoringOfInfo();

	/**
	 * Sets the value of the '{@link iqtool.infoMonitoring#getMonitoringOfInfo <em>Monitoring Of Info</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Monitoring Of Info</em>' reference.
	 * @see #getMonitoringOfInfo()
	 * @generated
	 */
	void setMonitoringOfInfo(information value);

} // infoMonitoring
