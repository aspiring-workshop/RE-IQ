/**
 */
package iqtool;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>general Goal</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see iqtool.IqtoolPackage#getgeneralGoal()
 * @model
 * @generated
 */
public interface generalGoal extends goal {
} // generalGoal
