/**
 */
package iqtool;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>information</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.information#getName <em>Name</em>}</li>
 *   <li>{@link iqtool.information#getVolatility <em>Volatility</em>}</li>
 *   <li>{@link iqtool.information#getSubItem <em>Sub Item</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getinformation()
 * @model
 * @generated
 */
public interface information extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see iqtool.IqtoolPackage#getinformation_Name()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link iqtool.information#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Volatility</b></em>' attribute.
	 * The default value is <code>"100"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Volatility</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Volatility</em>' attribute.
	 * @see #setVolatility(int)
	 * @see iqtool.IqtoolPackage#getinformation_Volatility()
	 * @model default="100"
	 * @generated
	 */
	int getVolatility();

	/**
	 * Sets the value of the '{@link iqtool.information#getVolatility <em>Volatility</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Volatility</em>' attribute.
	 * @see #getVolatility()
	 * @generated
	 */
	void setVolatility(int value);

	/**
	 * Returns the value of the '<em><b>Sub Item</b></em>' reference list.
	 * The list contents are of type {@link iqtool.information}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sub Item</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sub Item</em>' reference list.
	 * @see iqtool.IqtoolPackage#getinformation_SubItem()
	 * @model type="iqtool.information" upper="2"
	 * @generated
	 */
	EList getSubItem();

} // information
