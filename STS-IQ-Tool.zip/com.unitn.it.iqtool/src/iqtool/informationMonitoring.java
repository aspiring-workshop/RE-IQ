/**
 */
package iqtool;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>information Monitoring</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.informationMonitoring#getMonitoringOfInformation <em>Monitoring Of Information</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getinformationMonitoring()
 * @model
 * @generated
 */
public interface informationMonitoring extends monitoring {
	/**
	 * Returns the value of the '<em><b>Monitoring Of Information</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Monitoring Of Information</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Monitoring Of Information</em>' reference.
	 * @see #setMonitoringOfInformation(information)
	 * @see iqtool.IqtoolPackage#getinformationMonitoring_MonitoringOfInformation()
	 * @model
	 * @generated
	 */
	information getMonitoringOfInformation();

	/**
	 * Sets the value of the '{@link iqtool.informationMonitoring#getMonitoringOfInformation <em>Monitoring Of Information</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Monitoring Of Information</em>' reference.
	 * @see #getMonitoringOfInformation()
	 * @generated
	 */
	void setMonitoringOfInformation(information value);

} // informationMonitoring
