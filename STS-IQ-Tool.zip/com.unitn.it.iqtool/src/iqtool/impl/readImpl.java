/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.blv_type;
import iqtool.goal;
import iqtool.information;
import iqtool.purposeOfUseTypes;
import iqtool.read;
import iqtool.rtype;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>read</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.readImpl#getPou <em>Pou</em>}</li>
 *   <li>{@link iqtool.impl.readImpl#getReadOf <em>Read Of</em>}</li>
 *   <li>{@link iqtool.impl.readImpl#getReadBy <em>Read By</em>}</li>
 *   <li>{@link iqtool.impl.readImpl#getReadType <em>Read Type</em>}</li>
 *   <li>{@link iqtool.impl.readImpl#getPrd_blv_type <em>Prd blv type</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class readImpl extends MinimalEObjectImpl.Container implements read {
	/**
	 * The default value of the '{@link #getPou() <em>Pou</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPou()
	 * @generated
	 * @ordered
	 */
	protected static final purposeOfUseTypes POU_EDEFAULT = purposeOfUseTypes.TRADING_LITERAL;

	/**
	 * The cached value of the '{@link #getPou() <em>Pou</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPou()
	 * @generated
	 * @ordered
	 */
	protected purposeOfUseTypes pou = POU_EDEFAULT;

	/**
	 * The cached value of the '{@link #getReadOf() <em>Read Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReadOf()
	 * @generated
	 * @ordered
	 */
	protected information readOf;

	/**
	 * The cached value of the '{@link #getReadBy() <em>Read By</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReadBy()
	 * @generated
	 * @ordered
	 */
	protected goal readBy;

	/**
	 * The default value of the '{@link #getReadType() <em>Read Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReadType()
	 * @generated
	 * @ordered
	 */
	protected static final rtype READ_TYPE_EDEFAULT = rtype.R_LITERAL;

	/**
	 * The cached value of the '{@link #getReadType() <em>Read Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReadType()
	 * @generated
	 * @ordered
	 */
	protected rtype readType = READ_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getPrd_blv_type() <em>Prd blv type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrd_blv_type()
	 * @generated
	 * @ordered
	 */
	protected static final blv_type PRD_BLV_TYPE_EDEFAULT = blv_type.CHK_BLV_LITERAL;

	/**
	 * The cached value of the '{@link #getPrd_blv_type() <em>Prd blv type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrd_blv_type()
	 * @generated
	 * @ordered
	 */
	protected blv_type prd_blv_type = PRD_BLV_TYPE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected readImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.READ;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public purposeOfUseTypes getPou() {
		return pou;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPou(purposeOfUseTypes newPou) {
		purposeOfUseTypes oldPou = pou;
		pou = newPou == null ? POU_EDEFAULT : newPou;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.READ__POU, oldPou, pou));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information getReadOf() {
		if (readOf != null && readOf.eIsProxy()) {
			InternalEObject oldReadOf = (InternalEObject)readOf;
			readOf = (information)eResolveProxy(oldReadOf);
			if (readOf != oldReadOf) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.READ__READ_OF, oldReadOf, readOf));
			}
		}
		return readOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information basicGetReadOf() {
		return readOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReadOf(information newReadOf) {
		information oldReadOf = readOf;
		readOf = newReadOf;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.READ__READ_OF, oldReadOf, readOf));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goal getReadBy() {
		if (readBy != null && readBy.eIsProxy()) {
			InternalEObject oldReadBy = (InternalEObject)readBy;
			readBy = (goal)eResolveProxy(oldReadBy);
			if (readBy != oldReadBy) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.READ__READ_BY, oldReadBy, readBy));
			}
		}
		return readBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goal basicGetReadBy() {
		return readBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReadBy(goal newReadBy) {
		goal oldReadBy = readBy;
		readBy = newReadBy;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.READ__READ_BY, oldReadBy, readBy));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public rtype getReadType() {
		return readType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReadType(rtype newReadType) {
		rtype oldReadType = readType;
		readType = newReadType == null ? READ_TYPE_EDEFAULT : newReadType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.READ__READ_TYPE, oldReadType, readType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public blv_type getPrd_blv_type() {
		return prd_blv_type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPrd_blv_type(blv_type newPrd_blv_type) {
		blv_type oldPrd_blv_type = prd_blv_type;
		prd_blv_type = newPrd_blv_type == null ? PRD_BLV_TYPE_EDEFAULT : newPrd_blv_type;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.READ__PRD_BLV_TYPE, oldPrd_blv_type, prd_blv_type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.READ__POU:
				return getPou();
			case IqtoolPackage.READ__READ_OF:
				if (resolve) return getReadOf();
				return basicGetReadOf();
			case IqtoolPackage.READ__READ_BY:
				if (resolve) return getReadBy();
				return basicGetReadBy();
			case IqtoolPackage.READ__READ_TYPE:
				return getReadType();
			case IqtoolPackage.READ__PRD_BLV_TYPE:
				return getPrd_blv_type();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.READ__POU:
				setPou((purposeOfUseTypes)newValue);
				return;
			case IqtoolPackage.READ__READ_OF:
				setReadOf((information)newValue);
				return;
			case IqtoolPackage.READ__READ_BY:
				setReadBy((goal)newValue);
				return;
			case IqtoolPackage.READ__READ_TYPE:
				setReadType((rtype)newValue);
				return;
			case IqtoolPackage.READ__PRD_BLV_TYPE:
				setPrd_blv_type((blv_type)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.READ__POU:
				setPou(POU_EDEFAULT);
				return;
			case IqtoolPackage.READ__READ_OF:
				setReadOf((information)null);
				return;
			case IqtoolPackage.READ__READ_BY:
				setReadBy((goal)null);
				return;
			case IqtoolPackage.READ__READ_TYPE:
				setReadType(READ_TYPE_EDEFAULT);
				return;
			case IqtoolPackage.READ__PRD_BLV_TYPE:
				setPrd_blv_type(PRD_BLV_TYPE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.READ__POU:
				return pou != POU_EDEFAULT;
			case IqtoolPackage.READ__READ_OF:
				return readOf != null;
			case IqtoolPackage.READ__READ_BY:
				return readBy != null;
			case IqtoolPackage.READ__READ_TYPE:
				return readType != READ_TYPE_EDEFAULT;
			case IqtoolPackage.READ__PRD_BLV_TYPE:
				return prd_blv_type != PRD_BLV_TYPE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (pou: ");
		result.append(pou);
		result.append(", readType: ");
		result.append(readType);
		result.append(", prd_blv_type: ");
		result.append(prd_blv_type);
		result.append(')');
		return result.toString();
	}

} //readImpl
