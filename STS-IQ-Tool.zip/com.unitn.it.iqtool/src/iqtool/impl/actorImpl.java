/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.actor;
import iqtool.goal;
import iqtool.information;
import iqtool.threat;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>actor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.actorImpl#getName <em>Name</em>}</li>
 *   <li>{@link iqtool.impl.actorImpl#getAims <em>Aims</em>}</li>
 *   <li>{@link iqtool.impl.actorImpl#getOwn <em>Own</em>}</li>
 *   <li>{@link iqtool.impl.actorImpl#getCapableOfThreat <em>Capable Of Threat</em>}</li>
 *   <li>{@link iqtool.impl.actorImpl#getIncapableOfThreat <em>Incapable Of Threat</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public abstract class actorImpl extends MinimalEObjectImpl.Container implements actor {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAims() <em>Aims</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAims()
	 * @generated
	 * @ordered
	 */
	protected EList aims;

	/**
	 * The cached value of the '{@link #getOwn() <em>Own</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOwn()
	 * @generated
	 * @ordered
	 */
	protected EList own;

	/**
	 * The cached value of the '{@link #getCapableOfThreat() <em>Capable Of Threat</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapableOfThreat()
	 * @generated
	 * @ordered
	 */
	protected EList capableOfThreat;

	/**
	 * The cached value of the '{@link #getIncapableOfThreat() <em>Incapable Of Threat</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIncapableOfThreat()
	 * @generated
	 * @ordered
	 */
	protected EList incapableOfThreat;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected actorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.ACTOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.ACTOR__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getAims() {
		if (aims == null) {
			aims = new EObjectResolvingEList(goal.class, this, IqtoolPackage.ACTOR__AIMS);
		}
		return aims;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getOwn() {
		if (own == null) {
			own = new EObjectResolvingEList(information.class, this, IqtoolPackage.ACTOR__OWN);
		}
		return own;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getCapableOfThreat() {
		if (capableOfThreat == null) {
			capableOfThreat = new EObjectResolvingEList(threat.class, this, IqtoolPackage.ACTOR__CAPABLE_OF_THREAT);
		}
		return capableOfThreat;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getIncapableOfThreat() {
		if (incapableOfThreat == null) {
			incapableOfThreat = new EObjectResolvingEList(threat.class, this, IqtoolPackage.ACTOR__INCAPABLE_OF_THREAT);
		}
		return incapableOfThreat;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.ACTOR__NAME:
				return getName();
			case IqtoolPackage.ACTOR__AIMS:
				return getAims();
			case IqtoolPackage.ACTOR__OWN:
				return getOwn();
			case IqtoolPackage.ACTOR__CAPABLE_OF_THREAT:
				return getCapableOfThreat();
			case IqtoolPackage.ACTOR__INCAPABLE_OF_THREAT:
				return getIncapableOfThreat();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.ACTOR__NAME:
				setName((String)newValue);
				return;
			case IqtoolPackage.ACTOR__AIMS:
				getAims().clear();
				getAims().addAll((Collection)newValue);
				return;
			case IqtoolPackage.ACTOR__OWN:
				getOwn().clear();
				getOwn().addAll((Collection)newValue);
				return;
			case IqtoolPackage.ACTOR__CAPABLE_OF_THREAT:
				getCapableOfThreat().clear();
				getCapableOfThreat().addAll((Collection)newValue);
				return;
			case IqtoolPackage.ACTOR__INCAPABLE_OF_THREAT:
				getIncapableOfThreat().clear();
				getIncapableOfThreat().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.ACTOR__NAME:
				setName(NAME_EDEFAULT);
				return;
			case IqtoolPackage.ACTOR__AIMS:
				getAims().clear();
				return;
			case IqtoolPackage.ACTOR__OWN:
				getOwn().clear();
				return;
			case IqtoolPackage.ACTOR__CAPABLE_OF_THREAT:
				getCapableOfThreat().clear();
				return;
			case IqtoolPackage.ACTOR__INCAPABLE_OF_THREAT:
				getIncapableOfThreat().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.ACTOR__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case IqtoolPackage.ACTOR__AIMS:
				return aims != null && !aims.isEmpty();
			case IqtoolPackage.ACTOR__OWN:
				return own != null && !own.isEmpty();
			case IqtoolPackage.ACTOR__CAPABLE_OF_THREAT:
				return capableOfThreat != null && !capableOfThreat.isEmpty();
			case IqtoolPackage.ACTOR__INCAPABLE_OF_THREAT:
				return incapableOfThreat != null && !incapableOfThreat.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //actorImpl
