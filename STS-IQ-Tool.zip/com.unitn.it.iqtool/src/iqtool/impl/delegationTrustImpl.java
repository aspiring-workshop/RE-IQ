/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.actor;
import iqtool.delegationTrust;
import iqtool.goal;
import iqtool.trustLevel;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>delegation Trust</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.delegationTrustImpl#getTrustlevel <em>Trustlevel</em>}</li>
 *   <li>{@link iqtool.impl.delegationTrustImpl#getTrustumGoal <em>Trustum Goal</em>}</li>
 *   <li>{@link iqtool.impl.delegationTrustImpl#getTrustorGoal <em>Trustor Goal</em>}</li>
 *   <li>{@link iqtool.impl.delegationTrustImpl#getTrusteeGoal <em>Trustee Goal</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class delegationTrustImpl extends MinimalEObjectImpl.Container implements delegationTrust {
	/**
	 * The default value of the '{@link #getTrustlevel() <em>Trustlevel</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustlevel()
	 * @generated
	 * @ordered
	 */
	protected static final trustLevel TRUSTLEVEL_EDEFAULT = trustLevel.TRUST_LITERAL;

	/**
	 * The cached value of the '{@link #getTrustlevel() <em>Trustlevel</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustlevel()
	 * @generated
	 * @ordered
	 */
	protected trustLevel trustlevel = TRUSTLEVEL_EDEFAULT;

	/**
	 * The cached value of the '{@link #getTrustumGoal() <em>Trustum Goal</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustumGoal()
	 * @generated
	 * @ordered
	 */
	protected goal trustumGoal;

	/**
	 * The cached value of the '{@link #getTrustorGoal() <em>Trustor Goal</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustorGoal()
	 * @generated
	 * @ordered
	 */
	protected actor trustorGoal;

	/**
	 * The cached value of the '{@link #getTrusteeGoal() <em>Trustee Goal</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrusteeGoal()
	 * @generated
	 * @ordered
	 */
	protected actor trusteeGoal;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected delegationTrustImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.DELEGATION_TRUST;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public trustLevel getTrustlevel() {
		return trustlevel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTrustlevel(trustLevel newTrustlevel) {
		trustLevel oldTrustlevel = trustlevel;
		trustlevel = newTrustlevel == null ? TRUSTLEVEL_EDEFAULT : newTrustlevel;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.DELEGATION_TRUST__TRUSTLEVEL, oldTrustlevel, trustlevel));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goal getTrustumGoal() {
		if (trustumGoal != null && trustumGoal.eIsProxy()) {
			InternalEObject oldTrustumGoal = (InternalEObject)trustumGoal;
			trustumGoal = (goal)eResolveProxy(oldTrustumGoal);
			if (trustumGoal != oldTrustumGoal) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.DELEGATION_TRUST__TRUSTUM_GOAL, oldTrustumGoal, trustumGoal));
			}
		}
		return trustumGoal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goal basicGetTrustumGoal() {
		return trustumGoal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTrustumGoal(goal newTrustumGoal) {
		goal oldTrustumGoal = trustumGoal;
		trustumGoal = newTrustumGoal;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.DELEGATION_TRUST__TRUSTUM_GOAL, oldTrustumGoal, trustumGoal));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getTrustorGoal() {
		if (trustorGoal != null && trustorGoal.eIsProxy()) {
			InternalEObject oldTrustorGoal = (InternalEObject)trustorGoal;
			trustorGoal = (actor)eResolveProxy(oldTrustorGoal);
			if (trustorGoal != oldTrustorGoal) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.DELEGATION_TRUST__TRUSTOR_GOAL, oldTrustorGoal, trustorGoal));
			}
		}
		return trustorGoal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetTrustorGoal() {
		return trustorGoal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTrustorGoal(actor newTrustorGoal) {
		actor oldTrustorGoal = trustorGoal;
		trustorGoal = newTrustorGoal;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.DELEGATION_TRUST__TRUSTOR_GOAL, oldTrustorGoal, trustorGoal));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getTrusteeGoal() {
		if (trusteeGoal != null && trusteeGoal.eIsProxy()) {
			InternalEObject oldTrusteeGoal = (InternalEObject)trusteeGoal;
			trusteeGoal = (actor)eResolveProxy(oldTrusteeGoal);
			if (trusteeGoal != oldTrusteeGoal) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.DELEGATION_TRUST__TRUSTEE_GOAL, oldTrusteeGoal, trusteeGoal));
			}
		}
		return trusteeGoal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetTrusteeGoal() {
		return trusteeGoal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTrusteeGoal(actor newTrusteeGoal) {
		actor oldTrusteeGoal = trusteeGoal;
		trusteeGoal = newTrusteeGoal;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.DELEGATION_TRUST__TRUSTEE_GOAL, oldTrusteeGoal, trusteeGoal));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.DELEGATION_TRUST__TRUSTLEVEL:
				return getTrustlevel();
			case IqtoolPackage.DELEGATION_TRUST__TRUSTUM_GOAL:
				if (resolve) return getTrustumGoal();
				return basicGetTrustumGoal();
			case IqtoolPackage.DELEGATION_TRUST__TRUSTOR_GOAL:
				if (resolve) return getTrustorGoal();
				return basicGetTrustorGoal();
			case IqtoolPackage.DELEGATION_TRUST__TRUSTEE_GOAL:
				if (resolve) return getTrusteeGoal();
				return basicGetTrusteeGoal();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.DELEGATION_TRUST__TRUSTLEVEL:
				setTrustlevel((trustLevel)newValue);
				return;
			case IqtoolPackage.DELEGATION_TRUST__TRUSTUM_GOAL:
				setTrustumGoal((goal)newValue);
				return;
			case IqtoolPackage.DELEGATION_TRUST__TRUSTOR_GOAL:
				setTrustorGoal((actor)newValue);
				return;
			case IqtoolPackage.DELEGATION_TRUST__TRUSTEE_GOAL:
				setTrusteeGoal((actor)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.DELEGATION_TRUST__TRUSTLEVEL:
				setTrustlevel(TRUSTLEVEL_EDEFAULT);
				return;
			case IqtoolPackage.DELEGATION_TRUST__TRUSTUM_GOAL:
				setTrustumGoal((goal)null);
				return;
			case IqtoolPackage.DELEGATION_TRUST__TRUSTOR_GOAL:
				setTrustorGoal((actor)null);
				return;
			case IqtoolPackage.DELEGATION_TRUST__TRUSTEE_GOAL:
				setTrusteeGoal((actor)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.DELEGATION_TRUST__TRUSTLEVEL:
				return trustlevel != TRUSTLEVEL_EDEFAULT;
			case IqtoolPackage.DELEGATION_TRUST__TRUSTUM_GOAL:
				return trustumGoal != null;
			case IqtoolPackage.DELEGATION_TRUST__TRUSTOR_GOAL:
				return trustorGoal != null;
			case IqtoolPackage.DELEGATION_TRUST__TRUSTEE_GOAL:
				return trusteeGoal != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (trustlevel: ");
		result.append(trustlevel);
		result.append(')');
		return result.toString();
	}

} //delegationTrustImpl
