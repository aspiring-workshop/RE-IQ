/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.goal;
import iqtool.goalThreat;

import java.util.Collection;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>goal Threat</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.goalThreatImpl#getGoalThreat <em>Goal Threat</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class goalThreatImpl extends threatImpl implements goalThreat {
	/**
	 * The cached value of the '{@link #getGoalThreat() <em>Goal Threat</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGoalThreat()
	 * @generated
	 * @ordered
	 */
	protected EList goalThreat;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected goalThreatImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.GOAL_THREAT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getGoalThreat() {
		if (goalThreat == null) {
			goalThreat = new EObjectResolvingEList(goal.class, this, IqtoolPackage.GOAL_THREAT__GOAL_THREAT);
		}
		return goalThreat;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.GOAL_THREAT__GOAL_THREAT:
				return getGoalThreat();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.GOAL_THREAT__GOAL_THREAT:
				getGoalThreat().clear();
				getGoalThreat().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.GOAL_THREAT__GOAL_THREAT:
				getGoalThreat().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.GOAL_THREAT__GOAL_THREAT:
				return goalThreat != null && !goalThreat.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //goalThreatImpl
