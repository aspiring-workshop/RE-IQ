/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.actor;
import iqtool.goal;
import iqtool.goalDelegation;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>goal Delegation</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.goalDelegationImpl#getDelegationOf <em>Delegation Of</em>}</li>
 *   <li>{@link iqtool.impl.goalDelegationImpl#getDelegationFrom <em>Delegation From</em>}</li>
 *   <li>{@link iqtool.impl.goalDelegationImpl#getDelegationTo <em>Delegation To</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class goalDelegationImpl extends MinimalEObjectImpl.Container implements goalDelegation {
	/**
	 * The cached value of the '{@link #getDelegationOf() <em>Delegation Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDelegationOf()
	 * @generated
	 * @ordered
	 */
	protected goal delegationOf;

	/**
	 * The cached value of the '{@link #getDelegationFrom() <em>Delegation From</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDelegationFrom()
	 * @generated
	 * @ordered
	 */
	protected actor delegationFrom;

	/**
	 * The cached value of the '{@link #getDelegationTo() <em>Delegation To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDelegationTo()
	 * @generated
	 * @ordered
	 */
	protected actor delegationTo;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected goalDelegationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.GOAL_DELEGATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goal getDelegationOf() {
		if (delegationOf != null && delegationOf.eIsProxy()) {
			InternalEObject oldDelegationOf = (InternalEObject)delegationOf;
			delegationOf = (goal)eResolveProxy(oldDelegationOf);
			if (delegationOf != oldDelegationOf) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.GOAL_DELEGATION__DELEGATION_OF, oldDelegationOf, delegationOf));
			}
		}
		return delegationOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goal basicGetDelegationOf() {
		return delegationOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDelegationOf(goal newDelegationOf) {
		goal oldDelegationOf = delegationOf;
		delegationOf = newDelegationOf;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.GOAL_DELEGATION__DELEGATION_OF, oldDelegationOf, delegationOf));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getDelegationFrom() {
		if (delegationFrom != null && delegationFrom.eIsProxy()) {
			InternalEObject oldDelegationFrom = (InternalEObject)delegationFrom;
			delegationFrom = (actor)eResolveProxy(oldDelegationFrom);
			if (delegationFrom != oldDelegationFrom) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.GOAL_DELEGATION__DELEGATION_FROM, oldDelegationFrom, delegationFrom));
			}
		}
		return delegationFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetDelegationFrom() {
		return delegationFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDelegationFrom(actor newDelegationFrom) {
		actor oldDelegationFrom = delegationFrom;
		delegationFrom = newDelegationFrom;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.GOAL_DELEGATION__DELEGATION_FROM, oldDelegationFrom, delegationFrom));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getDelegationTo() {
		if (delegationTo != null && delegationTo.eIsProxy()) {
			InternalEObject oldDelegationTo = (InternalEObject)delegationTo;
			delegationTo = (actor)eResolveProxy(oldDelegationTo);
			if (delegationTo != oldDelegationTo) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.GOAL_DELEGATION__DELEGATION_TO, oldDelegationTo, delegationTo));
			}
		}
		return delegationTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetDelegationTo() {
		return delegationTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDelegationTo(actor newDelegationTo) {
		actor oldDelegationTo = delegationTo;
		delegationTo = newDelegationTo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.GOAL_DELEGATION__DELEGATION_TO, oldDelegationTo, delegationTo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.GOAL_DELEGATION__DELEGATION_OF:
				if (resolve) return getDelegationOf();
				return basicGetDelegationOf();
			case IqtoolPackage.GOAL_DELEGATION__DELEGATION_FROM:
				if (resolve) return getDelegationFrom();
				return basicGetDelegationFrom();
			case IqtoolPackage.GOAL_DELEGATION__DELEGATION_TO:
				if (resolve) return getDelegationTo();
				return basicGetDelegationTo();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.GOAL_DELEGATION__DELEGATION_OF:
				setDelegationOf((goal)newValue);
				return;
			case IqtoolPackage.GOAL_DELEGATION__DELEGATION_FROM:
				setDelegationFrom((actor)newValue);
				return;
			case IqtoolPackage.GOAL_DELEGATION__DELEGATION_TO:
				setDelegationTo((actor)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.GOAL_DELEGATION__DELEGATION_OF:
				setDelegationOf((goal)null);
				return;
			case IqtoolPackage.GOAL_DELEGATION__DELEGATION_FROM:
				setDelegationFrom((actor)null);
				return;
			case IqtoolPackage.GOAL_DELEGATION__DELEGATION_TO:
				setDelegationTo((actor)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.GOAL_DELEGATION__DELEGATION_OF:
				return delegationOf != null;
			case IqtoolPackage.GOAL_DELEGATION__DELEGATION_FROM:
				return delegationFrom != null;
			case IqtoolPackage.GOAL_DELEGATION__DELEGATION_TO:
				return delegationTo != null;
		}
		return super.eIsSet(featureID);
	}

} //goalDelegationImpl
