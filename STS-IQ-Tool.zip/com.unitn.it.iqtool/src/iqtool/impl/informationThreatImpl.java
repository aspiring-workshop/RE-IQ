/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.information;
import iqtool.informationThreat;

import java.util.Collection;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>information Threat</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.informationThreatImpl#getThreatInformation <em>Threat Information</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class informationThreatImpl extends threatImpl implements informationThreat {
	/**
	 * The cached value of the '{@link #getThreatInformation() <em>Threat Information</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThreatInformation()
	 * @generated
	 * @ordered
	 */
	protected EList threatInformation;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected informationThreatImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.INFORMATION_THREAT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getThreatInformation() {
		if (threatInformation == null) {
			threatInformation = new EObjectResolvingEList(information.class, this, IqtoolPackage.INFORMATION_THREAT__THREAT_INFORMATION);
		}
		return threatInformation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.INFORMATION_THREAT__THREAT_INFORMATION:
				return getThreatInformation();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.INFORMATION_THREAT__THREAT_INFORMATION:
				getThreatInformation().clear();
				getThreatInformation().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.INFORMATION_THREAT__THREAT_INFORMATION:
				getThreatInformation().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.INFORMATION_THREAT__THREAT_INFORMATION:
				return threatInformation != null && !threatInformation.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //informationThreatImpl
