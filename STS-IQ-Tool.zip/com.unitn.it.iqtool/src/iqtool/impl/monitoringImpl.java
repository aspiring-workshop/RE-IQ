/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.actor;
import iqtool.monitoring;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>monitoring</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.monitoringImpl#getMonitor <em>Monitor</em>}</li>
 *   <li>{@link iqtool.impl.monitoringImpl#getMonitored <em>Monitored</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class monitoringImpl extends MinimalEObjectImpl.Container implements monitoring {
	/**
	 * The cached value of the '{@link #getMonitor() <em>Monitor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMonitor()
	 * @generated
	 * @ordered
	 */
	protected actor monitor;

	/**
	 * The cached value of the '{@link #getMonitored() <em>Monitored</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMonitored()
	 * @generated
	 * @ordered
	 */
	protected actor monitored;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected monitoringImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.MONITORING;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getMonitor() {
		if (monitor != null && monitor.eIsProxy()) {
			InternalEObject oldMonitor = (InternalEObject)monitor;
			monitor = (actor)eResolveProxy(oldMonitor);
			if (monitor != oldMonitor) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.MONITORING__MONITOR, oldMonitor, monitor));
			}
		}
		return monitor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetMonitor() {
		return monitor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMonitor(actor newMonitor) {
		actor oldMonitor = monitor;
		monitor = newMonitor;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.MONITORING__MONITOR, oldMonitor, monitor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getMonitored() {
		if (monitored != null && monitored.eIsProxy()) {
			InternalEObject oldMonitored = (InternalEObject)monitored;
			monitored = (actor)eResolveProxy(oldMonitored);
			if (monitored != oldMonitored) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.MONITORING__MONITORED, oldMonitored, monitored));
			}
		}
		return monitored;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetMonitored() {
		return monitored;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMonitored(actor newMonitored) {
		actor oldMonitored = monitored;
		monitored = newMonitored;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.MONITORING__MONITORED, oldMonitored, monitored));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.MONITORING__MONITOR:
				if (resolve) return getMonitor();
				return basicGetMonitor();
			case IqtoolPackage.MONITORING__MONITORED:
				if (resolve) return getMonitored();
				return basicGetMonitored();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.MONITORING__MONITOR:
				setMonitor((actor)newValue);
				return;
			case IqtoolPackage.MONITORING__MONITORED:
				setMonitored((actor)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.MONITORING__MONITOR:
				setMonitor((actor)null);
				return;
			case IqtoolPackage.MONITORING__MONITORED:
				setMonitored((actor)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.MONITORING__MONITOR:
				return monitor != null;
			case IqtoolPackage.MONITORING__MONITORED:
				return monitored != null;
		}
		return super.eIsSet(featureID);
	}

} //monitoringImpl
