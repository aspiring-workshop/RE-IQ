/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.actor;
import iqtool.information;
import iqtool.modifyPermType;
import iqtool.permDelegation;
import iqtool.producePermType;
import iqtool.readPermType;
import iqtool.sendPermType;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>perm Delegation</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.permDelegationImpl#getPermOver <em>Perm Over</em>}</li>
 *   <li>{@link iqtool.impl.permDelegationImpl#getPermDeleFrom <em>Perm Dele From</em>}</li>
 *   <li>{@link iqtool.impl.permDelegationImpl#getPermDeleTo <em>Perm Dele To</em>}</li>
 *   <li>{@link iqtool.impl.permDelegationImpl#getReadPerm <em>Read Perm</em>}</li>
 *   <li>{@link iqtool.impl.permDelegationImpl#getProducePerm <em>Produce Perm</em>}</li>
 *   <li>{@link iqtool.impl.permDelegationImpl#getModifyPerm <em>Modify Perm</em>}</li>
 *   <li>{@link iqtool.impl.permDelegationImpl#getSendPerm <em>Send Perm</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class permDelegationImpl extends MinimalEObjectImpl.Container implements permDelegation {
	/**
	 * The cached value of the '{@link #getPermOver() <em>Perm Over</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPermOver()
	 * @generated
	 * @ordered
	 */
	protected information permOver;

	/**
	 * The cached value of the '{@link #getPermDeleFrom() <em>Perm Dele From</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPermDeleFrom()
	 * @generated
	 * @ordered
	 */
	protected actor permDeleFrom;

	/**
	 * The cached value of the '{@link #getPermDeleTo() <em>Perm Dele To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPermDeleTo()
	 * @generated
	 * @ordered
	 */
	protected actor permDeleTo;

	/**
	 * The default value of the '{@link #getReadPerm() <em>Read Perm</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReadPerm()
	 * @generated
	 * @ordered
	 */
	protected static final readPermType READ_PERM_EDEFAULT = readPermType.R_LITERAL;

	/**
	 * The cached value of the '{@link #getReadPerm() <em>Read Perm</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReadPerm()
	 * @generated
	 * @ordered
	 */
	protected readPermType readPerm = READ_PERM_EDEFAULT;

	/**
	 * The default value of the '{@link #getProducePerm() <em>Produce Perm</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProducePerm()
	 * @generated
	 * @ordered
	 */
	protected static final producePermType PRODUCE_PERM_EDEFAULT = producePermType.P_LITERAL;

	/**
	 * The cached value of the '{@link #getProducePerm() <em>Produce Perm</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProducePerm()
	 * @generated
	 * @ordered
	 */
	protected producePermType producePerm = PRODUCE_PERM_EDEFAULT;

	/**
	 * The default value of the '{@link #getModifyPerm() <em>Modify Perm</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModifyPerm()
	 * @generated
	 * @ordered
	 */
	protected static final modifyPermType MODIFY_PERM_EDEFAULT = modifyPermType.M_LITERAL;

	/**
	 * The cached value of the '{@link #getModifyPerm() <em>Modify Perm</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModifyPerm()
	 * @generated
	 * @ordered
	 */
	protected modifyPermType modifyPerm = MODIFY_PERM_EDEFAULT;

	/**
	 * The default value of the '{@link #getSendPerm() <em>Send Perm</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSendPerm()
	 * @generated
	 * @ordered
	 */
	protected static final sendPermType SEND_PERM_EDEFAULT = sendPermType.S_LITERAL;

	/**
	 * The cached value of the '{@link #getSendPerm() <em>Send Perm</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSendPerm()
	 * @generated
	 * @ordered
	 */
	protected sendPermType sendPerm = SEND_PERM_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected permDelegationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.PERM_DELEGATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information getPermOver() {
		if (permOver != null && permOver.eIsProxy()) {
			InternalEObject oldPermOver = (InternalEObject)permOver;
			permOver = (information)eResolveProxy(oldPermOver);
			if (permOver != oldPermOver) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.PERM_DELEGATION__PERM_OVER, oldPermOver, permOver));
			}
		}
		return permOver;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information basicGetPermOver() {
		return permOver;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPermOver(information newPermOver) {
		information oldPermOver = permOver;
		permOver = newPermOver;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PERM_DELEGATION__PERM_OVER, oldPermOver, permOver));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getPermDeleFrom() {
		if (permDeleFrom != null && permDeleFrom.eIsProxy()) {
			InternalEObject oldPermDeleFrom = (InternalEObject)permDeleFrom;
			permDeleFrom = (actor)eResolveProxy(oldPermDeleFrom);
			if (permDeleFrom != oldPermDeleFrom) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.PERM_DELEGATION__PERM_DELE_FROM, oldPermDeleFrom, permDeleFrom));
			}
		}
		return permDeleFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetPermDeleFrom() {
		return permDeleFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPermDeleFrom(actor newPermDeleFrom) {
		actor oldPermDeleFrom = permDeleFrom;
		permDeleFrom = newPermDeleFrom;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PERM_DELEGATION__PERM_DELE_FROM, oldPermDeleFrom, permDeleFrom));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getPermDeleTo() {
		if (permDeleTo != null && permDeleTo.eIsProxy()) {
			InternalEObject oldPermDeleTo = (InternalEObject)permDeleTo;
			permDeleTo = (actor)eResolveProxy(oldPermDeleTo);
			if (permDeleTo != oldPermDeleTo) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.PERM_DELEGATION__PERM_DELE_TO, oldPermDeleTo, permDeleTo));
			}
		}
		return permDeleTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetPermDeleTo() {
		return permDeleTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPermDeleTo(actor newPermDeleTo) {
		actor oldPermDeleTo = permDeleTo;
		permDeleTo = newPermDeleTo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PERM_DELEGATION__PERM_DELE_TO, oldPermDeleTo, permDeleTo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public readPermType getReadPerm() {
		return readPerm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReadPerm(readPermType newReadPerm) {
		readPermType oldReadPerm = readPerm;
		readPerm = newReadPerm == null ? READ_PERM_EDEFAULT : newReadPerm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PERM_DELEGATION__READ_PERM, oldReadPerm, readPerm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public producePermType getProducePerm() {
		return producePerm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProducePerm(producePermType newProducePerm) {
		producePermType oldProducePerm = producePerm;
		producePerm = newProducePerm == null ? PRODUCE_PERM_EDEFAULT : newProducePerm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PERM_DELEGATION__PRODUCE_PERM, oldProducePerm, producePerm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public modifyPermType getModifyPerm() {
		return modifyPerm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setModifyPerm(modifyPermType newModifyPerm) {
		modifyPermType oldModifyPerm = modifyPerm;
		modifyPerm = newModifyPerm == null ? MODIFY_PERM_EDEFAULT : newModifyPerm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PERM_DELEGATION__MODIFY_PERM, oldModifyPerm, modifyPerm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public sendPermType getSendPerm() {
		return sendPerm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSendPerm(sendPermType newSendPerm) {
		sendPermType oldSendPerm = sendPerm;
		sendPerm = newSendPerm == null ? SEND_PERM_EDEFAULT : newSendPerm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PERM_DELEGATION__SEND_PERM, oldSendPerm, sendPerm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.PERM_DELEGATION__PERM_OVER:
				if (resolve) return getPermOver();
				return basicGetPermOver();
			case IqtoolPackage.PERM_DELEGATION__PERM_DELE_FROM:
				if (resolve) return getPermDeleFrom();
				return basicGetPermDeleFrom();
			case IqtoolPackage.PERM_DELEGATION__PERM_DELE_TO:
				if (resolve) return getPermDeleTo();
				return basicGetPermDeleTo();
			case IqtoolPackage.PERM_DELEGATION__READ_PERM:
				return getReadPerm();
			case IqtoolPackage.PERM_DELEGATION__PRODUCE_PERM:
				return getProducePerm();
			case IqtoolPackage.PERM_DELEGATION__MODIFY_PERM:
				return getModifyPerm();
			case IqtoolPackage.PERM_DELEGATION__SEND_PERM:
				return getSendPerm();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.PERM_DELEGATION__PERM_OVER:
				setPermOver((information)newValue);
				return;
			case IqtoolPackage.PERM_DELEGATION__PERM_DELE_FROM:
				setPermDeleFrom((actor)newValue);
				return;
			case IqtoolPackage.PERM_DELEGATION__PERM_DELE_TO:
				setPermDeleTo((actor)newValue);
				return;
			case IqtoolPackage.PERM_DELEGATION__READ_PERM:
				setReadPerm((readPermType)newValue);
				return;
			case IqtoolPackage.PERM_DELEGATION__PRODUCE_PERM:
				setProducePerm((producePermType)newValue);
				return;
			case IqtoolPackage.PERM_DELEGATION__MODIFY_PERM:
				setModifyPerm((modifyPermType)newValue);
				return;
			case IqtoolPackage.PERM_DELEGATION__SEND_PERM:
				setSendPerm((sendPermType)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.PERM_DELEGATION__PERM_OVER:
				setPermOver((information)null);
				return;
			case IqtoolPackage.PERM_DELEGATION__PERM_DELE_FROM:
				setPermDeleFrom((actor)null);
				return;
			case IqtoolPackage.PERM_DELEGATION__PERM_DELE_TO:
				setPermDeleTo((actor)null);
				return;
			case IqtoolPackage.PERM_DELEGATION__READ_PERM:
				setReadPerm(READ_PERM_EDEFAULT);
				return;
			case IqtoolPackage.PERM_DELEGATION__PRODUCE_PERM:
				setProducePerm(PRODUCE_PERM_EDEFAULT);
				return;
			case IqtoolPackage.PERM_DELEGATION__MODIFY_PERM:
				setModifyPerm(MODIFY_PERM_EDEFAULT);
				return;
			case IqtoolPackage.PERM_DELEGATION__SEND_PERM:
				setSendPerm(SEND_PERM_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.PERM_DELEGATION__PERM_OVER:
				return permOver != null;
			case IqtoolPackage.PERM_DELEGATION__PERM_DELE_FROM:
				return permDeleFrom != null;
			case IqtoolPackage.PERM_DELEGATION__PERM_DELE_TO:
				return permDeleTo != null;
			case IqtoolPackage.PERM_DELEGATION__READ_PERM:
				return readPerm != READ_PERM_EDEFAULT;
			case IqtoolPackage.PERM_DELEGATION__PRODUCE_PERM:
				return producePerm != PRODUCE_PERM_EDEFAULT;
			case IqtoolPackage.PERM_DELEGATION__MODIFY_PERM:
				return modifyPerm != MODIFY_PERM_EDEFAULT;
			case IqtoolPackage.PERM_DELEGATION__SEND_PERM:
				return sendPerm != SEND_PERM_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (readPerm: ");
		result.append(readPerm);
		result.append(", producePerm: ");
		result.append(producePerm);
		result.append(", modifyPerm: ");
		result.append(modifyPerm);
		result.append(", sendPerm: ");
		result.append(sendPerm);
		result.append(')');
		return result.toString();
	}

} //permDelegationImpl
