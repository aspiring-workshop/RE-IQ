/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.actor;
import iqtool.information;
import iqtool.produceTrust;
import iqtool.trustLevel;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>produce Trust</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.produceTrustImpl#getTrustlevel <em>Trustlevel</em>}</li>
 *   <li>{@link iqtool.impl.produceTrustImpl#getProduceTrustor <em>Produce Trustor</em>}</li>
 *   <li>{@link iqtool.impl.produceTrustImpl#getProduceTrustee <em>Produce Trustee</em>}</li>
 *   <li>{@link iqtool.impl.produceTrustImpl#getProduceTrustOf <em>Produce Trust Of</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class produceTrustImpl extends MinimalEObjectImpl.Container implements produceTrust {
	/**
	 * The default value of the '{@link #getTrustlevel() <em>Trustlevel</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustlevel()
	 * @generated
	 * @ordered
	 */
	protected static final trustLevel TRUSTLEVEL_EDEFAULT = trustLevel.TRUST_LITERAL;

	/**
	 * The cached value of the '{@link #getTrustlevel() <em>Trustlevel</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustlevel()
	 * @generated
	 * @ordered
	 */
	protected trustLevel trustlevel = TRUSTLEVEL_EDEFAULT;

	/**
	 * The cached value of the '{@link #getProduceTrustor() <em>Produce Trustor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProduceTrustor()
	 * @generated
	 * @ordered
	 */
	protected actor produceTrustor;

	/**
	 * The cached value of the '{@link #getProduceTrustee() <em>Produce Trustee</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProduceTrustee()
	 * @generated
	 * @ordered
	 */
	protected actor produceTrustee;

	/**
	 * The cached value of the '{@link #getProduceTrustOf() <em>Produce Trust Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProduceTrustOf()
	 * @generated
	 * @ordered
	 */
	protected information produceTrustOf;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected produceTrustImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.PRODUCE_TRUST;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public trustLevel getTrustlevel() {
		return trustlevel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTrustlevel(trustLevel newTrustlevel) {
		trustLevel oldTrustlevel = trustlevel;
		trustlevel = newTrustlevel == null ? TRUSTLEVEL_EDEFAULT : newTrustlevel;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PRODUCE_TRUST__TRUSTLEVEL, oldTrustlevel, trustlevel));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getProduceTrustor() {
		if (produceTrustor != null && produceTrustor.eIsProxy()) {
			InternalEObject oldProduceTrustor = (InternalEObject)produceTrustor;
			produceTrustor = (actor)eResolveProxy(oldProduceTrustor);
			if (produceTrustor != oldProduceTrustor) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.PRODUCE_TRUST__PRODUCE_TRUSTOR, oldProduceTrustor, produceTrustor));
			}
		}
		return produceTrustor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetProduceTrustor() {
		return produceTrustor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProduceTrustor(actor newProduceTrustor) {
		actor oldProduceTrustor = produceTrustor;
		produceTrustor = newProduceTrustor;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PRODUCE_TRUST__PRODUCE_TRUSTOR, oldProduceTrustor, produceTrustor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getProduceTrustee() {
		if (produceTrustee != null && produceTrustee.eIsProxy()) {
			InternalEObject oldProduceTrustee = (InternalEObject)produceTrustee;
			produceTrustee = (actor)eResolveProxy(oldProduceTrustee);
			if (produceTrustee != oldProduceTrustee) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.PRODUCE_TRUST__PRODUCE_TRUSTEE, oldProduceTrustee, produceTrustee));
			}
		}
		return produceTrustee;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetProduceTrustee() {
		return produceTrustee;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProduceTrustee(actor newProduceTrustee) {
		actor oldProduceTrustee = produceTrustee;
		produceTrustee = newProduceTrustee;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PRODUCE_TRUST__PRODUCE_TRUSTEE, oldProduceTrustee, produceTrustee));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information getProduceTrustOf() {
		if (produceTrustOf != null && produceTrustOf.eIsProxy()) {
			InternalEObject oldProduceTrustOf = (InternalEObject)produceTrustOf;
			produceTrustOf = (information)eResolveProxy(oldProduceTrustOf);
			if (produceTrustOf != oldProduceTrustOf) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.PRODUCE_TRUST__PRODUCE_TRUST_OF, oldProduceTrustOf, produceTrustOf));
			}
		}
		return produceTrustOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information basicGetProduceTrustOf() {
		return produceTrustOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProduceTrustOf(information newProduceTrustOf) {
		information oldProduceTrustOf = produceTrustOf;
		produceTrustOf = newProduceTrustOf;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PRODUCE_TRUST__PRODUCE_TRUST_OF, oldProduceTrustOf, produceTrustOf));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.PRODUCE_TRUST__TRUSTLEVEL:
				return getTrustlevel();
			case IqtoolPackage.PRODUCE_TRUST__PRODUCE_TRUSTOR:
				if (resolve) return getProduceTrustor();
				return basicGetProduceTrustor();
			case IqtoolPackage.PRODUCE_TRUST__PRODUCE_TRUSTEE:
				if (resolve) return getProduceTrustee();
				return basicGetProduceTrustee();
			case IqtoolPackage.PRODUCE_TRUST__PRODUCE_TRUST_OF:
				if (resolve) return getProduceTrustOf();
				return basicGetProduceTrustOf();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.PRODUCE_TRUST__TRUSTLEVEL:
				setTrustlevel((trustLevel)newValue);
				return;
			case IqtoolPackage.PRODUCE_TRUST__PRODUCE_TRUSTOR:
				setProduceTrustor((actor)newValue);
				return;
			case IqtoolPackage.PRODUCE_TRUST__PRODUCE_TRUSTEE:
				setProduceTrustee((actor)newValue);
				return;
			case IqtoolPackage.PRODUCE_TRUST__PRODUCE_TRUST_OF:
				setProduceTrustOf((information)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.PRODUCE_TRUST__TRUSTLEVEL:
				setTrustlevel(TRUSTLEVEL_EDEFAULT);
				return;
			case IqtoolPackage.PRODUCE_TRUST__PRODUCE_TRUSTOR:
				setProduceTrustor((actor)null);
				return;
			case IqtoolPackage.PRODUCE_TRUST__PRODUCE_TRUSTEE:
				setProduceTrustee((actor)null);
				return;
			case IqtoolPackage.PRODUCE_TRUST__PRODUCE_TRUST_OF:
				setProduceTrustOf((information)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.PRODUCE_TRUST__TRUSTLEVEL:
				return trustlevel != TRUSTLEVEL_EDEFAULT;
			case IqtoolPackage.PRODUCE_TRUST__PRODUCE_TRUSTOR:
				return produceTrustor != null;
			case IqtoolPackage.PRODUCE_TRUST__PRODUCE_TRUSTEE:
				return produceTrustee != null;
			case IqtoolPackage.PRODUCE_TRUST__PRODUCE_TRUST_OF:
				return produceTrustOf != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (trustlevel: ");
		result.append(trustlevel);
		result.append(')');
		return result.toString();
	}

} //produceTrustImpl
