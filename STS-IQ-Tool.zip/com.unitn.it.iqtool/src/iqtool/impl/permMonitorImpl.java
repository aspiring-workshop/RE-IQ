/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.actor;
import iqtool.information;
import iqtool.permMonitor;
import iqtool.permMonitorType;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>perm Monitor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.permMonitorImpl#getOver <em>Over</em>}</li>
 *   <li>{@link iqtool.impl.permMonitorImpl#getR <em>R</em>}</li>
 *   <li>{@link iqtool.impl.permMonitorImpl#getP <em>P</em>}</li>
 *   <li>{@link iqtool.impl.permMonitorImpl#getS <em>S</em>}</li>
 *   <li>{@link iqtool.impl.permMonitorImpl#getM <em>M</em>}</li>
 *   <li>{@link iqtool.impl.permMonitorImpl#getMonitored <em>Monitored</em>}</li>
 *   <li>{@link iqtool.impl.permMonitorImpl#getMonitor <em>Monitor</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class permMonitorImpl extends MinimalEObjectImpl.Container implements permMonitor {
	/**
	 * The cached value of the '{@link #getOver() <em>Over</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOver()
	 * @generated
	 * @ordered
	 */
	protected information over;

	/**
	 * The default value of the '{@link #getR() <em>R</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getR()
	 * @generated
	 * @ordered
	 */
	protected static final permMonitorType R_EDEFAULT = permMonitorType.MONITOR_LITERAL;

	/**
	 * The cached value of the '{@link #getR() <em>R</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getR()
	 * @generated
	 * @ordered
	 */
	protected permMonitorType r = R_EDEFAULT;

	/**
	 * The default value of the '{@link #getP() <em>P</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getP()
	 * @generated
	 * @ordered
	 */
	protected static final permMonitorType P_EDEFAULT = permMonitorType.MONITOR_LITERAL;

	/**
	 * The cached value of the '{@link #getP() <em>P</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getP()
	 * @generated
	 * @ordered
	 */
	protected permMonitorType p = P_EDEFAULT;

	/**
	 * The default value of the '{@link #getS() <em>S</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getS()
	 * @generated
	 * @ordered
	 */
	protected static final permMonitorType S_EDEFAULT = permMonitorType.MONITOR_LITERAL;

	/**
	 * The cached value of the '{@link #getS() <em>S</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getS()
	 * @generated
	 * @ordered
	 */
	protected permMonitorType s = S_EDEFAULT;

	/**
	 * The default value of the '{@link #getM() <em>M</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getM()
	 * @generated
	 * @ordered
	 */
	protected static final permMonitorType M_EDEFAULT = permMonitorType.MONITOR_LITERAL;

	/**
	 * The cached value of the '{@link #getM() <em>M</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getM()
	 * @generated
	 * @ordered
	 */
	protected permMonitorType m = M_EDEFAULT;

	/**
	 * The cached value of the '{@link #getMonitored() <em>Monitored</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMonitored()
	 * @generated
	 * @ordered
	 */
	protected actor monitored;

	/**
	 * The cached value of the '{@link #getMonitor() <em>Monitor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMonitor()
	 * @generated
	 * @ordered
	 */
	protected actor monitor;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected permMonitorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.PERM_MONITOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information getOver() {
		if (over != null && over.eIsProxy()) {
			InternalEObject oldOver = (InternalEObject)over;
			over = (information)eResolveProxy(oldOver);
			if (over != oldOver) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.PERM_MONITOR__OVER, oldOver, over));
			}
		}
		return over;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information basicGetOver() {
		return over;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOver(information newOver) {
		information oldOver = over;
		over = newOver;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PERM_MONITOR__OVER, oldOver, over));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public permMonitorType getR() {
		return r;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setR(permMonitorType newR) {
		permMonitorType oldR = r;
		r = newR == null ? R_EDEFAULT : newR;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PERM_MONITOR__R, oldR, r));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public permMonitorType getP() {
		return p;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setP(permMonitorType newP) {
		permMonitorType oldP = p;
		p = newP == null ? P_EDEFAULT : newP;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PERM_MONITOR__P, oldP, p));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public permMonitorType getS() {
		return s;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setS(permMonitorType newS) {
		permMonitorType oldS = s;
		s = newS == null ? S_EDEFAULT : newS;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PERM_MONITOR__S, oldS, s));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public permMonitorType getM() {
		return m;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setM(permMonitorType newM) {
		permMonitorType oldM = m;
		m = newM == null ? M_EDEFAULT : newM;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PERM_MONITOR__M, oldM, m));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getMonitored() {
		if (monitored != null && monitored.eIsProxy()) {
			InternalEObject oldMonitored = (InternalEObject)monitored;
			monitored = (actor)eResolveProxy(oldMonitored);
			if (monitored != oldMonitored) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.PERM_MONITOR__MONITORED, oldMonitored, monitored));
			}
		}
		return monitored;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetMonitored() {
		return monitored;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMonitored(actor newMonitored) {
		actor oldMonitored = monitored;
		monitored = newMonitored;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PERM_MONITOR__MONITORED, oldMonitored, monitored));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getMonitor() {
		if (monitor != null && monitor.eIsProxy()) {
			InternalEObject oldMonitor = (InternalEObject)monitor;
			monitor = (actor)eResolveProxy(oldMonitor);
			if (monitor != oldMonitor) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.PERM_MONITOR__MONITOR, oldMonitor, monitor));
			}
		}
		return monitor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetMonitor() {
		return monitor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMonitor(actor newMonitor) {
		actor oldMonitor = monitor;
		monitor = newMonitor;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PERM_MONITOR__MONITOR, oldMonitor, monitor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.PERM_MONITOR__OVER:
				if (resolve) return getOver();
				return basicGetOver();
			case IqtoolPackage.PERM_MONITOR__R:
				return getR();
			case IqtoolPackage.PERM_MONITOR__P:
				return getP();
			case IqtoolPackage.PERM_MONITOR__S:
				return getS();
			case IqtoolPackage.PERM_MONITOR__M:
				return getM();
			case IqtoolPackage.PERM_MONITOR__MONITORED:
				if (resolve) return getMonitored();
				return basicGetMonitored();
			case IqtoolPackage.PERM_MONITOR__MONITOR:
				if (resolve) return getMonitor();
				return basicGetMonitor();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.PERM_MONITOR__OVER:
				setOver((information)newValue);
				return;
			case IqtoolPackage.PERM_MONITOR__R:
				setR((permMonitorType)newValue);
				return;
			case IqtoolPackage.PERM_MONITOR__P:
				setP((permMonitorType)newValue);
				return;
			case IqtoolPackage.PERM_MONITOR__S:
				setS((permMonitorType)newValue);
				return;
			case IqtoolPackage.PERM_MONITOR__M:
				setM((permMonitorType)newValue);
				return;
			case IqtoolPackage.PERM_MONITOR__MONITORED:
				setMonitored((actor)newValue);
				return;
			case IqtoolPackage.PERM_MONITOR__MONITOR:
				setMonitor((actor)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.PERM_MONITOR__OVER:
				setOver((information)null);
				return;
			case IqtoolPackage.PERM_MONITOR__R:
				setR(R_EDEFAULT);
				return;
			case IqtoolPackage.PERM_MONITOR__P:
				setP(P_EDEFAULT);
				return;
			case IqtoolPackage.PERM_MONITOR__S:
				setS(S_EDEFAULT);
				return;
			case IqtoolPackage.PERM_MONITOR__M:
				setM(M_EDEFAULT);
				return;
			case IqtoolPackage.PERM_MONITOR__MONITORED:
				setMonitored((actor)null);
				return;
			case IqtoolPackage.PERM_MONITOR__MONITOR:
				setMonitor((actor)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.PERM_MONITOR__OVER:
				return over != null;
			case IqtoolPackage.PERM_MONITOR__R:
				return r != R_EDEFAULT;
			case IqtoolPackage.PERM_MONITOR__P:
				return p != P_EDEFAULT;
			case IqtoolPackage.PERM_MONITOR__S:
				return s != S_EDEFAULT;
			case IqtoolPackage.PERM_MONITOR__M:
				return m != M_EDEFAULT;
			case IqtoolPackage.PERM_MONITOR__MONITORED:
				return monitored != null;
			case IqtoolPackage.PERM_MONITOR__MONITOR:
				return monitor != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (r: ");
		result.append(r);
		result.append(", p: ");
		result.append(p);
		result.append(", s: ");
		result.append(s);
		result.append(", m: ");
		result.append(m);
		result.append(')');
		return result.toString();
	}

} //permMonitorImpl
