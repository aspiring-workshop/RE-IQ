/**
 */
package iqtool.tests;

import iqtool.IqtoolFactory;
import iqtool.goalDelegation;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>goal Delegation</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class goalDelegationTest extends TestCase {

	/**
	 * The fixture for this goal Delegation test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected goalDelegation fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(goalDelegationTest.class);
	}

	/**
	 * Constructs a new goal Delegation test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goalDelegationTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this goal Delegation test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(goalDelegation fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this goal Delegation test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private goalDelegation getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	protected void setUp() throws Exception {
		setFixture(IqtoolFactory.eINSTANCE.creategoalDelegation());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //goalDelegationTest
