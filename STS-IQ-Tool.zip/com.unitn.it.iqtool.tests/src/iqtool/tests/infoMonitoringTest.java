/**
 */
package iqtool.tests;

import iqtool.IqtoolFactory;
import iqtool.infoMonitoring;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>info Monitoring</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class infoMonitoringTest extends monitoringTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(infoMonitoringTest.class);
	}

	/**
	 * Constructs a new info Monitoring test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public infoMonitoringTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this info Monitoring test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private infoMonitoring getFixture() {
		return (infoMonitoring)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	protected void setUp() throws Exception {
		setFixture(IqtoolFactory.eINSTANCE.createinfoMonitoring());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //infoMonitoringTest
