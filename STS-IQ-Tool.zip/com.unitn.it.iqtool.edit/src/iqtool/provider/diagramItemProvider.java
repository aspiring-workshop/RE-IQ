/**
 */
package iqtool.provider;


import iqtool.IqtoolFactory;
import iqtool.IqtoolPackage;
import iqtool.diagram;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link iqtool.diagram} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class diagramItemProvider 
	extends ItemProviderAdapter
	implements
		IEditingDomainItemProvider,
		IStructuredItemContentProvider,
		ITreeItemContentProvider,
		IItemLabelProvider,
		IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public diagramItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addProduceElementPropertyDescriptor(object);
			addProduceTrustElementPropertyDescriptor(object);
			addInstanceGoalElementPropertyDescriptor(object);
			addGeneralGoalElementPropertyDescriptor(object);
			addInstanceInformationElementPropertyDescriptor(object);
			addGeneralInformationElementPropertyDescriptor(object);
			addGoalThreatElementPropertyDescriptor(object);
			addInformationThreatElementPropertyDescriptor(object);
			addGoalMonitoringElementPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Produce Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addProduceElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_diagram_produceElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_diagram_produceElement_feature", "_UI_diagram_type"),
				 IqtoolPackage.Literals.DIAGRAM__PRODUCE_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Produce Trust Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addProduceTrustElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_diagram_produceTrustElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_diagram_produceTrustElement_feature", "_UI_diagram_type"),
				 IqtoolPackage.Literals.DIAGRAM__PRODUCE_TRUST_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Instance Goal Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addInstanceGoalElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_diagram_instanceGoalElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_diagram_instanceGoalElement_feature", "_UI_diagram_type"),
				 IqtoolPackage.Literals.DIAGRAM__INSTANCE_GOAL_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the General Goal Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addGeneralGoalElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_diagram_generalGoalElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_diagram_generalGoalElement_feature", "_UI_diagram_type"),
				 IqtoolPackage.Literals.DIAGRAM__GENERAL_GOAL_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Instance Information Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addInstanceInformationElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_diagram_instanceInformationElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_diagram_instanceInformationElement_feature", "_UI_diagram_type"),
				 IqtoolPackage.Literals.DIAGRAM__INSTANCE_INFORMATION_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the General Information Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addGeneralInformationElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_diagram_generalInformationElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_diagram_generalInformationElement_feature", "_UI_diagram_type"),
				 IqtoolPackage.Literals.DIAGRAM__GENERAL_INFORMATION_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Goal Threat Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addGoalThreatElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_diagram_goalThreatElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_diagram_goalThreatElement_feature", "_UI_diagram_type"),
				 IqtoolPackage.Literals.DIAGRAM__GOAL_THREAT_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Information Threat Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addInformationThreatElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_diagram_informationThreatElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_diagram_informationThreatElement_feature", "_UI_diagram_type"),
				 IqtoolPackage.Literals.DIAGRAM__INFORMATION_THREAT_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Goal Monitoring Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addGoalMonitoringElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_diagram_goalMonitoringElement_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_diagram_goalMonitoringElement_feature", "_UI_diagram_type"),
				 IqtoolPackage.Literals.DIAGRAM__GOAL_MONITORING_ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Collection getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__SCOPE_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__DELEGATION_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__PROVISION_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__DELEGATION_TRUST_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__AGENT_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__ROLE_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__PERM_DELE_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__TRUST_PERM_DELE_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__READ_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__SEND_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__PRODUCE_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__PRODUCE_TRUST_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__INSTANCE_GOAL_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__GENERAL_GOAL_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__INSTANCE_INFORMATION_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__GENERAL_INFORMATION_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__GOAL_THREAT_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__INFORMATION_THREAT_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__GOAL_MONITORING_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__INFO_MONITORING_ELEMENT);
			childrenFeatures.add(IqtoolPackage.Literals.DIAGRAM__PERM_MONITOR_ELEMENT);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns diagram.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/diagram"));
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getText(Object object) {
		return getString("_UI_diagram_type");
	}
	

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(diagram.class)) {
			case IqtoolPackage.DIAGRAM__SCOPE_ELEMENT:
			case IqtoolPackage.DIAGRAM__DELEGATION_ELEMENT:
			case IqtoolPackage.DIAGRAM__PROVISION_ELEMENT:
			case IqtoolPackage.DIAGRAM__DELEGATION_TRUST_ELEMENT:
			case IqtoolPackage.DIAGRAM__AGENT_ELEMENT:
			case IqtoolPackage.DIAGRAM__ROLE_ELEMENT:
			case IqtoolPackage.DIAGRAM__PERM_DELE_ELEMENT:
			case IqtoolPackage.DIAGRAM__TRUST_PERM_DELE_ELEMENT:
			case IqtoolPackage.DIAGRAM__READ_ELEMENT:
			case IqtoolPackage.DIAGRAM__SEND_ELEMENT:
			case IqtoolPackage.DIAGRAM__PRODUCE_ELEMENT:
			case IqtoolPackage.DIAGRAM__PRODUCE_TRUST_ELEMENT:
			case IqtoolPackage.DIAGRAM__INSTANCE_GOAL_ELEMENT:
			case IqtoolPackage.DIAGRAM__GENERAL_GOAL_ELEMENT:
			case IqtoolPackage.DIAGRAM__INSTANCE_INFORMATION_ELEMENT:
			case IqtoolPackage.DIAGRAM__GENERAL_INFORMATION_ELEMENT:
			case IqtoolPackage.DIAGRAM__GOAL_THREAT_ELEMENT:
			case IqtoolPackage.DIAGRAM__INFORMATION_THREAT_ELEMENT:
			case IqtoolPackage.DIAGRAM__GOAL_MONITORING_ELEMENT:
			case IqtoolPackage.DIAGRAM__INFO_MONITORING_ELEMENT:
			case IqtoolPackage.DIAGRAM__PERM_MONITOR_ELEMENT:
				fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
				return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void collectNewChildDescriptors(Collection newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__SCOPE_ELEMENT,
				 IqtoolFactory.eINSTANCE.createscope()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__DELEGATION_ELEMENT,
				 IqtoolFactory.eINSTANCE.creategoalDelegation()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__PROVISION_ELEMENT,
				 IqtoolFactory.eINSTANCE.createinfoProvision()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__DELEGATION_TRUST_ELEMENT,
				 IqtoolFactory.eINSTANCE.createdelegationTrust()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__AGENT_ELEMENT,
				 IqtoolFactory.eINSTANCE.createagent()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__ROLE_ELEMENT,
				 IqtoolFactory.eINSTANCE.createrole()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__PERM_DELE_ELEMENT,
				 IqtoolFactory.eINSTANCE.createpermDelegation()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__TRUST_PERM_DELE_ELEMENT,
				 IqtoolFactory.eINSTANCE.createtrustPermDelegation()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__READ_ELEMENT,
				 IqtoolFactory.eINSTANCE.createread()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__SEND_ELEMENT,
				 IqtoolFactory.eINSTANCE.createsend()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__PRODUCE_ELEMENT,
				 IqtoolFactory.eINSTANCE.createproduce()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__PRODUCE_TRUST_ELEMENT,
				 IqtoolFactory.eINSTANCE.createproduceTrust()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__INSTANCE_GOAL_ELEMENT,
				 IqtoolFactory.eINSTANCE.createinstanceGoal()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__GENERAL_GOAL_ELEMENT,
				 IqtoolFactory.eINSTANCE.creategeneralGoal()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__INSTANCE_INFORMATION_ELEMENT,
				 IqtoolFactory.eINSTANCE.createinstanceInformation()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__GENERAL_INFORMATION_ELEMENT,
				 IqtoolFactory.eINSTANCE.creategeneral_information()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__GOAL_THREAT_ELEMENT,
				 IqtoolFactory.eINSTANCE.creategoalThreat()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__INFORMATION_THREAT_ELEMENT,
				 IqtoolFactory.eINSTANCE.createinformationThreat()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__GOAL_MONITORING_ELEMENT,
				 IqtoolFactory.eINSTANCE.creategoalMonitoring()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__INFO_MONITORING_ELEMENT,
				 IqtoolFactory.eINSTANCE.createinfoMonitoring()));

		newChildDescriptors.add
			(createChildParameter
				(IqtoolPackage.Literals.DIAGRAM__PERM_MONITOR_ELEMENT,
				 IqtoolFactory.eINSTANCE.createpermMonitor()));
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ResourceLocator getResourceLocator() {
		return IqtoolEditPlugin.INSTANCE;
	}

}
