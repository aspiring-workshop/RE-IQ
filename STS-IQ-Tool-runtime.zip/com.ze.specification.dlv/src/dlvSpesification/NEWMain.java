package dlvSpesification;



import it.unical.mat.wrapper.DLVError;
import it.unical.mat.wrapper.DLVInputProgram;
import it.unical.mat.wrapper.DLVInputProgramImpl;
import it.unical.mat.wrapper.DLVInvocation;
import it.unical.mat.wrapper.DLVInvocationException;
import it.unical.mat.wrapper.DLVWrapper;
import it.unical.mat.wrapper.Model;
import it.unical.mat.wrapper.ModelHandler;
import it.unical.mat.wrapper.ModelResult;
import it.unical.mat.wrapper.Predicate;

import java.io.IOException;


public class NEWMain {

	public static void main(String[] args) throws DLVInvocationException {
		// TODO Auto-generated method stub
		
		// Windows DLV Solver
		DLVInvocation invocation = DLVWrapper.getInstance().createInvocation("./DLV/win-dlv.exe");
		
		// MacOSX i386 DLV Solver
		// DLVInvocation invocation = DLVWrapper.getInstance().createInvocation("/DLV/dlv.i386-apple-darwin.exe");
		
		// Linux/FreeBSD x86-64	 DLV Solver
		// DLVInvocation invocation = DLVWrapper.getInstance().createInvocation("/DLV/dlv.x86-64-linux-elf-static");
		 
		 
		 DLVInputProgram inputProgram = new DLVInputProgramImpl();

	        // inputProgram.addFile("C:/Users/MGharib/runtime-EclipseApplication/SpecificationDlv/Predicates/Predicates.dl");
	        
	        inputProgram.addFile("C:/Users/MGharib/runtime-iqtool/com.ze.specification.dlv/Predicates/Predicates.dl");
	        
	        inputProgram.addFile("C:/Users/MGharib/runtime-EclipseApplication/com.unitn.it.dlv/Predicates/ModelPredicates.dl");
	        
	        invocation.setInputProgram(inputProgram);

	        invocation.setNumberOfModels(10);

	        ModelHandler modelHandler = new ModelHandler() {
	          
	            public void handleResult(DLVInvocation observed, ModelResult result) {
	                Model model = (Model) result;
	                Predicate p;
	                
	//System.out.println(model.size());
	//System.out.println(model.getPredicate(1).t);

	for(int i=0; i< model.size(); i++)
	  //              while (model.hasMorePredicates()) // for each predicate in m
	                {
	                    p = model.getPredicate(i);//.nextPredicate(); // gets next predicate

	                    System.out.println(p.toString()); // print out p
	                }
	                System.out.println("--- END Model");
	            }
	        };

	        invocation.subscribe(modelHandler);

	        try {
	            invocation.run();
	            invocation.waitUntilExecutionFinishes();

	            System.out.println("execution finished");
	        } catch (IOException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }

	        System.out.println("ERRORS");

	        for (DLVError error : invocation.getErrors()) {
	            System.out.println(error.getText());
	        }
	    }
		

	}



