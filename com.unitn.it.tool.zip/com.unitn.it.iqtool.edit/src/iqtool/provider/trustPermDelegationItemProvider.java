/**
 */
package iqtool.provider;


import iqtool.IqtoolPackage;
import iqtool.trustLevel;
import iqtool.trustPermDelegation;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link iqtool.trustPermDelegation} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class trustPermDelegationItemProvider 
	extends ItemProviderAdapter
	implements
		IEditingDomainItemProvider,
		IStructuredItemContentProvider,
		ITreeItemContentProvider,
		IItemLabelProvider,
		IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public trustPermDelegationItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addTrustPermDeleToPropertyDescriptor(object);
			addTrustPermDeleFromPropertyDescriptor(object);
			addTrustPermDeleOfPropertyDescriptor(object);
			addTrustproduePropertyDescriptor(object);
			addTrustreadPropertyDescriptor(object);
			addTrustsendPropertyDescriptor(object);
			addTrustmodifyPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Trust Perm Dele To feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTrustPermDeleToPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_trustPermDelegation_trustPermDeleTo_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_trustPermDelegation_trustPermDeleTo_feature", "_UI_trustPermDelegation_type"),
				 IqtoolPackage.Literals.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_TO,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Trust Perm Dele From feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTrustPermDeleFromPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_trustPermDelegation_trustPermDeleFrom_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_trustPermDelegation_trustPermDeleFrom_feature", "_UI_trustPermDelegation_type"),
				 IqtoolPackage.Literals.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_FROM,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Trust Perm Dele Of feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTrustPermDeleOfPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_trustPermDelegation_trustPermDeleOf_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_trustPermDelegation_trustPermDeleOf_feature", "_UI_trustPermDelegation_type"),
				 IqtoolPackage.Literals.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_OF,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Trustprodue feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTrustproduePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_trustPermDelegation_trustprodue_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_trustPermDelegation_trustprodue_feature", "_UI_trustPermDelegation_type"),
				 IqtoolPackage.Literals.TRUST_PERM_DELEGATION__TRUSTPRODUE,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Trustread feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTrustreadPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_trustPermDelegation_trustread_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_trustPermDelegation_trustread_feature", "_UI_trustPermDelegation_type"),
				 IqtoolPackage.Literals.TRUST_PERM_DELEGATION__TRUSTREAD,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Trustsend feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTrustsendPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_trustPermDelegation_trustsend_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_trustPermDelegation_trustsend_feature", "_UI_trustPermDelegation_type"),
				 IqtoolPackage.Literals.TRUST_PERM_DELEGATION__TRUSTSEND,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Trustmodify feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTrustmodifyPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_trustPermDelegation_trustmodify_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_trustPermDelegation_trustmodify_feature", "_UI_trustPermDelegation_type"),
				 IqtoolPackage.Literals.TRUST_PERM_DELEGATION__TRUSTMODIFY,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This returns trustPermDelegation.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/trustPermDelegation"));
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getText(Object object) {
		trustLevel labelValue = ((trustPermDelegation)object).getTrustprodue();
		String label = labelValue == null ? null : labelValue.toString();
		return label == null || label.length() == 0 ?
			getString("_UI_trustPermDelegation_type") :
			getString("_UI_trustPermDelegation_type") + " " + label;
	}
	

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(trustPermDelegation.class)) {
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTPRODUE:
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTREAD:
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTSEND:
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTMODIFY:
				fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
				return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void collectNewChildDescriptors(Collection newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ResourceLocator getResourceLocator() {
		return IqtoolEditPlugin.INSTANCE;
	}

}
