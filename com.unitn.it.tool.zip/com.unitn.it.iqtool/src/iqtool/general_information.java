/**
 */
package iqtool;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>general information</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see iqtool.IqtoolPackage#getgeneral_information()
 * @model
 * @generated
 */
public interface general_information extends information {
} // general_information
