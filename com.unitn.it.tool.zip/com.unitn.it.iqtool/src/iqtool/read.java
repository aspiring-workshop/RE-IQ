/**
 */
package iqtool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>read</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.read#getPou <em>Pou</em>}</li>
 *   <li>{@link iqtool.read#getReadOf <em>Read Of</em>}</li>
 *   <li>{@link iqtool.read#getReadBy <em>Read By</em>}</li>
 *   <li>{@link iqtool.read#getReadType <em>Read Type</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getread()
 * @model
 * @generated
 */
public interface read extends EObject {
	/**
	 * Returns the value of the '<em><b>Pou</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.purposeOfUseTypes}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pou</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pou</em>' attribute.
	 * @see iqtool.purposeOfUseTypes
	 * @see #setPou(purposeOfUseTypes)
	 * @see iqtool.IqtoolPackage#getread_Pou()
	 * @model
	 * @generated
	 */
	purposeOfUseTypes getPou();

	/**
	 * Sets the value of the '{@link iqtool.read#getPou <em>Pou</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pou</em>' attribute.
	 * @see iqtool.purposeOfUseTypes
	 * @see #getPou()
	 * @generated
	 */
	void setPou(purposeOfUseTypes value);

	/**
	 * Returns the value of the '<em><b>Read Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Read Of</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Read Of</em>' reference.
	 * @see #setReadOf(information)
	 * @see iqtool.IqtoolPackage#getread_ReadOf()
	 * @model
	 * @generated
	 */
	information getReadOf();

	/**
	 * Sets the value of the '{@link iqtool.read#getReadOf <em>Read Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Read Of</em>' reference.
	 * @see #getReadOf()
	 * @generated
	 */
	void setReadOf(information value);

	/**
	 * Returns the value of the '<em><b>Read By</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Read By</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Read By</em>' reference.
	 * @see #setReadBy(goal)
	 * @see iqtool.IqtoolPackage#getread_ReadBy()
	 * @model
	 * @generated
	 */
	goal getReadBy();

	/**
	 * Sets the value of the '{@link iqtool.read#getReadBy <em>Read By</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Read By</em>' reference.
	 * @see #getReadBy()
	 * @generated
	 */
	void setReadBy(goal value);

	/**
	 * Returns the value of the '<em><b>Read Type</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.rtype}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Read Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Read Type</em>' attribute.
	 * @see iqtool.rtype
	 * @see #setReadType(rtype)
	 * @see iqtool.IqtoolPackage#getread_ReadType()
	 * @model
	 * @generated
	 */
	rtype getReadType();

	/**
	 * Sets the value of the '{@link iqtool.read#getReadType <em>Read Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Read Type</em>' attribute.
	 * @see iqtool.rtype
	 * @see #getReadType()
	 * @generated
	 */
	void setReadType(rtype value);

} // read
