/**
 */
package iqtool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>goal Delegation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.goalDelegation#getDelegationOf <em>Delegation Of</em>}</li>
 *   <li>{@link iqtool.goalDelegation#getDelegationFrom <em>Delegation From</em>}</li>
 *   <li>{@link iqtool.goalDelegation#getDelegationTo <em>Delegation To</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getgoalDelegation()
 * @model
 * @generated
 */
public interface goalDelegation extends EObject {
	/**
	 * Returns the value of the '<em><b>Delegation Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Delegation Of</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Delegation Of</em>' reference.
	 * @see #setDelegationOf(goal)
	 * @see iqtool.IqtoolPackage#getgoalDelegation_DelegationOf()
	 * @model
	 * @generated
	 */
	goal getDelegationOf();

	/**
	 * Sets the value of the '{@link iqtool.goalDelegation#getDelegationOf <em>Delegation Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Delegation Of</em>' reference.
	 * @see #getDelegationOf()
	 * @generated
	 */
	void setDelegationOf(goal value);

	/**
	 * Returns the value of the '<em><b>Delegation From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Delegation From</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Delegation From</em>' reference.
	 * @see #setDelegationFrom(actor)
	 * @see iqtool.IqtoolPackage#getgoalDelegation_DelegationFrom()
	 * @model
	 * @generated
	 */
	actor getDelegationFrom();

	/**
	 * Sets the value of the '{@link iqtool.goalDelegation#getDelegationFrom <em>Delegation From</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Delegation From</em>' reference.
	 * @see #getDelegationFrom()
	 * @generated
	 */
	void setDelegationFrom(actor value);

	/**
	 * Returns the value of the '<em><b>Delegation To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Delegation To</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Delegation To</em>' reference.
	 * @see #setDelegationTo(actor)
	 * @see iqtool.IqtoolPackage#getgoalDelegation_DelegationTo()
	 * @model
	 * @generated
	 */
	actor getDelegationTo();

	/**
	 * Sets the value of the '{@link iqtool.goalDelegation#getDelegationTo <em>Delegation To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Delegation To</em>' reference.
	 * @see #getDelegationTo()
	 * @generated
	 */
	void setDelegationTo(actor value);

} // goalDelegation
