/**
 */
package iqtool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>info Provision</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.infoProvision#getProvisionOf <em>Provision Of</em>}</li>
 *   <li>{@link iqtool.infoProvision#getProvisionFrom <em>Provision From</em>}</li>
 *   <li>{@link iqtool.infoProvision#getProvisionTo <em>Provision To</em>}</li>
 *   <li>{@link iqtool.infoProvision#getType <em>Type</em>}</li>
 *   <li>{@link iqtool.infoProvision#getTime <em>Time</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getinfoProvision()
 * @model
 * @generated
 */
public interface infoProvision extends EObject {
	/**
	 * Returns the value of the '<em><b>Provision Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Provision Of</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Provision Of</em>' reference.
	 * @see #setProvisionOf(information)
	 * @see iqtool.IqtoolPackage#getinfoProvision_ProvisionOf()
	 * @model
	 * @generated
	 */
	information getProvisionOf();

	/**
	 * Sets the value of the '{@link iqtool.infoProvision#getProvisionOf <em>Provision Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Provision Of</em>' reference.
	 * @see #getProvisionOf()
	 * @generated
	 */
	void setProvisionOf(information value);

	/**
	 * Returns the value of the '<em><b>Provision From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Provision From</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Provision From</em>' reference.
	 * @see #setProvisionFrom(actor)
	 * @see iqtool.IqtoolPackage#getinfoProvision_ProvisionFrom()
	 * @model
	 * @generated
	 */
	actor getProvisionFrom();

	/**
	 * Sets the value of the '{@link iqtool.infoProvision#getProvisionFrom <em>Provision From</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Provision From</em>' reference.
	 * @see #getProvisionFrom()
	 * @generated
	 */
	void setProvisionFrom(actor value);

	/**
	 * Returns the value of the '<em><b>Provision To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Provision To</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Provision To</em>' reference.
	 * @see #setProvisionTo(actor)
	 * @see iqtool.IqtoolPackage#getinfoProvision_ProvisionTo()
	 * @model
	 * @generated
	 */
	actor getProvisionTo();

	/**
	 * Sets the value of the '{@link iqtool.infoProvision#getProvisionTo <em>Provision To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Provision To</em>' reference.
	 * @see #getProvisionTo()
	 * @generated
	 */
	void setProvisionTo(actor value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.provisionType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see iqtool.provisionType
	 * @see #setType(provisionType)
	 * @see iqtool.IqtoolPackage#getinfoProvision_Type()
	 * @model
	 * @generated
	 */
	provisionType getType();

	/**
	 * Sets the value of the '{@link iqtool.infoProvision#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see iqtool.provisionType
	 * @see #getType()
	 * @generated
	 */
	void setType(provisionType value);

	/**
	 * Returns the value of the '<em><b>Time</b></em>' attribute.
	 * The default value is <code>"100"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Time</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Time</em>' attribute.
	 * @see #setTime(int)
	 * @see iqtool.IqtoolPackage#getinfoProvision_Time()
	 * @model default="100"
	 * @generated
	 */
	int getTime();

	/**
	 * Sets the value of the '{@link iqtool.infoProvision#getTime <em>Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Time</em>' attribute.
	 * @see #getTime()
	 * @generated
	 */
	void setTime(int value);

} // infoProvision
