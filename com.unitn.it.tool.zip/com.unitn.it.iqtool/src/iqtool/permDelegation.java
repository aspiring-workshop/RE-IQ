/**
 */
package iqtool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>perm Delegation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.permDelegation#getPermOver <em>Perm Over</em>}</li>
 *   <li>{@link iqtool.permDelegation#getPermDeleFrom <em>Perm Dele From</em>}</li>
 *   <li>{@link iqtool.permDelegation#getPermDeleTo <em>Perm Dele To</em>}</li>
 *   <li>{@link iqtool.permDelegation#getReadPerm <em>Read Perm</em>}</li>
 *   <li>{@link iqtool.permDelegation#getProducePerm <em>Produce Perm</em>}</li>
 *   <li>{@link iqtool.permDelegation#getModifyPerm <em>Modify Perm</em>}</li>
 *   <li>{@link iqtool.permDelegation#getSendPerm <em>Send Perm</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getpermDelegation()
 * @model
 * @generated
 */
public interface permDelegation extends EObject {
	/**
	 * Returns the value of the '<em><b>Perm Over</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Perm Over</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Perm Over</em>' reference.
	 * @see #setPermOver(information)
	 * @see iqtool.IqtoolPackage#getpermDelegation_PermOver()
	 * @model
	 * @generated
	 */
	information getPermOver();

	/**
	 * Sets the value of the '{@link iqtool.permDelegation#getPermOver <em>Perm Over</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Perm Over</em>' reference.
	 * @see #getPermOver()
	 * @generated
	 */
	void setPermOver(information value);

	/**
	 * Returns the value of the '<em><b>Perm Dele From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Perm Dele From</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Perm Dele From</em>' reference.
	 * @see #setPermDeleFrom(actor)
	 * @see iqtool.IqtoolPackage#getpermDelegation_PermDeleFrom()
	 * @model
	 * @generated
	 */
	actor getPermDeleFrom();

	/**
	 * Sets the value of the '{@link iqtool.permDelegation#getPermDeleFrom <em>Perm Dele From</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Perm Dele From</em>' reference.
	 * @see #getPermDeleFrom()
	 * @generated
	 */
	void setPermDeleFrom(actor value);

	/**
	 * Returns the value of the '<em><b>Perm Dele To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Perm Dele To</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Perm Dele To</em>' reference.
	 * @see #setPermDeleTo(actor)
	 * @see iqtool.IqtoolPackage#getpermDelegation_PermDeleTo()
	 * @model
	 * @generated
	 */
	actor getPermDeleTo();

	/**
	 * Sets the value of the '{@link iqtool.permDelegation#getPermDeleTo <em>Perm Dele To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Perm Dele To</em>' reference.
	 * @see #getPermDeleTo()
	 * @generated
	 */
	void setPermDeleTo(actor value);

	/**
	 * Returns the value of the '<em><b>Read Perm</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.readPermType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Read Perm</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Read Perm</em>' attribute.
	 * @see iqtool.readPermType
	 * @see #setReadPerm(readPermType)
	 * @see iqtool.IqtoolPackage#getpermDelegation_ReadPerm()
	 * @model
	 * @generated
	 */
	readPermType getReadPerm();

	/**
	 * Sets the value of the '{@link iqtool.permDelegation#getReadPerm <em>Read Perm</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Read Perm</em>' attribute.
	 * @see iqtool.readPermType
	 * @see #getReadPerm()
	 * @generated
	 */
	void setReadPerm(readPermType value);

	/**
	 * Returns the value of the '<em><b>Produce Perm</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.producePermType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Produce Perm</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Produce Perm</em>' attribute.
	 * @see iqtool.producePermType
	 * @see #setProducePerm(producePermType)
	 * @see iqtool.IqtoolPackage#getpermDelegation_ProducePerm()
	 * @model
	 * @generated
	 */
	producePermType getProducePerm();

	/**
	 * Sets the value of the '{@link iqtool.permDelegation#getProducePerm <em>Produce Perm</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Produce Perm</em>' attribute.
	 * @see iqtool.producePermType
	 * @see #getProducePerm()
	 * @generated
	 */
	void setProducePerm(producePermType value);

	/**
	 * Returns the value of the '<em><b>Modify Perm</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.modifyPermType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Modify Perm</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Modify Perm</em>' attribute.
	 * @see iqtool.modifyPermType
	 * @see #setModifyPerm(modifyPermType)
	 * @see iqtool.IqtoolPackage#getpermDelegation_ModifyPerm()
	 * @model
	 * @generated
	 */
	modifyPermType getModifyPerm();

	/**
	 * Sets the value of the '{@link iqtool.permDelegation#getModifyPerm <em>Modify Perm</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Modify Perm</em>' attribute.
	 * @see iqtool.modifyPermType
	 * @see #getModifyPerm()
	 * @generated
	 */
	void setModifyPerm(modifyPermType value);

	/**
	 * Returns the value of the '<em><b>Send Perm</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.sendPermType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Send Perm</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Send Perm</em>' attribute.
	 * @see iqtool.sendPermType
	 * @see #setSendPerm(sendPermType)
	 * @see iqtool.IqtoolPackage#getpermDelegation_SendPerm()
	 * @model
	 * @generated
	 */
	sendPermType getSendPerm();

	/**
	 * Sets the value of the '{@link iqtool.permDelegation#getSendPerm <em>Send Perm</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Send Perm</em>' attribute.
	 * @see iqtool.sendPermType
	 * @see #getSendPerm()
	 * @generated
	 */
	void setSendPerm(sendPermType value);

} // permDelegation
