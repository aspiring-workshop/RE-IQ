/**
 */
package iqtool;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see iqtool.IqtoolPackage
 * @generated
 */
public interface IqtoolFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	IqtoolFactory eINSTANCE = iqtool.impl.IqtoolFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>diagram</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>diagram</em>'.
	 * @generated
	 */
	diagram creatediagram();

	/**
	 * Returns a new object of class '<em>role</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>role</em>'.
	 * @generated
	 */
	role createrole();

	/**
	 * Returns a new object of class '<em>agent</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>agent</em>'.
	 * @generated
	 */
	agent createagent();

	/**
	 * Returns a new object of class '<em>perm Delegation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>perm Delegation</em>'.
	 * @generated
	 */
	permDelegation createpermDelegation();

	/**
	 * Returns a new object of class '<em>start Postion</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>start Postion</em>'.
	 * @generated
	 */
	startPostion createstartPostion();

	/**
	 * Returns a new object of class '<em>read</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>read</em>'.
	 * @generated
	 */
	read createread();

	/**
	 * Returns a new object of class '<em>position</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>position</em>'.
	 * @generated
	 */
	position createposition();

	/**
	 * Returns a new object of class '<em>end Postion</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>end Postion</em>'.
	 * @generated
	 */
	endPostion createendPostion();

	/**
	 * Returns a new object of class '<em>send</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>send</em>'.
	 * @generated
	 */
	send createsend();

	/**
	 * Returns a new object of class '<em>goal Delegation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>goal Delegation</em>'.
	 * @generated
	 */
	goalDelegation creategoalDelegation();

	/**
	 * Returns a new object of class '<em>delegation Trust</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>delegation Trust</em>'.
	 * @generated
	 */
	delegationTrust createdelegationTrust();

	/**
	 * Returns a new object of class '<em>between Postion</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>between Postion</em>'.
	 * @generated
	 */
	betweenPostion createbetweenPostion();

	/**
	 * Returns a new object of class '<em>info Provision</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>info Provision</em>'.
	 * @generated
	 */
	infoProvision createinfoProvision();

	/**
	 * Returns a new object of class '<em>trust Perm Delegation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>trust Perm Delegation</em>'.
	 * @generated
	 */
	trustPermDelegation createtrustPermDelegation();

	/**
	 * Returns a new object of class '<em>information</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>information</em>'.
	 * @generated
	 */
	information createinformation();

	/**
	 * Returns a new object of class '<em>scope</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>scope</em>'.
	 * @generated
	 */
	scope createscope();

	/**
	 * Returns a new object of class '<em>goal</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>goal</em>'.
	 * @generated
	 */
	goal creategoal();

	/**
	 * Returns a new object of class '<em>produce</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>produce</em>'.
	 * @generated
	 */
	produce createproduce();

	/**
	 * Returns a new object of class '<em>produce Trust</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>produce Trust</em>'.
	 * @generated
	 */
	produceTrust createproduceTrust();

	/**
	 * Returns a new object of class '<em>softgoal</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>softgoal</em>'.
	 * @generated
	 */
	softgoal createsoftgoal();

	/**
	 * Returns a new object of class '<em>iq Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>iq Constraint</em>'.
	 * @generated
	 */
	iqConstraint createiqConstraint();

	/**
	 * Returns a new object of class '<em>instance Goal</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>instance Goal</em>'.
	 * @generated
	 */
	instanceGoal createinstanceGoal();

	/**
	 * Returns a new object of class '<em>general Goal</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>general Goal</em>'.
	 * @generated
	 */
	generalGoal creategeneralGoal();

	/**
	 * Returns a new object of class '<em>instance Information</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>instance Information</em>'.
	 * @generated
	 */
	instanceInformation createinstanceInformation();

	/**
	 * Returns a new object of class '<em>general information</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>general information</em>'.
	 * @generated
	 */
	general_information creategeneral_information();

	/**
	 * Returns a new object of class '<em>threat</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>threat</em>'.
	 * @generated
	 */
	threat createthreat();

	/**
	 * Returns a new object of class '<em>information Threat</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>information Threat</em>'.
	 * @generated
	 */
	informationThreat createinformationThreat();

	/**
	 * Returns a new object of class '<em>goal Threat</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>goal Threat</em>'.
	 * @generated
	 */
	goalThreat creategoalThreat();

	/**
	 * Returns a new object of class '<em>monitoring</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>monitoring</em>'.
	 * @generated
	 */
	monitoring createmonitoring();

	/**
	 * Returns a new object of class '<em>information Monitoring</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>information Monitoring</em>'.
	 * @generated
	 */
	informationMonitoring createinformationMonitoring();

	/**
	 * Returns a new object of class '<em>goal Monitoring</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>goal Monitoring</em>'.
	 * @generated
	 */
	goalMonitoring creategoalMonitoring();

	/**
	 * Returns a new object of class '<em>adoption</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>adoption</em>'.
	 * @generated
	 */
	adoption createadoption();

	/**
	 * Returns a new object of class '<em>Information Adoption</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Information Adoption</em>'.
	 * @generated
	 */
	InformationAdoption createInformationAdoption();

	/**
	 * Returns a new object of class '<em>goal Adoption</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>goal Adoption</em>'.
	 * @generated
	 */
	goalAdoption creategoalAdoption();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	IqtoolPackage getIqtoolPackage();

} //IqtoolFactory
