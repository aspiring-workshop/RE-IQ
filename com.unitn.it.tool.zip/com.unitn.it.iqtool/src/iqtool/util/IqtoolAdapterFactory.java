/**
 */
package iqtool.util;

import iqtool.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see iqtool.IqtoolPackage
 * @generated
 */
public class IqtoolAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static IqtoolPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IqtoolAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = IqtoolPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IqtoolSwitch modelSwitch =
		new IqtoolSwitch() {
			public Object caseactor(actor object) {
				return createactorAdapter();
			}
			public Object casediagram(diagram object) {
				return creatediagramAdapter();
			}
			public Object caserole(role object) {
				return createroleAdapter();
			}
			public Object caseagent(agent object) {
				return createagentAdapter();
			}
			public Object casepermDelegation(permDelegation object) {
				return createpermDelegationAdapter();
			}
			public Object casestartPostion(startPostion object) {
				return createstartPostionAdapter();
			}
			public Object caseread(read object) {
				return createreadAdapter();
			}
			public Object caseposition(position object) {
				return createpositionAdapter();
			}
			public Object caseendPostion(endPostion object) {
				return createendPostionAdapter();
			}
			public Object casesend(send object) {
				return createsendAdapter();
			}
			public Object casegoalDelegation(goalDelegation object) {
				return creategoalDelegationAdapter();
			}
			public Object casedelegationTrust(delegationTrust object) {
				return createdelegationTrustAdapter();
			}
			public Object casebetweenPostion(betweenPostion object) {
				return createbetweenPostionAdapter();
			}
			public Object caseinfoProvision(infoProvision object) {
				return createinfoProvisionAdapter();
			}
			public Object casetrustPermDelegation(trustPermDelegation object) {
				return createtrustPermDelegationAdapter();
			}
			public Object caseinformation(information object) {
				return createinformationAdapter();
			}
			public Object casescope(scope object) {
				return createscopeAdapter();
			}
			public Object casegoal(goal object) {
				return creategoalAdapter();
			}
			public Object caseproduce(produce object) {
				return createproduceAdapter();
			}
			public Object caseproduceTrust(produceTrust object) {
				return createproduceTrustAdapter();
			}
			public Object casesoftgoal(softgoal object) {
				return createsoftgoalAdapter();
			}
			public Object caseiqConstraint(iqConstraint object) {
				return createiqConstraintAdapter();
			}
			public Object caseinstanceGoal(instanceGoal object) {
				return createinstanceGoalAdapter();
			}
			public Object casegeneralGoal(generalGoal object) {
				return creategeneralGoalAdapter();
			}
			public Object caseinstanceInformation(instanceInformation object) {
				return createinstanceInformationAdapter();
			}
			public Object casegeneral_information(general_information object) {
				return creategeneral_informationAdapter();
			}
			public Object casethreat(threat object) {
				return createthreatAdapter();
			}
			public Object caseinformationThreat(informationThreat object) {
				return createinformationThreatAdapter();
			}
			public Object casegoalThreat(goalThreat object) {
				return creategoalThreatAdapter();
			}
			public Object casemonitoring(monitoring object) {
				return createmonitoringAdapter();
			}
			public Object caseinformationMonitoring(informationMonitoring object) {
				return createinformationMonitoringAdapter();
			}
			public Object casegoalMonitoring(goalMonitoring object) {
				return creategoalMonitoringAdapter();
			}
			public Object caseadoption(adoption object) {
				return createadoptionAdapter();
			}
			public Object caseInformationAdoption(InformationAdoption object) {
				return createInformationAdoptionAdapter();
			}
			public Object casegoalAdoption(goalAdoption object) {
				return creategoalAdoptionAdapter();
			}
			public Object defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	public Adapter createAdapter(Notifier target) {
		return (Adapter)modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link iqtool.actor <em>actor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.actor
	 * @generated
	 */
	public Adapter createactorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.diagram <em>diagram</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.diagram
	 * @generated
	 */
	public Adapter creatediagramAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.role <em>role</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.role
	 * @generated
	 */
	public Adapter createroleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.agent <em>agent</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.agent
	 * @generated
	 */
	public Adapter createagentAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.permDelegation <em>perm Delegation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.permDelegation
	 * @generated
	 */
	public Adapter createpermDelegationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.startPostion <em>start Postion</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.startPostion
	 * @generated
	 */
	public Adapter createstartPostionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.read <em>read</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.read
	 * @generated
	 */
	public Adapter createreadAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.position <em>position</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.position
	 * @generated
	 */
	public Adapter createpositionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.endPostion <em>end Postion</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.endPostion
	 * @generated
	 */
	public Adapter createendPostionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.send <em>send</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.send
	 * @generated
	 */
	public Adapter createsendAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.goalDelegation <em>goal Delegation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.goalDelegation
	 * @generated
	 */
	public Adapter creategoalDelegationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.delegationTrust <em>delegation Trust</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.delegationTrust
	 * @generated
	 */
	public Adapter createdelegationTrustAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.betweenPostion <em>between Postion</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.betweenPostion
	 * @generated
	 */
	public Adapter createbetweenPostionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.infoProvision <em>info Provision</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.infoProvision
	 * @generated
	 */
	public Adapter createinfoProvisionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.trustPermDelegation <em>trust Perm Delegation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.trustPermDelegation
	 * @generated
	 */
	public Adapter createtrustPermDelegationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.information <em>information</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.information
	 * @generated
	 */
	public Adapter createinformationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.scope <em>scope</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.scope
	 * @generated
	 */
	public Adapter createscopeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.goal <em>goal</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.goal
	 * @generated
	 */
	public Adapter creategoalAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.produce <em>produce</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.produce
	 * @generated
	 */
	public Adapter createproduceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.produceTrust <em>produce Trust</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.produceTrust
	 * @generated
	 */
	public Adapter createproduceTrustAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.softgoal <em>softgoal</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.softgoal
	 * @generated
	 */
	public Adapter createsoftgoalAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.iqConstraint <em>iq Constraint</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.iqConstraint
	 * @generated
	 */
	public Adapter createiqConstraintAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.instanceGoal <em>instance Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.instanceGoal
	 * @generated
	 */
	public Adapter createinstanceGoalAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.generalGoal <em>general Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.generalGoal
	 * @generated
	 */
	public Adapter creategeneralGoalAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.instanceInformation <em>instance Information</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.instanceInformation
	 * @generated
	 */
	public Adapter createinstanceInformationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.general_information <em>general information</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.general_information
	 * @generated
	 */
	public Adapter creategeneral_informationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.threat <em>threat</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.threat
	 * @generated
	 */
	public Adapter createthreatAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.informationThreat <em>information Threat</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.informationThreat
	 * @generated
	 */
	public Adapter createinformationThreatAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.goalThreat <em>goal Threat</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.goalThreat
	 * @generated
	 */
	public Adapter creategoalThreatAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.monitoring <em>monitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.monitoring
	 * @generated
	 */
	public Adapter createmonitoringAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.informationMonitoring <em>information Monitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.informationMonitoring
	 * @generated
	 */
	public Adapter createinformationMonitoringAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.goalMonitoring <em>goal Monitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.goalMonitoring
	 * @generated
	 */
	public Adapter creategoalMonitoringAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.adoption <em>adoption</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.adoption
	 * @generated
	 */
	public Adapter createadoptionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.InformationAdoption <em>Information Adoption</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.InformationAdoption
	 * @generated
	 */
	public Adapter createInformationAdoptionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link iqtool.goalAdoption <em>goal Adoption</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see iqtool.goalAdoption
	 * @generated
	 */
	public Adapter creategoalAdoptionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //IqtoolAdapterFactory
