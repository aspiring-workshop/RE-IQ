/**
 */
package iqtool;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>instance Information</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.instanceInformation#getInstance <em>Instance</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getinstanceInformation()
 * @model
 * @generated
 */
public interface instanceInformation extends information {
	/**
	 * Returns the value of the '<em><b>Instance</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Instance</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Instance</em>' reference.
	 * @see #setInstance(general_information)
	 * @see iqtool.IqtoolPackage#getinstanceInformation_Instance()
	 * @model required="true"
	 * @generated
	 */
	general_information getInstance();

	/**
	 * Sets the value of the '{@link iqtool.instanceInformation#getInstance <em>Instance</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Instance</em>' reference.
	 * @see #getInstance()
	 * @generated
	 */
	void setInstance(general_information value);

} // instanceInformation
