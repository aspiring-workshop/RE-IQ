/**
 */
package iqtool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>delegation Trust</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.delegationTrust#getTrustlevel <em>Trustlevel</em>}</li>
 *   <li>{@link iqtool.delegationTrust#getTrustumGoal <em>Trustum Goal</em>}</li>
 *   <li>{@link iqtool.delegationTrust#getTrustorGoal <em>Trustor Goal</em>}</li>
 *   <li>{@link iqtool.delegationTrust#getTrusteeGoal <em>Trustee Goal</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getdelegationTrust()
 * @model
 * @generated
 */
public interface delegationTrust extends EObject {
	/**
	 * Returns the value of the '<em><b>Trustlevel</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.trustLevel}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trustlevel</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trustlevel</em>' attribute.
	 * @see iqtool.trustLevel
	 * @see #setTrustlevel(trustLevel)
	 * @see iqtool.IqtoolPackage#getdelegationTrust_Trustlevel()
	 * @model
	 * @generated
	 */
	trustLevel getTrustlevel();

	/**
	 * Sets the value of the '{@link iqtool.delegationTrust#getTrustlevel <em>Trustlevel</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trustlevel</em>' attribute.
	 * @see iqtool.trustLevel
	 * @see #getTrustlevel()
	 * @generated
	 */
	void setTrustlevel(trustLevel value);

	/**
	 * Returns the value of the '<em><b>Trustum Goal</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trustum Goal</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trustum Goal</em>' reference.
	 * @see #setTrustumGoal(goal)
	 * @see iqtool.IqtoolPackage#getdelegationTrust_TrustumGoal()
	 * @model
	 * @generated
	 */
	goal getTrustumGoal();

	/**
	 * Sets the value of the '{@link iqtool.delegationTrust#getTrustumGoal <em>Trustum Goal</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trustum Goal</em>' reference.
	 * @see #getTrustumGoal()
	 * @generated
	 */
	void setTrustumGoal(goal value);

	/**
	 * Returns the value of the '<em><b>Trustor Goal</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trustor Goal</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trustor Goal</em>' reference.
	 * @see #setTrustorGoal(actor)
	 * @see iqtool.IqtoolPackage#getdelegationTrust_TrustorGoal()
	 * @model
	 * @generated
	 */
	actor getTrustorGoal();

	/**
	 * Sets the value of the '{@link iqtool.delegationTrust#getTrustorGoal <em>Trustor Goal</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trustor Goal</em>' reference.
	 * @see #getTrustorGoal()
	 * @generated
	 */
	void setTrustorGoal(actor value);

	/**
	 * Returns the value of the '<em><b>Trustee Goal</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trustee Goal</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trustee Goal</em>' reference.
	 * @see #setTrusteeGoal(actor)
	 * @see iqtool.IqtoolPackage#getdelegationTrust_TrusteeGoal()
	 * @model
	 * @generated
	 */
	actor getTrusteeGoal();

	/**
	 * Sets the value of the '{@link iqtool.delegationTrust#getTrusteeGoal <em>Trustee Goal</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trustee Goal</em>' reference.
	 * @see #getTrusteeGoal()
	 * @generated
	 */
	void setTrusteeGoal(actor value);

} // delegationTrust
