/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.goal;
import iqtool.startPostion;

import java.util.Collection;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>start Postion</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.startPostionImpl#getInarc <em>Inarc</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class startPostionImpl extends positionImpl implements startPostion {
	/**
	 * The cached value of the '{@link #getInarc() <em>Inarc</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInarc()
	 * @generated
	 * @ordered
	 */
	protected EList inarc;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected startPostionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.START_POSTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getInarc() {
		if (inarc == null) {
			inarc = new EObjectResolvingEList(goal.class, this, IqtoolPackage.START_POSTION__INARC);
		}
		return inarc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.START_POSTION__INARC:
				return getInarc();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.START_POSTION__INARC:
				getInarc().clear();
				getInarc().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.START_POSTION__INARC:
				getInarc().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.START_POSTION__INARC:
				return inarc != null && !inarc.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //startPostionImpl
