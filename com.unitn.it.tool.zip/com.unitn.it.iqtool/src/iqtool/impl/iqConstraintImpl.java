/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.iqConstraint;
import iqtool.iqConstraintType;
import iqtool.softgoal;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>iq Constraint</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.iqConstraintImpl#getType <em>Type</em>}</li>
 *   <li>{@link iqtool.impl.iqConstraintImpl#getApproximate <em>Approximate</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class iqConstraintImpl extends MinimalEObjectImpl.Container implements iqConstraint {
	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final iqConstraintType TYPE_EDEFAULT = iqConstraintType.ACCURACY_LITERAL;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected iqConstraintType type = TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getApproximate() <em>Approximate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getApproximate()
	 * @generated
	 * @ordered
	 */
	protected softgoal approximate;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected iqConstraintImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.IQ_CONSTRAINT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public iqConstraintType getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(iqConstraintType newType) {
		iqConstraintType oldType = type;
		type = newType == null ? TYPE_EDEFAULT : newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.IQ_CONSTRAINT__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public softgoal getApproximate() {
		if (approximate != null && approximate.eIsProxy()) {
			InternalEObject oldApproximate = (InternalEObject)approximate;
			approximate = (softgoal)eResolveProxy(oldApproximate);
			if (approximate != oldApproximate) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.IQ_CONSTRAINT__APPROXIMATE, oldApproximate, approximate));
			}
		}
		return approximate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public softgoal basicGetApproximate() {
		return approximate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setApproximate(softgoal newApproximate) {
		softgoal oldApproximate = approximate;
		approximate = newApproximate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.IQ_CONSTRAINT__APPROXIMATE, oldApproximate, approximate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.IQ_CONSTRAINT__TYPE:
				return getType();
			case IqtoolPackage.IQ_CONSTRAINT__APPROXIMATE:
				if (resolve) return getApproximate();
				return basicGetApproximate();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.IQ_CONSTRAINT__TYPE:
				setType((iqConstraintType)newValue);
				return;
			case IqtoolPackage.IQ_CONSTRAINT__APPROXIMATE:
				setApproximate((softgoal)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.IQ_CONSTRAINT__TYPE:
				setType(TYPE_EDEFAULT);
				return;
			case IqtoolPackage.IQ_CONSTRAINT__APPROXIMATE:
				setApproximate((softgoal)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.IQ_CONSTRAINT__TYPE:
				return type != TYPE_EDEFAULT;
			case IqtoolPackage.IQ_CONSTRAINT__APPROXIMATE:
				return approximate != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (type: ");
		result.append(type);
		result.append(')');
		return result.toString();
	}

} //iqConstraintImpl
