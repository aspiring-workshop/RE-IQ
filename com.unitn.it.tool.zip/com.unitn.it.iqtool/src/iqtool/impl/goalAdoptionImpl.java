/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.goal;
import iqtool.goalAdoption;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>goal Adoption</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.goalAdoptionImpl#getAdoptionOfGoal <em>Adoption Of Goal</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class goalAdoptionImpl extends adoptionImpl implements goalAdoption {
	/**
	 * The cached value of the '{@link #getAdoptionOfGoal() <em>Adoption Of Goal</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAdoptionOfGoal()
	 * @generated
	 * @ordered
	 */
	protected goal adoptionOfGoal;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected goalAdoptionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.GOAL_ADOPTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goal getAdoptionOfGoal() {
		if (adoptionOfGoal != null && adoptionOfGoal.eIsProxy()) {
			InternalEObject oldAdoptionOfGoal = (InternalEObject)adoptionOfGoal;
			adoptionOfGoal = (goal)eResolveProxy(oldAdoptionOfGoal);
			if (adoptionOfGoal != oldAdoptionOfGoal) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.GOAL_ADOPTION__ADOPTION_OF_GOAL, oldAdoptionOfGoal, adoptionOfGoal));
			}
		}
		return adoptionOfGoal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goal basicGetAdoptionOfGoal() {
		return adoptionOfGoal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAdoptionOfGoal(goal newAdoptionOfGoal) {
		goal oldAdoptionOfGoal = adoptionOfGoal;
		adoptionOfGoal = newAdoptionOfGoal;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.GOAL_ADOPTION__ADOPTION_OF_GOAL, oldAdoptionOfGoal, adoptionOfGoal));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.GOAL_ADOPTION__ADOPTION_OF_GOAL:
				if (resolve) return getAdoptionOfGoal();
				return basicGetAdoptionOfGoal();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.GOAL_ADOPTION__ADOPTION_OF_GOAL:
				setAdoptionOfGoal((goal)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.GOAL_ADOPTION__ADOPTION_OF_GOAL:
				setAdoptionOfGoal((goal)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.GOAL_ADOPTION__ADOPTION_OF_GOAL:
				return adoptionOfGoal != null;
		}
		return super.eIsSet(featureID);
	}

} //goalAdoptionImpl
