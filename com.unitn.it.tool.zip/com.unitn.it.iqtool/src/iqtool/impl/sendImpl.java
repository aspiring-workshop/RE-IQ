/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.actor;
import iqtool.goal;
import iqtool.information;
import iqtool.send;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>send</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.sendImpl#getTime <em>Time</em>}</li>
 *   <li>{@link iqtool.impl.sendImpl#getSendOf <em>Send Of</em>}</li>
 *   <li>{@link iqtool.impl.sendImpl#getSendBy <em>Send By</em>}</li>
 *   <li>{@link iqtool.impl.sendImpl#getSendTo <em>Send To</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class sendImpl extends MinimalEObjectImpl.Container implements send {
	/**
	 * The default value of the '{@link #getTime() <em>Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTime()
	 * @generated
	 * @ordered
	 */
	protected static final int TIME_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getTime() <em>Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTime()
	 * @generated
	 * @ordered
	 */
	protected int time = TIME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSendOf() <em>Send Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSendOf()
	 * @generated
	 * @ordered
	 */
	protected information sendOf;

	/**
	 * The cached value of the '{@link #getSendBy() <em>Send By</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSendBy()
	 * @generated
	 * @ordered
	 */
	protected goal sendBy;

	/**
	 * The cached value of the '{@link #getSendTo() <em>Send To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSendTo()
	 * @generated
	 * @ordered
	 */
	protected actor sendTo;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected sendImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.SEND;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTime() {
		return time;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTime(int newTime) {
		int oldTime = time;
		time = newTime;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.SEND__TIME, oldTime, time));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information getSendOf() {
		if (sendOf != null && sendOf.eIsProxy()) {
			InternalEObject oldSendOf = (InternalEObject)sendOf;
			sendOf = (information)eResolveProxy(oldSendOf);
			if (sendOf != oldSendOf) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.SEND__SEND_OF, oldSendOf, sendOf));
			}
		}
		return sendOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information basicGetSendOf() {
		return sendOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSendOf(information newSendOf) {
		information oldSendOf = sendOf;
		sendOf = newSendOf;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.SEND__SEND_OF, oldSendOf, sendOf));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goal getSendBy() {
		if (sendBy != null && sendBy.eIsProxy()) {
			InternalEObject oldSendBy = (InternalEObject)sendBy;
			sendBy = (goal)eResolveProxy(oldSendBy);
			if (sendBy != oldSendBy) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.SEND__SEND_BY, oldSendBy, sendBy));
			}
		}
		return sendBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goal basicGetSendBy() {
		return sendBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSendBy(goal newSendBy) {
		goal oldSendBy = sendBy;
		sendBy = newSendBy;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.SEND__SEND_BY, oldSendBy, sendBy));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getSendTo() {
		if (sendTo != null && sendTo.eIsProxy()) {
			InternalEObject oldSendTo = (InternalEObject)sendTo;
			sendTo = (actor)eResolveProxy(oldSendTo);
			if (sendTo != oldSendTo) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.SEND__SEND_TO, oldSendTo, sendTo));
			}
		}
		return sendTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetSendTo() {
		return sendTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSendTo(actor newSendTo) {
		actor oldSendTo = sendTo;
		sendTo = newSendTo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.SEND__SEND_TO, oldSendTo, sendTo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.SEND__TIME:
				return new Integer(getTime());
			case IqtoolPackage.SEND__SEND_OF:
				if (resolve) return getSendOf();
				return basicGetSendOf();
			case IqtoolPackage.SEND__SEND_BY:
				if (resolve) return getSendBy();
				return basicGetSendBy();
			case IqtoolPackage.SEND__SEND_TO:
				if (resolve) return getSendTo();
				return basicGetSendTo();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.SEND__TIME:
				setTime(((Integer)newValue).intValue());
				return;
			case IqtoolPackage.SEND__SEND_OF:
				setSendOf((information)newValue);
				return;
			case IqtoolPackage.SEND__SEND_BY:
				setSendBy((goal)newValue);
				return;
			case IqtoolPackage.SEND__SEND_TO:
				setSendTo((actor)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.SEND__TIME:
				setTime(TIME_EDEFAULT);
				return;
			case IqtoolPackage.SEND__SEND_OF:
				setSendOf((information)null);
				return;
			case IqtoolPackage.SEND__SEND_BY:
				setSendBy((goal)null);
				return;
			case IqtoolPackage.SEND__SEND_TO:
				setSendTo((actor)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.SEND__TIME:
				return time != TIME_EDEFAULT;
			case IqtoolPackage.SEND__SEND_OF:
				return sendOf != null;
			case IqtoolPackage.SEND__SEND_BY:
				return sendBy != null;
			case IqtoolPackage.SEND__SEND_TO:
				return sendTo != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (time: ");
		result.append(time);
		result.append(')');
		return result.toString();
	}

} //sendImpl
