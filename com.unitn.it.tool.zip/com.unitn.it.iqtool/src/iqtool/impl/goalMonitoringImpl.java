/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.goal;
import iqtool.goalMonitoring;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>goal Monitoring</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.goalMonitoringImpl#getMonitoringOfGoal <em>Monitoring Of Goal</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class goalMonitoringImpl extends monitoringImpl implements goalMonitoring {
	/**
	 * The cached value of the '{@link #getMonitoringOfGoal() <em>Monitoring Of Goal</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMonitoringOfGoal()
	 * @generated
	 * @ordered
	 */
	protected goal monitoringOfGoal;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected goalMonitoringImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.GOAL_MONITORING;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goal getMonitoringOfGoal() {
		if (monitoringOfGoal != null && monitoringOfGoal.eIsProxy()) {
			InternalEObject oldMonitoringOfGoal = (InternalEObject)monitoringOfGoal;
			monitoringOfGoal = (goal)eResolveProxy(oldMonitoringOfGoal);
			if (monitoringOfGoal != oldMonitoringOfGoal) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.GOAL_MONITORING__MONITORING_OF_GOAL, oldMonitoringOfGoal, monitoringOfGoal));
			}
		}
		return monitoringOfGoal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goal basicGetMonitoringOfGoal() {
		return monitoringOfGoal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMonitoringOfGoal(goal newMonitoringOfGoal) {
		goal oldMonitoringOfGoal = monitoringOfGoal;
		monitoringOfGoal = newMonitoringOfGoal;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.GOAL_MONITORING__MONITORING_OF_GOAL, oldMonitoringOfGoal, monitoringOfGoal));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.GOAL_MONITORING__MONITORING_OF_GOAL:
				if (resolve) return getMonitoringOfGoal();
				return basicGetMonitoringOfGoal();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.GOAL_MONITORING__MONITORING_OF_GOAL:
				setMonitoringOfGoal((goal)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.GOAL_MONITORING__MONITORING_OF_GOAL:
				setMonitoringOfGoal((goal)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.GOAL_MONITORING__MONITORING_OF_GOAL:
				return monitoringOfGoal != null;
		}
		return super.eIsSet(featureID);
	}

} //goalMonitoringImpl
