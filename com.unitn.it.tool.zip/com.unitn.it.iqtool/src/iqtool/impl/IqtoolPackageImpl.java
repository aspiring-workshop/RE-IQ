/**
 */
package iqtool.impl;

import iqtool.InformationAdoption;
import iqtool.IqtoolFactory;
import iqtool.IqtoolPackage;
import iqtool.actor;
import iqtool.adoption;
import iqtool.agent;
import iqtool.betweenPostion;
import iqtool.delegationTrust;
import iqtool.diagram;
import iqtool.endPostion;
import iqtool.generalGoal;
import iqtool.general_information;
import iqtool.goal;
import iqtool.goalAdoption;
import iqtool.goalDelegation;
import iqtool.goalMonitoring;
import iqtool.goalThreat;
import iqtool.infoProvision;
import iqtool.information;
import iqtool.informationMonitoring;
import iqtool.informationThreat;
import iqtool.instanceGoal;
import iqtool.instanceInformation;
import iqtool.iqConstraint;
import iqtool.iqConstraintType;
import iqtool.modifyPermType;
import iqtool.monitoring;
import iqtool.permDelegation;
import iqtool.position;
import iqtool.produce;
import iqtool.producePermType;
import iqtool.produceTrust;
import iqtool.producetype;
import iqtool.provisionType;
import iqtool.purposeOfUseTypes;
import iqtool.read;
import iqtool.readPermType;
import iqtool.role;
import iqtool.rtype;
import iqtool.scope;
import iqtool.send;
import iqtool.sendPermType;
import iqtool.softgoal;
import iqtool.softgoalType;
import iqtool.startPostion;
import iqtool.threat;
import iqtool.trustLevel;
import iqtool.trustPermDelegation;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.impl.EPackageImpl;
import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class IqtoolPackageImpl extends EPackageImpl implements IqtoolPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass actorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass diagramEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass roleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass agentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass permDelegationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass startPostionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass readEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass positionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass endPostionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sendEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass goalDelegationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass delegationTrustEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass betweenPostionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass infoProvisionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass trustPermDelegationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass informationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass scopeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass goalEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass produceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass produceTrustEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass softgoalEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass iqConstraintEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass instanceGoalEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass generalGoalEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass instanceInformationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass general_informationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass threatEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass informationThreatEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass goalThreatEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass monitoringEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass informationMonitoringEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass goalMonitoringEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass adoptionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass informationAdoptionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass goalAdoptionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum purposeOfUseTypesEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum sendPermTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum modifyPermTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum trustLevelEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum producePermTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum provisionTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum readPermTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum producetypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum softgoalTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum iqConstraintTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum rtypeEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see iqtool.IqtoolPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private IqtoolPackageImpl() {
		super(eNS_URI, IqtoolFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link IqtoolPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static IqtoolPackage init() {
		if (isInited) return (IqtoolPackage)EPackage.Registry.INSTANCE.getEPackage(IqtoolPackage.eNS_URI);

		// Obtain or create and register package
		IqtoolPackageImpl theIqtoolPackage = (IqtoolPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof IqtoolPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new IqtoolPackageImpl());

		isInited = true;

		// Initialize simple dependencies
		XMLTypePackage.eINSTANCE.eClass();

		// Create package meta-data objects
		theIqtoolPackage.createPackageContents();

		// Initialize created meta-data
		theIqtoolPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theIqtoolPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(IqtoolPackage.eNS_URI, theIqtoolPackage);
		return theIqtoolPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getactor() {
		return actorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getactor_Name() {
		return (EAttribute)actorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getactor_Aims() {
		return (EReference)actorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getactor_Own() {
		return (EReference)actorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getactor_CapableOfThreat() {
		return (EReference)actorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getactor_IncapableOfThreat() {
		return (EReference)actorEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getdiagram() {
		return diagramEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_ActorElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_GoalElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_InfoElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_ScopeElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_DelegationElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_ProvisionElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_DelegationTrustElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_AgentElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_RoleElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_PermDeleElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_TrustPermDeleElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_ReadElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_SendElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_PostionElelement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_ProduceElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_SpositionElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_BpositionElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_EpositionElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_ProduceTrustElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(18);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_SoftgoalElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(19);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_IqConstraintElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(20);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_ThreatElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(21);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_InstanceGoalElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(22);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_GeneralGoalElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(23);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_InstanceInformationElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(24);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_GeneralInformationElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(25);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_GoalThreatElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(26);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_InformationThreatElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(27);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_MonitoringElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(28);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_InformationMonitoringElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(29);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_GoalMonitoringElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(30);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_AdoptionElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(31);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_GoalAdoptionElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(32);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdiagram_InformationAdoptionElement() {
		return (EReference)diagramEClass.getEStructuralFeatures().get(33);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getrole() {
		return roleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getrole_Isa() {
		return (EReference)roleEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getrole_Is_capable() {
		return (EReference)roleEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getagent() {
		return agentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getagent_Play() {
		return (EReference)agentEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getpermDelegation() {
		return permDelegationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getpermDelegation_PermOver() {
		return (EReference)permDelegationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getpermDelegation_PermDeleFrom() {
		return (EReference)permDelegationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getpermDelegation_PermDeleTo() {
		return (EReference)permDelegationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getpermDelegation_ReadPerm() {
		return (EAttribute)permDelegationEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getpermDelegation_ProducePerm() {
		return (EAttribute)permDelegationEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getpermDelegation_ModifyPerm() {
		return (EAttribute)permDelegationEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getpermDelegation_SendPerm() {
		return (EAttribute)permDelegationEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getstartPostion() {
		return startPostionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getstartPostion_Inarc() {
		return (EReference)startPostionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getread() {
		return readEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getread_Pou() {
		return (EAttribute)readEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getread_ReadOf() {
		return (EReference)readEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getread_ReadBy() {
		return (EReference)readEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getread_ReadType() {
		return (EAttribute)readEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getposition() {
		return positionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getposition_Name() {
		return (EAttribute)positionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getendPostion() {
		return endPostionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getsend() {
		return sendEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getsend_Time() {
		return (EAttribute)sendEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getsend_SendOf() {
		return (EReference)sendEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getsend_SendBy() {
		return (EReference)sendEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getsend_SendTo() {
		return (EReference)sendEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getgoalDelegation() {
		return goalDelegationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getgoalDelegation_DelegationOf() {
		return (EReference)goalDelegationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getgoalDelegation_DelegationFrom() {
		return (EReference)goalDelegationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getgoalDelegation_DelegationTo() {
		return (EReference)goalDelegationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getdelegationTrust() {
		return delegationTrustEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getdelegationTrust_Trustlevel() {
		return (EAttribute)delegationTrustEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdelegationTrust_TrustumGoal() {
		return (EReference)delegationTrustEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdelegationTrust_TrustorGoal() {
		return (EReference)delegationTrustEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdelegationTrust_TrusteeGoal() {
		return (EReference)delegationTrustEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getbetweenPostion() {
		return betweenPostionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getbetweenPostion_Outarc() {
		return (EReference)betweenPostionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getinfoProvision() {
		return infoProvisionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getinfoProvision_ProvisionOf() {
		return (EReference)infoProvisionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getinfoProvision_ProvisionFrom() {
		return (EReference)infoProvisionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getinfoProvision_ProvisionTo() {
		return (EReference)infoProvisionEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getinfoProvision_Type() {
		return (EAttribute)infoProvisionEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getinfoProvision_Time() {
		return (EAttribute)infoProvisionEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass gettrustPermDelegation() {
		return trustPermDelegationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference gettrustPermDelegation_TrustPermDeleTo() {
		return (EReference)trustPermDelegationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference gettrustPermDelegation_TrustPermDeleFrom() {
		return (EReference)trustPermDelegationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference gettrustPermDelegation_TrustPermDeleOf() {
		return (EReference)trustPermDelegationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute gettrustPermDelegation_Trustprodue() {
		return (EAttribute)trustPermDelegationEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute gettrustPermDelegation_Trustread() {
		return (EAttribute)trustPermDelegationEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute gettrustPermDelegation_Trustsend() {
		return (EAttribute)trustPermDelegationEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute gettrustPermDelegation_Trustmodify() {
		return (EAttribute)trustPermDelegationEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getinformation() {
		return informationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getinformation_Name() {
		return (EAttribute)informationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getinformation_Volatility() {
		return (EAttribute)informationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getinformation_SubItem() {
		return (EReference)informationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getscope() {
		return scopeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getscope_Contains() {
		return (EReference)scopeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getgoal() {
		return goalEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getgoal_Name() {
		return (EAttribute)goalEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getgoal_Ordecomposition() {
		return (EReference)goalEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getgoal_Anddecomposition() {
		return (EReference)goalEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getgoal_Modify() {
		return (EReference)goalEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getgoal_Outarc() {
		return (EReference)goalEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getgoal_Inarc() {
		return (EReference)goalEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getproduce() {
		return produceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getproduce_ProduceBy() {
		return (EReference)produceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getproduce_ProduceOf() {
		return (EReference)produceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getproduce_ProduceType() {
		return (EAttribute)produceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getproduceTrust() {
		return produceTrustEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getproduceTrust_Trustlevel() {
		return (EAttribute)produceTrustEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getproduceTrust_ProduceTrustor() {
		return (EReference)produceTrustEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getproduceTrust_ProduceTrustee() {
		return (EReference)produceTrustEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getproduceTrust_ProduceTrustOf() {
		return (EReference)produceTrustEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getsoftgoal() {
		return softgoalEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getsoftgoal_Anddecomposition() {
		return (EReference)softgoalEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getsoftgoal_SoftGoalOf() {
		return (EReference)softgoalEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getsoftgoal_SoftgoalTarget() {
		return (EReference)softgoalEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getsoftgoal_SoftgoalConcerning() {
		return (EReference)softgoalEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getsoftgoal_Type() {
		return (EAttribute)softgoalEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getiqConstraint() {
		return iqConstraintEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getiqConstraint_Type() {
		return (EAttribute)iqConstraintEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getiqConstraint_Approximate() {
		return (EReference)iqConstraintEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getinstanceGoal() {
		return instanceGoalEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getinstanceGoal_Instance() {
		return (EReference)instanceGoalEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getgeneralGoal() {
		return generalGoalEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getinstanceInformation() {
		return instanceInformationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getinstanceInformation_Instance() {
		return (EReference)instanceInformationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getgeneral_information() {
		return general_informationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getthreat() {
		return threatEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getthreat_Name() {
		return (EAttribute)threatEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getthreat_PosContribute() {
		return (EReference)threatEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getthreat_NegContribute() {
		return (EReference)threatEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getinformationThreat() {
		return informationThreatEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getinformationThreat_ThreatInformation() {
		return (EReference)informationThreatEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getgoalThreat() {
		return goalThreatEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getgoalThreat_GoalThreat() {
		return (EReference)goalThreatEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getmonitoring() {
		return monitoringEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getmonitoring_Monitor() {
		return (EReference)monitoringEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getmonitoring_Monitored() {
		return (EReference)monitoringEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getinformationMonitoring() {
		return informationMonitoringEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getinformationMonitoring_MonitoringOfInformation() {
		return (EReference)informationMonitoringEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getgoalMonitoring() {
		return goalMonitoringEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getgoalMonitoring_MonitoringOfGoal() {
		return (EReference)goalMonitoringEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getadoption() {
		return adoptionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getadoption_AdoptionTo() {
		return (EReference)adoptionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getadoption_AdoptionFrom() {
		return (EReference)adoptionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInformationAdoption() {
		return informationAdoptionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getInformationAdoption_AdoptionOfInformation() {
		return (EReference)informationAdoptionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getgoalAdoption() {
		return goalAdoptionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getgoalAdoption_AdoptionOfGoal() {
		return (EReference)goalAdoptionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getpurposeOfUseTypes() {
		return purposeOfUseTypesEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getsendPermType() {
		return sendPermTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getmodifyPermType() {
		return modifyPermTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum gettrustLevel() {
		return trustLevelEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getproducePermType() {
		return producePermTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getprovisionType() {
		return provisionTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getreadPermType() {
		return readPermTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getproducetype() {
		return producetypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getsoftgoalType() {
		return softgoalTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getiqConstraintType() {
		return iqConstraintTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getrtype() {
		return rtypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IqtoolFactory getIqtoolFactory() {
		return (IqtoolFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		actorEClass = createEClass(ACTOR);
		createEAttribute(actorEClass, ACTOR__NAME);
		createEReference(actorEClass, ACTOR__AIMS);
		createEReference(actorEClass, ACTOR__OWN);
		createEReference(actorEClass, ACTOR__CAPABLE_OF_THREAT);
		createEReference(actorEClass, ACTOR__INCAPABLE_OF_THREAT);

		diagramEClass = createEClass(DIAGRAM);
		createEReference(diagramEClass, DIAGRAM__ACTOR_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__GOAL_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__INFO_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__SCOPE_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__DELEGATION_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__PROVISION_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__DELEGATION_TRUST_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__AGENT_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__ROLE_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__PERM_DELE_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__TRUST_PERM_DELE_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__READ_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__SEND_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__POSTION_ELELEMENT);
		createEReference(diagramEClass, DIAGRAM__PRODUCE_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__SPOSITION_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__BPOSITION_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__EPOSITION_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__PRODUCE_TRUST_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__SOFTGOAL_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__IQ_CONSTRAINT_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__THREAT_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__INSTANCE_GOAL_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__GENERAL_GOAL_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__INSTANCE_INFORMATION_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__GENERAL_INFORMATION_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__GOAL_THREAT_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__INFORMATION_THREAT_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__MONITORING_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__INFORMATION_MONITORING_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__GOAL_MONITORING_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__ADOPTION_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__GOAL_ADOPTION_ELEMENT);
		createEReference(diagramEClass, DIAGRAM__INFORMATION_ADOPTION_ELEMENT);

		roleEClass = createEClass(ROLE);
		createEReference(roleEClass, ROLE__ISA);
		createEReference(roleEClass, ROLE__IS_CAPABLE);

		agentEClass = createEClass(AGENT);
		createEReference(agentEClass, AGENT__PLAY);

		permDelegationEClass = createEClass(PERM_DELEGATION);
		createEReference(permDelegationEClass, PERM_DELEGATION__PERM_OVER);
		createEReference(permDelegationEClass, PERM_DELEGATION__PERM_DELE_FROM);
		createEReference(permDelegationEClass, PERM_DELEGATION__PERM_DELE_TO);
		createEAttribute(permDelegationEClass, PERM_DELEGATION__READ_PERM);
		createEAttribute(permDelegationEClass, PERM_DELEGATION__PRODUCE_PERM);
		createEAttribute(permDelegationEClass, PERM_DELEGATION__MODIFY_PERM);
		createEAttribute(permDelegationEClass, PERM_DELEGATION__SEND_PERM);

		startPostionEClass = createEClass(START_POSTION);
		createEReference(startPostionEClass, START_POSTION__INARC);

		readEClass = createEClass(READ);
		createEAttribute(readEClass, READ__POU);
		createEReference(readEClass, READ__READ_OF);
		createEReference(readEClass, READ__READ_BY);
		createEAttribute(readEClass, READ__READ_TYPE);

		positionEClass = createEClass(POSITION);
		createEAttribute(positionEClass, POSITION__NAME);

		endPostionEClass = createEClass(END_POSTION);

		sendEClass = createEClass(SEND);
		createEAttribute(sendEClass, SEND__TIME);
		createEReference(sendEClass, SEND__SEND_OF);
		createEReference(sendEClass, SEND__SEND_BY);
		createEReference(sendEClass, SEND__SEND_TO);

		goalDelegationEClass = createEClass(GOAL_DELEGATION);
		createEReference(goalDelegationEClass, GOAL_DELEGATION__DELEGATION_OF);
		createEReference(goalDelegationEClass, GOAL_DELEGATION__DELEGATION_FROM);
		createEReference(goalDelegationEClass, GOAL_DELEGATION__DELEGATION_TO);

		delegationTrustEClass = createEClass(DELEGATION_TRUST);
		createEAttribute(delegationTrustEClass, DELEGATION_TRUST__TRUSTLEVEL);
		createEReference(delegationTrustEClass, DELEGATION_TRUST__TRUSTUM_GOAL);
		createEReference(delegationTrustEClass, DELEGATION_TRUST__TRUSTOR_GOAL);
		createEReference(delegationTrustEClass, DELEGATION_TRUST__TRUSTEE_GOAL);

		betweenPostionEClass = createEClass(BETWEEN_POSTION);
		createEReference(betweenPostionEClass, BETWEEN_POSTION__OUTARC);

		infoProvisionEClass = createEClass(INFO_PROVISION);
		createEReference(infoProvisionEClass, INFO_PROVISION__PROVISION_OF);
		createEReference(infoProvisionEClass, INFO_PROVISION__PROVISION_FROM);
		createEReference(infoProvisionEClass, INFO_PROVISION__PROVISION_TO);
		createEAttribute(infoProvisionEClass, INFO_PROVISION__TYPE);
		createEAttribute(infoProvisionEClass, INFO_PROVISION__TIME);

		trustPermDelegationEClass = createEClass(TRUST_PERM_DELEGATION);
		createEReference(trustPermDelegationEClass, TRUST_PERM_DELEGATION__TRUST_PERM_DELE_TO);
		createEReference(trustPermDelegationEClass, TRUST_PERM_DELEGATION__TRUST_PERM_DELE_FROM);
		createEReference(trustPermDelegationEClass, TRUST_PERM_DELEGATION__TRUST_PERM_DELE_OF);
		createEAttribute(trustPermDelegationEClass, TRUST_PERM_DELEGATION__TRUSTPRODUE);
		createEAttribute(trustPermDelegationEClass, TRUST_PERM_DELEGATION__TRUSTREAD);
		createEAttribute(trustPermDelegationEClass, TRUST_PERM_DELEGATION__TRUSTSEND);
		createEAttribute(trustPermDelegationEClass, TRUST_PERM_DELEGATION__TRUSTMODIFY);

		informationEClass = createEClass(INFORMATION);
		createEAttribute(informationEClass, INFORMATION__NAME);
		createEAttribute(informationEClass, INFORMATION__VOLATILITY);
		createEReference(informationEClass, INFORMATION__SUB_ITEM);

		scopeEClass = createEClass(SCOPE);
		createEReference(scopeEClass, SCOPE__CONTAINS);

		goalEClass = createEClass(GOAL);
		createEAttribute(goalEClass, GOAL__NAME);
		createEReference(goalEClass, GOAL__ORDECOMPOSITION);
		createEReference(goalEClass, GOAL__ANDDECOMPOSITION);
		createEReference(goalEClass, GOAL__MODIFY);
		createEReference(goalEClass, GOAL__OUTARC);
		createEReference(goalEClass, GOAL__INARC);

		produceEClass = createEClass(PRODUCE);
		createEReference(produceEClass, PRODUCE__PRODUCE_BY);
		createEReference(produceEClass, PRODUCE__PRODUCE_OF);
		createEAttribute(produceEClass, PRODUCE__PRODUCE_TYPE);

		produceTrustEClass = createEClass(PRODUCE_TRUST);
		createEAttribute(produceTrustEClass, PRODUCE_TRUST__TRUSTLEVEL);
		createEReference(produceTrustEClass, PRODUCE_TRUST__PRODUCE_TRUSTOR);
		createEReference(produceTrustEClass, PRODUCE_TRUST__PRODUCE_TRUSTEE);
		createEReference(produceTrustEClass, PRODUCE_TRUST__PRODUCE_TRUST_OF);

		softgoalEClass = createEClass(SOFTGOAL);
		createEReference(softgoalEClass, SOFTGOAL__ANDDECOMPOSITION);
		createEReference(softgoalEClass, SOFTGOAL__SOFT_GOAL_OF);
		createEReference(softgoalEClass, SOFTGOAL__SOFTGOAL_TARGET);
		createEReference(softgoalEClass, SOFTGOAL__SOFTGOAL_CONCERNING);
		createEAttribute(softgoalEClass, SOFTGOAL__TYPE);

		iqConstraintEClass = createEClass(IQ_CONSTRAINT);
		createEAttribute(iqConstraintEClass, IQ_CONSTRAINT__TYPE);
		createEReference(iqConstraintEClass, IQ_CONSTRAINT__APPROXIMATE);

		instanceGoalEClass = createEClass(INSTANCE_GOAL);
		createEReference(instanceGoalEClass, INSTANCE_GOAL__INSTANCE);

		generalGoalEClass = createEClass(GENERAL_GOAL);

		instanceInformationEClass = createEClass(INSTANCE_INFORMATION);
		createEReference(instanceInformationEClass, INSTANCE_INFORMATION__INSTANCE);

		general_informationEClass = createEClass(GENERAL_INFORMATION);

		threatEClass = createEClass(THREAT);
		createEAttribute(threatEClass, THREAT__NAME);
		createEReference(threatEClass, THREAT__POS_CONTRIBUTE);
		createEReference(threatEClass, THREAT__NEG_CONTRIBUTE);

		informationThreatEClass = createEClass(INFORMATION_THREAT);
		createEReference(informationThreatEClass, INFORMATION_THREAT__THREAT_INFORMATION);

		goalThreatEClass = createEClass(GOAL_THREAT);
		createEReference(goalThreatEClass, GOAL_THREAT__GOAL_THREAT);

		monitoringEClass = createEClass(MONITORING);
		createEReference(monitoringEClass, MONITORING__MONITOR);
		createEReference(monitoringEClass, MONITORING__MONITORED);

		informationMonitoringEClass = createEClass(INFORMATION_MONITORING);
		createEReference(informationMonitoringEClass, INFORMATION_MONITORING__MONITORING_OF_INFORMATION);

		goalMonitoringEClass = createEClass(GOAL_MONITORING);
		createEReference(goalMonitoringEClass, GOAL_MONITORING__MONITORING_OF_GOAL);

		adoptionEClass = createEClass(ADOPTION);
		createEReference(adoptionEClass, ADOPTION__ADOPTION_TO);
		createEReference(adoptionEClass, ADOPTION__ADOPTION_FROM);

		informationAdoptionEClass = createEClass(INFORMATION_ADOPTION);
		createEReference(informationAdoptionEClass, INFORMATION_ADOPTION__ADOPTION_OF_INFORMATION);

		goalAdoptionEClass = createEClass(GOAL_ADOPTION);
		createEReference(goalAdoptionEClass, GOAL_ADOPTION__ADOPTION_OF_GOAL);

		// Create enums
		purposeOfUseTypesEEnum = createEEnum(PURPOSE_OF_USE_TYPES);
		sendPermTypeEEnum = createEEnum(SEND_PERM_TYPE);
		modifyPermTypeEEnum = createEEnum(MODIFY_PERM_TYPE);
		trustLevelEEnum = createEEnum(TRUST_LEVEL);
		producePermTypeEEnum = createEEnum(PRODUCE_PERM_TYPE);
		provisionTypeEEnum = createEEnum(PROVISION_TYPE);
		readPermTypeEEnum = createEEnum(READ_PERM_TYPE);
		producetypeEEnum = createEEnum(PRODUCETYPE);
		softgoalTypeEEnum = createEEnum(SOFTGOAL_TYPE);
		iqConstraintTypeEEnum = createEEnum(IQ_CONSTRAINT_TYPE);
		rtypeEEnum = createEEnum(RTYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		XMLTypePackage theXMLTypePackage = (XMLTypePackage)EPackage.Registry.INSTANCE.getEPackage(XMLTypePackage.eNS_URI);

		// Add supertypes to classes
		roleEClass.getESuperTypes().add(this.getactor());
		agentEClass.getESuperTypes().add(this.getactor());
		startPostionEClass.getESuperTypes().add(this.getposition());
		endPostionEClass.getESuperTypes().add(this.getposition());
		betweenPostionEClass.getESuperTypes().add(this.getposition());
		instanceGoalEClass.getESuperTypes().add(this.getgoal());
		generalGoalEClass.getESuperTypes().add(this.getgoal());
		instanceInformationEClass.getESuperTypes().add(this.getinformation());
		general_informationEClass.getESuperTypes().add(this.getinformation());
		informationThreatEClass.getESuperTypes().add(this.getthreat());
		goalThreatEClass.getESuperTypes().add(this.getthreat());
		informationMonitoringEClass.getESuperTypes().add(this.getmonitoring());
		goalMonitoringEClass.getESuperTypes().add(this.getmonitoring());
		informationAdoptionEClass.getESuperTypes().add(this.getadoption());
		goalAdoptionEClass.getESuperTypes().add(this.getadoption());

		// Initialize classes and features; add operations and parameters
		initEClass(actorEClass, actor.class, "actor", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getactor_Name(), theXMLTypePackage.getString(), "name", null, 0, 1, actor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getactor_Aims(), this.getgoal(), null, "aims", null, 0, -1, actor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getactor_Own(), this.getinformation(), null, "own", null, 0, -1, actor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getactor_CapableOfThreat(), this.getthreat(), null, "capableOfThreat", null, 0, -1, actor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getactor_IncapableOfThreat(), this.getthreat(), null, "incapableOfThreat", null, 0, -1, actor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(diagramEClass, diagram.class, "diagram", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getdiagram_ActorElement(), this.getactor(), null, "actorElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_GoalElement(), this.getgoal(), null, "goalElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_InfoElement(), this.getinformation(), null, "infoElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_ScopeElement(), this.getscope(), null, "scopeElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_DelegationElement(), this.getgoalDelegation(), null, "delegationElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_ProvisionElement(), this.getinfoProvision(), null, "provisionElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_DelegationTrustElement(), this.getdelegationTrust(), null, "delegationTrustElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_AgentElement(), this.getagent(), null, "agentElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_RoleElement(), this.getrole(), null, "roleElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_PermDeleElement(), this.getpermDelegation(), null, "permDeleElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_TrustPermDeleElement(), this.gettrustPermDelegation(), null, "trustPermDeleElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_ReadElement(), this.getread(), null, "readElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_SendElement(), this.getsend(), null, "sendElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_PostionElelement(), this.getposition(), null, "postionElelement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_ProduceElement(), this.getproduce(), null, "produceElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_SpositionElement(), this.getstartPostion(), null, "spositionElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_BpositionElement(), this.getbetweenPostion(), null, "bpositionElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_EpositionElement(), this.getendPostion(), null, "epositionElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_ProduceTrustElement(), this.getproduceTrust(), null, "produceTrustElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_SoftgoalElement(), this.getsoftgoal(), null, "softgoalElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_IqConstraintElement(), this.getiqConstraint(), null, "iqConstraintElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_ThreatElement(), this.getthreat(), null, "threatElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_InstanceGoalElement(), this.getinstanceGoal(), null, "instanceGoalElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_GeneralGoalElement(), this.getgeneralGoal(), null, "generalGoalElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_InstanceInformationElement(), this.getinstanceInformation(), null, "instanceInformationElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_GeneralInformationElement(), this.getgeneral_information(), null, "generalInformationElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_GoalThreatElement(), this.getgoalThreat(), null, "goalThreatElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_InformationThreatElement(), this.getinformationThreat(), null, "informationThreatElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_MonitoringElement(), this.getmonitoring(), null, "monitoringElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_InformationMonitoringElement(), this.getgoalMonitoring(), null, "informationMonitoringElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_GoalMonitoringElement(), this.getinformationMonitoring(), null, "goalMonitoringElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_AdoptionElement(), this.getadoption(), null, "adoptionElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_GoalAdoptionElement(), this.getgoalAdoption(), null, "goalAdoptionElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdiagram_InformationAdoptionElement(), this.getInformationAdoption(), null, "informationAdoptionElement", null, 0, -1, diagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(roleEClass, role.class, "role", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getrole_Isa(), this.getrole(), null, "isa", null, 0, -1, role.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getrole_Is_capable(), this.getgoal(), null, "is_capable", null, 0, -1, role.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(agentEClass, agent.class, "agent", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getagent_Play(), this.getrole(), null, "play", null, 1, -1, agent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(permDelegationEClass, permDelegation.class, "permDelegation", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getpermDelegation_PermOver(), this.getinformation(), null, "permOver", null, 0, 1, permDelegation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getpermDelegation_PermDeleFrom(), this.getactor(), null, "permDeleFrom", null, 0, 1, permDelegation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getpermDelegation_PermDeleTo(), this.getactor(), null, "permDeleTo", null, 0, 1, permDelegation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getpermDelegation_ReadPerm(), this.getreadPermType(), "readPerm", null, 0, 1, permDelegation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getpermDelegation_ProducePerm(), this.getproducePermType(), "producePerm", null, 0, 1, permDelegation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getpermDelegation_ModifyPerm(), this.getmodifyPermType(), "modifyPerm", null, 0, 1, permDelegation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getpermDelegation_SendPerm(), this.getsendPermType(), "sendPerm", null, 0, 1, permDelegation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(startPostionEClass, startPostion.class, "startPostion", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getstartPostion_Inarc(), this.getgoal(), null, "inarc", null, 0, -1, startPostion.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(readEClass, read.class, "read", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getread_Pou(), this.getpurposeOfUseTypes(), "pou", null, 0, 1, read.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getread_ReadOf(), this.getinformation(), null, "readOf", null, 0, 1, read.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getread_ReadBy(), this.getgoal(), null, "readBy", null, 0, 1, read.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getread_ReadType(), this.getrtype(), "readType", null, 0, 1, read.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(positionEClass, position.class, "position", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getposition_Name(), theXMLTypePackage.getString(), "name", null, 0, 1, position.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(endPostionEClass, endPostion.class, "endPostion", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(sendEClass, send.class, "send", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getsend_Time(), ecorePackage.getEInt(), "time", null, 0, 1, send.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getsend_SendOf(), this.getinformation(), null, "sendOf", null, 0, 1, send.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getsend_SendBy(), this.getgoal(), null, "sendBy", null, 0, 1, send.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getsend_SendTo(), this.getactor(), null, "sendTo", null, 0, 1, send.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(goalDelegationEClass, goalDelegation.class, "goalDelegation", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getgoalDelegation_DelegationOf(), this.getgoal(), null, "delegationOf", null, 0, 1, goalDelegation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getgoalDelegation_DelegationFrom(), this.getactor(), null, "delegationFrom", null, 0, 1, goalDelegation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getgoalDelegation_DelegationTo(), this.getactor(), null, "delegationTo", null, 0, 1, goalDelegation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(delegationTrustEClass, delegationTrust.class, "delegationTrust", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getdelegationTrust_Trustlevel(), this.gettrustLevel(), "trustlevel", null, 0, 1, delegationTrust.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdelegationTrust_TrustumGoal(), this.getgoal(), null, "trustumGoal", null, 0, 1, delegationTrust.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdelegationTrust_TrustorGoal(), this.getactor(), null, "trustorGoal", null, 0, 1, delegationTrust.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdelegationTrust_TrusteeGoal(), this.getactor(), null, "trusteeGoal", null, 0, 1, delegationTrust.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(betweenPostionEClass, betweenPostion.class, "betweenPostion", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getbetweenPostion_Outarc(), this.getgoal(), null, "outarc", null, 0, -1, betweenPostion.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(infoProvisionEClass, infoProvision.class, "infoProvision", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getinfoProvision_ProvisionOf(), this.getinformation(), null, "provisionOf", null, 0, 1, infoProvision.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getinfoProvision_ProvisionFrom(), this.getactor(), null, "provisionFrom", null, 0, 1, infoProvision.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getinfoProvision_ProvisionTo(), this.getactor(), null, "provisionTo", null, 0, 1, infoProvision.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getinfoProvision_Type(), this.getprovisionType(), "type", null, 0, 1, infoProvision.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getinfoProvision_Time(), ecorePackage.getEInt(), "time", "100", 0, 1, infoProvision.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(trustPermDelegationEClass, trustPermDelegation.class, "trustPermDelegation", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(gettrustPermDelegation_TrustPermDeleTo(), this.getactor(), null, "trustPermDeleTo", null, 0, 1, trustPermDelegation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(gettrustPermDelegation_TrustPermDeleFrom(), this.getactor(), null, "trustPermDeleFrom", null, 0, 1, trustPermDelegation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(gettrustPermDelegation_TrustPermDeleOf(), this.getinformation(), null, "trustPermDeleOf", null, 0, 1, trustPermDelegation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(gettrustPermDelegation_Trustprodue(), this.gettrustLevel(), "trustprodue", null, 0, 1, trustPermDelegation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(gettrustPermDelegation_Trustread(), this.gettrustLevel(), "trustread", null, 0, 1, trustPermDelegation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(gettrustPermDelegation_Trustsend(), this.gettrustLevel(), "trustsend", null, 0, 1, trustPermDelegation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(gettrustPermDelegation_Trustmodify(), this.gettrustLevel(), "trustmodify", null, 0, 1, trustPermDelegation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(informationEClass, information.class, "information", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getinformation_Name(), theXMLTypePackage.getString(), "name", null, 0, 1, information.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getinformation_Volatility(), ecorePackage.getEInt(), "volatility", "100", 0, 1, information.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getinformation_SubItem(), this.getinformation(), null, "subItem", null, 0, 2, information.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(scopeEClass, scope.class, "scope", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getscope_Contains(), this.getgoal(), null, "contains", null, 0, -1, scope.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(goalEClass, goal.class, "goal", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getgoal_Name(), theXMLTypePackage.getString(), "name", null, 0, 1, goal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getgoal_Ordecomposition(), this.getgoal(), null, "ordecomposition", null, 0, -1, goal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getgoal_Anddecomposition(), this.getgoal(), null, "anddecomposition", null, 0, -1, goal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getgoal_Modify(), this.getinformation(), null, "modify", null, 0, -1, goal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getgoal_Outarc(), this.getendPostion(), null, "outarc", null, 0, -1, goal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getgoal_Inarc(), this.getbetweenPostion(), null, "inarc", null, 0, -1, goal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(produceEClass, produce.class, "produce", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getproduce_ProduceBy(), this.getgoal(), null, "produceBy", null, 0, 1, produce.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getproduce_ProduceOf(), this.getinformation(), null, "produceOf", null, 0, 1, produce.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getproduce_ProduceType(), this.getproducetype(), "produceType", null, 0, 1, produce.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(produceTrustEClass, produceTrust.class, "produceTrust", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getproduceTrust_Trustlevel(), this.gettrustLevel(), "trustlevel", null, 0, 1, produceTrust.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getproduceTrust_ProduceTrustor(), this.getactor(), null, "produceTrustor", null, 0, 1, produceTrust.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getproduceTrust_ProduceTrustee(), this.getactor(), null, "produceTrustee", null, 0, 1, produceTrust.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getproduceTrust_ProduceTrustOf(), this.getinformation(), null, "produceTrustOf", null, 0, 1, produceTrust.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(softgoalEClass, softgoal.class, "softgoal", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getsoftgoal_Anddecomposition(), this.getsoftgoal(), null, "anddecomposition", null, 0, 1, softgoal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getsoftgoal_SoftGoalOf(), this.getactor(), null, "softGoalOf", null, 0, -1, softgoal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getsoftgoal_SoftgoalTarget(), this.getinformation(), null, "softgoalTarget", null, 0, 1, softgoal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getsoftgoal_SoftgoalConcerning(), this.getgoal(), null, "softgoalConcerning", null, 0, 1, softgoal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getsoftgoal_Type(), this.getsoftgoalType(), "type", null, 0, 1, softgoal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(iqConstraintEClass, iqConstraint.class, "iqConstraint", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getiqConstraint_Type(), this.getiqConstraintType(), "type", null, 0, 1, iqConstraint.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getiqConstraint_Approximate(), this.getsoftgoal(), null, "approximate", null, 0, 1, iqConstraint.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(instanceGoalEClass, instanceGoal.class, "instanceGoal", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getinstanceGoal_Instance(), this.getgeneralGoal(), null, "instance", null, 1, 1, instanceGoal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(generalGoalEClass, generalGoal.class, "generalGoal", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(instanceInformationEClass, instanceInformation.class, "instanceInformation", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getinstanceInformation_Instance(), this.getgeneral_information(), null, "instance", null, 1, 1, instanceInformation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(general_informationEClass, general_information.class, "general_information", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(threatEClass, threat.class, "threat", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getthreat_Name(), theXMLTypePackage.getString(), "name", null, 0, 1, threat.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getthreat_PosContribute(), this.getgoal(), null, "posContribute", null, 0, -1, threat.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getthreat_NegContribute(), this.getgoal(), null, "negContribute", null, 0, -1, threat.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(informationThreatEClass, informationThreat.class, "informationThreat", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getinformationThreat_ThreatInformation(), this.getinformation(), null, "threatInformation", null, 0, -1, informationThreat.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(goalThreatEClass, goalThreat.class, "goalThreat", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getgoalThreat_GoalThreat(), this.getgoal(), null, "goalThreat", null, 0, -1, goalThreat.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(monitoringEClass, monitoring.class, "monitoring", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getmonitoring_Monitor(), this.getactor(), null, "monitor", null, 0, 1, monitoring.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getmonitoring_Monitored(), this.getactor(), null, "monitored", null, 0, 1, monitoring.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(informationMonitoringEClass, informationMonitoring.class, "informationMonitoring", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getinformationMonitoring_MonitoringOfInformation(), this.getinformation(), null, "monitoringOfInformation", null, 0, 1, informationMonitoring.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(goalMonitoringEClass, goalMonitoring.class, "goalMonitoring", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getgoalMonitoring_MonitoringOfGoal(), this.getgoal(), null, "monitoringOfGoal", null, 0, 1, goalMonitoring.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(adoptionEClass, adoption.class, "adoption", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getadoption_AdoptionTo(), this.getactor(), null, "adoptionTo", null, 0, 1, adoption.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getadoption_AdoptionFrom(), this.getactor(), null, "adoptionFrom", null, 0, 1, adoption.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(informationAdoptionEClass, InformationAdoption.class, "InformationAdoption", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getInformationAdoption_AdoptionOfInformation(), this.getinformation(), null, "adoptionOfInformation", null, 0, 1, InformationAdoption.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(goalAdoptionEClass, goalAdoption.class, "goalAdoption", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getgoalAdoption_AdoptionOfGoal(), this.getgoal(), null, "adoptionOfGoal", null, 0, 1, goalAdoption.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(purposeOfUseTypesEEnum, purposeOfUseTypes.class, "purposeOfUseTypes");
		addEEnumLiteral(purposeOfUseTypesEEnum, purposeOfUseTypes.TRADING_LITERAL);
		addEEnumLiteral(purposeOfUseTypesEEnum, purposeOfUseTypes.ANALYZING_LITERAL);
		addEEnumLiteral(purposeOfUseTypesEEnum, purposeOfUseTypes.CB_LITERAL);

		initEEnum(sendPermTypeEEnum, sendPermType.class, "sendPermType");
		addEEnumLiteral(sendPermTypeEEnum, sendPermType.S_LITERAL);
		addEEnumLiteral(sendPermTypeEEnum, sendPermType.X_LITERAL);

		initEEnum(modifyPermTypeEEnum, modifyPermType.class, "modifyPermType");
		addEEnumLiteral(modifyPermTypeEEnum, modifyPermType.M_LITERAL);
		addEEnumLiteral(modifyPermTypeEEnum, modifyPermType.X_LITERAL);

		initEEnum(trustLevelEEnum, trustLevel.class, "trustLevel");
		addEEnumLiteral(trustLevelEEnum, trustLevel.TRUST_LITERAL);
		addEEnumLiteral(trustLevelEEnum, trustLevel.DISTRUST_LITERAL);

		initEEnum(producePermTypeEEnum, producePermType.class, "producePermType");
		addEEnumLiteral(producePermTypeEEnum, producePermType.P_LITERAL);
		addEEnumLiteral(producePermTypeEEnum, producePermType.X_LITERAL);

		initEEnum(provisionTypeEEnum, provisionType.class, "provisionType");
		addEEnumLiteral(provisionTypeEEnum, provisionType.PROVISION_LITERAL);
		addEEnumLiteral(provisionTypeEEnum, provisionType.IPROVISION_LITERAL);

		initEEnum(readPermTypeEEnum, readPermType.class, "readPermType");
		addEEnumLiteral(readPermTypeEEnum, readPermType.R_LITERAL);
		addEEnumLiteral(readPermTypeEEnum, readPermType.X_LITERAL);

		initEEnum(producetypeEEnum, producetype.class, "producetype");
		addEEnumLiteral(producetypeEEnum, producetype.CHK_BELIEVABILITY_LITERAL);
		addEEnumLiteral(producetypeEEnum, producetype.NO_CHK_BELIEVABILITY_LITERAL);

		initEEnum(softgoalTypeEEnum, softgoalType.class, "softgoalType");
		addEEnumLiteral(softgoalTypeEEnum, softgoalType.ACCURACY_LITERAL);
		addEEnumLiteral(softgoalTypeEEnum, softgoalType.COMPLETENESS_LITERAL);
		addEEnumLiteral(softgoalTypeEEnum, softgoalType.ACCESSIBILITY_LITERAL);
		addEEnumLiteral(softgoalTypeEEnum, softgoalType.TRUSTWORTHINESS_LITERAL);
		addEEnumLiteral(softgoalTypeEEnum, softgoalType.BELIEVABILITY_LITERAL);
		addEEnumLiteral(softgoalTypeEEnum, softgoalType.TIMELINESS_LITERAL);
		addEEnumLiteral(softgoalTypeEEnum, softgoalType.CONSISTENCY_LITERAL);
		addEEnumLiteral(softgoalTypeEEnum, softgoalType.TOP_LEVEL_IQ_LITERAL);

		initEEnum(iqConstraintTypeEEnum, iqConstraintType.class, "iqConstraintType");
		addEEnumLiteral(iqConstraintTypeEEnum, iqConstraintType.ACCURACY_LITERAL);
		addEEnumLiteral(iqConstraintTypeEEnum, iqConstraintType.COMPLETENESS_LITERAL);
		addEEnumLiteral(iqConstraintTypeEEnum, iqConstraintType.ACCESSIBILITY_LITERAL);
		addEEnumLiteral(iqConstraintTypeEEnum, iqConstraintType.TRUSTWORTHINESS_LITERAL);
		addEEnumLiteral(iqConstraintTypeEEnum, iqConstraintType.BELIEVABILITY_LITERAL);
		addEEnumLiteral(iqConstraintTypeEEnum, iqConstraintType.TIMELINESS_LITERAL);
		addEEnumLiteral(iqConstraintTypeEEnum, iqConstraintType.CONSISTENCY_LITERAL);

		initEEnum(rtypeEEnum, rtype.class, "rtype");
		addEEnumLiteral(rtypeEEnum, rtype.R_LITERAL);
		addEEnumLiteral(rtypeEEnum, rtype.O_LITERAL);

		// Create resource
		createResource(eNS_URI);
	}

} //IqtoolPackageImpl
