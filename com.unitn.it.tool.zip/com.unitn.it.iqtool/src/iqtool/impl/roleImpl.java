/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.goal;
import iqtool.role;

import java.util.Collection;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>role</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.roleImpl#getIsa <em>Isa</em>}</li>
 *   <li>{@link iqtool.impl.roleImpl#getIs_capable <em>Is capable</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class roleImpl extends actorImpl implements role {
	/**
	 * The cached value of the '{@link #getIsa() <em>Isa</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIsa()
	 * @generated
	 * @ordered
	 */
	protected EList isa;

	/**
	 * The cached value of the '{@link #getIs_capable() <em>Is capable</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_capable()
	 * @generated
	 * @ordered
	 */
	protected EList is_capable;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected roleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.ROLE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getIsa() {
		if (isa == null) {
			isa = new EObjectResolvingEList(role.class, this, IqtoolPackage.ROLE__ISA);
		}
		return isa;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getIs_capable() {
		if (is_capable == null) {
			is_capable = new EObjectResolvingEList(goal.class, this, IqtoolPackage.ROLE__IS_CAPABLE);
		}
		return is_capable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.ROLE__ISA:
				return getIsa();
			case IqtoolPackage.ROLE__IS_CAPABLE:
				return getIs_capable();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.ROLE__ISA:
				getIsa().clear();
				getIsa().addAll((Collection)newValue);
				return;
			case IqtoolPackage.ROLE__IS_CAPABLE:
				getIs_capable().clear();
				getIs_capable().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.ROLE__ISA:
				getIsa().clear();
				return;
			case IqtoolPackage.ROLE__IS_CAPABLE:
				getIs_capable().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.ROLE__ISA:
				return isa != null && !isa.isEmpty();
			case IqtoolPackage.ROLE__IS_CAPABLE:
				return is_capable != null && !is_capable.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //roleImpl
