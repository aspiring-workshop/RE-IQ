/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.betweenPostion;
import iqtool.goal;

import java.util.Collection;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>between Postion</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.betweenPostionImpl#getOutarc <em>Outarc</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class betweenPostionImpl extends positionImpl implements betweenPostion {
	/**
	 * The cached value of the '{@link #getOutarc() <em>Outarc</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutarc()
	 * @generated
	 * @ordered
	 */
	protected EList outarc;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected betweenPostionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.BETWEEN_POSTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getOutarc() {
		if (outarc == null) {
			outarc = new EObjectResolvingEList(goal.class, this, IqtoolPackage.BETWEEN_POSTION__OUTARC);
		}
		return outarc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.BETWEEN_POSTION__OUTARC:
				return getOutarc();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.BETWEEN_POSTION__OUTARC:
				getOutarc().clear();
				getOutarc().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.BETWEEN_POSTION__OUTARC:
				getOutarc().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.BETWEEN_POSTION__OUTARC:
				return outarc != null && !outarc.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //betweenPostionImpl
