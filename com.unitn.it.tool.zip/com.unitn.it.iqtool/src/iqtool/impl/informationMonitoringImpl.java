/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.information;
import iqtool.informationMonitoring;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>information Monitoring</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.informationMonitoringImpl#getMonitoringOfInformation <em>Monitoring Of Information</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class informationMonitoringImpl extends monitoringImpl implements informationMonitoring {
	/**
	 * The cached value of the '{@link #getMonitoringOfInformation() <em>Monitoring Of Information</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMonitoringOfInformation()
	 * @generated
	 * @ordered
	 */
	protected information monitoringOfInformation;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected informationMonitoringImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.INFORMATION_MONITORING;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information getMonitoringOfInformation() {
		if (monitoringOfInformation != null && monitoringOfInformation.eIsProxy()) {
			InternalEObject oldMonitoringOfInformation = (InternalEObject)monitoringOfInformation;
			monitoringOfInformation = (information)eResolveProxy(oldMonitoringOfInformation);
			if (monitoringOfInformation != oldMonitoringOfInformation) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.INFORMATION_MONITORING__MONITORING_OF_INFORMATION, oldMonitoringOfInformation, monitoringOfInformation));
			}
		}
		return monitoringOfInformation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information basicGetMonitoringOfInformation() {
		return monitoringOfInformation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMonitoringOfInformation(information newMonitoringOfInformation) {
		information oldMonitoringOfInformation = monitoringOfInformation;
		monitoringOfInformation = newMonitoringOfInformation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.INFORMATION_MONITORING__MONITORING_OF_INFORMATION, oldMonitoringOfInformation, monitoringOfInformation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.INFORMATION_MONITORING__MONITORING_OF_INFORMATION:
				if (resolve) return getMonitoringOfInformation();
				return basicGetMonitoringOfInformation();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.INFORMATION_MONITORING__MONITORING_OF_INFORMATION:
				setMonitoringOfInformation((information)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.INFORMATION_MONITORING__MONITORING_OF_INFORMATION:
				setMonitoringOfInformation((information)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.INFORMATION_MONITORING__MONITORING_OF_INFORMATION:
				return monitoringOfInformation != null;
		}
		return super.eIsSet(featureID);
	}

} //informationMonitoringImpl
