/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.actor;
import iqtool.adoption;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>adoption</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.adoptionImpl#getAdoptionTo <em>Adoption To</em>}</li>
 *   <li>{@link iqtool.impl.adoptionImpl#getAdoptionFrom <em>Adoption From</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class adoptionImpl extends MinimalEObjectImpl.Container implements adoption {
	/**
	 * The cached value of the '{@link #getAdoptionTo() <em>Adoption To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAdoptionTo()
	 * @generated
	 * @ordered
	 */
	protected actor adoptionTo;

	/**
	 * The cached value of the '{@link #getAdoptionFrom() <em>Adoption From</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAdoptionFrom()
	 * @generated
	 * @ordered
	 */
	protected actor adoptionFrom;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected adoptionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.ADOPTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getAdoptionTo() {
		if (adoptionTo != null && adoptionTo.eIsProxy()) {
			InternalEObject oldAdoptionTo = (InternalEObject)adoptionTo;
			adoptionTo = (actor)eResolveProxy(oldAdoptionTo);
			if (adoptionTo != oldAdoptionTo) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.ADOPTION__ADOPTION_TO, oldAdoptionTo, adoptionTo));
			}
		}
		return adoptionTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetAdoptionTo() {
		return adoptionTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAdoptionTo(actor newAdoptionTo) {
		actor oldAdoptionTo = adoptionTo;
		adoptionTo = newAdoptionTo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.ADOPTION__ADOPTION_TO, oldAdoptionTo, adoptionTo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getAdoptionFrom() {
		if (adoptionFrom != null && adoptionFrom.eIsProxy()) {
			InternalEObject oldAdoptionFrom = (InternalEObject)adoptionFrom;
			adoptionFrom = (actor)eResolveProxy(oldAdoptionFrom);
			if (adoptionFrom != oldAdoptionFrom) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.ADOPTION__ADOPTION_FROM, oldAdoptionFrom, adoptionFrom));
			}
		}
		return adoptionFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetAdoptionFrom() {
		return adoptionFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAdoptionFrom(actor newAdoptionFrom) {
		actor oldAdoptionFrom = adoptionFrom;
		adoptionFrom = newAdoptionFrom;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.ADOPTION__ADOPTION_FROM, oldAdoptionFrom, adoptionFrom));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.ADOPTION__ADOPTION_TO:
				if (resolve) return getAdoptionTo();
				return basicGetAdoptionTo();
			case IqtoolPackage.ADOPTION__ADOPTION_FROM:
				if (resolve) return getAdoptionFrom();
				return basicGetAdoptionFrom();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.ADOPTION__ADOPTION_TO:
				setAdoptionTo((actor)newValue);
				return;
			case IqtoolPackage.ADOPTION__ADOPTION_FROM:
				setAdoptionFrom((actor)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.ADOPTION__ADOPTION_TO:
				setAdoptionTo((actor)null);
				return;
			case IqtoolPackage.ADOPTION__ADOPTION_FROM:
				setAdoptionFrom((actor)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.ADOPTION__ADOPTION_TO:
				return adoptionTo != null;
			case IqtoolPackage.ADOPTION__ADOPTION_FROM:
				return adoptionFrom != null;
		}
		return super.eIsSet(featureID);
	}

} //adoptionImpl
