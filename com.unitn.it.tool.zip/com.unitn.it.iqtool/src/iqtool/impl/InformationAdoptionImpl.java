/**
 */
package iqtool.impl;

import iqtool.InformationAdoption;
import iqtool.IqtoolPackage;
import iqtool.information;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Information Adoption</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.InformationAdoptionImpl#getAdoptionOfInformation <em>Adoption Of Information</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class InformationAdoptionImpl extends adoptionImpl implements InformationAdoption {
	/**
	 * The cached value of the '{@link #getAdoptionOfInformation() <em>Adoption Of Information</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAdoptionOfInformation()
	 * @generated
	 * @ordered
	 */
	protected information adoptionOfInformation;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InformationAdoptionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.INFORMATION_ADOPTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information getAdoptionOfInformation() {
		if (adoptionOfInformation != null && adoptionOfInformation.eIsProxy()) {
			InternalEObject oldAdoptionOfInformation = (InternalEObject)adoptionOfInformation;
			adoptionOfInformation = (information)eResolveProxy(oldAdoptionOfInformation);
			if (adoptionOfInformation != oldAdoptionOfInformation) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.INFORMATION_ADOPTION__ADOPTION_OF_INFORMATION, oldAdoptionOfInformation, adoptionOfInformation));
			}
		}
		return adoptionOfInformation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information basicGetAdoptionOfInformation() {
		return adoptionOfInformation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAdoptionOfInformation(information newAdoptionOfInformation) {
		information oldAdoptionOfInformation = adoptionOfInformation;
		adoptionOfInformation = newAdoptionOfInformation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.INFORMATION_ADOPTION__ADOPTION_OF_INFORMATION, oldAdoptionOfInformation, adoptionOfInformation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.INFORMATION_ADOPTION__ADOPTION_OF_INFORMATION:
				if (resolve) return getAdoptionOfInformation();
				return basicGetAdoptionOfInformation();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.INFORMATION_ADOPTION__ADOPTION_OF_INFORMATION:
				setAdoptionOfInformation((information)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.INFORMATION_ADOPTION__ADOPTION_OF_INFORMATION:
				setAdoptionOfInformation((information)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.INFORMATION_ADOPTION__ADOPTION_OF_INFORMATION:
				return adoptionOfInformation != null;
		}
		return super.eIsSet(featureID);
	}

} //InformationAdoptionImpl
