/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.goal;
import iqtool.information;
import iqtool.produce;
import iqtool.producetype;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>produce</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.produceImpl#getProduceBy <em>Produce By</em>}</li>
 *   <li>{@link iqtool.impl.produceImpl#getProduceOf <em>Produce Of</em>}</li>
 *   <li>{@link iqtool.impl.produceImpl#getProduceType <em>Produce Type</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class produceImpl extends MinimalEObjectImpl.Container implements produce {
	/**
	 * The cached value of the '{@link #getProduceBy() <em>Produce By</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProduceBy()
	 * @generated
	 * @ordered
	 */
	protected goal produceBy;

	/**
	 * The cached value of the '{@link #getProduceOf() <em>Produce Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProduceOf()
	 * @generated
	 * @ordered
	 */
	protected information produceOf;

	/**
	 * The default value of the '{@link #getProduceType() <em>Produce Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProduceType()
	 * @generated
	 * @ordered
	 */
	protected static final producetype PRODUCE_TYPE_EDEFAULT = producetype.CHK_BELIEVABILITY_LITERAL;

	/**
	 * The cached value of the '{@link #getProduceType() <em>Produce Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProduceType()
	 * @generated
	 * @ordered
	 */
	protected producetype produceType = PRODUCE_TYPE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected produceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.PRODUCE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goal getProduceBy() {
		if (produceBy != null && produceBy.eIsProxy()) {
			InternalEObject oldProduceBy = (InternalEObject)produceBy;
			produceBy = (goal)eResolveProxy(oldProduceBy);
			if (produceBy != oldProduceBy) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.PRODUCE__PRODUCE_BY, oldProduceBy, produceBy));
			}
		}
		return produceBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goal basicGetProduceBy() {
		return produceBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProduceBy(goal newProduceBy) {
		goal oldProduceBy = produceBy;
		produceBy = newProduceBy;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PRODUCE__PRODUCE_BY, oldProduceBy, produceBy));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information getProduceOf() {
		if (produceOf != null && produceOf.eIsProxy()) {
			InternalEObject oldProduceOf = (InternalEObject)produceOf;
			produceOf = (information)eResolveProxy(oldProduceOf);
			if (produceOf != oldProduceOf) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.PRODUCE__PRODUCE_OF, oldProduceOf, produceOf));
			}
		}
		return produceOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information basicGetProduceOf() {
		return produceOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProduceOf(information newProduceOf) {
		information oldProduceOf = produceOf;
		produceOf = newProduceOf;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PRODUCE__PRODUCE_OF, oldProduceOf, produceOf));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public producetype getProduceType() {
		return produceType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProduceType(producetype newProduceType) {
		producetype oldProduceType = produceType;
		produceType = newProduceType == null ? PRODUCE_TYPE_EDEFAULT : newProduceType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PRODUCE__PRODUCE_TYPE, oldProduceType, produceType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.PRODUCE__PRODUCE_BY:
				if (resolve) return getProduceBy();
				return basicGetProduceBy();
			case IqtoolPackage.PRODUCE__PRODUCE_OF:
				if (resolve) return getProduceOf();
				return basicGetProduceOf();
			case IqtoolPackage.PRODUCE__PRODUCE_TYPE:
				return getProduceType();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.PRODUCE__PRODUCE_BY:
				setProduceBy((goal)newValue);
				return;
			case IqtoolPackage.PRODUCE__PRODUCE_OF:
				setProduceOf((information)newValue);
				return;
			case IqtoolPackage.PRODUCE__PRODUCE_TYPE:
				setProduceType((producetype)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.PRODUCE__PRODUCE_BY:
				setProduceBy((goal)null);
				return;
			case IqtoolPackage.PRODUCE__PRODUCE_OF:
				setProduceOf((information)null);
				return;
			case IqtoolPackage.PRODUCE__PRODUCE_TYPE:
				setProduceType(PRODUCE_TYPE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.PRODUCE__PRODUCE_BY:
				return produceBy != null;
			case IqtoolPackage.PRODUCE__PRODUCE_OF:
				return produceOf != null;
			case IqtoolPackage.PRODUCE__PRODUCE_TYPE:
				return produceType != PRODUCE_TYPE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (produceType: ");
		result.append(produceType);
		result.append(')');
		return result.toString();
	}

} //produceImpl
