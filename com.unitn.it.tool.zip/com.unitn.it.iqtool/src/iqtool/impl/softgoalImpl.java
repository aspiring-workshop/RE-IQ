/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.actor;
import iqtool.goal;
import iqtool.information;
import iqtool.softgoal;
import iqtool.softgoalType;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>softgoal</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.softgoalImpl#getAnddecomposition <em>Anddecomposition</em>}</li>
 *   <li>{@link iqtool.impl.softgoalImpl#getSoftGoalOf <em>Soft Goal Of</em>}</li>
 *   <li>{@link iqtool.impl.softgoalImpl#getSoftgoalTarget <em>Softgoal Target</em>}</li>
 *   <li>{@link iqtool.impl.softgoalImpl#getSoftgoalConcerning <em>Softgoal Concerning</em>}</li>
 *   <li>{@link iqtool.impl.softgoalImpl#getType <em>Type</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class softgoalImpl extends MinimalEObjectImpl.Container implements softgoal {
	/**
	 * The cached value of the '{@link #getAnddecomposition() <em>Anddecomposition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAnddecomposition()
	 * @generated
	 * @ordered
	 */
	protected softgoal anddecomposition;

	/**
	 * The cached value of the '{@link #getSoftGoalOf() <em>Soft Goal Of</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSoftGoalOf()
	 * @generated
	 * @ordered
	 */
	protected EList softGoalOf;

	/**
	 * The cached value of the '{@link #getSoftgoalTarget() <em>Softgoal Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSoftgoalTarget()
	 * @generated
	 * @ordered
	 */
	protected information softgoalTarget;

	/**
	 * The cached value of the '{@link #getSoftgoalConcerning() <em>Softgoal Concerning</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSoftgoalConcerning()
	 * @generated
	 * @ordered
	 */
	protected goal softgoalConcerning;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final softgoalType TYPE_EDEFAULT = softgoalType.ACCURACY_LITERAL;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected softgoalType type = TYPE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected softgoalImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.SOFTGOAL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public softgoal getAnddecomposition() {
		if (anddecomposition != null && anddecomposition.eIsProxy()) {
			InternalEObject oldAnddecomposition = (InternalEObject)anddecomposition;
			anddecomposition = (softgoal)eResolveProxy(oldAnddecomposition);
			if (anddecomposition != oldAnddecomposition) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.SOFTGOAL__ANDDECOMPOSITION, oldAnddecomposition, anddecomposition));
			}
		}
		return anddecomposition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public softgoal basicGetAnddecomposition() {
		return anddecomposition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAnddecomposition(softgoal newAnddecomposition) {
		softgoal oldAnddecomposition = anddecomposition;
		anddecomposition = newAnddecomposition;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.SOFTGOAL__ANDDECOMPOSITION, oldAnddecomposition, anddecomposition));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getSoftGoalOf() {
		if (softGoalOf == null) {
			softGoalOf = new EObjectResolvingEList(actor.class, this, IqtoolPackage.SOFTGOAL__SOFT_GOAL_OF);
		}
		return softGoalOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information getSoftgoalTarget() {
		if (softgoalTarget != null && softgoalTarget.eIsProxy()) {
			InternalEObject oldSoftgoalTarget = (InternalEObject)softgoalTarget;
			softgoalTarget = (information)eResolveProxy(oldSoftgoalTarget);
			if (softgoalTarget != oldSoftgoalTarget) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.SOFTGOAL__SOFTGOAL_TARGET, oldSoftgoalTarget, softgoalTarget));
			}
		}
		return softgoalTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information basicGetSoftgoalTarget() {
		return softgoalTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSoftgoalTarget(information newSoftgoalTarget) {
		information oldSoftgoalTarget = softgoalTarget;
		softgoalTarget = newSoftgoalTarget;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.SOFTGOAL__SOFTGOAL_TARGET, oldSoftgoalTarget, softgoalTarget));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goal getSoftgoalConcerning() {
		if (softgoalConcerning != null && softgoalConcerning.eIsProxy()) {
			InternalEObject oldSoftgoalConcerning = (InternalEObject)softgoalConcerning;
			softgoalConcerning = (goal)eResolveProxy(oldSoftgoalConcerning);
			if (softgoalConcerning != oldSoftgoalConcerning) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.SOFTGOAL__SOFTGOAL_CONCERNING, oldSoftgoalConcerning, softgoalConcerning));
			}
		}
		return softgoalConcerning;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goal basicGetSoftgoalConcerning() {
		return softgoalConcerning;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSoftgoalConcerning(goal newSoftgoalConcerning) {
		goal oldSoftgoalConcerning = softgoalConcerning;
		softgoalConcerning = newSoftgoalConcerning;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.SOFTGOAL__SOFTGOAL_CONCERNING, oldSoftgoalConcerning, softgoalConcerning));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public softgoalType getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(softgoalType newType) {
		softgoalType oldType = type;
		type = newType == null ? TYPE_EDEFAULT : newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.SOFTGOAL__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.SOFTGOAL__ANDDECOMPOSITION:
				if (resolve) return getAnddecomposition();
				return basicGetAnddecomposition();
			case IqtoolPackage.SOFTGOAL__SOFT_GOAL_OF:
				return getSoftGoalOf();
			case IqtoolPackage.SOFTGOAL__SOFTGOAL_TARGET:
				if (resolve) return getSoftgoalTarget();
				return basicGetSoftgoalTarget();
			case IqtoolPackage.SOFTGOAL__SOFTGOAL_CONCERNING:
				if (resolve) return getSoftgoalConcerning();
				return basicGetSoftgoalConcerning();
			case IqtoolPackage.SOFTGOAL__TYPE:
				return getType();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.SOFTGOAL__ANDDECOMPOSITION:
				setAnddecomposition((softgoal)newValue);
				return;
			case IqtoolPackage.SOFTGOAL__SOFT_GOAL_OF:
				getSoftGoalOf().clear();
				getSoftGoalOf().addAll((Collection)newValue);
				return;
			case IqtoolPackage.SOFTGOAL__SOFTGOAL_TARGET:
				setSoftgoalTarget((information)newValue);
				return;
			case IqtoolPackage.SOFTGOAL__SOFTGOAL_CONCERNING:
				setSoftgoalConcerning((goal)newValue);
				return;
			case IqtoolPackage.SOFTGOAL__TYPE:
				setType((softgoalType)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.SOFTGOAL__ANDDECOMPOSITION:
				setAnddecomposition((softgoal)null);
				return;
			case IqtoolPackage.SOFTGOAL__SOFT_GOAL_OF:
				getSoftGoalOf().clear();
				return;
			case IqtoolPackage.SOFTGOAL__SOFTGOAL_TARGET:
				setSoftgoalTarget((information)null);
				return;
			case IqtoolPackage.SOFTGOAL__SOFTGOAL_CONCERNING:
				setSoftgoalConcerning((goal)null);
				return;
			case IqtoolPackage.SOFTGOAL__TYPE:
				setType(TYPE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.SOFTGOAL__ANDDECOMPOSITION:
				return anddecomposition != null;
			case IqtoolPackage.SOFTGOAL__SOFT_GOAL_OF:
				return softGoalOf != null && !softGoalOf.isEmpty();
			case IqtoolPackage.SOFTGOAL__SOFTGOAL_TARGET:
				return softgoalTarget != null;
			case IqtoolPackage.SOFTGOAL__SOFTGOAL_CONCERNING:
				return softgoalConcerning != null;
			case IqtoolPackage.SOFTGOAL__TYPE:
				return type != TYPE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (type: ");
		result.append(type);
		result.append(')');
		return result.toString();
	}

} //softgoalImpl
