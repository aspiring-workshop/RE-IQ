/**
 */
package iqtool.impl;

import iqtool.InformationAdoption;
import iqtool.IqtoolPackage;
import iqtool.actor;
import iqtool.adoption;
import iqtool.agent;
import iqtool.betweenPostion;
import iqtool.delegationTrust;
import iqtool.diagram;
import iqtool.endPostion;
import iqtool.generalGoal;
import iqtool.general_information;
import iqtool.goal;
import iqtool.goalAdoption;
import iqtool.goalDelegation;
import iqtool.goalMonitoring;
import iqtool.goalThreat;
import iqtool.infoProvision;
import iqtool.information;
import iqtool.informationMonitoring;
import iqtool.informationThreat;
import iqtool.instanceGoal;
import iqtool.instanceInformation;
import iqtool.iqConstraint;
import iqtool.monitoring;
import iqtool.permDelegation;
import iqtool.position;
import iqtool.produce;
import iqtool.produceTrust;
import iqtool.read;
import iqtool.role;
import iqtool.scope;
import iqtool.send;
import iqtool.softgoal;
import iqtool.startPostion;
import iqtool.threat;
import iqtool.trustPermDelegation;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>diagram</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.diagramImpl#getActorElement <em>Actor Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getGoalElement <em>Goal Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getInfoElement <em>Info Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getScopeElement <em>Scope Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getDelegationElement <em>Delegation Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getProvisionElement <em>Provision Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getDelegationTrustElement <em>Delegation Trust Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getAgentElement <em>Agent Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getRoleElement <em>Role Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getPermDeleElement <em>Perm Dele Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getTrustPermDeleElement <em>Trust Perm Dele Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getReadElement <em>Read Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getSendElement <em>Send Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getPostionElelement <em>Postion Elelement</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getProduceElement <em>Produce Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getSpositionElement <em>Sposition Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getBpositionElement <em>Bposition Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getEpositionElement <em>Eposition Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getProduceTrustElement <em>Produce Trust Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getSoftgoalElement <em>Softgoal Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getIqConstraintElement <em>Iq Constraint Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getThreatElement <em>Threat Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getInstanceGoalElement <em>Instance Goal Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getGeneralGoalElement <em>General Goal Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getInstanceInformationElement <em>Instance Information Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getGeneralInformationElement <em>General Information Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getGoalThreatElement <em>Goal Threat Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getInformationThreatElement <em>Information Threat Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getMonitoringElement <em>Monitoring Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getInformationMonitoringElement <em>Information Monitoring Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getGoalMonitoringElement <em>Goal Monitoring Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getAdoptionElement <em>Adoption Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getGoalAdoptionElement <em>Goal Adoption Element</em>}</li>
 *   <li>{@link iqtool.impl.diagramImpl#getInformationAdoptionElement <em>Information Adoption Element</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class diagramImpl extends MinimalEObjectImpl.Container implements diagram {
	/**
	 * The cached value of the '{@link #getActorElement() <em>Actor Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActorElement()
	 * @generated
	 * @ordered
	 */
	protected EList actorElement;

	/**
	 * The cached value of the '{@link #getGoalElement() <em>Goal Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGoalElement()
	 * @generated
	 * @ordered
	 */
	protected EList goalElement;

	/**
	 * The cached value of the '{@link #getInfoElement() <em>Info Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInfoElement()
	 * @generated
	 * @ordered
	 */
	protected EList infoElement;

	/**
	 * The cached value of the '{@link #getScopeElement() <em>Scope Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScopeElement()
	 * @generated
	 * @ordered
	 */
	protected EList scopeElement;

	/**
	 * The cached value of the '{@link #getDelegationElement() <em>Delegation Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDelegationElement()
	 * @generated
	 * @ordered
	 */
	protected EList delegationElement;

	/**
	 * The cached value of the '{@link #getProvisionElement() <em>Provision Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProvisionElement()
	 * @generated
	 * @ordered
	 */
	protected EList provisionElement;

	/**
	 * The cached value of the '{@link #getDelegationTrustElement() <em>Delegation Trust Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDelegationTrustElement()
	 * @generated
	 * @ordered
	 */
	protected EList delegationTrustElement;

	/**
	 * The cached value of the '{@link #getAgentElement() <em>Agent Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAgentElement()
	 * @generated
	 * @ordered
	 */
	protected EList agentElement;

	/**
	 * The cached value of the '{@link #getRoleElement() <em>Role Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoleElement()
	 * @generated
	 * @ordered
	 */
	protected EList roleElement;

	/**
	 * The cached value of the '{@link #getPermDeleElement() <em>Perm Dele Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPermDeleElement()
	 * @generated
	 * @ordered
	 */
	protected EList permDeleElement;

	/**
	 * The cached value of the '{@link #getTrustPermDeleElement() <em>Trust Perm Dele Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustPermDeleElement()
	 * @generated
	 * @ordered
	 */
	protected EList trustPermDeleElement;

	/**
	 * The cached value of the '{@link #getReadElement() <em>Read Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReadElement()
	 * @generated
	 * @ordered
	 */
	protected EList readElement;

	/**
	 * The cached value of the '{@link #getSendElement() <em>Send Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSendElement()
	 * @generated
	 * @ordered
	 */
	protected EList sendElement;

	/**
	 * The cached value of the '{@link #getPostionElelement() <em>Postion Elelement</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPostionElelement()
	 * @generated
	 * @ordered
	 */
	protected EList postionElelement;

	/**
	 * The cached value of the '{@link #getProduceElement() <em>Produce Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProduceElement()
	 * @generated
	 * @ordered
	 */
	protected EList produceElement;

	/**
	 * The cached value of the '{@link #getSpositionElement() <em>Sposition Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSpositionElement()
	 * @generated
	 * @ordered
	 */
	protected EList spositionElement;

	/**
	 * The cached value of the '{@link #getBpositionElement() <em>Bposition Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBpositionElement()
	 * @generated
	 * @ordered
	 */
	protected EList bpositionElement;

	/**
	 * The cached value of the '{@link #getEpositionElement() <em>Eposition Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEpositionElement()
	 * @generated
	 * @ordered
	 */
	protected EList epositionElement;

	/**
	 * The cached value of the '{@link #getProduceTrustElement() <em>Produce Trust Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProduceTrustElement()
	 * @generated
	 * @ordered
	 */
	protected EList produceTrustElement;

	/**
	 * The cached value of the '{@link #getSoftgoalElement() <em>Softgoal Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSoftgoalElement()
	 * @generated
	 * @ordered
	 */
	protected EList softgoalElement;

	/**
	 * The cached value of the '{@link #getIqConstraintElement() <em>Iq Constraint Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIqConstraintElement()
	 * @generated
	 * @ordered
	 */
	protected EList iqConstraintElement;

	/**
	 * The cached value of the '{@link #getThreatElement() <em>Threat Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThreatElement()
	 * @generated
	 * @ordered
	 */
	protected EList threatElement;

	/**
	 * The cached value of the '{@link #getInstanceGoalElement() <em>Instance Goal Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInstanceGoalElement()
	 * @generated
	 * @ordered
	 */
	protected EList instanceGoalElement;

	/**
	 * The cached value of the '{@link #getGeneralGoalElement() <em>General Goal Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGeneralGoalElement()
	 * @generated
	 * @ordered
	 */
	protected EList generalGoalElement;

	/**
	 * The cached value of the '{@link #getInstanceInformationElement() <em>Instance Information Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInstanceInformationElement()
	 * @generated
	 * @ordered
	 */
	protected EList instanceInformationElement;

	/**
	 * The cached value of the '{@link #getGeneralInformationElement() <em>General Information Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGeneralInformationElement()
	 * @generated
	 * @ordered
	 */
	protected EList generalInformationElement;

	/**
	 * The cached value of the '{@link #getGoalThreatElement() <em>Goal Threat Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGoalThreatElement()
	 * @generated
	 * @ordered
	 */
	protected EList goalThreatElement;

	/**
	 * The cached value of the '{@link #getInformationThreatElement() <em>Information Threat Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInformationThreatElement()
	 * @generated
	 * @ordered
	 */
	protected EList informationThreatElement;

	/**
	 * The cached value of the '{@link #getMonitoringElement() <em>Monitoring Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMonitoringElement()
	 * @generated
	 * @ordered
	 */
	protected EList monitoringElement;

	/**
	 * The cached value of the '{@link #getInformationMonitoringElement() <em>Information Monitoring Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInformationMonitoringElement()
	 * @generated
	 * @ordered
	 */
	protected EList informationMonitoringElement;

	/**
	 * The cached value of the '{@link #getGoalMonitoringElement() <em>Goal Monitoring Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGoalMonitoringElement()
	 * @generated
	 * @ordered
	 */
	protected EList goalMonitoringElement;

	/**
	 * The cached value of the '{@link #getAdoptionElement() <em>Adoption Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAdoptionElement()
	 * @generated
	 * @ordered
	 */
	protected EList adoptionElement;

	/**
	 * The cached value of the '{@link #getGoalAdoptionElement() <em>Goal Adoption Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGoalAdoptionElement()
	 * @generated
	 * @ordered
	 */
	protected EList goalAdoptionElement;

	/**
	 * The cached value of the '{@link #getInformationAdoptionElement() <em>Information Adoption Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInformationAdoptionElement()
	 * @generated
	 * @ordered
	 */
	protected EList informationAdoptionElement;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected diagramImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.DIAGRAM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getActorElement() {
		if (actorElement == null) {
			actorElement = new EObjectContainmentEList(actor.class, this, IqtoolPackage.DIAGRAM__ACTOR_ELEMENT);
		}
		return actorElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getGoalElement() {
		if (goalElement == null) {
			goalElement = new EObjectContainmentEList(goal.class, this, IqtoolPackage.DIAGRAM__GOAL_ELEMENT);
		}
		return goalElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getInfoElement() {
		if (infoElement == null) {
			infoElement = new EObjectContainmentEList(information.class, this, IqtoolPackage.DIAGRAM__INFO_ELEMENT);
		}
		return infoElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getScopeElement() {
		if (scopeElement == null) {
			scopeElement = new EObjectContainmentEList(scope.class, this, IqtoolPackage.DIAGRAM__SCOPE_ELEMENT);
		}
		return scopeElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getDelegationElement() {
		if (delegationElement == null) {
			delegationElement = new EObjectContainmentEList(goalDelegation.class, this, IqtoolPackage.DIAGRAM__DELEGATION_ELEMENT);
		}
		return delegationElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getProvisionElement() {
		if (provisionElement == null) {
			provisionElement = new EObjectContainmentEList(infoProvision.class, this, IqtoolPackage.DIAGRAM__PROVISION_ELEMENT);
		}
		return provisionElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getDelegationTrustElement() {
		if (delegationTrustElement == null) {
			delegationTrustElement = new EObjectContainmentEList(delegationTrust.class, this, IqtoolPackage.DIAGRAM__DELEGATION_TRUST_ELEMENT);
		}
		return delegationTrustElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getAgentElement() {
		if (agentElement == null) {
			agentElement = new EObjectContainmentEList(agent.class, this, IqtoolPackage.DIAGRAM__AGENT_ELEMENT);
		}
		return agentElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getRoleElement() {
		if (roleElement == null) {
			roleElement = new EObjectContainmentEList(role.class, this, IqtoolPackage.DIAGRAM__ROLE_ELEMENT);
		}
		return roleElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getPermDeleElement() {
		if (permDeleElement == null) {
			permDeleElement = new EObjectContainmentEList(permDelegation.class, this, IqtoolPackage.DIAGRAM__PERM_DELE_ELEMENT);
		}
		return permDeleElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getTrustPermDeleElement() {
		if (trustPermDeleElement == null) {
			trustPermDeleElement = new EObjectContainmentEList(trustPermDelegation.class, this, IqtoolPackage.DIAGRAM__TRUST_PERM_DELE_ELEMENT);
		}
		return trustPermDeleElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getReadElement() {
		if (readElement == null) {
			readElement = new EObjectContainmentEList(read.class, this, IqtoolPackage.DIAGRAM__READ_ELEMENT);
		}
		return readElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getSendElement() {
		if (sendElement == null) {
			sendElement = new EObjectContainmentEList(send.class, this, IqtoolPackage.DIAGRAM__SEND_ELEMENT);
		}
		return sendElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getPostionElelement() {
		if (postionElelement == null) {
			postionElelement = new EObjectContainmentEList(position.class, this, IqtoolPackage.DIAGRAM__POSTION_ELELEMENT);
		}
		return postionElelement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getProduceElement() {
		if (produceElement == null) {
			produceElement = new EObjectContainmentEList(produce.class, this, IqtoolPackage.DIAGRAM__PRODUCE_ELEMENT);
		}
		return produceElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getSpositionElement() {
		if (spositionElement == null) {
			spositionElement = new EObjectContainmentEList(startPostion.class, this, IqtoolPackage.DIAGRAM__SPOSITION_ELEMENT);
		}
		return spositionElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getBpositionElement() {
		if (bpositionElement == null) {
			bpositionElement = new EObjectContainmentEList(betweenPostion.class, this, IqtoolPackage.DIAGRAM__BPOSITION_ELEMENT);
		}
		return bpositionElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getEpositionElement() {
		if (epositionElement == null) {
			epositionElement = new EObjectContainmentEList(endPostion.class, this, IqtoolPackage.DIAGRAM__EPOSITION_ELEMENT);
		}
		return epositionElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getProduceTrustElement() {
		if (produceTrustElement == null) {
			produceTrustElement = new EObjectContainmentEList(produceTrust.class, this, IqtoolPackage.DIAGRAM__PRODUCE_TRUST_ELEMENT);
		}
		return produceTrustElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getSoftgoalElement() {
		if (softgoalElement == null) {
			softgoalElement = new EObjectContainmentEList(softgoal.class, this, IqtoolPackage.DIAGRAM__SOFTGOAL_ELEMENT);
		}
		return softgoalElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getIqConstraintElement() {
		if (iqConstraintElement == null) {
			iqConstraintElement = new EObjectContainmentEList(iqConstraint.class, this, IqtoolPackage.DIAGRAM__IQ_CONSTRAINT_ELEMENT);
		}
		return iqConstraintElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getThreatElement() {
		if (threatElement == null) {
			threatElement = new EObjectContainmentEList(threat.class, this, IqtoolPackage.DIAGRAM__THREAT_ELEMENT);
		}
		return threatElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getInstanceGoalElement() {
		if (instanceGoalElement == null) {
			instanceGoalElement = new EObjectContainmentEList(instanceGoal.class, this, IqtoolPackage.DIAGRAM__INSTANCE_GOAL_ELEMENT);
		}
		return instanceGoalElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getGeneralGoalElement() {
		if (generalGoalElement == null) {
			generalGoalElement = new EObjectContainmentEList(generalGoal.class, this, IqtoolPackage.DIAGRAM__GENERAL_GOAL_ELEMENT);
		}
		return generalGoalElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getInstanceInformationElement() {
		if (instanceInformationElement == null) {
			instanceInformationElement = new EObjectContainmentEList(instanceInformation.class, this, IqtoolPackage.DIAGRAM__INSTANCE_INFORMATION_ELEMENT);
		}
		return instanceInformationElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getGeneralInformationElement() {
		if (generalInformationElement == null) {
			generalInformationElement = new EObjectContainmentEList(general_information.class, this, IqtoolPackage.DIAGRAM__GENERAL_INFORMATION_ELEMENT);
		}
		return generalInformationElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getGoalThreatElement() {
		if (goalThreatElement == null) {
			goalThreatElement = new EObjectContainmentEList(goalThreat.class, this, IqtoolPackage.DIAGRAM__GOAL_THREAT_ELEMENT);
		}
		return goalThreatElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getInformationThreatElement() {
		if (informationThreatElement == null) {
			informationThreatElement = new EObjectContainmentEList(informationThreat.class, this, IqtoolPackage.DIAGRAM__INFORMATION_THREAT_ELEMENT);
		}
		return informationThreatElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getMonitoringElement() {
		if (monitoringElement == null) {
			monitoringElement = new EObjectContainmentEList(monitoring.class, this, IqtoolPackage.DIAGRAM__MONITORING_ELEMENT);
		}
		return monitoringElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getInformationMonitoringElement() {
		if (informationMonitoringElement == null) {
			informationMonitoringElement = new EObjectContainmentEList(goalMonitoring.class, this, IqtoolPackage.DIAGRAM__INFORMATION_MONITORING_ELEMENT);
		}
		return informationMonitoringElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getGoalMonitoringElement() {
		if (goalMonitoringElement == null) {
			goalMonitoringElement = new EObjectContainmentEList(informationMonitoring.class, this, IqtoolPackage.DIAGRAM__GOAL_MONITORING_ELEMENT);
		}
		return goalMonitoringElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getAdoptionElement() {
		if (adoptionElement == null) {
			adoptionElement = new EObjectContainmentEList(adoption.class, this, IqtoolPackage.DIAGRAM__ADOPTION_ELEMENT);
		}
		return adoptionElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getGoalAdoptionElement() {
		if (goalAdoptionElement == null) {
			goalAdoptionElement = new EObjectContainmentEList(goalAdoption.class, this, IqtoolPackage.DIAGRAM__GOAL_ADOPTION_ELEMENT);
		}
		return goalAdoptionElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getInformationAdoptionElement() {
		if (informationAdoptionElement == null) {
			informationAdoptionElement = new EObjectContainmentEList(InformationAdoption.class, this, IqtoolPackage.DIAGRAM__INFORMATION_ADOPTION_ELEMENT);
		}
		return informationAdoptionElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case IqtoolPackage.DIAGRAM__ACTOR_ELEMENT:
				return ((InternalEList)getActorElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__GOAL_ELEMENT:
				return ((InternalEList)getGoalElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__INFO_ELEMENT:
				return ((InternalEList)getInfoElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__SCOPE_ELEMENT:
				return ((InternalEList)getScopeElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__DELEGATION_ELEMENT:
				return ((InternalEList)getDelegationElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__PROVISION_ELEMENT:
				return ((InternalEList)getProvisionElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__DELEGATION_TRUST_ELEMENT:
				return ((InternalEList)getDelegationTrustElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__AGENT_ELEMENT:
				return ((InternalEList)getAgentElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__ROLE_ELEMENT:
				return ((InternalEList)getRoleElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__PERM_DELE_ELEMENT:
				return ((InternalEList)getPermDeleElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__TRUST_PERM_DELE_ELEMENT:
				return ((InternalEList)getTrustPermDeleElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__READ_ELEMENT:
				return ((InternalEList)getReadElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__SEND_ELEMENT:
				return ((InternalEList)getSendElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__POSTION_ELELEMENT:
				return ((InternalEList)getPostionElelement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__PRODUCE_ELEMENT:
				return ((InternalEList)getProduceElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__SPOSITION_ELEMENT:
				return ((InternalEList)getSpositionElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__BPOSITION_ELEMENT:
				return ((InternalEList)getBpositionElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__EPOSITION_ELEMENT:
				return ((InternalEList)getEpositionElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__PRODUCE_TRUST_ELEMENT:
				return ((InternalEList)getProduceTrustElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__SOFTGOAL_ELEMENT:
				return ((InternalEList)getSoftgoalElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__IQ_CONSTRAINT_ELEMENT:
				return ((InternalEList)getIqConstraintElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__THREAT_ELEMENT:
				return ((InternalEList)getThreatElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__INSTANCE_GOAL_ELEMENT:
				return ((InternalEList)getInstanceGoalElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__GENERAL_GOAL_ELEMENT:
				return ((InternalEList)getGeneralGoalElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__INSTANCE_INFORMATION_ELEMENT:
				return ((InternalEList)getInstanceInformationElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__GENERAL_INFORMATION_ELEMENT:
				return ((InternalEList)getGeneralInformationElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__GOAL_THREAT_ELEMENT:
				return ((InternalEList)getGoalThreatElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__INFORMATION_THREAT_ELEMENT:
				return ((InternalEList)getInformationThreatElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__MONITORING_ELEMENT:
				return ((InternalEList)getMonitoringElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__INFORMATION_MONITORING_ELEMENT:
				return ((InternalEList)getInformationMonitoringElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__GOAL_MONITORING_ELEMENT:
				return ((InternalEList)getGoalMonitoringElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__ADOPTION_ELEMENT:
				return ((InternalEList)getAdoptionElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__GOAL_ADOPTION_ELEMENT:
				return ((InternalEList)getGoalAdoptionElement()).basicRemove(otherEnd, msgs);
			case IqtoolPackage.DIAGRAM__INFORMATION_ADOPTION_ELEMENT:
				return ((InternalEList)getInformationAdoptionElement()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.DIAGRAM__ACTOR_ELEMENT:
				return getActorElement();
			case IqtoolPackage.DIAGRAM__GOAL_ELEMENT:
				return getGoalElement();
			case IqtoolPackage.DIAGRAM__INFO_ELEMENT:
				return getInfoElement();
			case IqtoolPackage.DIAGRAM__SCOPE_ELEMENT:
				return getScopeElement();
			case IqtoolPackage.DIAGRAM__DELEGATION_ELEMENT:
				return getDelegationElement();
			case IqtoolPackage.DIAGRAM__PROVISION_ELEMENT:
				return getProvisionElement();
			case IqtoolPackage.DIAGRAM__DELEGATION_TRUST_ELEMENT:
				return getDelegationTrustElement();
			case IqtoolPackage.DIAGRAM__AGENT_ELEMENT:
				return getAgentElement();
			case IqtoolPackage.DIAGRAM__ROLE_ELEMENT:
				return getRoleElement();
			case IqtoolPackage.DIAGRAM__PERM_DELE_ELEMENT:
				return getPermDeleElement();
			case IqtoolPackage.DIAGRAM__TRUST_PERM_DELE_ELEMENT:
				return getTrustPermDeleElement();
			case IqtoolPackage.DIAGRAM__READ_ELEMENT:
				return getReadElement();
			case IqtoolPackage.DIAGRAM__SEND_ELEMENT:
				return getSendElement();
			case IqtoolPackage.DIAGRAM__POSTION_ELELEMENT:
				return getPostionElelement();
			case IqtoolPackage.DIAGRAM__PRODUCE_ELEMENT:
				return getProduceElement();
			case IqtoolPackage.DIAGRAM__SPOSITION_ELEMENT:
				return getSpositionElement();
			case IqtoolPackage.DIAGRAM__BPOSITION_ELEMENT:
				return getBpositionElement();
			case IqtoolPackage.DIAGRAM__EPOSITION_ELEMENT:
				return getEpositionElement();
			case IqtoolPackage.DIAGRAM__PRODUCE_TRUST_ELEMENT:
				return getProduceTrustElement();
			case IqtoolPackage.DIAGRAM__SOFTGOAL_ELEMENT:
				return getSoftgoalElement();
			case IqtoolPackage.DIAGRAM__IQ_CONSTRAINT_ELEMENT:
				return getIqConstraintElement();
			case IqtoolPackage.DIAGRAM__THREAT_ELEMENT:
				return getThreatElement();
			case IqtoolPackage.DIAGRAM__INSTANCE_GOAL_ELEMENT:
				return getInstanceGoalElement();
			case IqtoolPackage.DIAGRAM__GENERAL_GOAL_ELEMENT:
				return getGeneralGoalElement();
			case IqtoolPackage.DIAGRAM__INSTANCE_INFORMATION_ELEMENT:
				return getInstanceInformationElement();
			case IqtoolPackage.DIAGRAM__GENERAL_INFORMATION_ELEMENT:
				return getGeneralInformationElement();
			case IqtoolPackage.DIAGRAM__GOAL_THREAT_ELEMENT:
				return getGoalThreatElement();
			case IqtoolPackage.DIAGRAM__INFORMATION_THREAT_ELEMENT:
				return getInformationThreatElement();
			case IqtoolPackage.DIAGRAM__MONITORING_ELEMENT:
				return getMonitoringElement();
			case IqtoolPackage.DIAGRAM__INFORMATION_MONITORING_ELEMENT:
				return getInformationMonitoringElement();
			case IqtoolPackage.DIAGRAM__GOAL_MONITORING_ELEMENT:
				return getGoalMonitoringElement();
			case IqtoolPackage.DIAGRAM__ADOPTION_ELEMENT:
				return getAdoptionElement();
			case IqtoolPackage.DIAGRAM__GOAL_ADOPTION_ELEMENT:
				return getGoalAdoptionElement();
			case IqtoolPackage.DIAGRAM__INFORMATION_ADOPTION_ELEMENT:
				return getInformationAdoptionElement();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.DIAGRAM__ACTOR_ELEMENT:
				getActorElement().clear();
				getActorElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__GOAL_ELEMENT:
				getGoalElement().clear();
				getGoalElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__INFO_ELEMENT:
				getInfoElement().clear();
				getInfoElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__SCOPE_ELEMENT:
				getScopeElement().clear();
				getScopeElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__DELEGATION_ELEMENT:
				getDelegationElement().clear();
				getDelegationElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__PROVISION_ELEMENT:
				getProvisionElement().clear();
				getProvisionElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__DELEGATION_TRUST_ELEMENT:
				getDelegationTrustElement().clear();
				getDelegationTrustElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__AGENT_ELEMENT:
				getAgentElement().clear();
				getAgentElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__ROLE_ELEMENT:
				getRoleElement().clear();
				getRoleElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__PERM_DELE_ELEMENT:
				getPermDeleElement().clear();
				getPermDeleElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__TRUST_PERM_DELE_ELEMENT:
				getTrustPermDeleElement().clear();
				getTrustPermDeleElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__READ_ELEMENT:
				getReadElement().clear();
				getReadElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__SEND_ELEMENT:
				getSendElement().clear();
				getSendElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__POSTION_ELELEMENT:
				getPostionElelement().clear();
				getPostionElelement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__PRODUCE_ELEMENT:
				getProduceElement().clear();
				getProduceElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__SPOSITION_ELEMENT:
				getSpositionElement().clear();
				getSpositionElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__BPOSITION_ELEMENT:
				getBpositionElement().clear();
				getBpositionElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__EPOSITION_ELEMENT:
				getEpositionElement().clear();
				getEpositionElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__PRODUCE_TRUST_ELEMENT:
				getProduceTrustElement().clear();
				getProduceTrustElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__SOFTGOAL_ELEMENT:
				getSoftgoalElement().clear();
				getSoftgoalElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__IQ_CONSTRAINT_ELEMENT:
				getIqConstraintElement().clear();
				getIqConstraintElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__THREAT_ELEMENT:
				getThreatElement().clear();
				getThreatElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__INSTANCE_GOAL_ELEMENT:
				getInstanceGoalElement().clear();
				getInstanceGoalElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__GENERAL_GOAL_ELEMENT:
				getGeneralGoalElement().clear();
				getGeneralGoalElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__INSTANCE_INFORMATION_ELEMENT:
				getInstanceInformationElement().clear();
				getInstanceInformationElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__GENERAL_INFORMATION_ELEMENT:
				getGeneralInformationElement().clear();
				getGeneralInformationElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__GOAL_THREAT_ELEMENT:
				getGoalThreatElement().clear();
				getGoalThreatElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__INFORMATION_THREAT_ELEMENT:
				getInformationThreatElement().clear();
				getInformationThreatElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__MONITORING_ELEMENT:
				getMonitoringElement().clear();
				getMonitoringElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__INFORMATION_MONITORING_ELEMENT:
				getInformationMonitoringElement().clear();
				getInformationMonitoringElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__GOAL_MONITORING_ELEMENT:
				getGoalMonitoringElement().clear();
				getGoalMonitoringElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__ADOPTION_ELEMENT:
				getAdoptionElement().clear();
				getAdoptionElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__GOAL_ADOPTION_ELEMENT:
				getGoalAdoptionElement().clear();
				getGoalAdoptionElement().addAll((Collection)newValue);
				return;
			case IqtoolPackage.DIAGRAM__INFORMATION_ADOPTION_ELEMENT:
				getInformationAdoptionElement().clear();
				getInformationAdoptionElement().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.DIAGRAM__ACTOR_ELEMENT:
				getActorElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__GOAL_ELEMENT:
				getGoalElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__INFO_ELEMENT:
				getInfoElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__SCOPE_ELEMENT:
				getScopeElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__DELEGATION_ELEMENT:
				getDelegationElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__PROVISION_ELEMENT:
				getProvisionElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__DELEGATION_TRUST_ELEMENT:
				getDelegationTrustElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__AGENT_ELEMENT:
				getAgentElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__ROLE_ELEMENT:
				getRoleElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__PERM_DELE_ELEMENT:
				getPermDeleElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__TRUST_PERM_DELE_ELEMENT:
				getTrustPermDeleElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__READ_ELEMENT:
				getReadElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__SEND_ELEMENT:
				getSendElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__POSTION_ELELEMENT:
				getPostionElelement().clear();
				return;
			case IqtoolPackage.DIAGRAM__PRODUCE_ELEMENT:
				getProduceElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__SPOSITION_ELEMENT:
				getSpositionElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__BPOSITION_ELEMENT:
				getBpositionElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__EPOSITION_ELEMENT:
				getEpositionElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__PRODUCE_TRUST_ELEMENT:
				getProduceTrustElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__SOFTGOAL_ELEMENT:
				getSoftgoalElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__IQ_CONSTRAINT_ELEMENT:
				getIqConstraintElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__THREAT_ELEMENT:
				getThreatElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__INSTANCE_GOAL_ELEMENT:
				getInstanceGoalElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__GENERAL_GOAL_ELEMENT:
				getGeneralGoalElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__INSTANCE_INFORMATION_ELEMENT:
				getInstanceInformationElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__GENERAL_INFORMATION_ELEMENT:
				getGeneralInformationElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__GOAL_THREAT_ELEMENT:
				getGoalThreatElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__INFORMATION_THREAT_ELEMENT:
				getInformationThreatElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__MONITORING_ELEMENT:
				getMonitoringElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__INFORMATION_MONITORING_ELEMENT:
				getInformationMonitoringElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__GOAL_MONITORING_ELEMENT:
				getGoalMonitoringElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__ADOPTION_ELEMENT:
				getAdoptionElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__GOAL_ADOPTION_ELEMENT:
				getGoalAdoptionElement().clear();
				return;
			case IqtoolPackage.DIAGRAM__INFORMATION_ADOPTION_ELEMENT:
				getInformationAdoptionElement().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.DIAGRAM__ACTOR_ELEMENT:
				return actorElement != null && !actorElement.isEmpty();
			case IqtoolPackage.DIAGRAM__GOAL_ELEMENT:
				return goalElement != null && !goalElement.isEmpty();
			case IqtoolPackage.DIAGRAM__INFO_ELEMENT:
				return infoElement != null && !infoElement.isEmpty();
			case IqtoolPackage.DIAGRAM__SCOPE_ELEMENT:
				return scopeElement != null && !scopeElement.isEmpty();
			case IqtoolPackage.DIAGRAM__DELEGATION_ELEMENT:
				return delegationElement != null && !delegationElement.isEmpty();
			case IqtoolPackage.DIAGRAM__PROVISION_ELEMENT:
				return provisionElement != null && !provisionElement.isEmpty();
			case IqtoolPackage.DIAGRAM__DELEGATION_TRUST_ELEMENT:
				return delegationTrustElement != null && !delegationTrustElement.isEmpty();
			case IqtoolPackage.DIAGRAM__AGENT_ELEMENT:
				return agentElement != null && !agentElement.isEmpty();
			case IqtoolPackage.DIAGRAM__ROLE_ELEMENT:
				return roleElement != null && !roleElement.isEmpty();
			case IqtoolPackage.DIAGRAM__PERM_DELE_ELEMENT:
				return permDeleElement != null && !permDeleElement.isEmpty();
			case IqtoolPackage.DIAGRAM__TRUST_PERM_DELE_ELEMENT:
				return trustPermDeleElement != null && !trustPermDeleElement.isEmpty();
			case IqtoolPackage.DIAGRAM__READ_ELEMENT:
				return readElement != null && !readElement.isEmpty();
			case IqtoolPackage.DIAGRAM__SEND_ELEMENT:
				return sendElement != null && !sendElement.isEmpty();
			case IqtoolPackage.DIAGRAM__POSTION_ELELEMENT:
				return postionElelement != null && !postionElelement.isEmpty();
			case IqtoolPackage.DIAGRAM__PRODUCE_ELEMENT:
				return produceElement != null && !produceElement.isEmpty();
			case IqtoolPackage.DIAGRAM__SPOSITION_ELEMENT:
				return spositionElement != null && !spositionElement.isEmpty();
			case IqtoolPackage.DIAGRAM__BPOSITION_ELEMENT:
				return bpositionElement != null && !bpositionElement.isEmpty();
			case IqtoolPackage.DIAGRAM__EPOSITION_ELEMENT:
				return epositionElement != null && !epositionElement.isEmpty();
			case IqtoolPackage.DIAGRAM__PRODUCE_TRUST_ELEMENT:
				return produceTrustElement != null && !produceTrustElement.isEmpty();
			case IqtoolPackage.DIAGRAM__SOFTGOAL_ELEMENT:
				return softgoalElement != null && !softgoalElement.isEmpty();
			case IqtoolPackage.DIAGRAM__IQ_CONSTRAINT_ELEMENT:
				return iqConstraintElement != null && !iqConstraintElement.isEmpty();
			case IqtoolPackage.DIAGRAM__THREAT_ELEMENT:
				return threatElement != null && !threatElement.isEmpty();
			case IqtoolPackage.DIAGRAM__INSTANCE_GOAL_ELEMENT:
				return instanceGoalElement != null && !instanceGoalElement.isEmpty();
			case IqtoolPackage.DIAGRAM__GENERAL_GOAL_ELEMENT:
				return generalGoalElement != null && !generalGoalElement.isEmpty();
			case IqtoolPackage.DIAGRAM__INSTANCE_INFORMATION_ELEMENT:
				return instanceInformationElement != null && !instanceInformationElement.isEmpty();
			case IqtoolPackage.DIAGRAM__GENERAL_INFORMATION_ELEMENT:
				return generalInformationElement != null && !generalInformationElement.isEmpty();
			case IqtoolPackage.DIAGRAM__GOAL_THREAT_ELEMENT:
				return goalThreatElement != null && !goalThreatElement.isEmpty();
			case IqtoolPackage.DIAGRAM__INFORMATION_THREAT_ELEMENT:
				return informationThreatElement != null && !informationThreatElement.isEmpty();
			case IqtoolPackage.DIAGRAM__MONITORING_ELEMENT:
				return monitoringElement != null && !monitoringElement.isEmpty();
			case IqtoolPackage.DIAGRAM__INFORMATION_MONITORING_ELEMENT:
				return informationMonitoringElement != null && !informationMonitoringElement.isEmpty();
			case IqtoolPackage.DIAGRAM__GOAL_MONITORING_ELEMENT:
				return goalMonitoringElement != null && !goalMonitoringElement.isEmpty();
			case IqtoolPackage.DIAGRAM__ADOPTION_ELEMENT:
				return adoptionElement != null && !adoptionElement.isEmpty();
			case IqtoolPackage.DIAGRAM__GOAL_ADOPTION_ELEMENT:
				return goalAdoptionElement != null && !goalAdoptionElement.isEmpty();
			case IqtoolPackage.DIAGRAM__INFORMATION_ADOPTION_ELEMENT:
				return informationAdoptionElement != null && !informationAdoptionElement.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //diagramImpl
