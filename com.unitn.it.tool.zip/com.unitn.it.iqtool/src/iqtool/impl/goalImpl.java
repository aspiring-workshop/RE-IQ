/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.betweenPostion;
import iqtool.endPostion;
import iqtool.goal;
import iqtool.information;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>goal</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.goalImpl#getName <em>Name</em>}</li>
 *   <li>{@link iqtool.impl.goalImpl#getOrdecomposition <em>Ordecomposition</em>}</li>
 *   <li>{@link iqtool.impl.goalImpl#getAnddecomposition <em>Anddecomposition</em>}</li>
 *   <li>{@link iqtool.impl.goalImpl#getModify <em>Modify</em>}</li>
 *   <li>{@link iqtool.impl.goalImpl#getOutarc <em>Outarc</em>}</li>
 *   <li>{@link iqtool.impl.goalImpl#getInarc <em>Inarc</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class goalImpl extends MinimalEObjectImpl.Container implements goal {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getOrdecomposition() <em>Ordecomposition</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOrdecomposition()
	 * @generated
	 * @ordered
	 */
	protected EList ordecomposition;

	/**
	 * The cached value of the '{@link #getAnddecomposition() <em>Anddecomposition</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAnddecomposition()
	 * @generated
	 * @ordered
	 */
	protected EList anddecomposition;

	/**
	 * The cached value of the '{@link #getModify() <em>Modify</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModify()
	 * @generated
	 * @ordered
	 */
	protected EList modify;

	/**
	 * The cached value of the '{@link #getOutarc() <em>Outarc</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutarc()
	 * @generated
	 * @ordered
	 */
	protected EList outarc;

	/**
	 * The cached value of the '{@link #getInarc() <em>Inarc</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInarc()
	 * @generated
	 * @ordered
	 */
	protected EList inarc;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected goalImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.GOAL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.GOAL__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getOrdecomposition() {
		if (ordecomposition == null) {
			ordecomposition = new EObjectResolvingEList(goal.class, this, IqtoolPackage.GOAL__ORDECOMPOSITION);
		}
		return ordecomposition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getAnddecomposition() {
		if (anddecomposition == null) {
			anddecomposition = new EObjectResolvingEList(goal.class, this, IqtoolPackage.GOAL__ANDDECOMPOSITION);
		}
		return anddecomposition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getModify() {
		if (modify == null) {
			modify = new EObjectResolvingEList(information.class, this, IqtoolPackage.GOAL__MODIFY);
		}
		return modify;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getOutarc() {
		if (outarc == null) {
			outarc = new EObjectResolvingEList(endPostion.class, this, IqtoolPackage.GOAL__OUTARC);
		}
		return outarc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getInarc() {
		if (inarc == null) {
			inarc = new EObjectResolvingEList(betweenPostion.class, this, IqtoolPackage.GOAL__INARC);
		}
		return inarc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.GOAL__NAME:
				return getName();
			case IqtoolPackage.GOAL__ORDECOMPOSITION:
				return getOrdecomposition();
			case IqtoolPackage.GOAL__ANDDECOMPOSITION:
				return getAnddecomposition();
			case IqtoolPackage.GOAL__MODIFY:
				return getModify();
			case IqtoolPackage.GOAL__OUTARC:
				return getOutarc();
			case IqtoolPackage.GOAL__INARC:
				return getInarc();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.GOAL__NAME:
				setName((String)newValue);
				return;
			case IqtoolPackage.GOAL__ORDECOMPOSITION:
				getOrdecomposition().clear();
				getOrdecomposition().addAll((Collection)newValue);
				return;
			case IqtoolPackage.GOAL__ANDDECOMPOSITION:
				getAnddecomposition().clear();
				getAnddecomposition().addAll((Collection)newValue);
				return;
			case IqtoolPackage.GOAL__MODIFY:
				getModify().clear();
				getModify().addAll((Collection)newValue);
				return;
			case IqtoolPackage.GOAL__OUTARC:
				getOutarc().clear();
				getOutarc().addAll((Collection)newValue);
				return;
			case IqtoolPackage.GOAL__INARC:
				getInarc().clear();
				getInarc().addAll((Collection)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.GOAL__NAME:
				setName(NAME_EDEFAULT);
				return;
			case IqtoolPackage.GOAL__ORDECOMPOSITION:
				getOrdecomposition().clear();
				return;
			case IqtoolPackage.GOAL__ANDDECOMPOSITION:
				getAnddecomposition().clear();
				return;
			case IqtoolPackage.GOAL__MODIFY:
				getModify().clear();
				return;
			case IqtoolPackage.GOAL__OUTARC:
				getOutarc().clear();
				return;
			case IqtoolPackage.GOAL__INARC:
				getInarc().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.GOAL__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case IqtoolPackage.GOAL__ORDECOMPOSITION:
				return ordecomposition != null && !ordecomposition.isEmpty();
			case IqtoolPackage.GOAL__ANDDECOMPOSITION:
				return anddecomposition != null && !anddecomposition.isEmpty();
			case IqtoolPackage.GOAL__MODIFY:
				return modify != null && !modify.isEmpty();
			case IqtoolPackage.GOAL__OUTARC:
				return outarc != null && !outarc.isEmpty();
			case IqtoolPackage.GOAL__INARC:
				return inarc != null && !inarc.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //goalImpl
