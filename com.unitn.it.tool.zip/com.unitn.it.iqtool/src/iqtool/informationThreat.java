/**
 */
package iqtool;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>information Threat</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.informationThreat#getThreatInformation <em>Threat Information</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getinformationThreat()
 * @model
 * @generated
 */
public interface informationThreat extends threat {
	/**
	 * Returns the value of the '<em><b>Threat Information</b></em>' reference list.
	 * The list contents are of type {@link iqtool.information}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Threat Information</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Threat Information</em>' reference list.
	 * @see iqtool.IqtoolPackage#getinformationThreat_ThreatInformation()
	 * @model type="iqtool.information"
	 * @generated
	 */
	EList getThreatInformation();

} // informationThreat
