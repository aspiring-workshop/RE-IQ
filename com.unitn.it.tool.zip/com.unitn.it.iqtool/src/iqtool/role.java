/**
 */
package iqtool;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>role</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.role#getIsa <em>Isa</em>}</li>
 *   <li>{@link iqtool.role#getIs_capable <em>Is capable</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getrole()
 * @model
 * @generated
 */
public interface role extends actor {
	/**
	 * Returns the value of the '<em><b>Isa</b></em>' reference list.
	 * The list contents are of type {@link iqtool.role}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Isa</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Isa</em>' reference list.
	 * @see iqtool.IqtoolPackage#getrole_Isa()
	 * @model type="iqtool.role"
	 * @generated
	 */
	EList getIsa();

	/**
	 * Returns the value of the '<em><b>Is capable</b></em>' reference list.
	 * The list contents are of type {@link iqtool.goal}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is capable</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is capable</em>' reference list.
	 * @see iqtool.IqtoolPackage#getrole_Is_capable()
	 * @model type="iqtool.goal"
	 * @generated
	 */
	EList getIs_capable();

} // role
