/**
 */
package iqtool;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see iqtool.IqtoolFactory
 * @model kind="package"
 * @generated
 */
public interface IqtoolPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "iqtool";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/iqtool";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "iqtool";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	IqtoolPackage eINSTANCE = iqtool.impl.IqtoolPackageImpl.init();

	/**
	 * The meta object id for the '{@link iqtool.impl.actorImpl <em>actor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.actorImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getactor()
	 * @generated
	 */
	int ACTOR = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR__NAME = 0;

	/**
	 * The feature id for the '<em><b>Aims</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR__AIMS = 1;

	/**
	 * The feature id for the '<em><b>Own</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR__OWN = 2;

	/**
	 * The feature id for the '<em><b>Capable Of Threat</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR__CAPABLE_OF_THREAT = 3;

	/**
	 * The feature id for the '<em><b>Incapable Of Threat</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR__INCAPABLE_OF_THREAT = 4;

	/**
	 * The number of structural features of the '<em>actor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link iqtool.impl.diagramImpl <em>diagram</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.diagramImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getdiagram()
	 * @generated
	 */
	int DIAGRAM = 1;

	/**
	 * The feature id for the '<em><b>Actor Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__ACTOR_ELEMENT = 0;

	/**
	 * The feature id for the '<em><b>Goal Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__GOAL_ELEMENT = 1;

	/**
	 * The feature id for the '<em><b>Info Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__INFO_ELEMENT = 2;

	/**
	 * The feature id for the '<em><b>Scope Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__SCOPE_ELEMENT = 3;

	/**
	 * The feature id for the '<em><b>Delegation Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__DELEGATION_ELEMENT = 4;

	/**
	 * The feature id for the '<em><b>Provision Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__PROVISION_ELEMENT = 5;

	/**
	 * The feature id for the '<em><b>Delegation Trust Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__DELEGATION_TRUST_ELEMENT = 6;

	/**
	 * The feature id for the '<em><b>Agent Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__AGENT_ELEMENT = 7;

	/**
	 * The feature id for the '<em><b>Role Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__ROLE_ELEMENT = 8;

	/**
	 * The feature id for the '<em><b>Perm Dele Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__PERM_DELE_ELEMENT = 9;

	/**
	 * The feature id for the '<em><b>Trust Perm Dele Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__TRUST_PERM_DELE_ELEMENT = 10;

	/**
	 * The feature id for the '<em><b>Read Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__READ_ELEMENT = 11;

	/**
	 * The feature id for the '<em><b>Send Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__SEND_ELEMENT = 12;

	/**
	 * The feature id for the '<em><b>Postion Elelement</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__POSTION_ELELEMENT = 13;

	/**
	 * The feature id for the '<em><b>Produce Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__PRODUCE_ELEMENT = 14;

	/**
	 * The feature id for the '<em><b>Sposition Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__SPOSITION_ELEMENT = 15;

	/**
	 * The feature id for the '<em><b>Bposition Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__BPOSITION_ELEMENT = 16;

	/**
	 * The feature id for the '<em><b>Eposition Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__EPOSITION_ELEMENT = 17;

	/**
	 * The feature id for the '<em><b>Produce Trust Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__PRODUCE_TRUST_ELEMENT = 18;

	/**
	 * The feature id for the '<em><b>Softgoal Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__SOFTGOAL_ELEMENT = 19;

	/**
	 * The feature id for the '<em><b>Iq Constraint Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__IQ_CONSTRAINT_ELEMENT = 20;

	/**
	 * The feature id for the '<em><b>Threat Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__THREAT_ELEMENT = 21;

	/**
	 * The feature id for the '<em><b>Instance Goal Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__INSTANCE_GOAL_ELEMENT = 22;

	/**
	 * The feature id for the '<em><b>General Goal Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__GENERAL_GOAL_ELEMENT = 23;

	/**
	 * The feature id for the '<em><b>Instance Information Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__INSTANCE_INFORMATION_ELEMENT = 24;

	/**
	 * The feature id for the '<em><b>General Information Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__GENERAL_INFORMATION_ELEMENT = 25;

	/**
	 * The feature id for the '<em><b>Goal Threat Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__GOAL_THREAT_ELEMENT = 26;

	/**
	 * The feature id for the '<em><b>Information Threat Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__INFORMATION_THREAT_ELEMENT = 27;

	/**
	 * The feature id for the '<em><b>Monitoring Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__MONITORING_ELEMENT = 28;

	/**
	 * The feature id for the '<em><b>Information Monitoring Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__INFORMATION_MONITORING_ELEMENT = 29;

	/**
	 * The feature id for the '<em><b>Goal Monitoring Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__GOAL_MONITORING_ELEMENT = 30;

	/**
	 * The feature id for the '<em><b>Adoption Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__ADOPTION_ELEMENT = 31;

	/**
	 * The feature id for the '<em><b>Goal Adoption Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__GOAL_ADOPTION_ELEMENT = 32;

	/**
	 * The feature id for the '<em><b>Information Adoption Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM__INFORMATION_ADOPTION_ELEMENT = 33;

	/**
	 * The number of structural features of the '<em>diagram</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIAGRAM_FEATURE_COUNT = 34;

	/**
	 * The meta object id for the '{@link iqtool.impl.roleImpl <em>role</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.roleImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getrole()
	 * @generated
	 */
	int ROLE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__NAME = ACTOR__NAME;

	/**
	 * The feature id for the '<em><b>Aims</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__AIMS = ACTOR__AIMS;

	/**
	 * The feature id for the '<em><b>Own</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__OWN = ACTOR__OWN;

	/**
	 * The feature id for the '<em><b>Capable Of Threat</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__CAPABLE_OF_THREAT = ACTOR__CAPABLE_OF_THREAT;

	/**
	 * The feature id for the '<em><b>Incapable Of Threat</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__INCAPABLE_OF_THREAT = ACTOR__INCAPABLE_OF_THREAT;

	/**
	 * The feature id for the '<em><b>Isa</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__ISA = ACTOR_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Is capable</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__IS_CAPABLE = ACTOR_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>role</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_FEATURE_COUNT = ACTOR_FEATURE_COUNT + 2;

	/**
	 * The meta object id for the '{@link iqtool.impl.agentImpl <em>agent</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.agentImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getagent()
	 * @generated
	 */
	int AGENT = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT__NAME = ACTOR__NAME;

	/**
	 * The feature id for the '<em><b>Aims</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT__AIMS = ACTOR__AIMS;

	/**
	 * The feature id for the '<em><b>Own</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT__OWN = ACTOR__OWN;

	/**
	 * The feature id for the '<em><b>Capable Of Threat</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT__CAPABLE_OF_THREAT = ACTOR__CAPABLE_OF_THREAT;

	/**
	 * The feature id for the '<em><b>Incapable Of Threat</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT__INCAPABLE_OF_THREAT = ACTOR__INCAPABLE_OF_THREAT;

	/**
	 * The feature id for the '<em><b>Play</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT__PLAY = ACTOR_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>agent</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENT_FEATURE_COUNT = ACTOR_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.permDelegationImpl <em>perm Delegation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.permDelegationImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getpermDelegation()
	 * @generated
	 */
	int PERM_DELEGATION = 4;

	/**
	 * The feature id for the '<em><b>Perm Over</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_DELEGATION__PERM_OVER = 0;

	/**
	 * The feature id for the '<em><b>Perm Dele From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_DELEGATION__PERM_DELE_FROM = 1;

	/**
	 * The feature id for the '<em><b>Perm Dele To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_DELEGATION__PERM_DELE_TO = 2;

	/**
	 * The feature id for the '<em><b>Read Perm</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_DELEGATION__READ_PERM = 3;

	/**
	 * The feature id for the '<em><b>Produce Perm</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_DELEGATION__PRODUCE_PERM = 4;

	/**
	 * The feature id for the '<em><b>Modify Perm</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_DELEGATION__MODIFY_PERM = 5;

	/**
	 * The feature id for the '<em><b>Send Perm</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_DELEGATION__SEND_PERM = 6;

	/**
	 * The number of structural features of the '<em>perm Delegation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERM_DELEGATION_FEATURE_COUNT = 7;

	/**
	 * The meta object id for the '{@link iqtool.impl.positionImpl <em>position</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.positionImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getposition()
	 * @generated
	 */
	int POSITION = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION__NAME = 0;

	/**
	 * The number of structural features of the '<em>position</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.startPostionImpl <em>start Postion</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.startPostionImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getstartPostion()
	 * @generated
	 */
	int START_POSTION = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int START_POSTION__NAME = POSITION__NAME;

	/**
	 * The feature id for the '<em><b>Inarc</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int START_POSTION__INARC = POSITION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>start Postion</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int START_POSTION_FEATURE_COUNT = POSITION_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.readImpl <em>read</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.readImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getread()
	 * @generated
	 */
	int READ = 6;

	/**
	 * The feature id for the '<em><b>Pou</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READ__POU = 0;

	/**
	 * The feature id for the '<em><b>Read Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READ__READ_OF = 1;

	/**
	 * The feature id for the '<em><b>Read By</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READ__READ_BY = 2;

	/**
	 * The feature id for the '<em><b>Read Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READ__READ_TYPE = 3;

	/**
	 * The number of structural features of the '<em>read</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READ_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link iqtool.impl.endPostionImpl <em>end Postion</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.endPostionImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getendPostion()
	 * @generated
	 */
	int END_POSTION = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_POSTION__NAME = POSITION__NAME;

	/**
	 * The number of structural features of the '<em>end Postion</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_POSTION_FEATURE_COUNT = POSITION_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link iqtool.impl.sendImpl <em>send</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.sendImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getsend()
	 * @generated
	 */
	int SEND = 9;

	/**
	 * The feature id for the '<em><b>Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEND__TIME = 0;

	/**
	 * The feature id for the '<em><b>Send Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEND__SEND_OF = 1;

	/**
	 * The feature id for the '<em><b>Send By</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEND__SEND_BY = 2;

	/**
	 * The feature id for the '<em><b>Send To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEND__SEND_TO = 3;

	/**
	 * The number of structural features of the '<em>send</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEND_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link iqtool.impl.goalDelegationImpl <em>goal Delegation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.goalDelegationImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getgoalDelegation()
	 * @generated
	 */
	int GOAL_DELEGATION = 10;

	/**
	 * The feature id for the '<em><b>Delegation Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_DELEGATION__DELEGATION_OF = 0;

	/**
	 * The feature id for the '<em><b>Delegation From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_DELEGATION__DELEGATION_FROM = 1;

	/**
	 * The feature id for the '<em><b>Delegation To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_DELEGATION__DELEGATION_TO = 2;

	/**
	 * The number of structural features of the '<em>goal Delegation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_DELEGATION_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link iqtool.impl.delegationTrustImpl <em>delegation Trust</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.delegationTrustImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getdelegationTrust()
	 * @generated
	 */
	int DELEGATION_TRUST = 11;

	/**
	 * The feature id for the '<em><b>Trustlevel</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELEGATION_TRUST__TRUSTLEVEL = 0;

	/**
	 * The feature id for the '<em><b>Trustum Goal</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELEGATION_TRUST__TRUSTUM_GOAL = 1;

	/**
	 * The feature id for the '<em><b>Trustor Goal</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELEGATION_TRUST__TRUSTOR_GOAL = 2;

	/**
	 * The feature id for the '<em><b>Trustee Goal</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELEGATION_TRUST__TRUSTEE_GOAL = 3;

	/**
	 * The number of structural features of the '<em>delegation Trust</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELEGATION_TRUST_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link iqtool.impl.betweenPostionImpl <em>between Postion</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.betweenPostionImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getbetweenPostion()
	 * @generated
	 */
	int BETWEEN_POSTION = 12;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BETWEEN_POSTION__NAME = POSITION__NAME;

	/**
	 * The feature id for the '<em><b>Outarc</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BETWEEN_POSTION__OUTARC = POSITION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>between Postion</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BETWEEN_POSTION_FEATURE_COUNT = POSITION_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.infoProvisionImpl <em>info Provision</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.infoProvisionImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getinfoProvision()
	 * @generated
	 */
	int INFO_PROVISION = 13;

	/**
	 * The feature id for the '<em><b>Provision Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_PROVISION__PROVISION_OF = 0;

	/**
	 * The feature id for the '<em><b>Provision From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_PROVISION__PROVISION_FROM = 1;

	/**
	 * The feature id for the '<em><b>Provision To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_PROVISION__PROVISION_TO = 2;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_PROVISION__TYPE = 3;

	/**
	 * The feature id for the '<em><b>Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_PROVISION__TIME = 4;

	/**
	 * The number of structural features of the '<em>info Provision</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFO_PROVISION_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link iqtool.impl.trustPermDelegationImpl <em>trust Perm Delegation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.trustPermDelegationImpl
	 * @see iqtool.impl.IqtoolPackageImpl#gettrustPermDelegation()
	 * @generated
	 */
	int TRUST_PERM_DELEGATION = 14;

	/**
	 * The feature id for the '<em><b>Trust Perm Dele To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_PERM_DELEGATION__TRUST_PERM_DELE_TO = 0;

	/**
	 * The feature id for the '<em><b>Trust Perm Dele From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_PERM_DELEGATION__TRUST_PERM_DELE_FROM = 1;

	/**
	 * The feature id for the '<em><b>Trust Perm Dele Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_PERM_DELEGATION__TRUST_PERM_DELE_OF = 2;

	/**
	 * The feature id for the '<em><b>Trustprodue</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_PERM_DELEGATION__TRUSTPRODUE = 3;

	/**
	 * The feature id for the '<em><b>Trustread</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_PERM_DELEGATION__TRUSTREAD = 4;

	/**
	 * The feature id for the '<em><b>Trustsend</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_PERM_DELEGATION__TRUSTSEND = 5;

	/**
	 * The feature id for the '<em><b>Trustmodify</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_PERM_DELEGATION__TRUSTMODIFY = 6;

	/**
	 * The number of structural features of the '<em>trust Perm Delegation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRUST_PERM_DELEGATION_FEATURE_COUNT = 7;

	/**
	 * The meta object id for the '{@link iqtool.impl.informationImpl <em>information</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.informationImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getinformation()
	 * @generated
	 */
	int INFORMATION = 15;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Volatility</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION__VOLATILITY = 1;

	/**
	 * The feature id for the '<em><b>Sub Item</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION__SUB_ITEM = 2;

	/**
	 * The number of structural features of the '<em>information</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link iqtool.impl.scopeImpl <em>scope</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.scopeImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getscope()
	 * @generated
	 */
	int SCOPE = 16;

	/**
	 * The feature id for the '<em><b>Contains</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCOPE__CONTAINS = 0;

	/**
	 * The number of structural features of the '<em>scope</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCOPE_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.goalImpl <em>goal</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.goalImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getgoal()
	 * @generated
	 */
	int GOAL = 17;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__NAME = 0;

	/**
	 * The feature id for the '<em><b>Ordecomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__ORDECOMPOSITION = 1;

	/**
	 * The feature id for the '<em><b>Anddecomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__ANDDECOMPOSITION = 2;

	/**
	 * The feature id for the '<em><b>Modify</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__MODIFY = 3;

	/**
	 * The feature id for the '<em><b>Outarc</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__OUTARC = 4;

	/**
	 * The feature id for the '<em><b>Inarc</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL__INARC = 5;

	/**
	 * The number of structural features of the '<em>goal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_FEATURE_COUNT = 6;

	/**
	 * The meta object id for the '{@link iqtool.impl.produceImpl <em>produce</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.produceImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getproduce()
	 * @generated
	 */
	int PRODUCE = 18;

	/**
	 * The feature id for the '<em><b>Produce By</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE__PRODUCE_BY = 0;

	/**
	 * The feature id for the '<em><b>Produce Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE__PRODUCE_OF = 1;

	/**
	 * The feature id for the '<em><b>Produce Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE__PRODUCE_TYPE = 2;

	/**
	 * The number of structural features of the '<em>produce</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link iqtool.impl.produceTrustImpl <em>produce Trust</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.produceTrustImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getproduceTrust()
	 * @generated
	 */
	int PRODUCE_TRUST = 19;

	/**
	 * The feature id for the '<em><b>Trustlevel</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE_TRUST__TRUSTLEVEL = 0;

	/**
	 * The feature id for the '<em><b>Produce Trustor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE_TRUST__PRODUCE_TRUSTOR = 1;

	/**
	 * The feature id for the '<em><b>Produce Trustee</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE_TRUST__PRODUCE_TRUSTEE = 2;

	/**
	 * The feature id for the '<em><b>Produce Trust Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE_TRUST__PRODUCE_TRUST_OF = 3;

	/**
	 * The number of structural features of the '<em>produce Trust</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCE_TRUST_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link iqtool.impl.softgoalImpl <em>softgoal</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.softgoalImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getsoftgoal()
	 * @generated
	 */
	int SOFTGOAL = 20;

	/**
	 * The feature id for the '<em><b>Anddecomposition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTGOAL__ANDDECOMPOSITION = 0;

	/**
	 * The feature id for the '<em><b>Soft Goal Of</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTGOAL__SOFT_GOAL_OF = 1;

	/**
	 * The feature id for the '<em><b>Softgoal Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTGOAL__SOFTGOAL_TARGET = 2;

	/**
	 * The feature id for the '<em><b>Softgoal Concerning</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTGOAL__SOFTGOAL_CONCERNING = 3;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTGOAL__TYPE = 4;

	/**
	 * The number of structural features of the '<em>softgoal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOFTGOAL_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link iqtool.impl.iqConstraintImpl <em>iq Constraint</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.iqConstraintImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getiqConstraint()
	 * @generated
	 */
	int IQ_CONSTRAINT = 21;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IQ_CONSTRAINT__TYPE = 0;

	/**
	 * The feature id for the '<em><b>Approximate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IQ_CONSTRAINT__APPROXIMATE = 1;

	/**
	 * The number of structural features of the '<em>iq Constraint</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IQ_CONSTRAINT_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link iqtool.impl.instanceGoalImpl <em>instance Goal</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.instanceGoalImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getinstanceGoal()
	 * @generated
	 */
	int INSTANCE_GOAL = 22;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_GOAL__NAME = GOAL__NAME;

	/**
	 * The feature id for the '<em><b>Ordecomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_GOAL__ORDECOMPOSITION = GOAL__ORDECOMPOSITION;

	/**
	 * The feature id for the '<em><b>Anddecomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_GOAL__ANDDECOMPOSITION = GOAL__ANDDECOMPOSITION;

	/**
	 * The feature id for the '<em><b>Modify</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_GOAL__MODIFY = GOAL__MODIFY;

	/**
	 * The feature id for the '<em><b>Outarc</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_GOAL__OUTARC = GOAL__OUTARC;

	/**
	 * The feature id for the '<em><b>Inarc</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_GOAL__INARC = GOAL__INARC;

	/**
	 * The feature id for the '<em><b>Instance</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_GOAL__INSTANCE = GOAL_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>instance Goal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_GOAL_FEATURE_COUNT = GOAL_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.generalGoalImpl <em>general Goal</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.generalGoalImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getgeneralGoal()
	 * @generated
	 */
	int GENERAL_GOAL = 23;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_GOAL__NAME = GOAL__NAME;

	/**
	 * The feature id for the '<em><b>Ordecomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_GOAL__ORDECOMPOSITION = GOAL__ORDECOMPOSITION;

	/**
	 * The feature id for the '<em><b>Anddecomposition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_GOAL__ANDDECOMPOSITION = GOAL__ANDDECOMPOSITION;

	/**
	 * The feature id for the '<em><b>Modify</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_GOAL__MODIFY = GOAL__MODIFY;

	/**
	 * The feature id for the '<em><b>Outarc</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_GOAL__OUTARC = GOAL__OUTARC;

	/**
	 * The feature id for the '<em><b>Inarc</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_GOAL__INARC = GOAL__INARC;

	/**
	 * The number of structural features of the '<em>general Goal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_GOAL_FEATURE_COUNT = GOAL_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link iqtool.impl.instanceInformationImpl <em>instance Information</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.instanceInformationImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getinstanceInformation()
	 * @generated
	 */
	int INSTANCE_INFORMATION = 24;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_INFORMATION__NAME = INFORMATION__NAME;

	/**
	 * The feature id for the '<em><b>Volatility</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_INFORMATION__VOLATILITY = INFORMATION__VOLATILITY;

	/**
	 * The feature id for the '<em><b>Sub Item</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_INFORMATION__SUB_ITEM = INFORMATION__SUB_ITEM;

	/**
	 * The feature id for the '<em><b>Instance</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_INFORMATION__INSTANCE = INFORMATION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>instance Information</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_INFORMATION_FEATURE_COUNT = INFORMATION_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.general_informationImpl <em>general information</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.general_informationImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getgeneral_information()
	 * @generated
	 */
	int GENERAL_INFORMATION = 25;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_INFORMATION__NAME = INFORMATION__NAME;

	/**
	 * The feature id for the '<em><b>Volatility</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_INFORMATION__VOLATILITY = INFORMATION__VOLATILITY;

	/**
	 * The feature id for the '<em><b>Sub Item</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_INFORMATION__SUB_ITEM = INFORMATION__SUB_ITEM;

	/**
	 * The number of structural features of the '<em>general information</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_INFORMATION_FEATURE_COUNT = INFORMATION_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link iqtool.impl.threatImpl <em>threat</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.threatImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getthreat()
	 * @generated
	 */
	int THREAT = 26;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREAT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Pos Contribute</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREAT__POS_CONTRIBUTE = 1;

	/**
	 * The feature id for the '<em><b>Neg Contribute</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREAT__NEG_CONTRIBUTE = 2;

	/**
	 * The number of structural features of the '<em>threat</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREAT_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link iqtool.impl.informationThreatImpl <em>information Threat</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.informationThreatImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getinformationThreat()
	 * @generated
	 */
	int INFORMATION_THREAT = 27;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_THREAT__NAME = THREAT__NAME;

	/**
	 * The feature id for the '<em><b>Pos Contribute</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_THREAT__POS_CONTRIBUTE = THREAT__POS_CONTRIBUTE;

	/**
	 * The feature id for the '<em><b>Neg Contribute</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_THREAT__NEG_CONTRIBUTE = THREAT__NEG_CONTRIBUTE;

	/**
	 * The feature id for the '<em><b>Threat Information</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_THREAT__THREAT_INFORMATION = THREAT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>information Threat</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_THREAT_FEATURE_COUNT = THREAT_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.goalThreatImpl <em>goal Threat</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.goalThreatImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getgoalThreat()
	 * @generated
	 */
	int GOAL_THREAT = 28;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_THREAT__NAME = THREAT__NAME;

	/**
	 * The feature id for the '<em><b>Pos Contribute</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_THREAT__POS_CONTRIBUTE = THREAT__POS_CONTRIBUTE;

	/**
	 * The feature id for the '<em><b>Neg Contribute</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_THREAT__NEG_CONTRIBUTE = THREAT__NEG_CONTRIBUTE;

	/**
	 * The feature id for the '<em><b>Goal Threat</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_THREAT__GOAL_THREAT = THREAT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>goal Threat</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_THREAT_FEATURE_COUNT = THREAT_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.monitoringImpl <em>monitoring</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.monitoringImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getmonitoring()
	 * @generated
	 */
	int MONITORING = 29;

	/**
	 * The feature id for the '<em><b>Monitor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITORING__MONITOR = 0;

	/**
	 * The feature id for the '<em><b>Monitored</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITORING__MONITORED = 1;

	/**
	 * The number of structural features of the '<em>monitoring</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITORING_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link iqtool.impl.informationMonitoringImpl <em>information Monitoring</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.informationMonitoringImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getinformationMonitoring()
	 * @generated
	 */
	int INFORMATION_MONITORING = 30;

	/**
	 * The feature id for the '<em><b>Monitor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_MONITORING__MONITOR = MONITORING__MONITOR;

	/**
	 * The feature id for the '<em><b>Monitored</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_MONITORING__MONITORED = MONITORING__MONITORED;

	/**
	 * The feature id for the '<em><b>Monitoring Of Information</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_MONITORING__MONITORING_OF_INFORMATION = MONITORING_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>information Monitoring</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_MONITORING_FEATURE_COUNT = MONITORING_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.goalMonitoringImpl <em>goal Monitoring</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.goalMonitoringImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getgoalMonitoring()
	 * @generated
	 */
	int GOAL_MONITORING = 31;

	/**
	 * The feature id for the '<em><b>Monitor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_MONITORING__MONITOR = MONITORING__MONITOR;

	/**
	 * The feature id for the '<em><b>Monitored</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_MONITORING__MONITORED = MONITORING__MONITORED;

	/**
	 * The feature id for the '<em><b>Monitoring Of Goal</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_MONITORING__MONITORING_OF_GOAL = MONITORING_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>goal Monitoring</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_MONITORING_FEATURE_COUNT = MONITORING_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.adoptionImpl <em>adoption</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.adoptionImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getadoption()
	 * @generated
	 */
	int ADOPTION = 32;

	/**
	 * The feature id for the '<em><b>Adoption To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADOPTION__ADOPTION_TO = 0;

	/**
	 * The feature id for the '<em><b>Adoption From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADOPTION__ADOPTION_FROM = 1;

	/**
	 * The number of structural features of the '<em>adoption</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADOPTION_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link iqtool.impl.InformationAdoptionImpl <em>Information Adoption</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.InformationAdoptionImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getInformationAdoption()
	 * @generated
	 */
	int INFORMATION_ADOPTION = 33;

	/**
	 * The feature id for the '<em><b>Adoption To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_ADOPTION__ADOPTION_TO = ADOPTION__ADOPTION_TO;

	/**
	 * The feature id for the '<em><b>Adoption From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_ADOPTION__ADOPTION_FROM = ADOPTION__ADOPTION_FROM;

	/**
	 * The feature id for the '<em><b>Adoption Of Information</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_ADOPTION__ADOPTION_OF_INFORMATION = ADOPTION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Information Adoption</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_ADOPTION_FEATURE_COUNT = ADOPTION_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link iqtool.impl.goalAdoptionImpl <em>goal Adoption</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.impl.goalAdoptionImpl
	 * @see iqtool.impl.IqtoolPackageImpl#getgoalAdoption()
	 * @generated
	 */
	int GOAL_ADOPTION = 34;

	/**
	 * The feature id for the '<em><b>Adoption To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_ADOPTION__ADOPTION_TO = ADOPTION__ADOPTION_TO;

	/**
	 * The feature id for the '<em><b>Adoption From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_ADOPTION__ADOPTION_FROM = ADOPTION__ADOPTION_FROM;

	/**
	 * The feature id for the '<em><b>Adoption Of Goal</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_ADOPTION__ADOPTION_OF_GOAL = ADOPTION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>goal Adoption</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOAL_ADOPTION_FEATURE_COUNT = ADOPTION_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link iqtool.purposeOfUseTypes <em>purpose Of Use Types</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.purposeOfUseTypes
	 * @see iqtool.impl.IqtoolPackageImpl#getpurposeOfUseTypes()
	 * @generated
	 */
	int PURPOSE_OF_USE_TYPES = 35;

	/**
	 * The meta object id for the '{@link iqtool.sendPermType <em>send Perm Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.sendPermType
	 * @see iqtool.impl.IqtoolPackageImpl#getsendPermType()
	 * @generated
	 */
	int SEND_PERM_TYPE = 36;

	/**
	 * The meta object id for the '{@link iqtool.modifyPermType <em>modify Perm Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.modifyPermType
	 * @see iqtool.impl.IqtoolPackageImpl#getmodifyPermType()
	 * @generated
	 */
	int MODIFY_PERM_TYPE = 37;

	/**
	 * The meta object id for the '{@link iqtool.trustLevel <em>trust Level</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.trustLevel
	 * @see iqtool.impl.IqtoolPackageImpl#gettrustLevel()
	 * @generated
	 */
	int TRUST_LEVEL = 38;

	/**
	 * The meta object id for the '{@link iqtool.producePermType <em>produce Perm Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.producePermType
	 * @see iqtool.impl.IqtoolPackageImpl#getproducePermType()
	 * @generated
	 */
	int PRODUCE_PERM_TYPE = 39;

	/**
	 * The meta object id for the '{@link iqtool.provisionType <em>provision Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.provisionType
	 * @see iqtool.impl.IqtoolPackageImpl#getprovisionType()
	 * @generated
	 */
	int PROVISION_TYPE = 40;

	/**
	 * The meta object id for the '{@link iqtool.readPermType <em>read Perm Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.readPermType
	 * @see iqtool.impl.IqtoolPackageImpl#getreadPermType()
	 * @generated
	 */
	int READ_PERM_TYPE = 41;

	/**
	 * The meta object id for the '{@link iqtool.producetype <em>producetype</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.producetype
	 * @see iqtool.impl.IqtoolPackageImpl#getproducetype()
	 * @generated
	 */
	int PRODUCETYPE = 42;

	/**
	 * The meta object id for the '{@link iqtool.softgoalType <em>softgoal Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.softgoalType
	 * @see iqtool.impl.IqtoolPackageImpl#getsoftgoalType()
	 * @generated
	 */
	int SOFTGOAL_TYPE = 43;

	/**
	 * The meta object id for the '{@link iqtool.iqConstraintType <em>iq Constraint Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.iqConstraintType
	 * @see iqtool.impl.IqtoolPackageImpl#getiqConstraintType()
	 * @generated
	 */
	int IQ_CONSTRAINT_TYPE = 44;


	/**
	 * The meta object id for the '{@link iqtool.rtype <em>rtype</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see iqtool.rtype
	 * @see iqtool.impl.IqtoolPackageImpl#getrtype()
	 * @generated
	 */
	int RTYPE = 45;

	/**
	 * Returns the meta object for class '{@link iqtool.actor <em>actor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>actor</em>'.
	 * @see iqtool.actor
	 * @generated
	 */
	EClass getactor();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.actor#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see iqtool.actor#getName()
	 * @see #getactor()
	 * @generated
	 */
	EAttribute getactor_Name();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.actor#getAims <em>Aims</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Aims</em>'.
	 * @see iqtool.actor#getAims()
	 * @see #getactor()
	 * @generated
	 */
	EReference getactor_Aims();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.actor#getOwn <em>Own</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Own</em>'.
	 * @see iqtool.actor#getOwn()
	 * @see #getactor()
	 * @generated
	 */
	EReference getactor_Own();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.actor#getCapableOfThreat <em>Capable Of Threat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Capable Of Threat</em>'.
	 * @see iqtool.actor#getCapableOfThreat()
	 * @see #getactor()
	 * @generated
	 */
	EReference getactor_CapableOfThreat();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.actor#getIncapableOfThreat <em>Incapable Of Threat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Incapable Of Threat</em>'.
	 * @see iqtool.actor#getIncapableOfThreat()
	 * @see #getactor()
	 * @generated
	 */
	EReference getactor_IncapableOfThreat();

	/**
	 * Returns the meta object for class '{@link iqtool.diagram <em>diagram</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>diagram</em>'.
	 * @see iqtool.diagram
	 * @generated
	 */
	EClass getdiagram();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getActorElement <em>Actor Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Actor Element</em>'.
	 * @see iqtool.diagram#getActorElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_ActorElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getGoalElement <em>Goal Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Goal Element</em>'.
	 * @see iqtool.diagram#getGoalElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_GoalElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getInfoElement <em>Info Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Info Element</em>'.
	 * @see iqtool.diagram#getInfoElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_InfoElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getScopeElement <em>Scope Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Scope Element</em>'.
	 * @see iqtool.diagram#getScopeElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_ScopeElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getDelegationElement <em>Delegation Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Delegation Element</em>'.
	 * @see iqtool.diagram#getDelegationElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_DelegationElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getProvisionElement <em>Provision Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Provision Element</em>'.
	 * @see iqtool.diagram#getProvisionElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_ProvisionElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getDelegationTrustElement <em>Delegation Trust Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Delegation Trust Element</em>'.
	 * @see iqtool.diagram#getDelegationTrustElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_DelegationTrustElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getAgentElement <em>Agent Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Agent Element</em>'.
	 * @see iqtool.diagram#getAgentElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_AgentElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getRoleElement <em>Role Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Role Element</em>'.
	 * @see iqtool.diagram#getRoleElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_RoleElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getPermDeleElement <em>Perm Dele Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Perm Dele Element</em>'.
	 * @see iqtool.diagram#getPermDeleElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_PermDeleElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getTrustPermDeleElement <em>Trust Perm Dele Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Trust Perm Dele Element</em>'.
	 * @see iqtool.diagram#getTrustPermDeleElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_TrustPermDeleElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getReadElement <em>Read Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Read Element</em>'.
	 * @see iqtool.diagram#getReadElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_ReadElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getSendElement <em>Send Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Send Element</em>'.
	 * @see iqtool.diagram#getSendElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_SendElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getPostionElelement <em>Postion Elelement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Postion Elelement</em>'.
	 * @see iqtool.diagram#getPostionElelement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_PostionElelement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getProduceElement <em>Produce Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Produce Element</em>'.
	 * @see iqtool.diagram#getProduceElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_ProduceElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getSpositionElement <em>Sposition Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sposition Element</em>'.
	 * @see iqtool.diagram#getSpositionElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_SpositionElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getBpositionElement <em>Bposition Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Bposition Element</em>'.
	 * @see iqtool.diagram#getBpositionElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_BpositionElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getEpositionElement <em>Eposition Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Eposition Element</em>'.
	 * @see iqtool.diagram#getEpositionElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_EpositionElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getProduceTrustElement <em>Produce Trust Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Produce Trust Element</em>'.
	 * @see iqtool.diagram#getProduceTrustElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_ProduceTrustElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getSoftgoalElement <em>Softgoal Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Softgoal Element</em>'.
	 * @see iqtool.diagram#getSoftgoalElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_SoftgoalElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getIqConstraintElement <em>Iq Constraint Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Iq Constraint Element</em>'.
	 * @see iqtool.diagram#getIqConstraintElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_IqConstraintElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getThreatElement <em>Threat Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Threat Element</em>'.
	 * @see iqtool.diagram#getThreatElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_ThreatElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getInstanceGoalElement <em>Instance Goal Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Instance Goal Element</em>'.
	 * @see iqtool.diagram#getInstanceGoalElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_InstanceGoalElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getGeneralGoalElement <em>General Goal Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>General Goal Element</em>'.
	 * @see iqtool.diagram#getGeneralGoalElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_GeneralGoalElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getInstanceInformationElement <em>Instance Information Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Instance Information Element</em>'.
	 * @see iqtool.diagram#getInstanceInformationElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_InstanceInformationElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getGeneralInformationElement <em>General Information Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>General Information Element</em>'.
	 * @see iqtool.diagram#getGeneralInformationElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_GeneralInformationElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getGoalThreatElement <em>Goal Threat Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Goal Threat Element</em>'.
	 * @see iqtool.diagram#getGoalThreatElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_GoalThreatElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getInformationThreatElement <em>Information Threat Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Information Threat Element</em>'.
	 * @see iqtool.diagram#getInformationThreatElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_InformationThreatElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getMonitoringElement <em>Monitoring Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Monitoring Element</em>'.
	 * @see iqtool.diagram#getMonitoringElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_MonitoringElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getInformationMonitoringElement <em>Information Monitoring Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Information Monitoring Element</em>'.
	 * @see iqtool.diagram#getInformationMonitoringElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_InformationMonitoringElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getGoalMonitoringElement <em>Goal Monitoring Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Goal Monitoring Element</em>'.
	 * @see iqtool.diagram#getGoalMonitoringElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_GoalMonitoringElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getAdoptionElement <em>Adoption Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Adoption Element</em>'.
	 * @see iqtool.diagram#getAdoptionElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_AdoptionElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getGoalAdoptionElement <em>Goal Adoption Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Goal Adoption Element</em>'.
	 * @see iqtool.diagram#getGoalAdoptionElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_GoalAdoptionElement();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.diagram#getInformationAdoptionElement <em>Information Adoption Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Information Adoption Element</em>'.
	 * @see iqtool.diagram#getInformationAdoptionElement()
	 * @see #getdiagram()
	 * @generated
	 */
	EReference getdiagram_InformationAdoptionElement();

	/**
	 * Returns the meta object for class '{@link iqtool.role <em>role</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>role</em>'.
	 * @see iqtool.role
	 * @generated
	 */
	EClass getrole();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.role#getIsa <em>Isa</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Isa</em>'.
	 * @see iqtool.role#getIsa()
	 * @see #getrole()
	 * @generated
	 */
	EReference getrole_Isa();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.role#getIs_capable <em>Is capable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Is capable</em>'.
	 * @see iqtool.role#getIs_capable()
	 * @see #getrole()
	 * @generated
	 */
	EReference getrole_Is_capable();

	/**
	 * Returns the meta object for class '{@link iqtool.agent <em>agent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>agent</em>'.
	 * @see iqtool.agent
	 * @generated
	 */
	EClass getagent();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.agent#getPlay <em>Play</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Play</em>'.
	 * @see iqtool.agent#getPlay()
	 * @see #getagent()
	 * @generated
	 */
	EReference getagent_Play();

	/**
	 * Returns the meta object for class '{@link iqtool.permDelegation <em>perm Delegation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>perm Delegation</em>'.
	 * @see iqtool.permDelegation
	 * @generated
	 */
	EClass getpermDelegation();

	/**
	 * Returns the meta object for the reference '{@link iqtool.permDelegation#getPermOver <em>Perm Over</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Perm Over</em>'.
	 * @see iqtool.permDelegation#getPermOver()
	 * @see #getpermDelegation()
	 * @generated
	 */
	EReference getpermDelegation_PermOver();

	/**
	 * Returns the meta object for the reference '{@link iqtool.permDelegation#getPermDeleFrom <em>Perm Dele From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Perm Dele From</em>'.
	 * @see iqtool.permDelegation#getPermDeleFrom()
	 * @see #getpermDelegation()
	 * @generated
	 */
	EReference getpermDelegation_PermDeleFrom();

	/**
	 * Returns the meta object for the reference '{@link iqtool.permDelegation#getPermDeleTo <em>Perm Dele To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Perm Dele To</em>'.
	 * @see iqtool.permDelegation#getPermDeleTo()
	 * @see #getpermDelegation()
	 * @generated
	 */
	EReference getpermDelegation_PermDeleTo();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.permDelegation#getReadPerm <em>Read Perm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Read Perm</em>'.
	 * @see iqtool.permDelegation#getReadPerm()
	 * @see #getpermDelegation()
	 * @generated
	 */
	EAttribute getpermDelegation_ReadPerm();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.permDelegation#getProducePerm <em>Produce Perm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Produce Perm</em>'.
	 * @see iqtool.permDelegation#getProducePerm()
	 * @see #getpermDelegation()
	 * @generated
	 */
	EAttribute getpermDelegation_ProducePerm();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.permDelegation#getModifyPerm <em>Modify Perm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Modify Perm</em>'.
	 * @see iqtool.permDelegation#getModifyPerm()
	 * @see #getpermDelegation()
	 * @generated
	 */
	EAttribute getpermDelegation_ModifyPerm();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.permDelegation#getSendPerm <em>Send Perm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Send Perm</em>'.
	 * @see iqtool.permDelegation#getSendPerm()
	 * @see #getpermDelegation()
	 * @generated
	 */
	EAttribute getpermDelegation_SendPerm();

	/**
	 * Returns the meta object for class '{@link iqtool.startPostion <em>start Postion</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>start Postion</em>'.
	 * @see iqtool.startPostion
	 * @generated
	 */
	EClass getstartPostion();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.startPostion#getInarc <em>Inarc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Inarc</em>'.
	 * @see iqtool.startPostion#getInarc()
	 * @see #getstartPostion()
	 * @generated
	 */
	EReference getstartPostion_Inarc();

	/**
	 * Returns the meta object for class '{@link iqtool.read <em>read</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>read</em>'.
	 * @see iqtool.read
	 * @generated
	 */
	EClass getread();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.read#getPou <em>Pou</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Pou</em>'.
	 * @see iqtool.read#getPou()
	 * @see #getread()
	 * @generated
	 */
	EAttribute getread_Pou();

	/**
	 * Returns the meta object for the reference '{@link iqtool.read#getReadOf <em>Read Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Read Of</em>'.
	 * @see iqtool.read#getReadOf()
	 * @see #getread()
	 * @generated
	 */
	EReference getread_ReadOf();

	/**
	 * Returns the meta object for the reference '{@link iqtool.read#getReadBy <em>Read By</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Read By</em>'.
	 * @see iqtool.read#getReadBy()
	 * @see #getread()
	 * @generated
	 */
	EReference getread_ReadBy();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.read#getReadType <em>Read Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Read Type</em>'.
	 * @see iqtool.read#getReadType()
	 * @see #getread()
	 * @generated
	 */
	EAttribute getread_ReadType();

	/**
	 * Returns the meta object for class '{@link iqtool.position <em>position</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>position</em>'.
	 * @see iqtool.position
	 * @generated
	 */
	EClass getposition();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.position#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see iqtool.position#getName()
	 * @see #getposition()
	 * @generated
	 */
	EAttribute getposition_Name();

	/**
	 * Returns the meta object for class '{@link iqtool.endPostion <em>end Postion</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>end Postion</em>'.
	 * @see iqtool.endPostion
	 * @generated
	 */
	EClass getendPostion();

	/**
	 * Returns the meta object for class '{@link iqtool.send <em>send</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>send</em>'.
	 * @see iqtool.send
	 * @generated
	 */
	EClass getsend();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.send#getTime <em>Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Time</em>'.
	 * @see iqtool.send#getTime()
	 * @see #getsend()
	 * @generated
	 */
	EAttribute getsend_Time();

	/**
	 * Returns the meta object for the reference '{@link iqtool.send#getSendOf <em>Send Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Send Of</em>'.
	 * @see iqtool.send#getSendOf()
	 * @see #getsend()
	 * @generated
	 */
	EReference getsend_SendOf();

	/**
	 * Returns the meta object for the reference '{@link iqtool.send#getSendBy <em>Send By</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Send By</em>'.
	 * @see iqtool.send#getSendBy()
	 * @see #getsend()
	 * @generated
	 */
	EReference getsend_SendBy();

	/**
	 * Returns the meta object for the reference '{@link iqtool.send#getSendTo <em>Send To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Send To</em>'.
	 * @see iqtool.send#getSendTo()
	 * @see #getsend()
	 * @generated
	 */
	EReference getsend_SendTo();

	/**
	 * Returns the meta object for class '{@link iqtool.goalDelegation <em>goal Delegation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>goal Delegation</em>'.
	 * @see iqtool.goalDelegation
	 * @generated
	 */
	EClass getgoalDelegation();

	/**
	 * Returns the meta object for the reference '{@link iqtool.goalDelegation#getDelegationOf <em>Delegation Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Delegation Of</em>'.
	 * @see iqtool.goalDelegation#getDelegationOf()
	 * @see #getgoalDelegation()
	 * @generated
	 */
	EReference getgoalDelegation_DelegationOf();

	/**
	 * Returns the meta object for the reference '{@link iqtool.goalDelegation#getDelegationFrom <em>Delegation From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Delegation From</em>'.
	 * @see iqtool.goalDelegation#getDelegationFrom()
	 * @see #getgoalDelegation()
	 * @generated
	 */
	EReference getgoalDelegation_DelegationFrom();

	/**
	 * Returns the meta object for the reference '{@link iqtool.goalDelegation#getDelegationTo <em>Delegation To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Delegation To</em>'.
	 * @see iqtool.goalDelegation#getDelegationTo()
	 * @see #getgoalDelegation()
	 * @generated
	 */
	EReference getgoalDelegation_DelegationTo();

	/**
	 * Returns the meta object for class '{@link iqtool.delegationTrust <em>delegation Trust</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>delegation Trust</em>'.
	 * @see iqtool.delegationTrust
	 * @generated
	 */
	EClass getdelegationTrust();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.delegationTrust#getTrustlevel <em>Trustlevel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Trustlevel</em>'.
	 * @see iqtool.delegationTrust#getTrustlevel()
	 * @see #getdelegationTrust()
	 * @generated
	 */
	EAttribute getdelegationTrust_Trustlevel();

	/**
	 * Returns the meta object for the reference '{@link iqtool.delegationTrust#getTrustumGoal <em>Trustum Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Trustum Goal</em>'.
	 * @see iqtool.delegationTrust#getTrustumGoal()
	 * @see #getdelegationTrust()
	 * @generated
	 */
	EReference getdelegationTrust_TrustumGoal();

	/**
	 * Returns the meta object for the reference '{@link iqtool.delegationTrust#getTrustorGoal <em>Trustor Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Trustor Goal</em>'.
	 * @see iqtool.delegationTrust#getTrustorGoal()
	 * @see #getdelegationTrust()
	 * @generated
	 */
	EReference getdelegationTrust_TrustorGoal();

	/**
	 * Returns the meta object for the reference '{@link iqtool.delegationTrust#getTrusteeGoal <em>Trustee Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Trustee Goal</em>'.
	 * @see iqtool.delegationTrust#getTrusteeGoal()
	 * @see #getdelegationTrust()
	 * @generated
	 */
	EReference getdelegationTrust_TrusteeGoal();

	/**
	 * Returns the meta object for class '{@link iqtool.betweenPostion <em>between Postion</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>between Postion</em>'.
	 * @see iqtool.betweenPostion
	 * @generated
	 */
	EClass getbetweenPostion();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.betweenPostion#getOutarc <em>Outarc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Outarc</em>'.
	 * @see iqtool.betweenPostion#getOutarc()
	 * @see #getbetweenPostion()
	 * @generated
	 */
	EReference getbetweenPostion_Outarc();

	/**
	 * Returns the meta object for class '{@link iqtool.infoProvision <em>info Provision</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>info Provision</em>'.
	 * @see iqtool.infoProvision
	 * @generated
	 */
	EClass getinfoProvision();

	/**
	 * Returns the meta object for the reference '{@link iqtool.infoProvision#getProvisionOf <em>Provision Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Provision Of</em>'.
	 * @see iqtool.infoProvision#getProvisionOf()
	 * @see #getinfoProvision()
	 * @generated
	 */
	EReference getinfoProvision_ProvisionOf();

	/**
	 * Returns the meta object for the reference '{@link iqtool.infoProvision#getProvisionFrom <em>Provision From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Provision From</em>'.
	 * @see iqtool.infoProvision#getProvisionFrom()
	 * @see #getinfoProvision()
	 * @generated
	 */
	EReference getinfoProvision_ProvisionFrom();

	/**
	 * Returns the meta object for the reference '{@link iqtool.infoProvision#getProvisionTo <em>Provision To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Provision To</em>'.
	 * @see iqtool.infoProvision#getProvisionTo()
	 * @see #getinfoProvision()
	 * @generated
	 */
	EReference getinfoProvision_ProvisionTo();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.infoProvision#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see iqtool.infoProvision#getType()
	 * @see #getinfoProvision()
	 * @generated
	 */
	EAttribute getinfoProvision_Type();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.infoProvision#getTime <em>Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Time</em>'.
	 * @see iqtool.infoProvision#getTime()
	 * @see #getinfoProvision()
	 * @generated
	 */
	EAttribute getinfoProvision_Time();

	/**
	 * Returns the meta object for class '{@link iqtool.trustPermDelegation <em>trust Perm Delegation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>trust Perm Delegation</em>'.
	 * @see iqtool.trustPermDelegation
	 * @generated
	 */
	EClass gettrustPermDelegation();

	/**
	 * Returns the meta object for the reference '{@link iqtool.trustPermDelegation#getTrustPermDeleTo <em>Trust Perm Dele To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Trust Perm Dele To</em>'.
	 * @see iqtool.trustPermDelegation#getTrustPermDeleTo()
	 * @see #gettrustPermDelegation()
	 * @generated
	 */
	EReference gettrustPermDelegation_TrustPermDeleTo();

	/**
	 * Returns the meta object for the reference '{@link iqtool.trustPermDelegation#getTrustPermDeleFrom <em>Trust Perm Dele From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Trust Perm Dele From</em>'.
	 * @see iqtool.trustPermDelegation#getTrustPermDeleFrom()
	 * @see #gettrustPermDelegation()
	 * @generated
	 */
	EReference gettrustPermDelegation_TrustPermDeleFrom();

	/**
	 * Returns the meta object for the reference '{@link iqtool.trustPermDelegation#getTrustPermDeleOf <em>Trust Perm Dele Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Trust Perm Dele Of</em>'.
	 * @see iqtool.trustPermDelegation#getTrustPermDeleOf()
	 * @see #gettrustPermDelegation()
	 * @generated
	 */
	EReference gettrustPermDelegation_TrustPermDeleOf();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.trustPermDelegation#getTrustprodue <em>Trustprodue</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Trustprodue</em>'.
	 * @see iqtool.trustPermDelegation#getTrustprodue()
	 * @see #gettrustPermDelegation()
	 * @generated
	 */
	EAttribute gettrustPermDelegation_Trustprodue();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.trustPermDelegation#getTrustread <em>Trustread</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Trustread</em>'.
	 * @see iqtool.trustPermDelegation#getTrustread()
	 * @see #gettrustPermDelegation()
	 * @generated
	 */
	EAttribute gettrustPermDelegation_Trustread();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.trustPermDelegation#getTrustsend <em>Trustsend</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Trustsend</em>'.
	 * @see iqtool.trustPermDelegation#getTrustsend()
	 * @see #gettrustPermDelegation()
	 * @generated
	 */
	EAttribute gettrustPermDelegation_Trustsend();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.trustPermDelegation#getTrustmodify <em>Trustmodify</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Trustmodify</em>'.
	 * @see iqtool.trustPermDelegation#getTrustmodify()
	 * @see #gettrustPermDelegation()
	 * @generated
	 */
	EAttribute gettrustPermDelegation_Trustmodify();

	/**
	 * Returns the meta object for class '{@link iqtool.information <em>information</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>information</em>'.
	 * @see iqtool.information
	 * @generated
	 */
	EClass getinformation();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.information#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see iqtool.information#getName()
	 * @see #getinformation()
	 * @generated
	 */
	EAttribute getinformation_Name();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.information#getVolatility <em>Volatility</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Volatility</em>'.
	 * @see iqtool.information#getVolatility()
	 * @see #getinformation()
	 * @generated
	 */
	EAttribute getinformation_Volatility();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.information#getSubItem <em>Sub Item</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Sub Item</em>'.
	 * @see iqtool.information#getSubItem()
	 * @see #getinformation()
	 * @generated
	 */
	EReference getinformation_SubItem();

	/**
	 * Returns the meta object for class '{@link iqtool.scope <em>scope</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>scope</em>'.
	 * @see iqtool.scope
	 * @generated
	 */
	EClass getscope();

	/**
	 * Returns the meta object for the containment reference list '{@link iqtool.scope#getContains <em>Contains</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Contains</em>'.
	 * @see iqtool.scope#getContains()
	 * @see #getscope()
	 * @generated
	 */
	EReference getscope_Contains();

	/**
	 * Returns the meta object for class '{@link iqtool.goal <em>goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>goal</em>'.
	 * @see iqtool.goal
	 * @generated
	 */
	EClass getgoal();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.goal#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see iqtool.goal#getName()
	 * @see #getgoal()
	 * @generated
	 */
	EAttribute getgoal_Name();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.goal#getOrdecomposition <em>Ordecomposition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Ordecomposition</em>'.
	 * @see iqtool.goal#getOrdecomposition()
	 * @see #getgoal()
	 * @generated
	 */
	EReference getgoal_Ordecomposition();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.goal#getAnddecomposition <em>Anddecomposition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Anddecomposition</em>'.
	 * @see iqtool.goal#getAnddecomposition()
	 * @see #getgoal()
	 * @generated
	 */
	EReference getgoal_Anddecomposition();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.goal#getModify <em>Modify</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Modify</em>'.
	 * @see iqtool.goal#getModify()
	 * @see #getgoal()
	 * @generated
	 */
	EReference getgoal_Modify();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.goal#getOutarc <em>Outarc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Outarc</em>'.
	 * @see iqtool.goal#getOutarc()
	 * @see #getgoal()
	 * @generated
	 */
	EReference getgoal_Outarc();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.goal#getInarc <em>Inarc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Inarc</em>'.
	 * @see iqtool.goal#getInarc()
	 * @see #getgoal()
	 * @generated
	 */
	EReference getgoal_Inarc();

	/**
	 * Returns the meta object for class '{@link iqtool.produce <em>produce</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>produce</em>'.
	 * @see iqtool.produce
	 * @generated
	 */
	EClass getproduce();

	/**
	 * Returns the meta object for the reference '{@link iqtool.produce#getProduceBy <em>Produce By</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Produce By</em>'.
	 * @see iqtool.produce#getProduceBy()
	 * @see #getproduce()
	 * @generated
	 */
	EReference getproduce_ProduceBy();

	/**
	 * Returns the meta object for the reference '{@link iqtool.produce#getProduceOf <em>Produce Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Produce Of</em>'.
	 * @see iqtool.produce#getProduceOf()
	 * @see #getproduce()
	 * @generated
	 */
	EReference getproduce_ProduceOf();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.produce#getProduceType <em>Produce Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Produce Type</em>'.
	 * @see iqtool.produce#getProduceType()
	 * @see #getproduce()
	 * @generated
	 */
	EAttribute getproduce_ProduceType();

	/**
	 * Returns the meta object for class '{@link iqtool.produceTrust <em>produce Trust</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>produce Trust</em>'.
	 * @see iqtool.produceTrust
	 * @generated
	 */
	EClass getproduceTrust();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.produceTrust#getTrustlevel <em>Trustlevel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Trustlevel</em>'.
	 * @see iqtool.produceTrust#getTrustlevel()
	 * @see #getproduceTrust()
	 * @generated
	 */
	EAttribute getproduceTrust_Trustlevel();

	/**
	 * Returns the meta object for the reference '{@link iqtool.produceTrust#getProduceTrustor <em>Produce Trustor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Produce Trustor</em>'.
	 * @see iqtool.produceTrust#getProduceTrustor()
	 * @see #getproduceTrust()
	 * @generated
	 */
	EReference getproduceTrust_ProduceTrustor();

	/**
	 * Returns the meta object for the reference '{@link iqtool.produceTrust#getProduceTrustee <em>Produce Trustee</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Produce Trustee</em>'.
	 * @see iqtool.produceTrust#getProduceTrustee()
	 * @see #getproduceTrust()
	 * @generated
	 */
	EReference getproduceTrust_ProduceTrustee();

	/**
	 * Returns the meta object for the reference '{@link iqtool.produceTrust#getProduceTrustOf <em>Produce Trust Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Produce Trust Of</em>'.
	 * @see iqtool.produceTrust#getProduceTrustOf()
	 * @see #getproduceTrust()
	 * @generated
	 */
	EReference getproduceTrust_ProduceTrustOf();

	/**
	 * Returns the meta object for class '{@link iqtool.softgoal <em>softgoal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>softgoal</em>'.
	 * @see iqtool.softgoal
	 * @generated
	 */
	EClass getsoftgoal();

	/**
	 * Returns the meta object for the reference '{@link iqtool.softgoal#getAnddecomposition <em>Anddecomposition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Anddecomposition</em>'.
	 * @see iqtool.softgoal#getAnddecomposition()
	 * @see #getsoftgoal()
	 * @generated
	 */
	EReference getsoftgoal_Anddecomposition();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.softgoal#getSoftGoalOf <em>Soft Goal Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Soft Goal Of</em>'.
	 * @see iqtool.softgoal#getSoftGoalOf()
	 * @see #getsoftgoal()
	 * @generated
	 */
	EReference getsoftgoal_SoftGoalOf();

	/**
	 * Returns the meta object for the reference '{@link iqtool.softgoal#getSoftgoalTarget <em>Softgoal Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Softgoal Target</em>'.
	 * @see iqtool.softgoal#getSoftgoalTarget()
	 * @see #getsoftgoal()
	 * @generated
	 */
	EReference getsoftgoal_SoftgoalTarget();

	/**
	 * Returns the meta object for the reference '{@link iqtool.softgoal#getSoftgoalConcerning <em>Softgoal Concerning</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Softgoal Concerning</em>'.
	 * @see iqtool.softgoal#getSoftgoalConcerning()
	 * @see #getsoftgoal()
	 * @generated
	 */
	EReference getsoftgoal_SoftgoalConcerning();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.softgoal#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see iqtool.softgoal#getType()
	 * @see #getsoftgoal()
	 * @generated
	 */
	EAttribute getsoftgoal_Type();

	/**
	 * Returns the meta object for class '{@link iqtool.iqConstraint <em>iq Constraint</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>iq Constraint</em>'.
	 * @see iqtool.iqConstraint
	 * @generated
	 */
	EClass getiqConstraint();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.iqConstraint#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see iqtool.iqConstraint#getType()
	 * @see #getiqConstraint()
	 * @generated
	 */
	EAttribute getiqConstraint_Type();

	/**
	 * Returns the meta object for the reference '{@link iqtool.iqConstraint#getApproximate <em>Approximate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Approximate</em>'.
	 * @see iqtool.iqConstraint#getApproximate()
	 * @see #getiqConstraint()
	 * @generated
	 */
	EReference getiqConstraint_Approximate();

	/**
	 * Returns the meta object for class '{@link iqtool.instanceGoal <em>instance Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>instance Goal</em>'.
	 * @see iqtool.instanceGoal
	 * @generated
	 */
	EClass getinstanceGoal();

	/**
	 * Returns the meta object for the reference '{@link iqtool.instanceGoal#getInstance <em>Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Instance</em>'.
	 * @see iqtool.instanceGoal#getInstance()
	 * @see #getinstanceGoal()
	 * @generated
	 */
	EReference getinstanceGoal_Instance();

	/**
	 * Returns the meta object for class '{@link iqtool.generalGoal <em>general Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>general Goal</em>'.
	 * @see iqtool.generalGoal
	 * @generated
	 */
	EClass getgeneralGoal();

	/**
	 * Returns the meta object for class '{@link iqtool.instanceInformation <em>instance Information</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>instance Information</em>'.
	 * @see iqtool.instanceInformation
	 * @generated
	 */
	EClass getinstanceInformation();

	/**
	 * Returns the meta object for the reference '{@link iqtool.instanceInformation#getInstance <em>Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Instance</em>'.
	 * @see iqtool.instanceInformation#getInstance()
	 * @see #getinstanceInformation()
	 * @generated
	 */
	EReference getinstanceInformation_Instance();

	/**
	 * Returns the meta object for class '{@link iqtool.general_information <em>general information</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>general information</em>'.
	 * @see iqtool.general_information
	 * @generated
	 */
	EClass getgeneral_information();

	/**
	 * Returns the meta object for class '{@link iqtool.threat <em>threat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>threat</em>'.
	 * @see iqtool.threat
	 * @generated
	 */
	EClass getthreat();

	/**
	 * Returns the meta object for the attribute '{@link iqtool.threat#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see iqtool.threat#getName()
	 * @see #getthreat()
	 * @generated
	 */
	EAttribute getthreat_Name();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.threat#getPosContribute <em>Pos Contribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Pos Contribute</em>'.
	 * @see iqtool.threat#getPosContribute()
	 * @see #getthreat()
	 * @generated
	 */
	EReference getthreat_PosContribute();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.threat#getNegContribute <em>Neg Contribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Neg Contribute</em>'.
	 * @see iqtool.threat#getNegContribute()
	 * @see #getthreat()
	 * @generated
	 */
	EReference getthreat_NegContribute();

	/**
	 * Returns the meta object for class '{@link iqtool.informationThreat <em>information Threat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>information Threat</em>'.
	 * @see iqtool.informationThreat
	 * @generated
	 */
	EClass getinformationThreat();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.informationThreat#getThreatInformation <em>Threat Information</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Threat Information</em>'.
	 * @see iqtool.informationThreat#getThreatInformation()
	 * @see #getinformationThreat()
	 * @generated
	 */
	EReference getinformationThreat_ThreatInformation();

	/**
	 * Returns the meta object for class '{@link iqtool.goalThreat <em>goal Threat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>goal Threat</em>'.
	 * @see iqtool.goalThreat
	 * @generated
	 */
	EClass getgoalThreat();

	/**
	 * Returns the meta object for the reference list '{@link iqtool.goalThreat#getGoalThreat <em>Goal Threat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Goal Threat</em>'.
	 * @see iqtool.goalThreat#getGoalThreat()
	 * @see #getgoalThreat()
	 * @generated
	 */
	EReference getgoalThreat_GoalThreat();

	/**
	 * Returns the meta object for class '{@link iqtool.monitoring <em>monitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>monitoring</em>'.
	 * @see iqtool.monitoring
	 * @generated
	 */
	EClass getmonitoring();

	/**
	 * Returns the meta object for the reference '{@link iqtool.monitoring#getMonitor <em>Monitor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Monitor</em>'.
	 * @see iqtool.monitoring#getMonitor()
	 * @see #getmonitoring()
	 * @generated
	 */
	EReference getmonitoring_Monitor();

	/**
	 * Returns the meta object for the reference '{@link iqtool.monitoring#getMonitored <em>Monitored</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Monitored</em>'.
	 * @see iqtool.monitoring#getMonitored()
	 * @see #getmonitoring()
	 * @generated
	 */
	EReference getmonitoring_Monitored();

	/**
	 * Returns the meta object for class '{@link iqtool.informationMonitoring <em>information Monitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>information Monitoring</em>'.
	 * @see iqtool.informationMonitoring
	 * @generated
	 */
	EClass getinformationMonitoring();

	/**
	 * Returns the meta object for the reference '{@link iqtool.informationMonitoring#getMonitoringOfInformation <em>Monitoring Of Information</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Monitoring Of Information</em>'.
	 * @see iqtool.informationMonitoring#getMonitoringOfInformation()
	 * @see #getinformationMonitoring()
	 * @generated
	 */
	EReference getinformationMonitoring_MonitoringOfInformation();

	/**
	 * Returns the meta object for class '{@link iqtool.goalMonitoring <em>goal Monitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>goal Monitoring</em>'.
	 * @see iqtool.goalMonitoring
	 * @generated
	 */
	EClass getgoalMonitoring();

	/**
	 * Returns the meta object for the reference '{@link iqtool.goalMonitoring#getMonitoringOfGoal <em>Monitoring Of Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Monitoring Of Goal</em>'.
	 * @see iqtool.goalMonitoring#getMonitoringOfGoal()
	 * @see #getgoalMonitoring()
	 * @generated
	 */
	EReference getgoalMonitoring_MonitoringOfGoal();

	/**
	 * Returns the meta object for class '{@link iqtool.adoption <em>adoption</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>adoption</em>'.
	 * @see iqtool.adoption
	 * @generated
	 */
	EClass getadoption();

	/**
	 * Returns the meta object for the reference '{@link iqtool.adoption#getAdoptionTo <em>Adoption To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Adoption To</em>'.
	 * @see iqtool.adoption#getAdoptionTo()
	 * @see #getadoption()
	 * @generated
	 */
	EReference getadoption_AdoptionTo();

	/**
	 * Returns the meta object for the reference '{@link iqtool.adoption#getAdoptionFrom <em>Adoption From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Adoption From</em>'.
	 * @see iqtool.adoption#getAdoptionFrom()
	 * @see #getadoption()
	 * @generated
	 */
	EReference getadoption_AdoptionFrom();

	/**
	 * Returns the meta object for class '{@link iqtool.InformationAdoption <em>Information Adoption</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Information Adoption</em>'.
	 * @see iqtool.InformationAdoption
	 * @generated
	 */
	EClass getInformationAdoption();

	/**
	 * Returns the meta object for the reference '{@link iqtool.InformationAdoption#getAdoptionOfInformation <em>Adoption Of Information</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Adoption Of Information</em>'.
	 * @see iqtool.InformationAdoption#getAdoptionOfInformation()
	 * @see #getInformationAdoption()
	 * @generated
	 */
	EReference getInformationAdoption_AdoptionOfInformation();

	/**
	 * Returns the meta object for class '{@link iqtool.goalAdoption <em>goal Adoption</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>goal Adoption</em>'.
	 * @see iqtool.goalAdoption
	 * @generated
	 */
	EClass getgoalAdoption();

	/**
	 * Returns the meta object for the reference '{@link iqtool.goalAdoption#getAdoptionOfGoal <em>Adoption Of Goal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Adoption Of Goal</em>'.
	 * @see iqtool.goalAdoption#getAdoptionOfGoal()
	 * @see #getgoalAdoption()
	 * @generated
	 */
	EReference getgoalAdoption_AdoptionOfGoal();

	/**
	 * Returns the meta object for enum '{@link iqtool.purposeOfUseTypes <em>purpose Of Use Types</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>purpose Of Use Types</em>'.
	 * @see iqtool.purposeOfUseTypes
	 * @generated
	 */
	EEnum getpurposeOfUseTypes();

	/**
	 * Returns the meta object for enum '{@link iqtool.sendPermType <em>send Perm Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>send Perm Type</em>'.
	 * @see iqtool.sendPermType
	 * @generated
	 */
	EEnum getsendPermType();

	/**
	 * Returns the meta object for enum '{@link iqtool.modifyPermType <em>modify Perm Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>modify Perm Type</em>'.
	 * @see iqtool.modifyPermType
	 * @generated
	 */
	EEnum getmodifyPermType();

	/**
	 * Returns the meta object for enum '{@link iqtool.trustLevel <em>trust Level</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>trust Level</em>'.
	 * @see iqtool.trustLevel
	 * @generated
	 */
	EEnum gettrustLevel();

	/**
	 * Returns the meta object for enum '{@link iqtool.producePermType <em>produce Perm Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>produce Perm Type</em>'.
	 * @see iqtool.producePermType
	 * @generated
	 */
	EEnum getproducePermType();

	/**
	 * Returns the meta object for enum '{@link iqtool.provisionType <em>provision Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>provision Type</em>'.
	 * @see iqtool.provisionType
	 * @generated
	 */
	EEnum getprovisionType();

	/**
	 * Returns the meta object for enum '{@link iqtool.readPermType <em>read Perm Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>read Perm Type</em>'.
	 * @see iqtool.readPermType
	 * @generated
	 */
	EEnum getreadPermType();

	/**
	 * Returns the meta object for enum '{@link iqtool.producetype <em>producetype</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>producetype</em>'.
	 * @see iqtool.producetype
	 * @generated
	 */
	EEnum getproducetype();

	/**
	 * Returns the meta object for enum '{@link iqtool.softgoalType <em>softgoal Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>softgoal Type</em>'.
	 * @see iqtool.softgoalType
	 * @generated
	 */
	EEnum getsoftgoalType();

	/**
	 * Returns the meta object for enum '{@link iqtool.iqConstraintType <em>iq Constraint Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>iq Constraint Type</em>'.
	 * @see iqtool.iqConstraintType
	 * @generated
	 */
	EEnum getiqConstraintType();

	/**
	 * Returns the meta object for enum '{@link iqtool.rtype <em>rtype</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>rtype</em>'.
	 * @see iqtool.rtype
	 * @generated
	 */
	EEnum getrtype();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	IqtoolFactory getIqtoolFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link iqtool.impl.actorImpl <em>actor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.actorImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getactor()
		 * @generated
		 */
		EClass ACTOR = eINSTANCE.getactor();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTOR__NAME = eINSTANCE.getactor_Name();

		/**
		 * The meta object literal for the '<em><b>Aims</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTOR__AIMS = eINSTANCE.getactor_Aims();

		/**
		 * The meta object literal for the '<em><b>Own</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTOR__OWN = eINSTANCE.getactor_Own();

		/**
		 * The meta object literal for the '<em><b>Capable Of Threat</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTOR__CAPABLE_OF_THREAT = eINSTANCE.getactor_CapableOfThreat();

		/**
		 * The meta object literal for the '<em><b>Incapable Of Threat</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTOR__INCAPABLE_OF_THREAT = eINSTANCE.getactor_IncapableOfThreat();

		/**
		 * The meta object literal for the '{@link iqtool.impl.diagramImpl <em>diagram</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.diagramImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getdiagram()
		 * @generated
		 */
		EClass DIAGRAM = eINSTANCE.getdiagram();

		/**
		 * The meta object literal for the '<em><b>Actor Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__ACTOR_ELEMENT = eINSTANCE.getdiagram_ActorElement();

		/**
		 * The meta object literal for the '<em><b>Goal Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__GOAL_ELEMENT = eINSTANCE.getdiagram_GoalElement();

		/**
		 * The meta object literal for the '<em><b>Info Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__INFO_ELEMENT = eINSTANCE.getdiagram_InfoElement();

		/**
		 * The meta object literal for the '<em><b>Scope Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__SCOPE_ELEMENT = eINSTANCE.getdiagram_ScopeElement();

		/**
		 * The meta object literal for the '<em><b>Delegation Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__DELEGATION_ELEMENT = eINSTANCE.getdiagram_DelegationElement();

		/**
		 * The meta object literal for the '<em><b>Provision Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__PROVISION_ELEMENT = eINSTANCE.getdiagram_ProvisionElement();

		/**
		 * The meta object literal for the '<em><b>Delegation Trust Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__DELEGATION_TRUST_ELEMENT = eINSTANCE.getdiagram_DelegationTrustElement();

		/**
		 * The meta object literal for the '<em><b>Agent Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__AGENT_ELEMENT = eINSTANCE.getdiagram_AgentElement();

		/**
		 * The meta object literal for the '<em><b>Role Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__ROLE_ELEMENT = eINSTANCE.getdiagram_RoleElement();

		/**
		 * The meta object literal for the '<em><b>Perm Dele Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__PERM_DELE_ELEMENT = eINSTANCE.getdiagram_PermDeleElement();

		/**
		 * The meta object literal for the '<em><b>Trust Perm Dele Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__TRUST_PERM_DELE_ELEMENT = eINSTANCE.getdiagram_TrustPermDeleElement();

		/**
		 * The meta object literal for the '<em><b>Read Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__READ_ELEMENT = eINSTANCE.getdiagram_ReadElement();

		/**
		 * The meta object literal for the '<em><b>Send Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__SEND_ELEMENT = eINSTANCE.getdiagram_SendElement();

		/**
		 * The meta object literal for the '<em><b>Postion Elelement</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__POSTION_ELELEMENT = eINSTANCE.getdiagram_PostionElelement();

		/**
		 * The meta object literal for the '<em><b>Produce Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__PRODUCE_ELEMENT = eINSTANCE.getdiagram_ProduceElement();

		/**
		 * The meta object literal for the '<em><b>Sposition Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__SPOSITION_ELEMENT = eINSTANCE.getdiagram_SpositionElement();

		/**
		 * The meta object literal for the '<em><b>Bposition Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__BPOSITION_ELEMENT = eINSTANCE.getdiagram_BpositionElement();

		/**
		 * The meta object literal for the '<em><b>Eposition Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__EPOSITION_ELEMENT = eINSTANCE.getdiagram_EpositionElement();

		/**
		 * The meta object literal for the '<em><b>Produce Trust Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__PRODUCE_TRUST_ELEMENT = eINSTANCE.getdiagram_ProduceTrustElement();

		/**
		 * The meta object literal for the '<em><b>Softgoal Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__SOFTGOAL_ELEMENT = eINSTANCE.getdiagram_SoftgoalElement();

		/**
		 * The meta object literal for the '<em><b>Iq Constraint Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__IQ_CONSTRAINT_ELEMENT = eINSTANCE.getdiagram_IqConstraintElement();

		/**
		 * The meta object literal for the '<em><b>Threat Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__THREAT_ELEMENT = eINSTANCE.getdiagram_ThreatElement();

		/**
		 * The meta object literal for the '<em><b>Instance Goal Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__INSTANCE_GOAL_ELEMENT = eINSTANCE.getdiagram_InstanceGoalElement();

		/**
		 * The meta object literal for the '<em><b>General Goal Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__GENERAL_GOAL_ELEMENT = eINSTANCE.getdiagram_GeneralGoalElement();

		/**
		 * The meta object literal for the '<em><b>Instance Information Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__INSTANCE_INFORMATION_ELEMENT = eINSTANCE.getdiagram_InstanceInformationElement();

		/**
		 * The meta object literal for the '<em><b>General Information Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__GENERAL_INFORMATION_ELEMENT = eINSTANCE.getdiagram_GeneralInformationElement();

		/**
		 * The meta object literal for the '<em><b>Goal Threat Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__GOAL_THREAT_ELEMENT = eINSTANCE.getdiagram_GoalThreatElement();

		/**
		 * The meta object literal for the '<em><b>Information Threat Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__INFORMATION_THREAT_ELEMENT = eINSTANCE.getdiagram_InformationThreatElement();

		/**
		 * The meta object literal for the '<em><b>Monitoring Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__MONITORING_ELEMENT = eINSTANCE.getdiagram_MonitoringElement();

		/**
		 * The meta object literal for the '<em><b>Information Monitoring Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__INFORMATION_MONITORING_ELEMENT = eINSTANCE.getdiagram_InformationMonitoringElement();

		/**
		 * The meta object literal for the '<em><b>Goal Monitoring Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__GOAL_MONITORING_ELEMENT = eINSTANCE.getdiagram_GoalMonitoringElement();

		/**
		 * The meta object literal for the '<em><b>Adoption Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__ADOPTION_ELEMENT = eINSTANCE.getdiagram_AdoptionElement();

		/**
		 * The meta object literal for the '<em><b>Goal Adoption Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__GOAL_ADOPTION_ELEMENT = eINSTANCE.getdiagram_GoalAdoptionElement();

		/**
		 * The meta object literal for the '<em><b>Information Adoption Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIAGRAM__INFORMATION_ADOPTION_ELEMENT = eINSTANCE.getdiagram_InformationAdoptionElement();

		/**
		 * The meta object literal for the '{@link iqtool.impl.roleImpl <em>role</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.roleImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getrole()
		 * @generated
		 */
		EClass ROLE = eINSTANCE.getrole();

		/**
		 * The meta object literal for the '<em><b>Isa</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__ISA = eINSTANCE.getrole_Isa();

		/**
		 * The meta object literal for the '<em><b>Is capable</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__IS_CAPABLE = eINSTANCE.getrole_Is_capable();

		/**
		 * The meta object literal for the '{@link iqtool.impl.agentImpl <em>agent</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.agentImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getagent()
		 * @generated
		 */
		EClass AGENT = eINSTANCE.getagent();

		/**
		 * The meta object literal for the '<em><b>Play</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AGENT__PLAY = eINSTANCE.getagent_Play();

		/**
		 * The meta object literal for the '{@link iqtool.impl.permDelegationImpl <em>perm Delegation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.permDelegationImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getpermDelegation()
		 * @generated
		 */
		EClass PERM_DELEGATION = eINSTANCE.getpermDelegation();

		/**
		 * The meta object literal for the '<em><b>Perm Over</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PERM_DELEGATION__PERM_OVER = eINSTANCE.getpermDelegation_PermOver();

		/**
		 * The meta object literal for the '<em><b>Perm Dele From</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PERM_DELEGATION__PERM_DELE_FROM = eINSTANCE.getpermDelegation_PermDeleFrom();

		/**
		 * The meta object literal for the '<em><b>Perm Dele To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PERM_DELEGATION__PERM_DELE_TO = eINSTANCE.getpermDelegation_PermDeleTo();

		/**
		 * The meta object literal for the '<em><b>Read Perm</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERM_DELEGATION__READ_PERM = eINSTANCE.getpermDelegation_ReadPerm();

		/**
		 * The meta object literal for the '<em><b>Produce Perm</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERM_DELEGATION__PRODUCE_PERM = eINSTANCE.getpermDelegation_ProducePerm();

		/**
		 * The meta object literal for the '<em><b>Modify Perm</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERM_DELEGATION__MODIFY_PERM = eINSTANCE.getpermDelegation_ModifyPerm();

		/**
		 * The meta object literal for the '<em><b>Send Perm</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERM_DELEGATION__SEND_PERM = eINSTANCE.getpermDelegation_SendPerm();

		/**
		 * The meta object literal for the '{@link iqtool.impl.startPostionImpl <em>start Postion</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.startPostionImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getstartPostion()
		 * @generated
		 */
		EClass START_POSTION = eINSTANCE.getstartPostion();

		/**
		 * The meta object literal for the '<em><b>Inarc</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference START_POSTION__INARC = eINSTANCE.getstartPostion_Inarc();

		/**
		 * The meta object literal for the '{@link iqtool.impl.readImpl <em>read</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.readImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getread()
		 * @generated
		 */
		EClass READ = eINSTANCE.getread();

		/**
		 * The meta object literal for the '<em><b>Pou</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute READ__POU = eINSTANCE.getread_Pou();

		/**
		 * The meta object literal for the '<em><b>Read Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference READ__READ_OF = eINSTANCE.getread_ReadOf();

		/**
		 * The meta object literal for the '<em><b>Read By</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference READ__READ_BY = eINSTANCE.getread_ReadBy();

		/**
		 * The meta object literal for the '<em><b>Read Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute READ__READ_TYPE = eINSTANCE.getread_ReadType();

		/**
		 * The meta object literal for the '{@link iqtool.impl.positionImpl <em>position</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.positionImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getposition()
		 * @generated
		 */
		EClass POSITION = eINSTANCE.getposition();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POSITION__NAME = eINSTANCE.getposition_Name();

		/**
		 * The meta object literal for the '{@link iqtool.impl.endPostionImpl <em>end Postion</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.endPostionImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getendPostion()
		 * @generated
		 */
		EClass END_POSTION = eINSTANCE.getendPostion();

		/**
		 * The meta object literal for the '{@link iqtool.impl.sendImpl <em>send</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.sendImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getsend()
		 * @generated
		 */
		EClass SEND = eINSTANCE.getsend();

		/**
		 * The meta object literal for the '<em><b>Time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEND__TIME = eINSTANCE.getsend_Time();

		/**
		 * The meta object literal for the '<em><b>Send Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEND__SEND_OF = eINSTANCE.getsend_SendOf();

		/**
		 * The meta object literal for the '<em><b>Send By</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEND__SEND_BY = eINSTANCE.getsend_SendBy();

		/**
		 * The meta object literal for the '<em><b>Send To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEND__SEND_TO = eINSTANCE.getsend_SendTo();

		/**
		 * The meta object literal for the '{@link iqtool.impl.goalDelegationImpl <em>goal Delegation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.goalDelegationImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getgoalDelegation()
		 * @generated
		 */
		EClass GOAL_DELEGATION = eINSTANCE.getgoalDelegation();

		/**
		 * The meta object literal for the '<em><b>Delegation Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL_DELEGATION__DELEGATION_OF = eINSTANCE.getgoalDelegation_DelegationOf();

		/**
		 * The meta object literal for the '<em><b>Delegation From</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL_DELEGATION__DELEGATION_FROM = eINSTANCE.getgoalDelegation_DelegationFrom();

		/**
		 * The meta object literal for the '<em><b>Delegation To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL_DELEGATION__DELEGATION_TO = eINSTANCE.getgoalDelegation_DelegationTo();

		/**
		 * The meta object literal for the '{@link iqtool.impl.delegationTrustImpl <em>delegation Trust</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.delegationTrustImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getdelegationTrust()
		 * @generated
		 */
		EClass DELEGATION_TRUST = eINSTANCE.getdelegationTrust();

		/**
		 * The meta object literal for the '<em><b>Trustlevel</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DELEGATION_TRUST__TRUSTLEVEL = eINSTANCE.getdelegationTrust_Trustlevel();

		/**
		 * The meta object literal for the '<em><b>Trustum Goal</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DELEGATION_TRUST__TRUSTUM_GOAL = eINSTANCE.getdelegationTrust_TrustumGoal();

		/**
		 * The meta object literal for the '<em><b>Trustor Goal</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DELEGATION_TRUST__TRUSTOR_GOAL = eINSTANCE.getdelegationTrust_TrustorGoal();

		/**
		 * The meta object literal for the '<em><b>Trustee Goal</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DELEGATION_TRUST__TRUSTEE_GOAL = eINSTANCE.getdelegationTrust_TrusteeGoal();

		/**
		 * The meta object literal for the '{@link iqtool.impl.betweenPostionImpl <em>between Postion</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.betweenPostionImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getbetweenPostion()
		 * @generated
		 */
		EClass BETWEEN_POSTION = eINSTANCE.getbetweenPostion();

		/**
		 * The meta object literal for the '<em><b>Outarc</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BETWEEN_POSTION__OUTARC = eINSTANCE.getbetweenPostion_Outarc();

		/**
		 * The meta object literal for the '{@link iqtool.impl.infoProvisionImpl <em>info Provision</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.infoProvisionImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getinfoProvision()
		 * @generated
		 */
		EClass INFO_PROVISION = eINSTANCE.getinfoProvision();

		/**
		 * The meta object literal for the '<em><b>Provision Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INFO_PROVISION__PROVISION_OF = eINSTANCE.getinfoProvision_ProvisionOf();

		/**
		 * The meta object literal for the '<em><b>Provision From</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INFO_PROVISION__PROVISION_FROM = eINSTANCE.getinfoProvision_ProvisionFrom();

		/**
		 * The meta object literal for the '<em><b>Provision To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INFO_PROVISION__PROVISION_TO = eINSTANCE.getinfoProvision_ProvisionTo();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INFO_PROVISION__TYPE = eINSTANCE.getinfoProvision_Type();

		/**
		 * The meta object literal for the '<em><b>Time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INFO_PROVISION__TIME = eINSTANCE.getinfoProvision_Time();

		/**
		 * The meta object literal for the '{@link iqtool.impl.trustPermDelegationImpl <em>trust Perm Delegation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.trustPermDelegationImpl
		 * @see iqtool.impl.IqtoolPackageImpl#gettrustPermDelegation()
		 * @generated
		 */
		EClass TRUST_PERM_DELEGATION = eINSTANCE.gettrustPermDelegation();

		/**
		 * The meta object literal for the '<em><b>Trust Perm Dele To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRUST_PERM_DELEGATION__TRUST_PERM_DELE_TO = eINSTANCE.gettrustPermDelegation_TrustPermDeleTo();

		/**
		 * The meta object literal for the '<em><b>Trust Perm Dele From</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRUST_PERM_DELEGATION__TRUST_PERM_DELE_FROM = eINSTANCE.gettrustPermDelegation_TrustPermDeleFrom();

		/**
		 * The meta object literal for the '<em><b>Trust Perm Dele Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRUST_PERM_DELEGATION__TRUST_PERM_DELE_OF = eINSTANCE.gettrustPermDelegation_TrustPermDeleOf();

		/**
		 * The meta object literal for the '<em><b>Trustprodue</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRUST_PERM_DELEGATION__TRUSTPRODUE = eINSTANCE.gettrustPermDelegation_Trustprodue();

		/**
		 * The meta object literal for the '<em><b>Trustread</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRUST_PERM_DELEGATION__TRUSTREAD = eINSTANCE.gettrustPermDelegation_Trustread();

		/**
		 * The meta object literal for the '<em><b>Trustsend</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRUST_PERM_DELEGATION__TRUSTSEND = eINSTANCE.gettrustPermDelegation_Trustsend();

		/**
		 * The meta object literal for the '<em><b>Trustmodify</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRUST_PERM_DELEGATION__TRUSTMODIFY = eINSTANCE.gettrustPermDelegation_Trustmodify();

		/**
		 * The meta object literal for the '{@link iqtool.impl.informationImpl <em>information</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.informationImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getinformation()
		 * @generated
		 */
		EClass INFORMATION = eINSTANCE.getinformation();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INFORMATION__NAME = eINSTANCE.getinformation_Name();

		/**
		 * The meta object literal for the '<em><b>Volatility</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INFORMATION__VOLATILITY = eINSTANCE.getinformation_Volatility();

		/**
		 * The meta object literal for the '<em><b>Sub Item</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INFORMATION__SUB_ITEM = eINSTANCE.getinformation_SubItem();

		/**
		 * The meta object literal for the '{@link iqtool.impl.scopeImpl <em>scope</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.scopeImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getscope()
		 * @generated
		 */
		EClass SCOPE = eINSTANCE.getscope();

		/**
		 * The meta object literal for the '<em><b>Contains</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCOPE__CONTAINS = eINSTANCE.getscope_Contains();

		/**
		 * The meta object literal for the '{@link iqtool.impl.goalImpl <em>goal</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.goalImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getgoal()
		 * @generated
		 */
		EClass GOAL = eINSTANCE.getgoal();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GOAL__NAME = eINSTANCE.getgoal_Name();

		/**
		 * The meta object literal for the '<em><b>Ordecomposition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL__ORDECOMPOSITION = eINSTANCE.getgoal_Ordecomposition();

		/**
		 * The meta object literal for the '<em><b>Anddecomposition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL__ANDDECOMPOSITION = eINSTANCE.getgoal_Anddecomposition();

		/**
		 * The meta object literal for the '<em><b>Modify</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL__MODIFY = eINSTANCE.getgoal_Modify();

		/**
		 * The meta object literal for the '<em><b>Outarc</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL__OUTARC = eINSTANCE.getgoal_Outarc();

		/**
		 * The meta object literal for the '<em><b>Inarc</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL__INARC = eINSTANCE.getgoal_Inarc();

		/**
		 * The meta object literal for the '{@link iqtool.impl.produceImpl <em>produce</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.produceImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getproduce()
		 * @generated
		 */
		EClass PRODUCE = eINSTANCE.getproduce();

		/**
		 * The meta object literal for the '<em><b>Produce By</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCE__PRODUCE_BY = eINSTANCE.getproduce_ProduceBy();

		/**
		 * The meta object literal for the '<em><b>Produce Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCE__PRODUCE_OF = eINSTANCE.getproduce_ProduceOf();

		/**
		 * The meta object literal for the '<em><b>Produce Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRODUCE__PRODUCE_TYPE = eINSTANCE.getproduce_ProduceType();

		/**
		 * The meta object literal for the '{@link iqtool.impl.produceTrustImpl <em>produce Trust</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.produceTrustImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getproduceTrust()
		 * @generated
		 */
		EClass PRODUCE_TRUST = eINSTANCE.getproduceTrust();

		/**
		 * The meta object literal for the '<em><b>Trustlevel</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRODUCE_TRUST__TRUSTLEVEL = eINSTANCE.getproduceTrust_Trustlevel();

		/**
		 * The meta object literal for the '<em><b>Produce Trustor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCE_TRUST__PRODUCE_TRUSTOR = eINSTANCE.getproduceTrust_ProduceTrustor();

		/**
		 * The meta object literal for the '<em><b>Produce Trustee</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCE_TRUST__PRODUCE_TRUSTEE = eINSTANCE.getproduceTrust_ProduceTrustee();

		/**
		 * The meta object literal for the '<em><b>Produce Trust Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCE_TRUST__PRODUCE_TRUST_OF = eINSTANCE.getproduceTrust_ProduceTrustOf();

		/**
		 * The meta object literal for the '{@link iqtool.impl.softgoalImpl <em>softgoal</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.softgoalImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getsoftgoal()
		 * @generated
		 */
		EClass SOFTGOAL = eINSTANCE.getsoftgoal();

		/**
		 * The meta object literal for the '<em><b>Anddecomposition</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SOFTGOAL__ANDDECOMPOSITION = eINSTANCE.getsoftgoal_Anddecomposition();

		/**
		 * The meta object literal for the '<em><b>Soft Goal Of</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SOFTGOAL__SOFT_GOAL_OF = eINSTANCE.getsoftgoal_SoftGoalOf();

		/**
		 * The meta object literal for the '<em><b>Softgoal Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SOFTGOAL__SOFTGOAL_TARGET = eINSTANCE.getsoftgoal_SoftgoalTarget();

		/**
		 * The meta object literal for the '<em><b>Softgoal Concerning</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SOFTGOAL__SOFTGOAL_CONCERNING = eINSTANCE.getsoftgoal_SoftgoalConcerning();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SOFTGOAL__TYPE = eINSTANCE.getsoftgoal_Type();

		/**
		 * The meta object literal for the '{@link iqtool.impl.iqConstraintImpl <em>iq Constraint</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.iqConstraintImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getiqConstraint()
		 * @generated
		 */
		EClass IQ_CONSTRAINT = eINSTANCE.getiqConstraint();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute IQ_CONSTRAINT__TYPE = eINSTANCE.getiqConstraint_Type();

		/**
		 * The meta object literal for the '<em><b>Approximate</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IQ_CONSTRAINT__APPROXIMATE = eINSTANCE.getiqConstraint_Approximate();

		/**
		 * The meta object literal for the '{@link iqtool.impl.instanceGoalImpl <em>instance Goal</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.instanceGoalImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getinstanceGoal()
		 * @generated
		 */
		EClass INSTANCE_GOAL = eINSTANCE.getinstanceGoal();

		/**
		 * The meta object literal for the '<em><b>Instance</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INSTANCE_GOAL__INSTANCE = eINSTANCE.getinstanceGoal_Instance();

		/**
		 * The meta object literal for the '{@link iqtool.impl.generalGoalImpl <em>general Goal</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.generalGoalImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getgeneralGoal()
		 * @generated
		 */
		EClass GENERAL_GOAL = eINSTANCE.getgeneralGoal();

		/**
		 * The meta object literal for the '{@link iqtool.impl.instanceInformationImpl <em>instance Information</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.instanceInformationImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getinstanceInformation()
		 * @generated
		 */
		EClass INSTANCE_INFORMATION = eINSTANCE.getinstanceInformation();

		/**
		 * The meta object literal for the '<em><b>Instance</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INSTANCE_INFORMATION__INSTANCE = eINSTANCE.getinstanceInformation_Instance();

		/**
		 * The meta object literal for the '{@link iqtool.impl.general_informationImpl <em>general information</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.general_informationImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getgeneral_information()
		 * @generated
		 */
		EClass GENERAL_INFORMATION = eINSTANCE.getgeneral_information();

		/**
		 * The meta object literal for the '{@link iqtool.impl.threatImpl <em>threat</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.threatImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getthreat()
		 * @generated
		 */
		EClass THREAT = eINSTANCE.getthreat();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute THREAT__NAME = eINSTANCE.getthreat_Name();

		/**
		 * The meta object literal for the '<em><b>Pos Contribute</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THREAT__POS_CONTRIBUTE = eINSTANCE.getthreat_PosContribute();

		/**
		 * The meta object literal for the '<em><b>Neg Contribute</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THREAT__NEG_CONTRIBUTE = eINSTANCE.getthreat_NegContribute();

		/**
		 * The meta object literal for the '{@link iqtool.impl.informationThreatImpl <em>information Threat</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.informationThreatImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getinformationThreat()
		 * @generated
		 */
		EClass INFORMATION_THREAT = eINSTANCE.getinformationThreat();

		/**
		 * The meta object literal for the '<em><b>Threat Information</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INFORMATION_THREAT__THREAT_INFORMATION = eINSTANCE.getinformationThreat_ThreatInformation();

		/**
		 * The meta object literal for the '{@link iqtool.impl.goalThreatImpl <em>goal Threat</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.goalThreatImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getgoalThreat()
		 * @generated
		 */
		EClass GOAL_THREAT = eINSTANCE.getgoalThreat();

		/**
		 * The meta object literal for the '<em><b>Goal Threat</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL_THREAT__GOAL_THREAT = eINSTANCE.getgoalThreat_GoalThreat();

		/**
		 * The meta object literal for the '{@link iqtool.impl.monitoringImpl <em>monitoring</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.monitoringImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getmonitoring()
		 * @generated
		 */
		EClass MONITORING = eINSTANCE.getmonitoring();

		/**
		 * The meta object literal for the '<em><b>Monitor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MONITORING__MONITOR = eINSTANCE.getmonitoring_Monitor();

		/**
		 * The meta object literal for the '<em><b>Monitored</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MONITORING__MONITORED = eINSTANCE.getmonitoring_Monitored();

		/**
		 * The meta object literal for the '{@link iqtool.impl.informationMonitoringImpl <em>information Monitoring</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.informationMonitoringImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getinformationMonitoring()
		 * @generated
		 */
		EClass INFORMATION_MONITORING = eINSTANCE.getinformationMonitoring();

		/**
		 * The meta object literal for the '<em><b>Monitoring Of Information</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INFORMATION_MONITORING__MONITORING_OF_INFORMATION = eINSTANCE.getinformationMonitoring_MonitoringOfInformation();

		/**
		 * The meta object literal for the '{@link iqtool.impl.goalMonitoringImpl <em>goal Monitoring</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.goalMonitoringImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getgoalMonitoring()
		 * @generated
		 */
		EClass GOAL_MONITORING = eINSTANCE.getgoalMonitoring();

		/**
		 * The meta object literal for the '<em><b>Monitoring Of Goal</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL_MONITORING__MONITORING_OF_GOAL = eINSTANCE.getgoalMonitoring_MonitoringOfGoal();

		/**
		 * The meta object literal for the '{@link iqtool.impl.adoptionImpl <em>adoption</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.adoptionImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getadoption()
		 * @generated
		 */
		EClass ADOPTION = eINSTANCE.getadoption();

		/**
		 * The meta object literal for the '<em><b>Adoption To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ADOPTION__ADOPTION_TO = eINSTANCE.getadoption_AdoptionTo();

		/**
		 * The meta object literal for the '<em><b>Adoption From</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ADOPTION__ADOPTION_FROM = eINSTANCE.getadoption_AdoptionFrom();

		/**
		 * The meta object literal for the '{@link iqtool.impl.InformationAdoptionImpl <em>Information Adoption</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.InformationAdoptionImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getInformationAdoption()
		 * @generated
		 */
		EClass INFORMATION_ADOPTION = eINSTANCE.getInformationAdoption();

		/**
		 * The meta object literal for the '<em><b>Adoption Of Information</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INFORMATION_ADOPTION__ADOPTION_OF_INFORMATION = eINSTANCE.getInformationAdoption_AdoptionOfInformation();

		/**
		 * The meta object literal for the '{@link iqtool.impl.goalAdoptionImpl <em>goal Adoption</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.impl.goalAdoptionImpl
		 * @see iqtool.impl.IqtoolPackageImpl#getgoalAdoption()
		 * @generated
		 */
		EClass GOAL_ADOPTION = eINSTANCE.getgoalAdoption();

		/**
		 * The meta object literal for the '<em><b>Adoption Of Goal</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GOAL_ADOPTION__ADOPTION_OF_GOAL = eINSTANCE.getgoalAdoption_AdoptionOfGoal();

		/**
		 * The meta object literal for the '{@link iqtool.purposeOfUseTypes <em>purpose Of Use Types</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.purposeOfUseTypes
		 * @see iqtool.impl.IqtoolPackageImpl#getpurposeOfUseTypes()
		 * @generated
		 */
		EEnum PURPOSE_OF_USE_TYPES = eINSTANCE.getpurposeOfUseTypes();

		/**
		 * The meta object literal for the '{@link iqtool.sendPermType <em>send Perm Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.sendPermType
		 * @see iqtool.impl.IqtoolPackageImpl#getsendPermType()
		 * @generated
		 */
		EEnum SEND_PERM_TYPE = eINSTANCE.getsendPermType();

		/**
		 * The meta object literal for the '{@link iqtool.modifyPermType <em>modify Perm Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.modifyPermType
		 * @see iqtool.impl.IqtoolPackageImpl#getmodifyPermType()
		 * @generated
		 */
		EEnum MODIFY_PERM_TYPE = eINSTANCE.getmodifyPermType();

		/**
		 * The meta object literal for the '{@link iqtool.trustLevel <em>trust Level</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.trustLevel
		 * @see iqtool.impl.IqtoolPackageImpl#gettrustLevel()
		 * @generated
		 */
		EEnum TRUST_LEVEL = eINSTANCE.gettrustLevel();

		/**
		 * The meta object literal for the '{@link iqtool.producePermType <em>produce Perm Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.producePermType
		 * @see iqtool.impl.IqtoolPackageImpl#getproducePermType()
		 * @generated
		 */
		EEnum PRODUCE_PERM_TYPE = eINSTANCE.getproducePermType();

		/**
		 * The meta object literal for the '{@link iqtool.provisionType <em>provision Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.provisionType
		 * @see iqtool.impl.IqtoolPackageImpl#getprovisionType()
		 * @generated
		 */
		EEnum PROVISION_TYPE = eINSTANCE.getprovisionType();

		/**
		 * The meta object literal for the '{@link iqtool.readPermType <em>read Perm Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.readPermType
		 * @see iqtool.impl.IqtoolPackageImpl#getreadPermType()
		 * @generated
		 */
		EEnum READ_PERM_TYPE = eINSTANCE.getreadPermType();

		/**
		 * The meta object literal for the '{@link iqtool.producetype <em>producetype</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.producetype
		 * @see iqtool.impl.IqtoolPackageImpl#getproducetype()
		 * @generated
		 */
		EEnum PRODUCETYPE = eINSTANCE.getproducetype();

		/**
		 * The meta object literal for the '{@link iqtool.softgoalType <em>softgoal Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.softgoalType
		 * @see iqtool.impl.IqtoolPackageImpl#getsoftgoalType()
		 * @generated
		 */
		EEnum SOFTGOAL_TYPE = eINSTANCE.getsoftgoalType();

		/**
		 * The meta object literal for the '{@link iqtool.iqConstraintType <em>iq Constraint Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.iqConstraintType
		 * @see iqtool.impl.IqtoolPackageImpl#getiqConstraintType()
		 * @generated
		 */
		EEnum IQ_CONSTRAINT_TYPE = eINSTANCE.getiqConstraintType();

		/**
		 * The meta object literal for the '{@link iqtool.rtype <em>rtype</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see iqtool.rtype
		 * @see iqtool.impl.IqtoolPackageImpl#getrtype()
		 * @generated
		 */
		EEnum RTYPE = eINSTANCE.getrtype();

	}

} //IqtoolPackage
