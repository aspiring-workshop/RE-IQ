/**
 */
package iqtool.tests;

import iqtool.IqtoolFactory;
import iqtool.permDelegation;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>perm Delegation</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class permDelegationTest extends TestCase {

	/**
	 * The fixture for this perm Delegation test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected permDelegation fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(permDelegationTest.class);
	}

	/**
	 * Constructs a new perm Delegation test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public permDelegationTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this perm Delegation test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(permDelegation fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this perm Delegation test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private permDelegation getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	protected void setUp() throws Exception {
		setFixture(IqtoolFactory.eINSTANCE.createpermDelegation());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //permDelegationTest
