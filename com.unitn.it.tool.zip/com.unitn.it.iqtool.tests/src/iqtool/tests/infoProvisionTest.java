/**
 */
package iqtool.tests;

import iqtool.IqtoolFactory;
import iqtool.infoProvision;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>info Provision</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class infoProvisionTest extends TestCase {

	/**
	 * The fixture for this info Provision test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected infoProvision fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(infoProvisionTest.class);
	}

	/**
	 * Constructs a new info Provision test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public infoProvisionTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this info Provision test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(infoProvision fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this info Provision test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private infoProvision getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	protected void setUp() throws Exception {
		setFixture(IqtoolFactory.eINSTANCE.createinfoProvision());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //infoProvisionTest
