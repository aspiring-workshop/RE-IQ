/**
 */
package iqtool.tests;

import iqtool.actor;

import junit.framework.TestCase;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>actor</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class actorTest extends TestCase {

	/**
	 * The fixture for this actor test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected actor fixture = null;

	/**
	 * Constructs a new actor test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actorTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this actor test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(actor fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this actor test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private actor getFixture() {
		return fixture;
	}

} //actorTest
