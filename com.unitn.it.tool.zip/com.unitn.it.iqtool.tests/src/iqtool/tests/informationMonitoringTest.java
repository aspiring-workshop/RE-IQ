/**
 */
package iqtool.tests;

import iqtool.IqtoolFactory;
import iqtool.informationMonitoring;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>information Monitoring</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class informationMonitoringTest extends monitoringTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(informationMonitoringTest.class);
	}

	/**
	 * Constructs a new information Monitoring test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public informationMonitoringTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this information Monitoring test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private informationMonitoring getFixture() {
		return (informationMonitoring)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	protected void setUp() throws Exception {
		setFixture(IqtoolFactory.eINSTANCE.createinformationMonitoring());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //informationMonitoringTest
