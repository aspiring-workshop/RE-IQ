/**
 */
package iqtool;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>diagram</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.diagram#getScopeElement <em>Scope Element</em>}</li>
 *   <li>{@link iqtool.diagram#getDelegationElement <em>Delegation Element</em>}</li>
 *   <li>{@link iqtool.diagram#getProvisionElement <em>Provision Element</em>}</li>
 *   <li>{@link iqtool.diagram#getDelegationTrustElement <em>Delegation Trust Element</em>}</li>
 *   <li>{@link iqtool.diagram#getAgentElement <em>Agent Element</em>}</li>
 *   <li>{@link iqtool.diagram#getRoleElement <em>Role Element</em>}</li>
 *   <li>{@link iqtool.diagram#getPermDeleElement <em>Perm Dele Element</em>}</li>
 *   <li>{@link iqtool.diagram#getTrustPermDeleElement <em>Trust Perm Dele Element</em>}</li>
 *   <li>{@link iqtool.diagram#getReadElement <em>Read Element</em>}</li>
 *   <li>{@link iqtool.diagram#getSendElement <em>Send Element</em>}</li>
 *   <li>{@link iqtool.diagram#getProduceElement <em>Produce Element</em>}</li>
 *   <li>{@link iqtool.diagram#getProduceTrustElement <em>Produce Trust Element</em>}</li>
 *   <li>{@link iqtool.diagram#getInstanceGoalElement <em>Instance Goal Element</em>}</li>
 *   <li>{@link iqtool.diagram#getGeneralGoalElement <em>General Goal Element</em>}</li>
 *   <li>{@link iqtool.diagram#getInstanceInformationElement <em>Instance Information Element</em>}</li>
 *   <li>{@link iqtool.diagram#getGeneralInformationElement <em>General Information Element</em>}</li>
 *   <li>{@link iqtool.diagram#getGoalThreatElement <em>Goal Threat Element</em>}</li>
 *   <li>{@link iqtool.diagram#getInformationThreatElement <em>Information Threat Element</em>}</li>
 *   <li>{@link iqtool.diagram#getGoalMonitoringElement <em>Goal Monitoring Element</em>}</li>
 *   <li>{@link iqtool.diagram#getInfoMonitoringElement <em>Info Monitoring Element</em>}</li>
 *   <li>{@link iqtool.diagram#getPermMonitorElement <em>Perm Monitor Element</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getdiagram()
 * @model
 * @generated
 */
public interface diagram extends EObject {
	/**
	 * Returns the value of the '<em><b>Scope Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.scope}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Scope Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Scope Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_ScopeElement()
	 * @model type="iqtool.scope" containment="true"
	 * @generated
	 */
	EList getScopeElement();

	/**
	 * Returns the value of the '<em><b>Delegation Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.goalDelegation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Delegation Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Delegation Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_DelegationElement()
	 * @model type="iqtool.goalDelegation" containment="true"
	 * @generated
	 */
	EList getDelegationElement();

	/**
	 * Returns the value of the '<em><b>Provision Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.infoProvision}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Provision Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Provision Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_ProvisionElement()
	 * @model type="iqtool.infoProvision" containment="true"
	 * @generated
	 */
	EList getProvisionElement();

	/**
	 * Returns the value of the '<em><b>Delegation Trust Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.delegationTrust}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Delegation Trust Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Delegation Trust Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_DelegationTrustElement()
	 * @model type="iqtool.delegationTrust" containment="true"
	 * @generated
	 */
	EList getDelegationTrustElement();

	/**
	 * Returns the value of the '<em><b>Agent Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.agent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Agent Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Agent Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_AgentElement()
	 * @model type="iqtool.agent" containment="true"
	 * @generated
	 */
	EList getAgentElement();

	/**
	 * Returns the value of the '<em><b>Role Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.role}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Role Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Role Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_RoleElement()
	 * @model type="iqtool.role" containment="true"
	 * @generated
	 */
	EList getRoleElement();

	/**
	 * Returns the value of the '<em><b>Perm Dele Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.permDelegation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Perm Dele Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Perm Dele Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_PermDeleElement()
	 * @model type="iqtool.permDelegation" containment="true"
	 * @generated
	 */
	EList getPermDeleElement();

	/**
	 * Returns the value of the '<em><b>Trust Perm Dele Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.trustPermDelegation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trust Perm Dele Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trust Perm Dele Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_TrustPermDeleElement()
	 * @model type="iqtool.trustPermDelegation" containment="true"
	 * @generated
	 */
	EList getTrustPermDeleElement();

	/**
	 * Returns the value of the '<em><b>Read Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.read}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Read Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Read Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_ReadElement()
	 * @model type="iqtool.read" containment="true"
	 * @generated
	 */
	EList getReadElement();

	/**
	 * Returns the value of the '<em><b>Send Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.send}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Send Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Send Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_SendElement()
	 * @model type="iqtool.send" containment="true"
	 * @generated
	 */
	EList getSendElement();

	/**
	 * Returns the value of the '<em><b>Produce Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.produce}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Produce Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Produce Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_ProduceElement()
	 * @model type="iqtool.produce" containment="true"
	 * @generated
	 */
	EList getProduceElement();

	/**
	 * Returns the value of the '<em><b>Produce Trust Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.produceTrust}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Produce Trust Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Produce Trust Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_ProduceTrustElement()
	 * @model type="iqtool.produceTrust" containment="true"
	 * @generated
	 */
	EList getProduceTrustElement();

	/**
	 * Returns the value of the '<em><b>Instance Goal Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.instanceGoal}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Instance Goal Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Instance Goal Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_InstanceGoalElement()
	 * @model type="iqtool.instanceGoal" containment="true"
	 * @generated
	 */
	EList getInstanceGoalElement();

	/**
	 * Returns the value of the '<em><b>General Goal Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.generalGoal}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>General Goal Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>General Goal Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_GeneralGoalElement()
	 * @model type="iqtool.generalGoal" containment="true"
	 * @generated
	 */
	EList getGeneralGoalElement();

	/**
	 * Returns the value of the '<em><b>Instance Information Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.instanceInformation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Instance Information Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Instance Information Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_InstanceInformationElement()
	 * @model type="iqtool.instanceInformation" containment="true"
	 * @generated
	 */
	EList getInstanceInformationElement();

	/**
	 * Returns the value of the '<em><b>General Information Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.general_information}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>General Information Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>General Information Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_GeneralInformationElement()
	 * @model type="iqtool.general_information" containment="true"
	 * @generated
	 */
	EList getGeneralInformationElement();

	/**
	 * Returns the value of the '<em><b>Goal Threat Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.goalThreat}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Goal Threat Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Goal Threat Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_GoalThreatElement()
	 * @model type="iqtool.goalThreat" containment="true"
	 * @generated
	 */
	EList getGoalThreatElement();

	/**
	 * Returns the value of the '<em><b>Information Threat Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.informationThreat}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Information Threat Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Information Threat Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_InformationThreatElement()
	 * @model type="iqtool.informationThreat" containment="true"
	 * @generated
	 */
	EList getInformationThreatElement();

	/**
	 * Returns the value of the '<em><b>Goal Monitoring Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.goalMonitoring}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Goal Monitoring Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Goal Monitoring Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_GoalMonitoringElement()
	 * @model type="iqtool.goalMonitoring" containment="true"
	 * @generated
	 */
	EList getGoalMonitoringElement();

	/**
	 * Returns the value of the '<em><b>Info Monitoring Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.infoMonitoring}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Info Monitoring Element</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Info Monitoring Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_InfoMonitoringElement()
	 * @model type="iqtool.infoMonitoring" containment="true"
	 * @generated
	 */
	EList getInfoMonitoringElement();

	/**
	 * Returns the value of the '<em><b>Perm Monitor Element</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.permMonitor}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Perm Monitor Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Perm Monitor Element</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getdiagram_PermMonitorElement()
	 * @model type="iqtool.permMonitor" containment="true"
	 * @generated
	 */
	EList getPermMonitorElement();

} // diagram
