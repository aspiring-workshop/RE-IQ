/**
 */
package iqtool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>trust Perm Delegation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.trustPermDelegation#getTrustPermDeleTo <em>Trust Perm Dele To</em>}</li>
 *   <li>{@link iqtool.trustPermDelegation#getTrustPermDeleFrom <em>Trust Perm Dele From</em>}</li>
 *   <li>{@link iqtool.trustPermDelegation#getTrustPermDeleOf <em>Trust Perm Dele Of</em>}</li>
 *   <li>{@link iqtool.trustPermDelegation#getTrustprodue <em>Trustprodue</em>}</li>
 *   <li>{@link iqtool.trustPermDelegation#getTrustread <em>Trustread</em>}</li>
 *   <li>{@link iqtool.trustPermDelegation#getTrustsend <em>Trustsend</em>}</li>
 *   <li>{@link iqtool.trustPermDelegation#getTrustmodify <em>Trustmodify</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#gettrustPermDelegation()
 * @model
 * @generated
 */
public interface trustPermDelegation extends EObject {
	/**
	 * Returns the value of the '<em><b>Trust Perm Dele To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trust Perm Dele To</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trust Perm Dele To</em>' reference.
	 * @see #setTrustPermDeleTo(actor)
	 * @see iqtool.IqtoolPackage#gettrustPermDelegation_TrustPermDeleTo()
	 * @model
	 * @generated
	 */
	actor getTrustPermDeleTo();

	/**
	 * Sets the value of the '{@link iqtool.trustPermDelegation#getTrustPermDeleTo <em>Trust Perm Dele To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trust Perm Dele To</em>' reference.
	 * @see #getTrustPermDeleTo()
	 * @generated
	 */
	void setTrustPermDeleTo(actor value);

	/**
	 * Returns the value of the '<em><b>Trust Perm Dele From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trust Perm Dele From</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trust Perm Dele From</em>' reference.
	 * @see #setTrustPermDeleFrom(actor)
	 * @see iqtool.IqtoolPackage#gettrustPermDelegation_TrustPermDeleFrom()
	 * @model
	 * @generated
	 */
	actor getTrustPermDeleFrom();

	/**
	 * Sets the value of the '{@link iqtool.trustPermDelegation#getTrustPermDeleFrom <em>Trust Perm Dele From</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trust Perm Dele From</em>' reference.
	 * @see #getTrustPermDeleFrom()
	 * @generated
	 */
	void setTrustPermDeleFrom(actor value);

	/**
	 * Returns the value of the '<em><b>Trust Perm Dele Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trust Perm Dele Of</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trust Perm Dele Of</em>' reference.
	 * @see #setTrustPermDeleOf(information)
	 * @see iqtool.IqtoolPackage#gettrustPermDelegation_TrustPermDeleOf()
	 * @model
	 * @generated
	 */
	information getTrustPermDeleOf();

	/**
	 * Sets the value of the '{@link iqtool.trustPermDelegation#getTrustPermDeleOf <em>Trust Perm Dele Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trust Perm Dele Of</em>' reference.
	 * @see #getTrustPermDeleOf()
	 * @generated
	 */
	void setTrustPermDeleOf(information value);

	/**
	 * Returns the value of the '<em><b>Trustprodue</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.trustLevel}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trustprodue</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trustprodue</em>' attribute.
	 * @see iqtool.trustLevel
	 * @see #setTrustprodue(trustLevel)
	 * @see iqtool.IqtoolPackage#gettrustPermDelegation_Trustprodue()
	 * @model
	 * @generated
	 */
	trustLevel getTrustprodue();

	/**
	 * Sets the value of the '{@link iqtool.trustPermDelegation#getTrustprodue <em>Trustprodue</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trustprodue</em>' attribute.
	 * @see iqtool.trustLevel
	 * @see #getTrustprodue()
	 * @generated
	 */
	void setTrustprodue(trustLevel value);

	/**
	 * Returns the value of the '<em><b>Trustread</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.trustLevel}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trustread</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trustread</em>' attribute.
	 * @see iqtool.trustLevel
	 * @see #setTrustread(trustLevel)
	 * @see iqtool.IqtoolPackage#gettrustPermDelegation_Trustread()
	 * @model
	 * @generated
	 */
	trustLevel getTrustread();

	/**
	 * Sets the value of the '{@link iqtool.trustPermDelegation#getTrustread <em>Trustread</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trustread</em>' attribute.
	 * @see iqtool.trustLevel
	 * @see #getTrustread()
	 * @generated
	 */
	void setTrustread(trustLevel value);

	/**
	 * Returns the value of the '<em><b>Trustsend</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.trustLevel}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trustsend</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trustsend</em>' attribute.
	 * @see iqtool.trustLevel
	 * @see #setTrustsend(trustLevel)
	 * @see iqtool.IqtoolPackage#gettrustPermDelegation_Trustsend()
	 * @model
	 * @generated
	 */
	trustLevel getTrustsend();

	/**
	 * Sets the value of the '{@link iqtool.trustPermDelegation#getTrustsend <em>Trustsend</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trustsend</em>' attribute.
	 * @see iqtool.trustLevel
	 * @see #getTrustsend()
	 * @generated
	 */
	void setTrustsend(trustLevel value);

	/**
	 * Returns the value of the '<em><b>Trustmodify</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.trustLevel}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trustmodify</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trustmodify</em>' attribute.
	 * @see iqtool.trustLevel
	 * @see #setTrustmodify(trustLevel)
	 * @see iqtool.IqtoolPackage#gettrustPermDelegation_Trustmodify()
	 * @model
	 * @generated
	 */
	trustLevel getTrustmodify();

	/**
	 * Sets the value of the '{@link iqtool.trustPermDelegation#getTrustmodify <em>Trustmodify</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trustmodify</em>' attribute.
	 * @see iqtool.trustLevel
	 * @see #getTrustmodify()
	 * @generated
	 */
	void setTrustmodify(trustLevel value);

} // trustPermDelegation
