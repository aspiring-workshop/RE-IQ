/**
 */
package iqtool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>iq Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.iqConstraint#getType <em>Type</em>}</li>
 *   <li>{@link iqtool.iqConstraint#getApproximate <em>Approximate</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getiqConstraint()
 * @model
 * @generated
 */
public interface iqConstraint extends EObject {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.iqConstraintType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see iqtool.iqConstraintType
	 * @see #setType(iqConstraintType)
	 * @see iqtool.IqtoolPackage#getiqConstraint_Type()
	 * @model
	 * @generated
	 */
	iqConstraintType getType();

	/**
	 * Sets the value of the '{@link iqtool.iqConstraint#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see iqtool.iqConstraintType
	 * @see #getType()
	 * @generated
	 */
	void setType(iqConstraintType value);

	/**
	 * Returns the value of the '<em><b>Approximate</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Approximate</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Approximate</em>' reference.
	 * @see #setApproximate(softgoal)
	 * @see iqtool.IqtoolPackage#getiqConstraint_Approximate()
	 * @model
	 * @generated
	 */
	softgoal getApproximate();

	/**
	 * Sets the value of the '{@link iqtool.iqConstraint#getApproximate <em>Approximate</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Approximate</em>' reference.
	 * @see #getApproximate()
	 * @generated
	 */
	void setApproximate(softgoal value);

} // iqConstraint
