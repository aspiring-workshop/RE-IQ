/**
 */
package iqtool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>send</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.send#getTime <em>Time</em>}</li>
 *   <li>{@link iqtool.send#getSendOf <em>Send Of</em>}</li>
 *   <li>{@link iqtool.send#getSendBy <em>Send By</em>}</li>
 *   <li>{@link iqtool.send#getSendTo <em>Send To</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getsend()
 * @model
 * @generated
 */
public interface send extends EObject {
	/**
	 * Returns the value of the '<em><b>Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Time</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Time</em>' attribute.
	 * @see #setTime(int)
	 * @see iqtool.IqtoolPackage#getsend_Time()
	 * @model
	 * @generated
	 */
	int getTime();

	/**
	 * Sets the value of the '{@link iqtool.send#getTime <em>Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Time</em>' attribute.
	 * @see #getTime()
	 * @generated
	 */
	void setTime(int value);

	/**
	 * Returns the value of the '<em><b>Send Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Send Of</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Send Of</em>' reference.
	 * @see #setSendOf(information)
	 * @see iqtool.IqtoolPackage#getsend_SendOf()
	 * @model
	 * @generated
	 */
	information getSendOf();

	/**
	 * Sets the value of the '{@link iqtool.send#getSendOf <em>Send Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Send Of</em>' reference.
	 * @see #getSendOf()
	 * @generated
	 */
	void setSendOf(information value);

	/**
	 * Returns the value of the '<em><b>Send By</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Send By</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Send By</em>' reference.
	 * @see #setSendBy(goal)
	 * @see iqtool.IqtoolPackage#getsend_SendBy()
	 * @model
	 * @generated
	 */
	goal getSendBy();

	/**
	 * Sets the value of the '{@link iqtool.send#getSendBy <em>Send By</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Send By</em>' reference.
	 * @see #getSendBy()
	 * @generated
	 */
	void setSendBy(goal value);

	/**
	 * Returns the value of the '<em><b>Send To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Send To</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Send To</em>' reference.
	 * @see #setSendTo(actor)
	 * @see iqtool.IqtoolPackage#getsend_SendTo()
	 * @model
	 * @generated
	 */
	actor getSendTo();

	/**
	 * Sets the value of the '{@link iqtool.send#getSendTo <em>Send To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Send To</em>' reference.
	 * @see #getSendTo()
	 * @generated
	 */
	void setSendTo(actor value);

} // send
