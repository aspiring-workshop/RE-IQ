/**
 */
package iqtool;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>purpose Of Use Types</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see iqtool.IqtoolPackage#getpurposeOfUseTypes()
 * @model
 * @generated
 */
public final class purposeOfUseTypes extends AbstractEnumerator {
	/**
	 * The '<em><b>Trading</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Trading</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #TRADING_LITERAL
	 * @model name="trading"
	 * @generated
	 * @ordered
	 */
	public static final int TRADING = 0;

	/**
	 * The '<em><b>Analyzing</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Analyzing</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ANALYZING_LITERAL
	 * @model name="analyzing"
	 * @generated
	 * @ordered
	 */
	public static final int ANALYZING = 1;

	/**
	 * The '<em><b>Cb</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Cb</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CB_LITERAL
	 * @model name="cb"
	 * @generated
	 * @ordered
	 */
	public static final int CB = 2;

	/**
	 * The '<em><b>Trading</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TRADING
	 * @generated
	 * @ordered
	 */
	public static final purposeOfUseTypes TRADING_LITERAL = new purposeOfUseTypes(TRADING, "trading", "trading");

	/**
	 * The '<em><b>Analyzing</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ANALYZING
	 * @generated
	 * @ordered
	 */
	public static final purposeOfUseTypes ANALYZING_LITERAL = new purposeOfUseTypes(ANALYZING, "analyzing", "analyzing");

	/**
	 * The '<em><b>Cb</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CB
	 * @generated
	 * @ordered
	 */
	public static final purposeOfUseTypes CB_LITERAL = new purposeOfUseTypes(CB, "cb", "cb");

	/**
	 * An array of all the '<em><b>purpose Of Use Types</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final purposeOfUseTypes[] VALUES_ARRAY =
		new purposeOfUseTypes[] {
			TRADING_LITERAL,
			ANALYZING_LITERAL,
			CB_LITERAL,
		};

	/**
	 * A public read-only list of all the '<em><b>purpose Of Use Types</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>purpose Of Use Types</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static purposeOfUseTypes get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			purposeOfUseTypes result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>purpose Of Use Types</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static purposeOfUseTypes getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			purposeOfUseTypes result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>purpose Of Use Types</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static purposeOfUseTypes get(int value) {
		switch (value) {
			case TRADING: return TRADING_LITERAL;
			case ANALYZING: return ANALYZING_LITERAL;
			case CB: return CB_LITERAL;
		}
		return null;
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private purposeOfUseTypes(int value, String name, String literal) {
		super(value, name, literal);
	}

} //purposeOfUseTypes
