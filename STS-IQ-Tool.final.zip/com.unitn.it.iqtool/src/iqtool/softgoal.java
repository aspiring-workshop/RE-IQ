/**
 */
package iqtool;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>softgoal</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.softgoal#getAnddecomposition <em>Anddecomposition</em>}</li>
 *   <li>{@link iqtool.softgoal#getSoftGoalOf <em>Soft Goal Of</em>}</li>
 *   <li>{@link iqtool.softgoal#getSoftgoalTarget <em>Softgoal Target</em>}</li>
 *   <li>{@link iqtool.softgoal#getSoftgoalConcerning <em>Softgoal Concerning</em>}</li>
 *   <li>{@link iqtool.softgoal#getType <em>Type</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getsoftgoal()
 * @model
 * @generated
 */
public interface softgoal extends EObject {
	/**
	 * Returns the value of the '<em><b>Anddecomposition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Anddecomposition</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Anddecomposition</em>' reference.
	 * @see #setAnddecomposition(softgoal)
	 * @see iqtool.IqtoolPackage#getsoftgoal_Anddecomposition()
	 * @model
	 * @generated
	 */
	softgoal getAnddecomposition();

	/**
	 * Sets the value of the '{@link iqtool.softgoal#getAnddecomposition <em>Anddecomposition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Anddecomposition</em>' reference.
	 * @see #getAnddecomposition()
	 * @generated
	 */
	void setAnddecomposition(softgoal value);

	/**
	 * Returns the value of the '<em><b>Soft Goal Of</b></em>' reference list.
	 * The list contents are of type {@link iqtool.actor}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Soft Goal Of</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Soft Goal Of</em>' reference list.
	 * @see iqtool.IqtoolPackage#getsoftgoal_SoftGoalOf()
	 * @model type="iqtool.actor"
	 * @generated
	 */
	EList getSoftGoalOf();

	/**
	 * Returns the value of the '<em><b>Softgoal Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Softgoal Target</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Softgoal Target</em>' reference.
	 * @see #setSoftgoalTarget(information)
	 * @see iqtool.IqtoolPackage#getsoftgoal_SoftgoalTarget()
	 * @model
	 * @generated
	 */
	information getSoftgoalTarget();

	/**
	 * Sets the value of the '{@link iqtool.softgoal#getSoftgoalTarget <em>Softgoal Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Softgoal Target</em>' reference.
	 * @see #getSoftgoalTarget()
	 * @generated
	 */
	void setSoftgoalTarget(information value);

	/**
	 * Returns the value of the '<em><b>Softgoal Concerning</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Softgoal Concerning</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Softgoal Concerning</em>' reference.
	 * @see #setSoftgoalConcerning(goal)
	 * @see iqtool.IqtoolPackage#getsoftgoal_SoftgoalConcerning()
	 * @model
	 * @generated
	 */
	goal getSoftgoalConcerning();

	/**
	 * Sets the value of the '{@link iqtool.softgoal#getSoftgoalConcerning <em>Softgoal Concerning</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Softgoal Concerning</em>' reference.
	 * @see #getSoftgoalConcerning()
	 * @generated
	 */
	void setSoftgoalConcerning(goal value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.softgoalType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see iqtool.softgoalType
	 * @see #setType(softgoalType)
	 * @see iqtool.IqtoolPackage#getsoftgoal_Type()
	 * @model
	 * @generated
	 */
	softgoalType getType();

	/**
	 * Sets the value of the '{@link iqtool.softgoal#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see iqtool.softgoalType
	 * @see #getType()
	 * @generated
	 */
	void setType(softgoalType value);

} // softgoal
