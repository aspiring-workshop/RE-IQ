/**
 */
package iqtool;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>softgoal Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see iqtool.IqtoolPackage#getsoftgoalType()
 * @model
 * @generated
 */
public final class softgoalType extends AbstractEnumerator {
	/**
	 * The '<em><b>Accuracy</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Accuracy</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ACCURACY_LITERAL
	 * @model name="accuracy"
	 * @generated
	 * @ordered
	 */
	public static final int ACCURACY = 0;

	/**
	 * The '<em><b>Completeness</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Completeness</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #COMPLETENESS_LITERAL
	 * @model name="completeness"
	 * @generated
	 * @ordered
	 */
	public static final int COMPLETENESS = 1;

	/**
	 * The '<em><b>Accessibility</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Accessibility</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ACCESSIBILITY_LITERAL
	 * @model name="accessibility"
	 * @generated
	 * @ordered
	 */
	public static final int ACCESSIBILITY = 2;

	/**
	 * The '<em><b>Trustworthiness</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Trustworthiness</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #TRUSTWORTHINESS_LITERAL
	 * @model name="trustworthiness"
	 * @generated
	 * @ordered
	 */
	public static final int TRUSTWORTHINESS = 3;

	/**
	 * The '<em><b>Believability</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Believability</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #BELIEVABILITY_LITERAL
	 * @model name="believability"
	 * @generated
	 * @ordered
	 */
	public static final int BELIEVABILITY = 4;

	/**
	 * The '<em><b>Timeliness</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Timeliness</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #TIMELINESS_LITERAL
	 * @model name="timeliness"
	 * @generated
	 * @ordered
	 */
	public static final int TIMELINESS = 5;

	/**
	 * The '<em><b>Consistency</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Consistency</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CONSISTENCY_LITERAL
	 * @model name="consistency"
	 * @generated
	 * @ordered
	 */
	public static final int CONSISTENCY = 6;

	/**
	 * The '<em><b>Top Level IQ</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Top Level IQ</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #TOP_LEVEL_IQ_LITERAL
	 * @model name="topLevelIQ"
	 * @generated
	 * @ordered
	 */
	public static final int TOP_LEVEL_IQ = 7;

	/**
	 * The '<em><b>Accuracy</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ACCURACY
	 * @generated
	 * @ordered
	 */
	public static final softgoalType ACCURACY_LITERAL = new softgoalType(ACCURACY, "accuracy", "accuracy");

	/**
	 * The '<em><b>Completeness</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #COMPLETENESS
	 * @generated
	 * @ordered
	 */
	public static final softgoalType COMPLETENESS_LITERAL = new softgoalType(COMPLETENESS, "completeness", "completeness");

	/**
	 * The '<em><b>Accessibility</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ACCESSIBILITY
	 * @generated
	 * @ordered
	 */
	public static final softgoalType ACCESSIBILITY_LITERAL = new softgoalType(ACCESSIBILITY, "accessibility", "accessibility");

	/**
	 * The '<em><b>Trustworthiness</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TRUSTWORTHINESS
	 * @generated
	 * @ordered
	 */
	public static final softgoalType TRUSTWORTHINESS_LITERAL = new softgoalType(TRUSTWORTHINESS, "trustworthiness", "trustworthiness");

	/**
	 * The '<em><b>Believability</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #BELIEVABILITY
	 * @generated
	 * @ordered
	 */
	public static final softgoalType BELIEVABILITY_LITERAL = new softgoalType(BELIEVABILITY, "believability", "believability");

	/**
	 * The '<em><b>Timeliness</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TIMELINESS
	 * @generated
	 * @ordered
	 */
	public static final softgoalType TIMELINESS_LITERAL = new softgoalType(TIMELINESS, "timeliness", "timeliness");

	/**
	 * The '<em><b>Consistency</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CONSISTENCY
	 * @generated
	 * @ordered
	 */
	public static final softgoalType CONSISTENCY_LITERAL = new softgoalType(CONSISTENCY, "consistency", "consistency");

	/**
	 * The '<em><b>Top Level IQ</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TOP_LEVEL_IQ
	 * @generated
	 * @ordered
	 */
	public static final softgoalType TOP_LEVEL_IQ_LITERAL = new softgoalType(TOP_LEVEL_IQ, "topLevelIQ", "topLevelIQ");

	/**
	 * An array of all the '<em><b>softgoal Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final softgoalType[] VALUES_ARRAY =
		new softgoalType[] {
			ACCURACY_LITERAL,
			COMPLETENESS_LITERAL,
			ACCESSIBILITY_LITERAL,
			TRUSTWORTHINESS_LITERAL,
			BELIEVABILITY_LITERAL,
			TIMELINESS_LITERAL,
			CONSISTENCY_LITERAL,
			TOP_LEVEL_IQ_LITERAL,
		};

	/**
	 * A public read-only list of all the '<em><b>softgoal Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>softgoal Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static softgoalType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			softgoalType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>softgoal Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static softgoalType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			softgoalType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>softgoal Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static softgoalType get(int value) {
		switch (value) {
			case ACCURACY: return ACCURACY_LITERAL;
			case COMPLETENESS: return COMPLETENESS_LITERAL;
			case ACCESSIBILITY: return ACCESSIBILITY_LITERAL;
			case TRUSTWORTHINESS: return TRUSTWORTHINESS_LITERAL;
			case BELIEVABILITY: return BELIEVABILITY_LITERAL;
			case TIMELINESS: return TIMELINESS_LITERAL;
			case CONSISTENCY: return CONSISTENCY_LITERAL;
			case TOP_LEVEL_IQ: return TOP_LEVEL_IQ_LITERAL;
		}
		return null;
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private softgoalType(int value, String name, String literal) {
		super(value, name, literal);
	}

} //softgoalType
