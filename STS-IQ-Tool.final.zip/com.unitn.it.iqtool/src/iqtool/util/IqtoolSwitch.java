/**
 */
package iqtool.util;

import iqtool.*;

import java.util.List;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see iqtool.IqtoolPackage
 * @generated
 */
public class IqtoolSwitch {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static IqtoolPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IqtoolSwitch() {
		if (modelPackage == null) {
			modelPackage = IqtoolPackage.eINSTANCE;
		}
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	public Object doSwitch(EObject theEObject) {
		return doSwitch(theEObject.eClass(), theEObject);
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	protected Object doSwitch(EClass theEClass, EObject theEObject) {
		if (theEClass.eContainer() == modelPackage) {
			return doSwitch(theEClass.getClassifierID(), theEObject);
		}
		else {
			List eSuperTypes = theEClass.getESuperTypes();
			return
				eSuperTypes.isEmpty() ?
					defaultCase(theEObject) :
					doSwitch((EClass)eSuperTypes.get(0), theEObject);
		}
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	protected Object doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
			case IqtoolPackage.ACTOR: {
				actor actor = (actor)theEObject;
				Object result = caseactor(actor);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.DIAGRAM: {
				diagram diagram = (diagram)theEObject;
				Object result = casediagram(diagram);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.ROLE: {
				role role = (role)theEObject;
				Object result = caserole(role);
				if (result == null) result = caseactor(role);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.AGENT: {
				agent agent = (agent)theEObject;
				Object result = caseagent(agent);
				if (result == null) result = caseactor(agent);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.PERM_DELEGATION: {
				permDelegation permDelegation = (permDelegation)theEObject;
				Object result = casepermDelegation(permDelegation);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.READ: {
				read read = (read)theEObject;
				Object result = caseread(read);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.SEND: {
				send send = (send)theEObject;
				Object result = casesend(send);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.GOAL_DELEGATION: {
				goalDelegation goalDelegation = (goalDelegation)theEObject;
				Object result = casegoalDelegation(goalDelegation);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.DELEGATION_TRUST: {
				delegationTrust delegationTrust = (delegationTrust)theEObject;
				Object result = casedelegationTrust(delegationTrust);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.INFO_PROVISION: {
				infoProvision infoProvision = (infoProvision)theEObject;
				Object result = caseinfoProvision(infoProvision);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.TRUST_PERM_DELEGATION: {
				trustPermDelegation trustPermDelegation = (trustPermDelegation)theEObject;
				Object result = casetrustPermDelegation(trustPermDelegation);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.INFORMATION: {
				information information = (information)theEObject;
				Object result = caseinformation(information);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.SCOPE: {
				scope scope = (scope)theEObject;
				Object result = casescope(scope);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.GOAL: {
				goal goal = (goal)theEObject;
				Object result = casegoal(goal);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.PRODUCE: {
				produce produce = (produce)theEObject;
				Object result = caseproduce(produce);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.PRODUCE_TRUST: {
				produceTrust produceTrust = (produceTrust)theEObject;
				Object result = caseproduceTrust(produceTrust);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.INSTANCE_GOAL: {
				instanceGoal instanceGoal = (instanceGoal)theEObject;
				Object result = caseinstanceGoal(instanceGoal);
				if (result == null) result = casegoal(instanceGoal);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.GENERAL_GOAL: {
				generalGoal generalGoal = (generalGoal)theEObject;
				Object result = casegeneralGoal(generalGoal);
				if (result == null) result = casegoal(generalGoal);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.INSTANCE_INFORMATION: {
				instanceInformation instanceInformation = (instanceInformation)theEObject;
				Object result = caseinstanceInformation(instanceInformation);
				if (result == null) result = caseinformation(instanceInformation);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.GENERAL_INFORMATION: {
				general_information general_information = (general_information)theEObject;
				Object result = casegeneral_information(general_information);
				if (result == null) result = caseinformation(general_information);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.THREAT: {
				threat threat = (threat)theEObject;
				Object result = casethreat(threat);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.INFORMATION_THREAT: {
				informationThreat informationThreat = (informationThreat)theEObject;
				Object result = caseinformationThreat(informationThreat);
				if (result == null) result = casethreat(informationThreat);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.GOAL_THREAT: {
				goalThreat goalThreat = (goalThreat)theEObject;
				Object result = casegoalThreat(goalThreat);
				if (result == null) result = casethreat(goalThreat);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.MONITORING: {
				monitoring monitoring = (monitoring)theEObject;
				Object result = casemonitoring(monitoring);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.GOAL_MONITORING: {
				goalMonitoring goalMonitoring = (goalMonitoring)theEObject;
				Object result = casegoalMonitoring(goalMonitoring);
				if (result == null) result = casemonitoring(goalMonitoring);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.PERM_MONITORING: {
				permMonitoring permMonitoring = (permMonitoring)theEObject;
				Object result = casepermMonitoring(permMonitoring);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.INFO_MONITORING: {
				infoMonitoring infoMonitoring = (infoMonitoring)theEObject;
				Object result = caseinfoMonitoring(infoMonitoring);
				if (result == null) result = casemonitoring(infoMonitoring);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case IqtoolPackage.PERM_MONITOR: {
				permMonitor permMonitor = (permMonitor)theEObject;
				Object result = casepermMonitor(permMonitor);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>actor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>actor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseactor(actor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>diagram</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>diagram</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object casediagram(diagram object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>role</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>role</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caserole(role object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>agent</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>agent</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseagent(agent object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>perm Delegation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>perm Delegation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object casepermDelegation(permDelegation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>read</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>read</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseread(read object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>send</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>send</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object casesend(send object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>goal Delegation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>goal Delegation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object casegoalDelegation(goalDelegation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>delegation Trust</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>delegation Trust</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object casedelegationTrust(delegationTrust object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>info Provision</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>info Provision</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseinfoProvision(infoProvision object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>trust Perm Delegation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>trust Perm Delegation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object casetrustPermDelegation(trustPermDelegation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>information</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>information</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseinformation(information object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>scope</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>scope</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object casescope(scope object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>goal</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>goal</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object casegoal(goal object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>produce</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>produce</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseproduce(produce object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>produce Trust</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>produce Trust</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseproduceTrust(produceTrust object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>instance Goal</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>instance Goal</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseinstanceGoal(instanceGoal object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>general Goal</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>general Goal</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object casegeneralGoal(generalGoal object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>instance Information</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>instance Information</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseinstanceInformation(instanceInformation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>general information</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>general information</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object casegeneral_information(general_information object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>threat</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>threat</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object casethreat(threat object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>information Threat</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>information Threat</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseinformationThreat(informationThreat object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>goal Threat</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>goal Threat</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object casegoalThreat(goalThreat object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>monitoring</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>monitoring</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object casemonitoring(monitoring object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>goal Monitoring</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>goal Monitoring</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object casegoalMonitoring(goalMonitoring object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>perm Monitoring</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>perm Monitoring</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object casepermMonitoring(permMonitoring object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>info Monitoring</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>info Monitoring</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseinfoMonitoring(infoMonitoring object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>perm Monitor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>perm Monitor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object casepermMonitor(permMonitor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	public Object defaultCase(EObject object) {
		return null;
	}

} //IqtoolSwitch
