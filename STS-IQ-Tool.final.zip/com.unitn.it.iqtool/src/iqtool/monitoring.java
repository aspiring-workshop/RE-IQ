/**
 */
package iqtool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>monitoring</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.monitoring#getMonitor <em>Monitor</em>}</li>
 *   <li>{@link iqtool.monitoring#getMonitored <em>Monitored</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getmonitoring()
 * @model
 * @generated
 */
public interface monitoring extends EObject {
	/**
	 * Returns the value of the '<em><b>Monitor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Monitor</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Monitor</em>' reference.
	 * @see #setMonitor(actor)
	 * @see iqtool.IqtoolPackage#getmonitoring_Monitor()
	 * @model
	 * @generated
	 */
	actor getMonitor();

	/**
	 * Sets the value of the '{@link iqtool.monitoring#getMonitor <em>Monitor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Monitor</em>' reference.
	 * @see #getMonitor()
	 * @generated
	 */
	void setMonitor(actor value);

	/**
	 * Returns the value of the '<em><b>Monitored</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Monitored</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Monitored</em>' reference.
	 * @see #setMonitored(actor)
	 * @see iqtool.IqtoolPackage#getmonitoring_Monitored()
	 * @model
	 * @generated
	 */
	actor getMonitored();

	/**
	 * Sets the value of the '{@link iqtool.monitoring#getMonitored <em>Monitored</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Monitored</em>' reference.
	 * @see #getMonitored()
	 * @generated
	 */
	void setMonitored(actor value);

} // monitoring
