/**
 */
package iqtool;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>agent</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.agent#getPlay <em>Play</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getagent()
 * @model
 * @generated
 */
public interface agent extends actor {
	/**
	 * Returns the value of the '<em><b>Play</b></em>' reference list.
	 * The list contents are of type {@link iqtool.role}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Play</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Play</em>' reference list.
	 * @see iqtool.IqtoolPackage#getagent_Play()
	 * @model type="iqtool.role" required="true"
	 * @generated
	 */
	EList getPlay();

} // agent
