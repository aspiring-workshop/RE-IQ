/**
 */
package iqtool;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>generalinformation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see iqtool.IqtoolPackage#getgeneralinformation()
 * @model
 * @generated
 */
public interface generalinformation extends information {
} // generalinformation
