/**
 */
package iqtool;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>perm Monitor Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see iqtool.IqtoolPackage#getpermMonitorType()
 * @model
 * @generated
 */
public final class permMonitorType extends AbstractEnumerator {
	/**
	 * The '<em><b>Monitor</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Monitor</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #MONITOR_LITERAL
	 * @model name="monitor"
	 * @generated
	 * @ordered
	 */
	public static final int MONITOR = 0;

	/**
	 * The '<em><b>Nomonitor</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Nomonitor</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #NOMONITOR_LITERAL
	 * @model name="nomonitor"
	 * @generated
	 * @ordered
	 */
	public static final int NOMONITOR = 0;

	/**
	 * The '<em><b>Monitor</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MONITOR
	 * @generated
	 * @ordered
	 */
	public static final permMonitorType MONITOR_LITERAL = new permMonitorType(MONITOR, "monitor", "monitor");

	/**
	 * The '<em><b>Nomonitor</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NOMONITOR
	 * @generated
	 * @ordered
	 */
	public static final permMonitorType NOMONITOR_LITERAL = new permMonitorType(NOMONITOR, "nomonitor", "nomonitor");

	/**
	 * An array of all the '<em><b>perm Monitor Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final permMonitorType[] VALUES_ARRAY =
		new permMonitorType[] {
			MONITOR_LITERAL,
			NOMONITOR_LITERAL,
		};

	/**
	 * A public read-only list of all the '<em><b>perm Monitor Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>perm Monitor Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static permMonitorType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			permMonitorType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>perm Monitor Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static permMonitorType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			permMonitorType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>perm Monitor Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static permMonitorType get(int value) {
		switch (value) {
			case MONITOR: return MONITOR_LITERAL;
		}
		return null;
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private permMonitorType(int value, String name, String literal) {
		super(value, name, literal);
	}

} //permMonitorType
