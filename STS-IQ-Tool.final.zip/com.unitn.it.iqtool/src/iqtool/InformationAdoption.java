/**
 */
package iqtool;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Information Adoption</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.InformationAdoption#getAdoptionOfInformation <em>Adoption Of Information</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getInformationAdoption()
 * @model
 * @generated
 */
public interface InformationAdoption extends adoption {
	/**
	 * Returns the value of the '<em><b>Adoption Of Information</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Adoption Of Information</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Adoption Of Information</em>' reference.
	 * @see #setAdoptionOfInformation(information)
	 * @see iqtool.IqtoolPackage#getInformationAdoption_AdoptionOfInformation()
	 * @model
	 * @generated
	 */
	information getAdoptionOfInformation();

	/**
	 * Sets the value of the '{@link iqtool.InformationAdoption#getAdoptionOfInformation <em>Adoption Of Information</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Adoption Of Information</em>' reference.
	 * @see #getAdoptionOfInformation()
	 * @generated
	 */
	void setAdoptionOfInformation(information value);

} // InformationAdoption
