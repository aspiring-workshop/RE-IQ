/**
 */
package iqtool;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>end Postion</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see iqtool.IqtoolPackage#getendPostion()
 * @model
 * @generated
 */
public interface endPostion extends position {
} // endPostion
