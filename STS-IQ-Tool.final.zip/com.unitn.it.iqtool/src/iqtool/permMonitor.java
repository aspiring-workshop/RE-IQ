/**
 */
package iqtool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>perm Monitor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.permMonitor#getOver <em>Over</em>}</li>
 *   <li>{@link iqtool.permMonitor#getR <em>R</em>}</li>
 *   <li>{@link iqtool.permMonitor#getP <em>P</em>}</li>
 *   <li>{@link iqtool.permMonitor#getS <em>S</em>}</li>
 *   <li>{@link iqtool.permMonitor#getM <em>M</em>}</li>
 *   <li>{@link iqtool.permMonitor#getMonitored <em>Monitored</em>}</li>
 *   <li>{@link iqtool.permMonitor#getMonitor <em>Monitor</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getpermMonitor()
 * @model
 * @generated
 */
public interface permMonitor extends EObject {
	/**
	 * Returns the value of the '<em><b>Over</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Over</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Over</em>' reference.
	 * @see #setOver(information)
	 * @see iqtool.IqtoolPackage#getpermMonitor_Over()
	 * @model
	 * @generated
	 */
	information getOver();

	/**
	 * Sets the value of the '{@link iqtool.permMonitor#getOver <em>Over</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Over</em>' reference.
	 * @see #getOver()
	 * @generated
	 */
	void setOver(information value);

	/**
	 * Returns the value of the '<em><b>R</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.permMonitorType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>R</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>R</em>' attribute.
	 * @see iqtool.permMonitorType
	 * @see #setR(permMonitorType)
	 * @see iqtool.IqtoolPackage#getpermMonitor_R()
	 * @model
	 * @generated
	 */
	permMonitorType getR();

	/**
	 * Sets the value of the '{@link iqtool.permMonitor#getR <em>R</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>R</em>' attribute.
	 * @see iqtool.permMonitorType
	 * @see #getR()
	 * @generated
	 */
	void setR(permMonitorType value);

	/**
	 * Returns the value of the '<em><b>P</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.permMonitorType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>P</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>P</em>' attribute.
	 * @see iqtool.permMonitorType
	 * @see #setP(permMonitorType)
	 * @see iqtool.IqtoolPackage#getpermMonitor_P()
	 * @model
	 * @generated
	 */
	permMonitorType getP();

	/**
	 * Sets the value of the '{@link iqtool.permMonitor#getP <em>P</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>P</em>' attribute.
	 * @see iqtool.permMonitorType
	 * @see #getP()
	 * @generated
	 */
	void setP(permMonitorType value);

	/**
	 * Returns the value of the '<em><b>S</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.permMonitorType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>S</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>S</em>' attribute.
	 * @see iqtool.permMonitorType
	 * @see #setS(permMonitorType)
	 * @see iqtool.IqtoolPackage#getpermMonitor_S()
	 * @model
	 * @generated
	 */
	permMonitorType getS();

	/**
	 * Sets the value of the '{@link iqtool.permMonitor#getS <em>S</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>S</em>' attribute.
	 * @see iqtool.permMonitorType
	 * @see #getS()
	 * @generated
	 */
	void setS(permMonitorType value);

	/**
	 * Returns the value of the '<em><b>M</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.permMonitorType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>M</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>M</em>' attribute.
	 * @see iqtool.permMonitorType
	 * @see #setM(permMonitorType)
	 * @see iqtool.IqtoolPackage#getpermMonitor_M()
	 * @model
	 * @generated
	 */
	permMonitorType getM();

	/**
	 * Sets the value of the '{@link iqtool.permMonitor#getM <em>M</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>M</em>' attribute.
	 * @see iqtool.permMonitorType
	 * @see #getM()
	 * @generated
	 */
	void setM(permMonitorType value);

	/**
	 * Returns the value of the '<em><b>Monitored</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Monitored</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Monitored</em>' reference.
	 * @see #setMonitored(actor)
	 * @see iqtool.IqtoolPackage#getpermMonitor_Monitored()
	 * @model
	 * @generated
	 */
	actor getMonitored();

	/**
	 * Sets the value of the '{@link iqtool.permMonitor#getMonitored <em>Monitored</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Monitored</em>' reference.
	 * @see #getMonitored()
	 * @generated
	 */
	void setMonitored(actor value);

	/**
	 * Returns the value of the '<em><b>Monitor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Monitor</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Monitor</em>' reference.
	 * @see #setMonitor(actor)
	 * @see iqtool.IqtoolPackage#getpermMonitor_Monitor()
	 * @model
	 * @generated
	 */
	actor getMonitor();

	/**
	 * Sets the value of the '{@link iqtool.permMonitor#getMonitor <em>Monitor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Monitor</em>' reference.
	 * @see #getMonitor()
	 * @generated
	 */
	void setMonitor(actor value);

} // permMonitor
