/**
 */
package iqtool;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>scope</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.scope#getContains <em>Contains</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getscope()
 * @model
 * @generated
 */
public interface scope extends EObject {
	/**
	 * Returns the value of the '<em><b>Contains</b></em>' containment reference list.
	 * The list contents are of type {@link iqtool.goal}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Contains</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Contains</em>' containment reference list.
	 * @see iqtool.IqtoolPackage#getscope_Contains()
	 * @model type="iqtool.goal" containment="true"
	 * @generated
	 */
	EList getContains();

} // scope
