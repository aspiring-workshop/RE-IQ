/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.actor;
import iqtool.infoProvision;
import iqtool.information;
import iqtool.provisionType;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>info Provision</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.infoProvisionImpl#getProvisionOf <em>Provision Of</em>}</li>
 *   <li>{@link iqtool.impl.infoProvisionImpl#getProvisionFrom <em>Provision From</em>}</li>
 *   <li>{@link iqtool.impl.infoProvisionImpl#getProvisionTo <em>Provision To</em>}</li>
 *   <li>{@link iqtool.impl.infoProvisionImpl#getType <em>Type</em>}</li>
 *   <li>{@link iqtool.impl.infoProvisionImpl#getTime <em>Time</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class infoProvisionImpl extends MinimalEObjectImpl.Container implements infoProvision {
	/**
	 * The cached value of the '{@link #getProvisionOf() <em>Provision Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProvisionOf()
	 * @generated
	 * @ordered
	 */
	protected information provisionOf;

	/**
	 * The cached value of the '{@link #getProvisionFrom() <em>Provision From</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProvisionFrom()
	 * @generated
	 * @ordered
	 */
	protected actor provisionFrom;

	/**
	 * The cached value of the '{@link #getProvisionTo() <em>Provision To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProvisionTo()
	 * @generated
	 * @ordered
	 */
	protected actor provisionTo;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final provisionType TYPE_EDEFAULT = provisionType.PROVISION_LITERAL;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected provisionType type = TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getTime() <em>Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTime()
	 * @generated
	 * @ordered
	 */
	protected static final int TIME_EDEFAULT = 100;

	/**
	 * The cached value of the '{@link #getTime() <em>Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTime()
	 * @generated
	 * @ordered
	 */
	protected int time = TIME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected infoProvisionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.INFO_PROVISION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information getProvisionOf() {
		if (provisionOf != null && provisionOf.eIsProxy()) {
			InternalEObject oldProvisionOf = (InternalEObject)provisionOf;
			provisionOf = (information)eResolveProxy(oldProvisionOf);
			if (provisionOf != oldProvisionOf) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.INFO_PROVISION__PROVISION_OF, oldProvisionOf, provisionOf));
			}
		}
		return provisionOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information basicGetProvisionOf() {
		return provisionOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProvisionOf(information newProvisionOf) {
		information oldProvisionOf = provisionOf;
		provisionOf = newProvisionOf;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.INFO_PROVISION__PROVISION_OF, oldProvisionOf, provisionOf));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getProvisionFrom() {
		if (provisionFrom != null && provisionFrom.eIsProxy()) {
			InternalEObject oldProvisionFrom = (InternalEObject)provisionFrom;
			provisionFrom = (actor)eResolveProxy(oldProvisionFrom);
			if (provisionFrom != oldProvisionFrom) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.INFO_PROVISION__PROVISION_FROM, oldProvisionFrom, provisionFrom));
			}
		}
		return provisionFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetProvisionFrom() {
		return provisionFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProvisionFrom(actor newProvisionFrom) {
		actor oldProvisionFrom = provisionFrom;
		provisionFrom = newProvisionFrom;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.INFO_PROVISION__PROVISION_FROM, oldProvisionFrom, provisionFrom));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getProvisionTo() {
		if (provisionTo != null && provisionTo.eIsProxy()) {
			InternalEObject oldProvisionTo = (InternalEObject)provisionTo;
			provisionTo = (actor)eResolveProxy(oldProvisionTo);
			if (provisionTo != oldProvisionTo) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.INFO_PROVISION__PROVISION_TO, oldProvisionTo, provisionTo));
			}
		}
		return provisionTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetProvisionTo() {
		return provisionTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProvisionTo(actor newProvisionTo) {
		actor oldProvisionTo = provisionTo;
		provisionTo = newProvisionTo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.INFO_PROVISION__PROVISION_TO, oldProvisionTo, provisionTo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public provisionType getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(provisionType newType) {
		provisionType oldType = type;
		type = newType == null ? TYPE_EDEFAULT : newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.INFO_PROVISION__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTime() {
		return time;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTime(int newTime) {
		int oldTime = time;
		time = newTime;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.INFO_PROVISION__TIME, oldTime, time));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.INFO_PROVISION__PROVISION_OF:
				if (resolve) return getProvisionOf();
				return basicGetProvisionOf();
			case IqtoolPackage.INFO_PROVISION__PROVISION_FROM:
				if (resolve) return getProvisionFrom();
				return basicGetProvisionFrom();
			case IqtoolPackage.INFO_PROVISION__PROVISION_TO:
				if (resolve) return getProvisionTo();
				return basicGetProvisionTo();
			case IqtoolPackage.INFO_PROVISION__TYPE:
				return getType();
			case IqtoolPackage.INFO_PROVISION__TIME:
				return new Integer(getTime());
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.INFO_PROVISION__PROVISION_OF:
				setProvisionOf((information)newValue);
				return;
			case IqtoolPackage.INFO_PROVISION__PROVISION_FROM:
				setProvisionFrom((actor)newValue);
				return;
			case IqtoolPackage.INFO_PROVISION__PROVISION_TO:
				setProvisionTo((actor)newValue);
				return;
			case IqtoolPackage.INFO_PROVISION__TYPE:
				setType((provisionType)newValue);
				return;
			case IqtoolPackage.INFO_PROVISION__TIME:
				setTime(((Integer)newValue).intValue());
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.INFO_PROVISION__PROVISION_OF:
				setProvisionOf((information)null);
				return;
			case IqtoolPackage.INFO_PROVISION__PROVISION_FROM:
				setProvisionFrom((actor)null);
				return;
			case IqtoolPackage.INFO_PROVISION__PROVISION_TO:
				setProvisionTo((actor)null);
				return;
			case IqtoolPackage.INFO_PROVISION__TYPE:
				setType(TYPE_EDEFAULT);
				return;
			case IqtoolPackage.INFO_PROVISION__TIME:
				setTime(TIME_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.INFO_PROVISION__PROVISION_OF:
				return provisionOf != null;
			case IqtoolPackage.INFO_PROVISION__PROVISION_FROM:
				return provisionFrom != null;
			case IqtoolPackage.INFO_PROVISION__PROVISION_TO:
				return provisionTo != null;
			case IqtoolPackage.INFO_PROVISION__TYPE:
				return type != TYPE_EDEFAULT;
			case IqtoolPackage.INFO_PROVISION__TIME:
				return time != TIME_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (type: ");
		result.append(type);
		result.append(", time: ");
		result.append(time);
		result.append(')');
		return result.toString();
	}

} //infoProvisionImpl
