/**
 */
package iqtool.impl;

import iqtool.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class IqtoolFactoryImpl extends EFactoryImpl implements IqtoolFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static IqtoolFactory init() {
		try {
			IqtoolFactory theIqtoolFactory = (IqtoolFactory)EPackage.Registry.INSTANCE.getEFactory(IqtoolPackage.eNS_URI);
			if (theIqtoolFactory != null) {
				return theIqtoolFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new IqtoolFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IqtoolFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case IqtoolPackage.DIAGRAM: return creatediagram();
			case IqtoolPackage.ROLE: return createrole();
			case IqtoolPackage.AGENT: return createagent();
			case IqtoolPackage.PERM_DELEGATION: return createpermDelegation();
			case IqtoolPackage.READ: return createread();
			case IqtoolPackage.SEND: return createsend();
			case IqtoolPackage.GOAL_DELEGATION: return creategoalDelegation();
			case IqtoolPackage.DELEGATION_TRUST: return createdelegationTrust();
			case IqtoolPackage.INFO_PROVISION: return createinfoProvision();
			case IqtoolPackage.TRUST_PERM_DELEGATION: return createtrustPermDelegation();
			case IqtoolPackage.INFORMATION: return createinformation();
			case IqtoolPackage.SCOPE: return createscope();
			case IqtoolPackage.GOAL: return creategoal();
			case IqtoolPackage.PRODUCE: return createproduce();
			case IqtoolPackage.PRODUCE_TRUST: return createproduceTrust();
			case IqtoolPackage.INSTANCE_GOAL: return createinstanceGoal();
			case IqtoolPackage.GENERAL_GOAL: return creategeneralGoal();
			case IqtoolPackage.INSTANCE_INFORMATION: return createinstanceInformation();
			case IqtoolPackage.GENERAL_INFORMATION: return creategeneral_information();
			case IqtoolPackage.THREAT: return createthreat();
			case IqtoolPackage.INFORMATION_THREAT: return createinformationThreat();
			case IqtoolPackage.GOAL_THREAT: return creategoalThreat();
			case IqtoolPackage.MONITORING: return createmonitoring();
			case IqtoolPackage.GOAL_MONITORING: return creategoalMonitoring();
			case IqtoolPackage.PERM_MONITORING: return createpermMonitoring();
			case IqtoolPackage.INFO_MONITORING: return createinfoMonitoring();
			case IqtoolPackage.PERM_MONITOR: return createpermMonitor();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case IqtoolPackage.PURPOSE_OF_USE_TYPES:
				return createpurposeOfUseTypesFromString(eDataType, initialValue);
			case IqtoolPackage.SEND_PERM_TYPE:
				return createsendPermTypeFromString(eDataType, initialValue);
			case IqtoolPackage.MODIFY_PERM_TYPE:
				return createmodifyPermTypeFromString(eDataType, initialValue);
			case IqtoolPackage.TRUST_LEVEL:
				return createtrustLevelFromString(eDataType, initialValue);
			case IqtoolPackage.PRODUCE_PERM_TYPE:
				return createproducePermTypeFromString(eDataType, initialValue);
			case IqtoolPackage.PROVISION_TYPE:
				return createprovisionTypeFromString(eDataType, initialValue);
			case IqtoolPackage.READ_PERM_TYPE:
				return createreadPermTypeFromString(eDataType, initialValue);
			case IqtoolPackage.BLV_TYPE:
				return createblv_typeFromString(eDataType, initialValue);
			case IqtoolPackage.RTYPE:
				return creatertypeFromString(eDataType, initialValue);
			case IqtoolPackage.PERM_MONITOR_TYPE:
				return createpermMonitorTypeFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case IqtoolPackage.PURPOSE_OF_USE_TYPES:
				return convertpurposeOfUseTypesToString(eDataType, instanceValue);
			case IqtoolPackage.SEND_PERM_TYPE:
				return convertsendPermTypeToString(eDataType, instanceValue);
			case IqtoolPackage.MODIFY_PERM_TYPE:
				return convertmodifyPermTypeToString(eDataType, instanceValue);
			case IqtoolPackage.TRUST_LEVEL:
				return converttrustLevelToString(eDataType, instanceValue);
			case IqtoolPackage.PRODUCE_PERM_TYPE:
				return convertproducePermTypeToString(eDataType, instanceValue);
			case IqtoolPackage.PROVISION_TYPE:
				return convertprovisionTypeToString(eDataType, instanceValue);
			case IqtoolPackage.READ_PERM_TYPE:
				return convertreadPermTypeToString(eDataType, instanceValue);
			case IqtoolPackage.BLV_TYPE:
				return convertblv_typeToString(eDataType, instanceValue);
			case IqtoolPackage.RTYPE:
				return convertrtypeToString(eDataType, instanceValue);
			case IqtoolPackage.PERM_MONITOR_TYPE:
				return convertpermMonitorTypeToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public diagram creatediagram() {
		diagramImpl diagram = new diagramImpl();
		return diagram;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public role createrole() {
		roleImpl role = new roleImpl();
		return role;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public agent createagent() {
		agentImpl agent = new agentImpl();
		return agent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public permDelegation createpermDelegation() {
		permDelegationImpl permDelegation = new permDelegationImpl();
		return permDelegation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public read createread() {
		readImpl read = new readImpl();
		return read;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public send createsend() {
		sendImpl send = new sendImpl();
		return send;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goalDelegation creategoalDelegation() {
		goalDelegationImpl goalDelegation = new goalDelegationImpl();
		return goalDelegation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public delegationTrust createdelegationTrust() {
		delegationTrustImpl delegationTrust = new delegationTrustImpl();
		return delegationTrust;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public infoProvision createinfoProvision() {
		infoProvisionImpl infoProvision = new infoProvisionImpl();
		return infoProvision;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public trustPermDelegation createtrustPermDelegation() {
		trustPermDelegationImpl trustPermDelegation = new trustPermDelegationImpl();
		return trustPermDelegation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information createinformation() {
		informationImpl information = new informationImpl();
		return information;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public scope createscope() {
		scopeImpl scope = new scopeImpl();
		return scope;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goal creategoal() {
		goalImpl goal = new goalImpl();
		return goal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public produce createproduce() {
		produceImpl produce = new produceImpl();
		return produce;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public produceTrust createproduceTrust() {
		produceTrustImpl produceTrust = new produceTrustImpl();
		return produceTrust;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public instanceGoal createinstanceGoal() {
		instanceGoalImpl instanceGoal = new instanceGoalImpl();
		return instanceGoal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public generalGoal creategeneralGoal() {
		generalGoalImpl generalGoal = new generalGoalImpl();
		return generalGoal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public instanceInformation createinstanceInformation() {
		instanceInformationImpl instanceInformation = new instanceInformationImpl();
		return instanceInformation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public general_information creategeneral_information() {
		general_informationImpl general_information = new general_informationImpl();
		return general_information;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public threat createthreat() {
		threatImpl threat = new threatImpl();
		return threat;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public informationThreat createinformationThreat() {
		informationThreatImpl informationThreat = new informationThreatImpl();
		return informationThreat;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goalThreat creategoalThreat() {
		goalThreatImpl goalThreat = new goalThreatImpl();
		return goalThreat;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public monitoring createmonitoring() {
		monitoringImpl monitoring = new monitoringImpl();
		return monitoring;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public goalMonitoring creategoalMonitoring() {
		goalMonitoringImpl goalMonitoring = new goalMonitoringImpl();
		return goalMonitoring;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public permMonitoring createpermMonitoring() {
		permMonitoringImpl permMonitoring = new permMonitoringImpl();
		return permMonitoring;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public infoMonitoring createinfoMonitoring() {
		infoMonitoringImpl infoMonitoring = new infoMonitoringImpl();
		return infoMonitoring;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public permMonitor createpermMonitor() {
		permMonitorImpl permMonitor = new permMonitorImpl();
		return permMonitor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public purposeOfUseTypes createpurposeOfUseTypesFromString(EDataType eDataType, String initialValue) {
		purposeOfUseTypes result = purposeOfUseTypes.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertpurposeOfUseTypesToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public sendPermType createsendPermTypeFromString(EDataType eDataType, String initialValue) {
		sendPermType result = sendPermType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertsendPermTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public modifyPermType createmodifyPermTypeFromString(EDataType eDataType, String initialValue) {
		modifyPermType result = modifyPermType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertmodifyPermTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public trustLevel createtrustLevelFromString(EDataType eDataType, String initialValue) {
		trustLevel result = trustLevel.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String converttrustLevelToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public producePermType createproducePermTypeFromString(EDataType eDataType, String initialValue) {
		producePermType result = producePermType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertproducePermTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public provisionType createprovisionTypeFromString(EDataType eDataType, String initialValue) {
		provisionType result = provisionType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertprovisionTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public readPermType createreadPermTypeFromString(EDataType eDataType, String initialValue) {
		readPermType result = readPermType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertreadPermTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public blv_type createblv_typeFromString(EDataType eDataType, String initialValue) {
		blv_type result = blv_type.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertblv_typeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public rtype creatertypeFromString(EDataType eDataType, String initialValue) {
		rtype result = rtype.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertrtypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public permMonitorType createpermMonitorTypeFromString(EDataType eDataType, String initialValue) {
		permMonitorType result = permMonitorType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertpermMonitorTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IqtoolPackage getIqtoolPackage() {
		return (IqtoolPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	public static IqtoolPackage getPackage() {
		return IqtoolPackage.eINSTANCE;
	}

} //IqtoolFactoryImpl
