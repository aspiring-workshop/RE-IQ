/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.actor;
import iqtool.information;
import iqtool.trustLevel;
import iqtool.trustPermDelegation;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>trust Perm Delegation</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.trustPermDelegationImpl#getTrustPermDeleTo <em>Trust Perm Dele To</em>}</li>
 *   <li>{@link iqtool.impl.trustPermDelegationImpl#getTrustPermDeleFrom <em>Trust Perm Dele From</em>}</li>
 *   <li>{@link iqtool.impl.trustPermDelegationImpl#getTrustPermDeleOf <em>Trust Perm Dele Of</em>}</li>
 *   <li>{@link iqtool.impl.trustPermDelegationImpl#getTrustprodue <em>Trustprodue</em>}</li>
 *   <li>{@link iqtool.impl.trustPermDelegationImpl#getTrustread <em>Trustread</em>}</li>
 *   <li>{@link iqtool.impl.trustPermDelegationImpl#getTrustsend <em>Trustsend</em>}</li>
 *   <li>{@link iqtool.impl.trustPermDelegationImpl#getTrustmodify <em>Trustmodify</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class trustPermDelegationImpl extends MinimalEObjectImpl.Container implements trustPermDelegation {
	/**
	 * The cached value of the '{@link #getTrustPermDeleTo() <em>Trust Perm Dele To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustPermDeleTo()
	 * @generated
	 * @ordered
	 */
	protected actor trustPermDeleTo;

	/**
	 * The cached value of the '{@link #getTrustPermDeleFrom() <em>Trust Perm Dele From</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustPermDeleFrom()
	 * @generated
	 * @ordered
	 */
	protected actor trustPermDeleFrom;

	/**
	 * The cached value of the '{@link #getTrustPermDeleOf() <em>Trust Perm Dele Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustPermDeleOf()
	 * @generated
	 * @ordered
	 */
	protected information trustPermDeleOf;

	/**
	 * The default value of the '{@link #getTrustprodue() <em>Trustprodue</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustprodue()
	 * @generated
	 * @ordered
	 */
	protected static final trustLevel TRUSTPRODUE_EDEFAULT = trustLevel.TRUST_LITERAL;

	/**
	 * The cached value of the '{@link #getTrustprodue() <em>Trustprodue</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustprodue()
	 * @generated
	 * @ordered
	 */
	protected trustLevel trustprodue = TRUSTPRODUE_EDEFAULT;

	/**
	 * The default value of the '{@link #getTrustread() <em>Trustread</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustread()
	 * @generated
	 * @ordered
	 */
	protected static final trustLevel TRUSTREAD_EDEFAULT = trustLevel.TRUST_LITERAL;

	/**
	 * The cached value of the '{@link #getTrustread() <em>Trustread</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustread()
	 * @generated
	 * @ordered
	 */
	protected trustLevel trustread = TRUSTREAD_EDEFAULT;

	/**
	 * The default value of the '{@link #getTrustsend() <em>Trustsend</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustsend()
	 * @generated
	 * @ordered
	 */
	protected static final trustLevel TRUSTSEND_EDEFAULT = trustLevel.TRUST_LITERAL;

	/**
	 * The cached value of the '{@link #getTrustsend() <em>Trustsend</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustsend()
	 * @generated
	 * @ordered
	 */
	protected trustLevel trustsend = TRUSTSEND_EDEFAULT;

	/**
	 * The default value of the '{@link #getTrustmodify() <em>Trustmodify</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustmodify()
	 * @generated
	 * @ordered
	 */
	protected static final trustLevel TRUSTMODIFY_EDEFAULT = trustLevel.TRUST_LITERAL;

	/**
	 * The cached value of the '{@link #getTrustmodify() <em>Trustmodify</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrustmodify()
	 * @generated
	 * @ordered
	 */
	protected trustLevel trustmodify = TRUSTMODIFY_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected trustPermDelegationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.TRUST_PERM_DELEGATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getTrustPermDeleTo() {
		if (trustPermDeleTo != null && trustPermDeleTo.eIsProxy()) {
			InternalEObject oldTrustPermDeleTo = (InternalEObject)trustPermDeleTo;
			trustPermDeleTo = (actor)eResolveProxy(oldTrustPermDeleTo);
			if (trustPermDeleTo != oldTrustPermDeleTo) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_TO, oldTrustPermDeleTo, trustPermDeleTo));
			}
		}
		return trustPermDeleTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetTrustPermDeleTo() {
		return trustPermDeleTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTrustPermDeleTo(actor newTrustPermDeleTo) {
		actor oldTrustPermDeleTo = trustPermDeleTo;
		trustPermDeleTo = newTrustPermDeleTo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_TO, oldTrustPermDeleTo, trustPermDeleTo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor getTrustPermDeleFrom() {
		if (trustPermDeleFrom != null && trustPermDeleFrom.eIsProxy()) {
			InternalEObject oldTrustPermDeleFrom = (InternalEObject)trustPermDeleFrom;
			trustPermDeleFrom = (actor)eResolveProxy(oldTrustPermDeleFrom);
			if (trustPermDeleFrom != oldTrustPermDeleFrom) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_FROM, oldTrustPermDeleFrom, trustPermDeleFrom));
			}
		}
		return trustPermDeleFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public actor basicGetTrustPermDeleFrom() {
		return trustPermDeleFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTrustPermDeleFrom(actor newTrustPermDeleFrom) {
		actor oldTrustPermDeleFrom = trustPermDeleFrom;
		trustPermDeleFrom = newTrustPermDeleFrom;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_FROM, oldTrustPermDeleFrom, trustPermDeleFrom));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information getTrustPermDeleOf() {
		if (trustPermDeleOf != null && trustPermDeleOf.eIsProxy()) {
			InternalEObject oldTrustPermDeleOf = (InternalEObject)trustPermDeleOf;
			trustPermDeleOf = (information)eResolveProxy(oldTrustPermDeleOf);
			if (trustPermDeleOf != oldTrustPermDeleOf) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_OF, oldTrustPermDeleOf, trustPermDeleOf));
			}
		}
		return trustPermDeleOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information basicGetTrustPermDeleOf() {
		return trustPermDeleOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTrustPermDeleOf(information newTrustPermDeleOf) {
		information oldTrustPermDeleOf = trustPermDeleOf;
		trustPermDeleOf = newTrustPermDeleOf;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_OF, oldTrustPermDeleOf, trustPermDeleOf));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public trustLevel getTrustprodue() {
		return trustprodue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTrustprodue(trustLevel newTrustprodue) {
		trustLevel oldTrustprodue = trustprodue;
		trustprodue = newTrustprodue == null ? TRUSTPRODUE_EDEFAULT : newTrustprodue;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTPRODUE, oldTrustprodue, trustprodue));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public trustLevel getTrustread() {
		return trustread;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTrustread(trustLevel newTrustread) {
		trustLevel oldTrustread = trustread;
		trustread = newTrustread == null ? TRUSTREAD_EDEFAULT : newTrustread;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTREAD, oldTrustread, trustread));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public trustLevel getTrustsend() {
		return trustsend;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTrustsend(trustLevel newTrustsend) {
		trustLevel oldTrustsend = trustsend;
		trustsend = newTrustsend == null ? TRUSTSEND_EDEFAULT : newTrustsend;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTSEND, oldTrustsend, trustsend));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public trustLevel getTrustmodify() {
		return trustmodify;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTrustmodify(trustLevel newTrustmodify) {
		trustLevel oldTrustmodify = trustmodify;
		trustmodify = newTrustmodify == null ? TRUSTMODIFY_EDEFAULT : newTrustmodify;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTMODIFY, oldTrustmodify, trustmodify));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_TO:
				if (resolve) return getTrustPermDeleTo();
				return basicGetTrustPermDeleTo();
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_FROM:
				if (resolve) return getTrustPermDeleFrom();
				return basicGetTrustPermDeleFrom();
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_OF:
				if (resolve) return getTrustPermDeleOf();
				return basicGetTrustPermDeleOf();
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTPRODUE:
				return getTrustprodue();
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTREAD:
				return getTrustread();
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTSEND:
				return getTrustsend();
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTMODIFY:
				return getTrustmodify();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_TO:
				setTrustPermDeleTo((actor)newValue);
				return;
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_FROM:
				setTrustPermDeleFrom((actor)newValue);
				return;
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_OF:
				setTrustPermDeleOf((information)newValue);
				return;
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTPRODUE:
				setTrustprodue((trustLevel)newValue);
				return;
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTREAD:
				setTrustread((trustLevel)newValue);
				return;
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTSEND:
				setTrustsend((trustLevel)newValue);
				return;
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTMODIFY:
				setTrustmodify((trustLevel)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_TO:
				setTrustPermDeleTo((actor)null);
				return;
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_FROM:
				setTrustPermDeleFrom((actor)null);
				return;
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_OF:
				setTrustPermDeleOf((information)null);
				return;
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTPRODUE:
				setTrustprodue(TRUSTPRODUE_EDEFAULT);
				return;
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTREAD:
				setTrustread(TRUSTREAD_EDEFAULT);
				return;
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTSEND:
				setTrustsend(TRUSTSEND_EDEFAULT);
				return;
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTMODIFY:
				setTrustmodify(TRUSTMODIFY_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_TO:
				return trustPermDeleTo != null;
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_FROM:
				return trustPermDeleFrom != null;
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUST_PERM_DELE_OF:
				return trustPermDeleOf != null;
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTPRODUE:
				return trustprodue != TRUSTPRODUE_EDEFAULT;
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTREAD:
				return trustread != TRUSTREAD_EDEFAULT;
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTSEND:
				return trustsend != TRUSTSEND_EDEFAULT;
			case IqtoolPackage.TRUST_PERM_DELEGATION__TRUSTMODIFY:
				return trustmodify != TRUSTMODIFY_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (trustprodue: ");
		result.append(trustprodue);
		result.append(", trustread: ");
		result.append(trustread);
		result.append(", trustsend: ");
		result.append(trustsend);
		result.append(", trustmodify: ");
		result.append(trustmodify);
		result.append(')');
		return result.toString();
	}

} //trustPermDelegationImpl
