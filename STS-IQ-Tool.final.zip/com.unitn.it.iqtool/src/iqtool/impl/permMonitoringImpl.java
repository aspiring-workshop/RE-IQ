/**
 */
package iqtool.impl;

import iqtool.IqtoolPackage;
import iqtool.information;
import iqtool.permMonitoring;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>perm Monitoring</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link iqtool.impl.permMonitoringImpl#getMonitorOf <em>Monitor Of</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class permMonitoringImpl extends MinimalEObjectImpl.Container implements permMonitoring {
	/**
	 * The cached value of the '{@link #getMonitorOf() <em>Monitor Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMonitorOf()
	 * @generated
	 * @ordered
	 */
	protected information monitorOf;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected permMonitoringImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return IqtoolPackage.Literals.PERM_MONITORING;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information getMonitorOf() {
		if (monitorOf != null && monitorOf.eIsProxy()) {
			InternalEObject oldMonitorOf = (InternalEObject)monitorOf;
			monitorOf = (information)eResolveProxy(oldMonitorOf);
			if (monitorOf != oldMonitorOf) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, IqtoolPackage.PERM_MONITORING__MONITOR_OF, oldMonitorOf, monitorOf));
			}
		}
		return monitorOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public information basicGetMonitorOf() {
		return monitorOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMonitorOf(information newMonitorOf) {
		information oldMonitorOf = monitorOf;
		monitorOf = newMonitorOf;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, IqtoolPackage.PERM_MONITORING__MONITOR_OF, oldMonitorOf, monitorOf));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case IqtoolPackage.PERM_MONITORING__MONITOR_OF:
				if (resolve) return getMonitorOf();
				return basicGetMonitorOf();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case IqtoolPackage.PERM_MONITORING__MONITOR_OF:
				setMonitorOf((information)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case IqtoolPackage.PERM_MONITORING__MONITOR_OF:
				setMonitorOf((information)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case IqtoolPackage.PERM_MONITORING__MONITOR_OF:
				return monitorOf != null;
		}
		return super.eIsSet(featureID);
	}

} //permMonitoringImpl
