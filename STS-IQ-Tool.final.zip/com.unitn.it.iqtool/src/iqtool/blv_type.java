/**
 */
package iqtool;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>blv type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see iqtool.IqtoolPackage#getblv_type()
 * @model
 * @generated
 */
public final class blv_type extends AbstractEnumerator {
	/**
	 * The '<em><b>Chk blv</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Chk blv</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CHK_BLV_LITERAL
	 * @model name="chk_blv"
	 * @generated
	 * @ordered
	 */
	public static final int CHK_BLV = 0;

	/**
	 * The '<em><b>No chk blv</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>No chk blv</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #NO_CHK_BLV_LITERAL
	 * @model name="no_chk_blv"
	 * @generated
	 * @ordered
	 */
	public static final int NO_CHK_BLV = 1;

	/**
	 * The '<em><b>Chk blv</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CHK_BLV
	 * @generated
	 * @ordered
	 */
	public static final blv_type CHK_BLV_LITERAL = new blv_type(CHK_BLV, "chk_blv", "chk_blv");

	/**
	 * The '<em><b>No chk blv</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NO_CHK_BLV
	 * @generated
	 * @ordered
	 */
	public static final blv_type NO_CHK_BLV_LITERAL = new blv_type(NO_CHK_BLV, "no_chk_blv", "no_chk_blv");

	/**
	 * An array of all the '<em><b>blv type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final blv_type[] VALUES_ARRAY =
		new blv_type[] {
			CHK_BLV_LITERAL,
			NO_CHK_BLV_LITERAL,
		};

	/**
	 * A public read-only list of all the '<em><b>blv type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>blv type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static blv_type get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			blv_type result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>blv type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static blv_type getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			blv_type result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>blv type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static blv_type get(int value) {
		switch (value) {
			case CHK_BLV: return CHK_BLV_LITERAL;
			case NO_CHK_BLV: return NO_CHK_BLV_LITERAL;
		}
		return null;
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private blv_type(int value, String name, String literal) {
		super(value, name, literal);
	}

} //blv_type
