/**
 */
package iqtool;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>produce Trust</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link iqtool.produceTrust#getTrustlevel <em>Trustlevel</em>}</li>
 *   <li>{@link iqtool.produceTrust#getProduceTrustor <em>Produce Trustor</em>}</li>
 *   <li>{@link iqtool.produceTrust#getProduceTrustee <em>Produce Trustee</em>}</li>
 *   <li>{@link iqtool.produceTrust#getProduceTrustOf <em>Produce Trust Of</em>}</li>
 * </ul>
 * </p>
 *
 * @see iqtool.IqtoolPackage#getproduceTrust()
 * @model
 * @generated
 */
public interface produceTrust extends EObject {
	/**
	 * Returns the value of the '<em><b>Trustlevel</b></em>' attribute.
	 * The literals are from the enumeration {@link iqtool.trustLevel}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trustlevel</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trustlevel</em>' attribute.
	 * @see iqtool.trustLevel
	 * @see #setTrustlevel(trustLevel)
	 * @see iqtool.IqtoolPackage#getproduceTrust_Trustlevel()
	 * @model
	 * @generated
	 */
	trustLevel getTrustlevel();

	/**
	 * Sets the value of the '{@link iqtool.produceTrust#getTrustlevel <em>Trustlevel</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trustlevel</em>' attribute.
	 * @see iqtool.trustLevel
	 * @see #getTrustlevel()
	 * @generated
	 */
	void setTrustlevel(trustLevel value);

	/**
	 * Returns the value of the '<em><b>Produce Trustor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Produce Trustor</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Produce Trustor</em>' reference.
	 * @see #setProduceTrustor(actor)
	 * @see iqtool.IqtoolPackage#getproduceTrust_ProduceTrustor()
	 * @model
	 * @generated
	 */
	actor getProduceTrustor();

	/**
	 * Sets the value of the '{@link iqtool.produceTrust#getProduceTrustor <em>Produce Trustor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Produce Trustor</em>' reference.
	 * @see #getProduceTrustor()
	 * @generated
	 */
	void setProduceTrustor(actor value);

	/**
	 * Returns the value of the '<em><b>Produce Trustee</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Produce Trustee</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Produce Trustee</em>' reference.
	 * @see #setProduceTrustee(actor)
	 * @see iqtool.IqtoolPackage#getproduceTrust_ProduceTrustee()
	 * @model
	 * @generated
	 */
	actor getProduceTrustee();

	/**
	 * Sets the value of the '{@link iqtool.produceTrust#getProduceTrustee <em>Produce Trustee</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Produce Trustee</em>' reference.
	 * @see #getProduceTrustee()
	 * @generated
	 */
	void setProduceTrustee(actor value);

	/**
	 * Returns the value of the '<em><b>Produce Trust Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Produce Trust Of</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Produce Trust Of</em>' reference.
	 * @see #setProduceTrustOf(information)
	 * @see iqtool.IqtoolPackage#getproduceTrust_ProduceTrustOf()
	 * @model
	 * @generated
	 */
	information getProduceTrustOf();

	/**
	 * Sets the value of the '{@link iqtool.produceTrust#getProduceTrustOf <em>Produce Trust Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Produce Trust Of</em>' reference.
	 * @see #getProduceTrustOf()
	 * @generated
	 */
	void setProduceTrustOf(information value);

} // produceTrust
