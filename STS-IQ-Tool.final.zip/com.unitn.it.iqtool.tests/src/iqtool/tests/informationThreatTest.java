/**
 */
package iqtool.tests;

import iqtool.IqtoolFactory;
import iqtool.informationThreat;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>information Threat</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class informationThreatTest extends threatTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(informationThreatTest.class);
	}

	/**
	 * Constructs a new information Threat test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public informationThreatTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this information Threat test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private informationThreat getFixture() {
		return (informationThreat)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	protected void setUp() throws Exception {
		setFixture(IqtoolFactory.eINSTANCE.createinformationThreat());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //informationThreatTest
