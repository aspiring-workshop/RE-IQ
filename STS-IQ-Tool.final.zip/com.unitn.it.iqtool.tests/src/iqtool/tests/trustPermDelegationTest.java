/**
 */
package iqtool.tests;

import iqtool.IqtoolFactory;
import iqtool.trustPermDelegation;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>trust Perm Delegation</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class trustPermDelegationTest extends TestCase {

	/**
	 * The fixture for this trust Perm Delegation test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected trustPermDelegation fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(trustPermDelegationTest.class);
	}

	/**
	 * Constructs a new trust Perm Delegation test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public trustPermDelegationTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this trust Perm Delegation test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(trustPermDelegation fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this trust Perm Delegation test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private trustPermDelegation getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	protected void setUp() throws Exception {
		setFixture(IqtoolFactory.eINSTANCE.createtrustPermDelegation());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //trustPermDelegationTest
