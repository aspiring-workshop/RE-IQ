/**
 */
package iqtool.tests;

import iqtool.IqtoolFactory;
import iqtool.delegationTrust;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>delegation Trust</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class delegationTrustTest extends TestCase {

	/**
	 * The fixture for this delegation Trust test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected delegationTrust fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(delegationTrustTest.class);
	}

	/**
	 * Constructs a new delegation Trust test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public delegationTrustTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this delegation Trust test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(delegationTrust fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this delegation Trust test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private delegationTrust getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	protected void setUp() throws Exception {
		setFixture(IqtoolFactory.eINSTANCE.createdelegationTrust());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //delegationTrustTest
